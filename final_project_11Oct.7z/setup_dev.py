import os
import sys

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app, db
from recruitflow.models import Role, User, PositionTitle, Vertical
from werkzeug.security import generate_password_hash

# Default admin credentials
DEFAULT_ADMIN_USERNAME = 'admin'
DEFAULT_ADMIN_PASSWORD = 'Admin@123'

def setup_database():
    """Initialize the database, create roles, and the first admin user."""
    with app.app_context():
        # Check if database exists
        db_file = app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
        if os.path.exists(db_file):
            print(f"⚠️  Database file '{db_file}' already exists.")
            recreate = input("Do you want to delete it and start fresh? (y/n): ").lower()
            if recreate == 'y':
                os.remove(db_file)
                print("✅ Existing database deleted.")
            else:
                print("❌ Setup cancelled. Using existing database.")
                return

        print("\n📦 Creating all database tables...")
        db.create_all()
        print("✅ Tables created successfully.\n")

        # Create roles
        print("👥 Creating user roles...")
        roles = ['CEO', 'Admin', 'Vertical_Head', 'Hiring_Manager', 'Recruiter', 'IP', 'Employee']
        for name in roles:
            if not Role.query.filter_by(name=name).first():
                role = Role(name=name)
                db.session.add(role)
        db.session.commit()
        print("✅ Roles created: CEO, Admin, Vertical Head, HM, Recruiter, IP, Employee\n")

        # Create sample verticals
        print("🏢 Creating sample verticals...")
        sample_verticals = [
            {'name': 'PMV1', 'description': 'Project management vertical 1'},
            {'name': 'PMV2', 'description': 'Project management vertical 2'},
            {'name': 'CC', 'description': 'Finance, HR and Accounts'},
            {'name': 'SA', 'description': 'Systems audit vertical'},
            {'name': 'CS', 'description': 'Cyber security vertical'},
        ]
        for v_data in sample_verticals:
            if not Vertical.query.filter_by(name=v_data['name']).first():
                vertical = Vertical(name=v_data['name'], description=v_data['description'])
                db.session.add(vertical)
        db.session.commit()
        print("✅ Verticals created\n")

        # Create default users
        print("👤 Creating default users...")

        # CEO
        ceo_role = Role.query.filter_by(name='CEO').first()
        if not User.query.filter_by(username='ceo').first() and ceo_role:
            ceo_user = User(
                username='ceo',
                password_hash=generate_password_hash('CEO@123'),
                role_id=ceo_role.id,
                full_name='Chief Executive Officer',
                email='ceo@rebit.org.in',
                is_active=True
            )
            db.session.add(ceo_user)

        # Admin
        admin_role = Role.query.filter_by(name='Admin').first()
        if not User.query.filter_by(username='admin').first() and admin_role:
            admin_user = User(
                username='admin',
                password_hash=generate_password_hash('Admin@123'),
                role_id=admin_role.id,
                full_name='System Administrator',
                email='admin@rebit.org.in',
                is_active=True
            )
            db.session.add(admin_user)

        db.session.commit()

        print("\n" + "=" * 60)
        print("✅ SETUP COMPLETE!")
        print("=" * 60)
        print("🔐 Default Credentials:")
        print("   CEO: ceo / CEO@123")
        print("   Admin: admin / Admin@123")
        print("=" * 60)

if __name__ == '__main__':
    setup_database()