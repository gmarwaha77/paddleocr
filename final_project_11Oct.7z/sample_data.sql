-- recruitflow_project/sample_data.sql
INSERT INTO roles (name) VALUES ('Hiring_Manager'), ('Recruiter'), ('IP'), ('Admin');

INSERT INTO users (username, password_hash, role_id) VALUES 
('admin', 'sha256$hashforadmin', 4),  -- SA, replace with real hash
('hm1', 'sha256$hashforhm1', 1),
('recruiter1', 'sha256$hashforrecruiter1', 2),
('ip1', 'sha256$hashforip1', 3);

INSERT INTO position_titles (title) VALUES ('Software Engineer'), ('Data Analyst'), ('Project Manager'); 
