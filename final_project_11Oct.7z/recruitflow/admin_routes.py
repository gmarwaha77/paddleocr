# recruitflow_project/admin_routes.py (NEW)
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from .models import db, User, Role, AuditLog
from recruitflow.utils import role_required, log_action
from werkzeug.security import generate_password_hash

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# --- User Management ---

@admin_bp.route('/users')
@login_required
@role_required('Admin')
def user_list():
    """Display a list of all users."""
    users = User.query.order_by(User.username).all()
    return render_template('admin/user_list.html', users=users)

@admin_bp.route('/users/new', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def create_user():
    """Create a new user."""
    if request.method == 'POST':
        username = request.form.get('username')
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        role_id = request.form.get('role_id')
        is_active = 'is_active' in request.form

        # Validation
        if User.query.filter_by(username=username).first():
            flash(f'Username "{username}" already exists.', 'danger')
            return redirect(request.url)
        if User.query.filter_by(email=email).first():
            flash(f'Email "{email}" is already in use.', 'danger')
            return redirect(request.url)

        new_user = User(
            username=username,
            full_name=full_name,
            email=email,
            role_id=int(role_id),
            is_active=is_active
        )
        new_user.set_password(password)

        db.session.add(new_user)
        db.session.commit()

        log_action(f'New user "{username}" created.', entity_type='User', entity_id=new_user.id)
        flash(f'User "{username}" has been created successfully.', 'success')
        return redirect(url_for('admin.user_list'))

    roles = Role.query.all()
    return render_template('admin/user_form.html', roles=roles, form_title='Create New User', user=None)


@admin_bp.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def edit_user(user_id):
    """Edit an existing user's details."""
    user = User.query.get_or_404(user_id)
    if request.method == 'POST':
        # Get data from form
        user.full_name = request.form.get('full_name')
        user.email = request.form.get('email')
        user.role_id = int(request.form.get('role_id'))
        user.is_active = 'is_active' in request.form
        password = request.form.get('password')

        # Check for email uniqueness if changed
        if User.query.filter(User.email == user.email, User.id != user_id).first():
            flash(f'Email "{user.email}" is already in use by another user.', 'danger')
            return redirect(request.url)

        if password:
            user.set_password(password)
            flash('User password has been updated.', 'info')

        db.session.commit()
        log_action(f'User "{user.username}" (ID: {user_id}) updated.', entity_type='User', entity_id=user_id)
        flash(f'User "{user.username}" has been updated successfully.', 'success')
        return redirect(url_for('admin.user_list'))

    roles = Role.query.all()
    return render_template('admin/user_form.html', roles=roles, user=user, form_title=f'Edit User: {user.username}')

@admin_bp.route('/verticals')
@login_required
@role_required('Admin')
def vertical_list():
    """Display all verticals"""
    verticals = Vertical.query.all()
    return render_template('admin/vertical_list.html', verticals=verticals)


@admin_bp.route('/verticals/create', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def create_vertical():
    """Create new vertical"""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        vertical_head_id = request.form.get('vertical_head_id')

        if Vertical.query.filter_by(name=name).first():
            flash(f'Vertical "{name}" already exists.', 'danger')
            return redirect(request.url)

        vertical = Vertical(
            name=name,
            description=description,
            vertical_head_id=int(vertical_head_id) if vertical_head_id else None,
            is_active=True
        )

        db.session.add(vertical)
        db.session.commit()

        log_action(f'Vertical "{name}" created.', entity_type='Vertical', entity_id=vertical.id)
        flash(f'Vertical "{name}" created successfully.', 'success')
        return redirect(url_for('admin.vertical_list'))

    # Get potential vertical heads
    vh_role = Role.query.filter_by(name='Vertical_Head').first()
    potential_heads = User.query.filter_by(role_id=vh_role.id).all() if vh_role else []

    return render_template('admin/vertical_form.html',
                           vertical=None,
                           potential_heads=potential_heads)


@admin_bp.route('/verticals/edit/<int:vertical_id>', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def edit_vertical(vertical_id):
    """Edit vertical"""
    vertical = Vertical.query.get_or_404(vertical_id)

    if request.method == 'POST':
        vertical.description = request.form.get('description')
        vertical.vertical_head_id = int(request.form.get('vertical_head_id')) if request.form.get(
            'vertical_head_id') else None
        vertical.is_active = 'is_active' in request.form

        db.session.commit()
        log_action(f'Vertical "{vertical.name}" updated.', entity_type='Vertical', entity_id=vertical_id)
        flash(f'Vertical "{vertical.name}" updated.', 'success')
        return redirect(url_for('admin.vertical_list'))

    vh_role = Role.query.filter_by(name='Vertical_Head').first()
    potential_heads = User.query.filter_by(role_id=vh_role.id).all() if vh_role else []

    return render_template('admin/vertical_form.html',
                           vertical=vertical,
                           potential_heads=potential_heads)

# --- Audit Log Viewer ---

@admin_bp.route('/audit-log')
@login_required
@role_required('Admin')
def audit_log():
    """Display the audit log."""
    page = request.args.get('page', 1, type=int)
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=20)
    return render_template('admin/audit_log.html', logs=logs)
