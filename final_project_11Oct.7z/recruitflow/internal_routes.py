# recruitflow/internal_routes.py
"""
Routes for internal employee applications
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime

from .models import db, Position, InternalApplication, PositionTitle
from .utils.helpers import log_action

internal_bp = Blueprint('internal', __name__, url_prefix='/internal')


@internal_bp.route('/positions')
@login_required
def open_positions():
    """View all open positions available for internal applications"""
    # Only show approved positions
    positions = Position.query.filter_by(status='approved').order_by(
        Position.created_at.desc()
    ).all()
    
    # Check which positions user has already applied for
    if hasattr(current_user, 'employee_id'):
        applied_positions = [
            app.position_id for app in InternalApplication.query.filter_by(
                employee_email=current_user.email
            ).all()
        ]
    else:
        applied_positions = []
    
    return render_template(
        'internal/open_positions.html',
        positions=positions,
        applied_positions=applied_positions
    )


@internal_bp.route('/apply/<int:position_id>', methods=['GET', 'POST'])
@login_required
def apply_internal(position_id):
    """Internal employee application form"""
    position = Position.query.get_or_404(position_id)
    
    if position.status != 'approved':
        flash('This position is not currently open for applications', 'warning')
        return redirect(url_for('internal.open_positions'))
    
    # Check if already applied
    existing_app = InternalApplication.query.filter_by(
        position_id=position_id,
        employee_email=current_user.email
    ).first()
    
    if existing_app:
        flash('You have already applied for this position', 'info')
        return redirect(url_for('internal.my_applications'))
    
    if request.method == 'POST':
        employee_id = request.form.get('employee_id', '').strip()
        current_dept = request.form.get('current_department', '').strip()
        current_desig = request.form.get('current_designation', '').strip()
        years_in_company = request.form.get('years_in_company', 0)
        why_suitable = request.form.get('why_suitable', '').strip()
        additional_info = request.form.get('additional_info', '').strip()
        
        if not all([employee_id, why_suitable]):
            flash('Employee ID and suitability statement are required', 'danger')
            return redirect(request.url)
        
        if len(why_suitable) < 50:
            flash('Please provide a more detailed explanation (minimum 50 characters)', 'warning')
            return redirect(request.url)
        
        application = InternalApplication(
            position_id=position_id,
            employee_id=employee_id,
            employee_name=current_user.full_name or current_user.username,
            employee_email=current_user.email,
            current_department=current_dept,
            current_designation=current_desig,
            years_in_company=float(years_in_company) if years_in_company else None,
            why_suitable=why_suitable,
            additional_info=additional_info,
            status='submitted'
        )
        
        db.session.add(application)
        db.session.commit()
        
        log_action(
            f'Internal application submitted by {current_user.username} for position {position.position_title.title}',
            entity_type='InternalApplication',
            entity_id=application.id
        )
        
        flash('Your application has been submitted successfully!', 'success')
        return redirect(url_for('internal.my_applications'))
    
    return render_template(
        'internal/apply_form.html',
        position=position
    )


@internal_bp.route('/my-applications')
@login_required
def my_applications():
    """View user's own internal applications"""
    applications = InternalApplication.query.filter_by(
        employee_email=current_user.email
    ).order_by(InternalApplication.applied_date.desc()).all()
    
    return render_template(
        'internal/my_applications.html',
        applications=applications
    )


@internal_bp.route('/manage-applications')
@login_required
def manage_applications():
    """HM view of internal applications for their positions"""
    from .utils.helpers import role_required
    
    if current_user.role.name not in ['Hiring_Manager', 'Admin']:
        flash('Access denied', 'danger')
        return redirect(url_for('main.dashboard'))
    
    if current_user.role.name == 'Hiring_Manager':
        # Get applications for HM's positions
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        applications = InternalApplication.query.filter(
            InternalApplication.position_id.in_(position_ids)
        ).order_by(InternalApplication.applied_date.desc()).all()
    else:
        # SA sees all
        applications = InternalApplication.query.order_by(
            InternalApplication.applied_date.desc()
        ).all()
    
    return render_template(
        'internal/manage_applications.html',
        applications=applications
    )


@internal_bp.route('/review/<int:app_id>', methods=['POST'])
@login_required
def review_application(app_id):
    """Review internal application"""
    from .utils.helpers import role_required
    
    if current_user.role.name not in ['Hiring_Manager', 'Admin']:
        flash('Access denied', 'danger')
        return redirect(url_for('main.dashboard'))
    
    application = InternalApplication.query.get_or_404(app_id)
    
    # Check if HM owns this position
    if current_user.role.name == 'Hiring_Manager':
        if application.position.hm_id != current_user.id:
            flash('You can only review applications for your positions', 'danger')
            return redirect(url_for('internal.manage_applications'))
    
    action = request.form.get('action')
    comments = request.form.get('comments', '')
    
    if action == 'shortlist':
        application.status = 'shortlisted'
        flash(f'Application from {application.employee_name} shortlisted', 'success')
    elif action == 'interview':
        application.status = 'interview'
        flash(f'Interview scheduled for {application.employee_name}', 'success')
    elif action == 'select':
        application.status = 'selected'
        flash(f'{application.employee_name} selected for the position', 'success')
    elif action == 'reject':
        application.status = 'rejected'
        flash(f'Application from {application.employee_name} rejected', 'info')
    
    application.reviewed_by = current_user.id
    application.review_comments = comments
    
    db.session.commit()
    
    log_action(
        f'Internal application reviewed: {application.employee_name} - Status: {action}',
        entity_type='InternalApplication',
        entity_id=app_id
    )
    
    return redirect(url_for('internal.manage_applications'))