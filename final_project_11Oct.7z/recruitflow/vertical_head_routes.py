# recruitflow/vertical_head_routes.py
"""
Routes for Vertical Head role
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from sqlalchemy import func

from .models import db, Position, Candidate, Vertical, PositionTitle, SalaryProposal
from .utils.helpers import role_required, log_action

vh_bp = Blueprint('vertical_head', __name__, url_prefix='/vertical-head')


@vh_bp.route('/dashboard')
@login_required
@role_required('Vertical_Head')
def dashboard():
    """Vertical Head dashboard with their vertical's pipeline"""

    # Get vertical head's vertical
    vertical = Vertical.query.get(current_user.vertical_id)

    if not vertical:
        flash('No vertical assigned', 'warning')
        return redirect(url_for('main.dashboard'))

    # Get positions in this vertical
    positions = Position.query.filter_by(vertical_id=vertical.id).all()

    # Positions pending approval
    pending_positions = Position.query.filter_by(
        vertical_id=vertical.id,
        status='pending_approval'
    ).all()

    # Active positions
    active_positions = Position.query.filter_by(
        vertical_id=vertical.id,
        status='approved'
    ).count()

    # Total candidates in pipeline
    position_ids = [p.id for p in positions]
    total_candidates = Candidate.query.filter(
        Candidate.position_id.in_(position_ids)
    ).count()

    # Candidates in interview stage
    in_interview = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status == 'interview'
    ).count()

    # Recent hires (last 30 days)
    recent_hires = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status == 'hired',
        Candidate.joining_date >= datetime.now().date() - timedelta(days=30)
    ).count()

    return render_template(
        'vertical_head/dashboard.html',
        vertical=vertical,
        pending_positions=pending_positions,
        active_positions=active_positions,
        total_candidates=total_candidates,
        in_interview=in_interview,
        recent_hires=recent_hires
    )


@vh_bp.route('/positions')
@login_required
@role_required('Vertical_Head')
def positions():
    """View all positions in vertical"""
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id
    ).order_by(Position.created_at.desc()).all()

    return render_template('vertical_head/positions.html', positions=positions)


@vh_bp.route('/pipeline')
@login_required
@role_required('Vertical_Head')
def pipeline():
    """Recruitment pipeline for vertical"""
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id,
        status='approved'
    ).all()

    position_ids = [p.id for p in positions]

    # Candidates by status
    pipeline_data = db.session.query(
        Candidate.status,
        func.count(Candidate.id)
    ).filter(
        Candidate.position_id.in_(position_ids)
    ).group_by(Candidate.status).all()

    return render_template(
        'vertical_head/pipeline.html',
        positions=positions,
        pipeline_data=pipeline_data
    )


@vh_bp.route('/salary-proposals')
@login_required
@role_required('Vertical_Head')
def salary_proposals():
    """View salary proposals for vertical (read-only)"""

    # Get all positions in vertical
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id
    ).all()

    position_ids = [p.id for p in positions]

    # Get candidates from these positions
    candidate_ids = [c.id for c in Candidate.query.filter(
        Candidate.position_id.in_(position_ids)
    ).all()]

    # Get salary proposals
    proposals = SalaryProposal.query.filter(
        SalaryProposal.candidate_id.in_(candidate_ids)
    ).order_by(SalaryProposal.created_at.desc()).all()

    return render_template(
        'vertical_head/salary_proposals.html',
        proposals=proposals
    )