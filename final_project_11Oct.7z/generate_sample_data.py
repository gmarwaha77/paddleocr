#!/usr/bin/env python
"""
generate_sample_data.py - Generate sample test data for RecruitFlow
Run after setup_dev.py to populate system with test data
Usage: python generate_sample_data.py
"""
import os
import sys
from datetime import datetime, timedelta
import random

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app, db
from recruitflow.models import (
    Role, User, PositionTitle, Position, Candidate,
    Interview, InterviewFeedback, SalaryProposal, Vertical
)
from werkzeug.security import generate_password_hash


def generate_sample_data():
    """Generate comprehensive sample data"""
    with app.app_context():
        print("\n" + "="*60)
        print("  🎲 Generating Sample Test Data")
        print("="*60 + "\n")

        # Get roles
        vh_role = Role.query.filter_by(name='Vertical_Head').first()
        hm_role = Role.query.filter_by(name='Hiring_Manager').first()
        recruiter_role = Role.query.filter_by(name='Recruiter').first()
        ip_role = Role.query.filter_by(name='IP').first()

        # Get verticals
        tech_vertical = Vertical.query.filter_by(name='PMV1').first()
        ops_vertical = Vertical.query.filter_by(name='PMV2').first()
        
        if not all([vh_role, hm_role, recruiter_role, ip_role]):
            print("❌ Error: Roles not found. Run setup_dev.py first!")
            return
        
        # 1. Create Sample Users
        print("👥 Creating sample users...")

        sample_users = [
            {
                'username': 'gaurav_vh',
                'password': 'Password123',
                'full_name': 'Gaurav Marwaha',
                'email': 'gaurav.marwaha@rebit.org.in',
                'role_id': None  # Will be Vertical Head
            },
            {
                'username': 'jegan_vh',
                'password': 'Password123',
                'full_name': 'Jegan Vijayrajan',
                'email': 'jegan.vijayrajan@rebit.org.in',
                'role_id': None  # Vertical Head
            },
            {
                'username': 'amit_hm',
                'password': 'Password123',
                'full_name': 'Amit Solanki',
                'email': 'amit.solanki@rebit.org.in',
                'role_id': None  # HM
            },
            {
                'username': 'kamlesh_hm',
                'password': 'Password123',
                'full_name': 'Kamlesh Ahire',
                'email': 'kamlesh.ahire@rebit.org.in',
                'role_id': None  # HM
            },
            {
                'username': 'deepika_recruiter',
                'password': 'Password123',
                'full_name': 'Deepika Maheshwari',
                'email': 'deepika.maheshwari@rebit.org.in',
                'role_id': None  # Recruiter
            },
            {
                'username': 'kulvinder_recruiter',
                'password': 'Password123',
                'full_name': 'Kulvinder Singh',
                'email': 'kulvinder.singh@rebit.org.in',
                'role_id': None  # Recruiter
            },
            {
                'username': 'paresh_ip',
                'password': 'Password123',
                'full_name': 'Paresh Patil',
                'email': 'paresh.patil@rebit.org.in',
                'role_id': None  # IP
            },
            {
                'username': 'shukti_ip',
                'password': 'Password123',
                'full_name': 'Shukti Sarwade',
                'email': 'shukti.sarwade@rebit.org.in',
                'role_id': None  # IP
            },
            {
                'username': 'anuja_ip',
                'password': 'Password123',
                'full_name': 'Anuja Patil',
                'email': 'anuja.patil@rebit.org.in',
                'role_id': None  # IP
            },
            {
                'username': 'nitin_ip',
                'password': 'Password123',
                'full_name': 'Nitin Patil',
                'email': 'nitin.patil@rebit.org.in',
                'role_id': None  # IP
            },
            {
                'username': 'kapil_ip',
                'password': 'Password123',
                'full_name': 'Kapil Gautam',
                'email': 'kapil.gautam@rebit.org.in',
                'role_id': None  # IP
            }
        ]
        
        employee_role = Role.query.filter_by(name='Employee').first()

        users_created = 0
        for idx, user_data in enumerate(sample_users):
            if not User.query.filter_by(username=user_data['username']).first():
                # Assign role
                if 'vh' in user_data['username']:
                    role_id = vh_role.id
                    vertical_id = tech_vertical.id if idx == 0 else ops_vertical.id
                elif 'hm' in user_data['username']:
                    role_id = hm_role.id
                    vertical_id = tech_vertical.id if idx == 2 else ops_vertical.id
                elif 'recruiter' in user_data['username']:
                    role_id = recruiter_role.id
                    vertical_id = None
                else:  # IP
                    role_id = ip_role.id
                    vertical_id = None

                user = User(
                    username=user_data['username'],
                    password_hash=generate_password_hash(user_data['password']),
                    full_name=user_data['full_name'],
                    email=user_data['email'],
                    role_id=role_id,
                    vertical_id=vertical_id,
                    is_active=True
                )
                db.session.add(user)
                users_created += 1

        db.session.commit()
        print(f"   ✅ Created {users_created} users")
        
        # 2. Create Additional Position Titles
        print("\n📋 Creating additional position titles...")
        
        additional_titles = [
            'Senior Software Engineer',
            'Backend Developer',
            'Frontend Developer',
            'DevOps Engineer',
            'Quality Assurance Engineer',
            'Business Analyst',
            'Product Manager',
            'Scrum Master',
            'Technical Writer',
            'System Administrator'
        ]
        
        titles_created = 0
        for title in additional_titles:
            if not PositionTitle.query.filter_by(title=title).first():
                pos_title = PositionTitle(title=title)
                db.session.add(pos_title)
                titles_created += 1
        
        db.session.commit()
        print(f"   ✅ Created {titles_created} position titles")
        
        # 3. Create Sample Positions
        print("\n💼 Creating sample positions...")
        
        hm_users = User.query.filter_by(role_id=hm_role.id).all()
        position_titles = PositionTitle.query.all()
        
        sample_positions = [
            {
                'title': 'Software Engineer',
                'project': 'E-Commerce Platform',
                'openings': 3,
                'status': 'approved'
            },
            {
                'title': 'Data Analyst',
                'project': 'Business Intelligence',
                'openings': 2,
                'status': 'approved'
            },
            {
                'title': 'Senior Software Engineer',
                'project': 'Mobile App Development',
                'openings': 1,
                'status': 'pending_approval'
            },
            {
                'title': 'DevOps Engineer',
                'project': 'Cloud Infrastructure',
                'openings': 2,
                'status': 'approved'
            },
            {
                'title': 'UI/UX Designer',
                'project': 'Product Design Team',
                'openings': 1,
                'status': 'draft'
            }
        ]
        
        positions_created = 0
        for pos_data in sample_positions:
            title_obj = PositionTitle.query.filter_by(title=pos_data['title']).first()
            if title_obj and hm_users:
                hm = random.choice(hm_users)
                position = Position(
                    title_id=title_obj.id,
                    project_name=pos_data['project'],
                    openings=pos_data['openings'],
                    jd_file_path='sample_jd.docx',  # Placeholder
                    status=pos_data['status'],
                    hm_id=hm.id,
                    created_at=datetime.utcnow() - timedelta(days=random.randint(1, 30))
                )
                db.session.add(position)
                positions_created += 1
        
        db.session.commit()
        print(f"   ✅ Created {positions_created} positions")
        
        # 4. Create Sample Candidates
        print("\n👨‍💼 Creating sample candidates...")
        
        approved_positions = Position.query.filter_by(status='approved').all()

        sample_candidates = [
            {
                'name': 'Rahul Gupta',
                'email': 'rahul.gupta@email.com',
                'phone': '+91-9876543210',
                'location': 'Bangalore',
                'experience': 5.0,
                'key_skills': 'Python, Django, Flask, PostgreSQL, Docker',
                'education': 'B.Tech Computer Science - IIT Delhi',
                'similarity_score': 85.5,
                'status': 'applied',
                'current_ctc': 1200000,
                'expected_ctc': 1500000
            },
            {
                'name': 'Priya Menon',
                'email': 'priya.menon@email.com',
                'phone': '+91-9876543211',
                'location': 'Mumbai',
                'experience': 3.5,
                'key_skills': 'React, JavaScript, TypeScript, Node.js, MongoDB',
                'education': 'B.E. Information Technology - BITS Pilani',
                'similarity_score': 78.2,
                'status': 'under_hm_review',
                'current_ctc': 800000,
                'expected_ctc': 1100000
            },
            {
                'name': 'Aditya Shah',
                'email': 'aditya.shah@email.com',
                'phone': '+91-9876543212',
                'location': 'Pune',
                'experience': 7.0,
                'key_skills': 'Java, Spring Boot, Microservices, AWS, Kubernetes',
                'education': 'M.Tech Computer Science - IIT Bombay',
                'similarity_score': 92.1,
                'status': 'interview',
                'current_ctc': 1800000,
                'expected_ctc': 2200000
            },
            {
                'name': 'Divya Krishnan',
                'email': 'divya.krishnan@email.com',
                'phone': '+91-9876543213',
                'location': 'Hyderabad',
                'experience': 4.5,
                'key_skills': 'Data Analysis, Python, SQL, Tableau, Power BI',
                'education': 'B.Sc Statistics - Delhi University',
                'similarity_score': 81.7,
                'status': 'test_passed',
                'current_ctc': 900000,
                'expected_ctc': 1200000
            },
            {
                'name': 'Rohan Joshi',
                'email': 'rohan.joshi@email.com',
                'phone': '+91-9876543214',
                'location': 'Chennai',
                'experience': 6.0,
                'key_skills': 'DevOps, Jenkins, Docker, Kubernetes, Terraform, AWS',
                'education': 'B.Tech Electronics - NIT Trichy',
                'similarity_score': 88.3,
                'status': 'offer_accepted',
                'current_ctc': 1500000,
                'expected_ctc': 1900000,
                'joining_date': datetime.now().date() + timedelta(days=30)
            }
        ]
        
        candidates_created = 0
        for cand_data in sample_candidates:
            if approved_positions:
                position = random.choice(approved_positions)
                candidate = Candidate(
                    position_id=position.id,
                    cv_file_path='sample_cv.pdf',  # Placeholder
                    name=cand_data['name'],
                    email=cand_data['email'],
                    phone=cand_data['phone'],
                    location=cand_data['location'],
                    experience=cand_data['experience'],
                    key_skills=cand_data['key_skills'],
                    education=cand_data['education'],
                    similarity_score=cand_data['similarity_score'],
                    status=cand_data['status'],
                    current_ctc=cand_data.get('current_ctc'),
                    expected_ctc=cand_data.get('expected_ctc'),
                    joining_date=cand_data.get('joining_date'),
                    created_at=datetime.utcnow() - timedelta(days=random.randint(1, 20))
                )
                db.session.add(candidate)
                candidates_created += 1
        
        db.session.commit()
        print(f"   ✅ Created {candidates_created} candidates")
        
        # 5. Create Sample Interviews
        print("\n📅 Creating sample interviews...")
        
        interview_candidates = Candidate.query.filter_by(status='interview').all()
        ip_users = User.query.filter_by(role_id=ip_role.id).all()
        
        interviews_created = 0
        for candidate in interview_candidates:
            interview = Interview(
                candidate_id=candidate.id,
                schedule_date=datetime.now().date() + timedelta(days=random.randint(1, 7)),
                schedule_time='10:00 AM',
                interview_mode='Video',
                meeting_link='https://meet.google.com/sample-link',
                status='scheduled'
            )
            db.session.add(interview)
            interviews_created += 1
        
        db.session.commit()
        print(f"   ✅ Created {interviews_created} interviews")
        
        # 6. Create Sample Salary Proposals
        print("\n💰 Creating sample salary proposals...")
        
        offer_candidates = Candidate.query.filter(
            Candidate.status.in_(['interview', 'offer_accepted'])
        ).all()
        recruiter_users = User.query.filter_by(role_id=recruiter_role.id).all()
        
        proposals_created = 0
        for candidate in offer_candidates[:3]:  # Just first 3
            if recruiter_users:
                recruiter = random.choice(recruiter_users)
                annual_ctc = candidate.expected_ctc or 1200000
                
                # Calculate breakup
                basic = annual_ctc * 0.40
                hra = basic * 0.50
                special = annual_ctc * 0.20
                bonus = annual_ctc * 0.10
                pf_employer = min(basic * 0.12, 1800 * 12)
                gratuity = basic * 0.0481
                monthly_gross = (basic + hra + special) / 12
                monthly_net = monthly_gross - (pf_employer / 12) - (2400 / 12)
                
                proposal = SalaryProposal(
                    candidate_id=candidate.id,
                    proposed_by=recruiter.id,
                    annual_ctc=annual_ctc,
                    basic_salary=basic,
                    hra=hra,
                    special_allowance=special,
                    performance_bonus=bonus,
                    pf_employer=pf_employer,
                    gratuity=gratuity,
                    pf_employee=pf_employer,
                    professional_tax=2400,
                    medical_insurance=5000,
                    monthly_gross=monthly_gross,
                    monthly_net=monthly_net,
                    status='pending' if candidate.status == 'interview' else 'accepted',
                    version=1,
                    is_final=candidate.status == 'offer_accepted'
                )
                db.session.add(proposal)
                proposals_created += 1
        
        db.session.commit()
        print(f"   ✅ Created {proposals_created} salary proposals")
        
        # Summary
        print("\n" + "="*60)
        print("  ✅ Sample Data Generation Complete!")
        print("="*60)
        print("\n📊 Summary:")
        print(f"   • Users: {users_created}")
        print(f"   • Position Titles: {titles_created}")
        print(f"   • Positions: {positions_created}")
        print(f"   • Candidates: {candidates_created}")
        print(f"   • Interviews: {interviews_created}")
        print(f"   • Salary Proposals: {proposals_created}")
        
        print("\n📝 Test User Credentials:")
        print("   • john_hm / Password123 (Hiring Manager)")
        print("   • mike_recruiter / Password123 (Recruiter)")
        print("   • david_ip / Password123 (Interview Panel)")
        print("   • admin / Admin@123 (Senior Approver)")
        
        print("\n🎯 Next Steps:")
        print("   1. Run: python run.py")
        print("   2. Login with any test user")
        print("   3. Explore the populated system")
        print("="*60 + "\n")


if __name__ == '__main__':
    generate_sample_data()