import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MenubarModule } from 'primeng/menubar';
import { MenuItem } from 'primeng/api';
import { AuthService } from './services/auth.service';

@Component({
    selector: 'app-root',
    standalone: true,
    imports: [CommonModule, RouterModule, MenubarModule],
    template: `
        <div class="app-container">
            <p-menubar *ngIf="isAuthenticated" [model]="menuItems">
                <ng-template pTemplate="end">
                    <div class="flex align-items-center gap-2">
                        <i class="pi pi-user"></i>
                        <span class="font-semibold">{{ username }}</span>
                        <button pButton label="Logout" icon="pi pi-sign-out"
                                class="p-button-sm p-button-text" (click)="logout()"></button>
                    </div>
                </ng-template>
            </p-menubar>

            <router-outlet></router-outlet>
        </div>
    `,
    styles: [`
      .app-container {
        min-height: 100vh;
        background-color: #f8f9fa;
      }
    `]
})
export class AppComponent implements OnInit {
    menuItems: MenuItem[] = [];
    isAuthenticated = false;
    username = '';

    constructor(
        private authService: AuthService,
        private router: Router
    ) {}

    ngOnInit() {
        this.authService.getCurrentUser().subscribe(user => {
            this.isAuthenticated = !!user;
            if (user) {
                this.username = user.username;
                this.buildMenu(user.roles);
            } else {
                this.menuItems = [];
            }
        });
    }

    buildMenu(roles: string[]) {
        this.menuItems = [];

        // Dashboard Menu - Role-specific
        if (roles.some(r => r.includes('MAKER'))) {
            this.menuItems.push({
                label: 'Dashboard',
                icon: 'pi pi-home',
                routerLink: '/dashboard/maker'
            });
        } else if (roles.some(r => r.includes('CHECKER'))) {
            this.menuItems.push({
                label: 'Dashboard',
                icon: 'pi pi-home',
                routerLink: '/dashboard/checker'
            });
        } else if (roles.some(r => r.includes('VENDOR'))) {
            this.menuItems.push({
                label: 'Dashboard',
                icon: 'pi pi-home',
                routerLink: '/dashboard/vendor'
            });
        }

        // Master Menu
        if (roles.some(r => r.includes('MASTER'))) {
            this.menuItems.push({
                label: 'Master Data',
                icon: 'pi pi-database',
                items: [
                    { label: 'Departments', icon: 'pi pi-building', routerLink: '/admin/departments' },
                    { label: 'Product Catalog', icon: 'pi pi-list', routerLink: '/admin/products' },
                    { label: 'Vendors', icon: 'pi pi-users', routerLink: '/admin/vendors' }
                ]
            });
        }

        // Cases Menu
        if (roles.some(r => r.includes('MAKER') || r.includes('CHECKER'))) {
            this.menuItems.push({
                label: 'Cases',
                icon: 'pi pi-briefcase',
                items: [
                    { label: 'All Cases', icon: 'pi pi-list', routerLink: '/cases/list' },
                    ...(roles.some(r => r.includes('MAKER')) ?
                        [{ label: 'Create Case', icon: 'pi pi-plus', routerLink: '/cases/create' }] :
                        [])
                ]
            });
        }

        // Invoice Scrutiny - Checker only
        if (roles.some(r => r.includes('CHECKER'))) {
            this.menuItems.push({
                label: 'Invoice Scrutiny',
                icon: 'pi pi-search',
                routerLink: '/cases/scrutiny/1'
            });
        }

        // Vendor Portal
        if (roles.some(r => r.includes('VENDOR'))) {
            this.menuItems.push({
                label: 'Vendor Portal',
                icon: 'pi pi-user',
                items: [
                    { label: 'My Bids', icon: 'pi pi-money-bill', routerLink: '/vendor/bids' },
                    { label: 'Upload Invoice', icon: 'pi pi-upload', routerLink: '/vendor/invoices' }
                ]
            });
        }
    }

    logout() {
        this.authService.logout();
        this.router.navigate(['/login']);
    }
}