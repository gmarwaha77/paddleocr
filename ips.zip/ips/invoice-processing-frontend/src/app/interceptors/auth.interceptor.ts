import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const credentials = localStorage.getItem('credentials');

    if (credentials && !req.headers.has('Authorization')) {
        const authReq = req.clone({
            setHeaders: {
                Authorization: `Basic ${credentials}`
            },
            withCredentials: true
        });
        return next(authReq);
    }

    return next(req);
};