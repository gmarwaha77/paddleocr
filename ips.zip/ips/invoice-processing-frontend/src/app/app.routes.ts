import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
    {
        path: 'login',
        loadComponent: () => import('./components/login/login.component').then(m => m.LoginComponent)
    },
    {
        path: 'dashboard',
        canActivate: [AuthGuard],
        children: [
            {
                path: 'maker',
                data: { roles: ['MAKER'] },
                loadComponent: () => import('./components/dashboards/maker-dashboard.component').then(m => m.MakerDashboardComponent)
            },
            {
                path: 'checker',
                data: { roles: ['CHECKER'] },
                loadComponent: () => import('./components/dashboards/checker-dashboard.component').then(m => m.CheckerDashboardComponent)
            },
            {
                path: 'vendor',
                data: { roles: ['VENDOR'] },
                loadComponent: () => import('./components/dashboards/vendor-dashboard.component').then(m => m.VendorDashboardComponent)
            },
            {
                path: '',
                redirectTo: 'maker',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: 'admin',
        canActivate: [AuthGuard],
        data: { roles: ['MASTER'] },
        loadChildren: () => import('./modules/admin/admin.routes').then(m => m.ADMIN_ROUTES)
    },
    {
        path: 'master',
        canActivate: [AuthGuard],
        data: { roles: ['MASTER'] },
        loadChildren: () => import('./modules/admin/admin.routes').then(m => m.ADMIN_ROUTES)
    },
    {
        path: 'cases',
        canActivate: [AuthGuard],
        data: { roles: ['MAKER', 'CHECKER'] },
        loadChildren: () => import('./modules/case-management/case.routes').then(m => m.CASE_ROUTES)
    },
    {
        path: 'vendor',
        canActivate: [AuthGuard],
        data: { roles: ['VENDOR'] },
        loadChildren: () => import('./modules/vendor-portal/vendor.routes').then(m => m.VENDOR_ROUTES)
    },
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'unauthorized',
        loadComponent: () => import('./components/unauthorized/unauthorized.component').then(m => m.UnauthorizedComponent)
    },
    {
        path: '**',
        redirectTo: '/login'
    }
];