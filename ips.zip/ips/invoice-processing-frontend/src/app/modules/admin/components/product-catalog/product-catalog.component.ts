import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TreeModule } from 'primeng/tree';
import { TreeNode } from 'primeng/api';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { TabViewModule } from 'primeng/tabview';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ProductService } from '../../../../services/product.service';
import { DepartmentService } from '../../../../services/department.service';
import {
    ProductCategory,
    SubCategory,
    Product,
    DimensionTemplate,
    DimensionDataType,
    DimensionUIComponent
} from '../../../../models/product.model';
import { Department } from '../../../../models/department.model';

@Component({
    selector: 'app-product-catalog',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        TreeModule,
        CardModule,
        ButtonModule,
        DialogModule,
        InputTextModule,
        InputNumberModule,
        InputTextareaModule,
        DropdownModule,
        CheckboxModule,
        TabViewModule,
        ToastModule,
        TableModule,
        TagModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-2xl font-bold m-0">Product Catalog Management</h2>
                    <div class="flex gap-2">
                        <button pButton label="Add Category" icon="pi pi-plus"
                                class="p-button-sm" (click)="showCategoryDialog()"></button>
                        <button pButton label="Add Sub-Category" icon="pi pi-plus"
                                class="p-button-sm p-button-secondary" (click)="showSubCategoryDialog()"
                                [disabled]="!selectedCategory"></button>
                        <button pButton label="Add Product" icon="pi pi-plus"
                                class="p-button-sm p-button-success" (click)="showProductDialog()"
                                [disabled]="!selectedSubCategory"></button>
                    </div>
                </div>

                <div class="grid">
                    <!-- Tree View -->
                    <div class="col-12 md:col-4">
                        <p-card header="Product Hierarchy">
                            <p-tree
                                    [value]="productTreeNodes"
                                    [loading]="loading"
                                    selectionMode="single"
                                    [(selection)]="selectedNode"
                                    (onNodeSelect)="onNodeSelect($event)"
                                    [filter]="true"
                                    filterPlaceholder="Search...">
                            </p-tree>
                        </p-card>
                    </div>

                    <!-- Details Panel -->
                    <div class="col-12 md:col-8">
                        <p-card *ngIf="selectedProduct" header="Product Details">
                            <p-tabView>
                                <p-tabPanel header="Basic Info">
                                    <div class="product-details">
                                        <div class="detail-row">
                                            <label>Product Code:</label>
                                            <span>{{ selectedProduct.productCode }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <label>Product Name:</label>
                                            <span>{{ selectedProduct.productName }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <label>Description:</label>
                                            <span>{{ selectedProduct.description }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <label>HSN/SAC Code:</label>
                                            <span>{{ selectedProduct.hsnSacCode }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <label>Unit of Measurement:</label>
                                            <span>{{ selectedProduct.unitOfMeasurement }}</span>
                                        </div>
                                        <div class="detail-row" *ngIf="selectedProduct.hasCeilingRate">
                                            <label>Ceiling Rate:</label>
                                            <span>₹ {{ selectedProduct.ceilingRate | number:'1.2-2' }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <label>Status:</label>
                                            <p-tag [value]="selectedProduct.isActive ? 'Active' : 'Inactive'"
                                                   [severity]="selectedProduct.isActive ? 'success' : 'danger'"></p-tag>
                                        </div>
                                        <div class="mt-3">
                                            <button pButton label="Edit Product" icon="pi pi-pencil"
                                                    class="p-button-sm mr-2" (click)="editProduct(selectedProduct)"></button>
                                            <button pButton label="Manage Dimensions" icon="pi pi-sliders-h"
                                                    class="p-button-sm p-button-secondary" (click)="showDimensionDialog()"></button>
                                        </div>
                                    </div>
                                </p-tabPanel>

                                <p-tabPanel header="Dimensions">
                                    <p-table [value]="selectedProduct.dimensions || []"
                                             styleClass="p-datatable-sm">
                                        <ng-template pTemplate="header">
                                            <tr>
                                                <th>Dimension Name</th>
                                                <th>Data Type</th>
                                                <th>UI Component</th>
                                                <th>Mandatory</th>
                                                <th>Used in Pricing</th>
                                                <th>Actions</th>
                                            </tr>
                                        </ng-template>
                                        <ng-template pTemplate="body" let-dim>
                                            <tr>
                                                <td>{{ dim.dimensionName }}</td>
                                                <td><p-tag [value]="dim.dataType"></p-tag></td>
                                                <td>{{ dim.uiComponent }}</td>
                                                <td>
                                                    <i [class]="dim.isMandatory ? 'pi pi-check text-green-500' : 'pi pi-times text-red-500'"></i>
                                                </td>
                                                <td>
                                                    <i [class]="dim.usedInPricing ? 'pi pi-check text-green-500' : 'pi pi-times text-red-500'"></i>
                                                </td>
                                                <td>
                                                    <button pButton icon="pi pi-pencil"
                                                            class="p-button-text p-button-sm"></button>
                                                </td>
                                            </tr>
                                        </ng-template>
                                        <ng-template pTemplate="emptymessage">
                                            <tr>
                                                <td colspan="6" class="text-center">
                                                    <p class="text-600">No dimensions configured</p>
                                                    <button pButton label="Add First Dimension"
                                                            class="p-button-sm mt-2" (click)="showDimensionDialog()"></button>
                                                </td>
                                            </tr>
                                        </ng-template>
                                    </p-table>
                                </p-tabPanel>
                            </p-tabView>
                        </p-card>

                        <p-card *ngIf="!selectedProduct" header="Getting Started">
                            <div class="text-center py-4">
                                <i class="pi pi-info-circle text-6xl text-blue-400 mb-3"></i>
                                <h3 class="mb-2">Build Your Product Catalog</h3>
                                <p class="text-600 mb-3">Create a hierarchical structure for your products:</p>
                                <div class="text-left inline-block">
                                    <p><strong>1. Add Category:</strong> Create product categories (e.g., Advertisements, IT Services)</p>
                                    <p><strong>2. Add Sub-Category:</strong> Organize products into sub-categories</p>
                                    <p><strong>3. Add Product:</strong> Define specific products with dimensions</p>
                                    <p><strong>4. Configure Dimensions:</strong> Set up dynamic attributes for each product</p>
                                </div>
                            </div>
                        </p-card>
                    </div>
                </div>
            </div>

            <!-- Category Dialog -->
            <p-dialog [(visible)]="categoryDialog" header="Category" [modal]="true"
                      [style]="{width: '500px'}">
                <div class="flex flex-column gap-3">
                    <div class="field">
                        <label class="required">Department</label>
                        <p-dropdown [options]="departments" [(ngModel)]="editingCategory.departmentId"
                                    optionLabel="departmentName" optionValue="id" placeholder="Select Department"
                                    [style]="{'width':'100%'}"></p-dropdown>
                    </div>
                    <div class="field">
                        <label class="required">Category Code</label>
                        <input pInputText [(ngModel)]="editingCategory.categoryCode"
                               placeholder="e.g., ADV" class="w-full" />
                    </div>
                    <div class="field">
                        <label class="required">Category Name</label>
                        <input pInputText [(ngModel)]="editingCategory.categoryName"
                               placeholder="e.g., Advertisements" class="w-full" />
                    </div>
                    <div class="field">
                        <label>Description</label>
                        <textarea pInputTextarea [(ngModel)]="editingCategory.description"
                                  rows="3" class="w-full"></textarea>
                    </div>
                </div>
                <ng-template pTemplate="footer">
                    <button pButton label="Cancel" icon="pi pi-times"
                            class="p-button-text" (click)="categoryDialog = false"></button>
                    <button pButton label="Save" icon="pi pi-check"
                            (click)="saveCategory()"></button>
                </ng-template>
            </p-dialog>

            <!-- Sub-Category Dialog -->
            <p-dialog [(visible)]="subCategoryDialog" header="Sub-Category" [modal]="true"
                      [style]="{width: '500px'}">
                <div class="flex flex-column gap-3">
                    <div class="field">
                        <label class="required">Parent Category</label>
                        <input pInputText [value]="selectedCategory?.categoryName"
                               [disabled]="true" class="w-full" />
                    </div>
                    <div class="field">
                        <label class="required">Sub-Category Code</label>
                        <input pInputText [(ngModel)]="editingSubCategory.subCategoryCode"
                               placeholder="e.g., PAC" class="w-full" />
                    </div>
                    <div class="field">
                        <label class="required">Sub-Category Name</label>
                        <input pInputText [(ngModel)]="editingSubCategory.subCategoryName"
                               placeholder="e.g., Public Awareness Campaign" class="w-full" />
                    </div>
                    <div class="field">
                        <label>Description</label>
                        <textarea pInputTextarea [(ngModel)]="editingSubCategory.description"
                                  rows="3" class="w-full"></textarea>
                    </div>
                </div>
                <ng-template pTemplate="footer">
                    <button pButton label="Cancel" icon="pi pi-times"
                            class="p-button-text" (click)="subCategoryDialog = false"></button>
                    <button pButton label="Save" icon="pi pi-check"
                            (click)="saveSubCategory()"></button>
                </ng-template>
            </p-dialog>

            <!-- Product Dialog -->
            <p-dialog [(visible)]="productDialog" header="Product" [modal]="true"
                      [style]="{width: '600px'}">
                <div class="grid">
                    <div class="col-12">
                        <label class="required">Sub-Category</label>
                        <input pInputText [value]="selectedSubCategory?.subCategoryName"
                               [disabled]="true" class="w-full" />
                    </div>
                    <div class="col-6">
                        <label class="required">Product Code</label>
                        <input pInputText [(ngModel)]="editingProduct.productCode"
                               placeholder="e.g., RADIO-001" class="w-full" />
                    </div>
                    <div class="col-6">
                        <label class="required">Product Name</label>
                        <input pInputText [(ngModel)]="editingProduct.productName"
                               placeholder="e.g., Radio Advertisement" class="w-full" />
                    </div>
                    <div class="col-12">
                        <label>Description</label>
                        <textarea pInputTextarea [(ngModel)]="editingProduct.description"
                                  rows="2" class="w-full"></textarea>
                    </div>
                    <div class="col-6">
                        <label>HSN/SAC Code</label>
                        <input pInputText [(ngModel)]="editingProduct.hsnSacCode"
                               placeholder="e.g., 998361" class="w-full" />
                    </div>
                    <div class="col-6">
                        <label>Classification Type</label>
                        <input pInputText [(ngModel)]="editingProduct.classificationType"
                               placeholder="e.g., Service" class="w-full" />
                    </div>
                    <div class="col-6">
                        <label>Unit of Measurement</label>
                        <input pInputText [(ngModel)]="editingProduct.unitOfMeasurement"
                               placeholder="e.g., Per Second" class="w-full" />
                    </div>
                    <div class="col-6">
                        <label>Has Ceiling Rate?</label>
                        <p-checkbox [(ngModel)]="editingProduct.hasCeilingRate"
                                    [binary]="true"></p-checkbox>
                    </div>
                    <div class="col-6" *ngIf="editingProduct.hasCeilingRate">
                        <label>Ceiling Rate (₹)</label>
                        <p-inputNumber [(ngModel)]="editingProduct.ceilingRate"
                                       mode="currency" currency="INR" locale="en-IN" class="w-full">
                        </p-inputNumber>
                    </div>
                </div>
                <ng-template pTemplate="footer">
                    <button pButton label="Cancel" icon="pi pi-times"
                            class="p-button-text" (click)="productDialog = false"></button>
                    <button pButton label="Save" icon="pi pi-check"
                            (click)="saveProduct()"></button>
                </ng-template>
            </p-dialog>

            <!-- Dimension Dialog -->
            <p-dialog [(visible)]="dimensionDialog" header="Dimension Configuration"
                      [modal]="true" [style]="{width: '700px'}" [maximizable]="true">
                <div class="mb-3">
                    <button pButton label="Add Dimension" icon="pi pi-plus"
                            class="p-button-sm" (click)="addNewDimension()"></button>
                </div>

                <div *ngFor="let dim of editingProduct.dimensions; let i = index"
                     class="dimension-card mb-3 p-3 surface-100 border-round">
                    <div class="grid">
                        <div class="col-12 flex justify-content-between align-items-center mb-2">
                            <h4 class="m-0">Dimension {{i + 1}}</h4>
                            <button pButton icon="pi pi-trash"
                                    class="p-button-text p-button-sm p-button-danger"
                                    (click)="removeDimension(i)"></button>
                        </div>
                        <div class="col-6">
                            <label class="required">Dimension Name</label>
                            <input pInputText [(ngModel)]="dim.dimensionName"
                                   placeholder="e.g., Frequency" class="w-full" />
                        </div>
                        <div class="col-6">
                            <label class="required">Dimension Key</label>
                            <input pInputText [(ngModel)]="dim.dimensionKey"
                                   placeholder="e.g., frequency" class="w-full" />
                        </div>
                        <div class="col-4">
                            <label class="required">Data Type</label>
                            <p-dropdown [options]="dataTypes" [(ngModel)]="dim.dataType"
                                        placeholder="Select Type" [style]="{'width':'100%'}"></p-dropdown>
                        </div>
                        <div class="col-4">
                            <label class="required">UI Component</label>
                            <p-dropdown [options]="uiComponents" [(ngModel)]="dim.uiComponent"
                                        placeholder="Select Component" [style]="{'width':'100%'}"></p-dropdown>
                        </div>
                        <div class="col-4 flex align-items-end gap-3">
                            <div>
                                <label>Mandatory</label>
                                <p-checkbox [(ngModel)]="dim.isMandatory" [binary]="true"></p-checkbox>
                            </div>
                            <div>
                                <label>Used in Pricing</label>
                                <p-checkbox [(ngModel)]="dim.usedInPricing" [binary]="true"></p-checkbox>
                            </div>
                        </div>
                        <div class="col-12" *ngIf="dim.dataType === 'ENUM'">
                            <label>Enum Values (comma-separated)</label>
                            <input pInputText [(ngModel)]="dim.enumValues"
                                   placeholder="e.g., Option1,Option2,Option3" class="w-full" />
                        </div>
                        <div class="col-6" *ngIf="dim.dataType === 'NUMBER' || dim.dataType === 'DECIMAL'">
                            <label>Min Value</label>
                            <p-inputNumber [(ngModel)]="dim.minValue" class="w-full"></p-inputNumber>
                        </div>
                        <div class="col-6" *ngIf="dim.dataType === 'NUMBER' || dim.dataType === 'DECIMAL'">
                            <label>Max Value</label>
                            <p-inputNumber [(ngModel)]="dim.maxValue" class="w-full"></p-inputNumber>
                        </div>
                        <div class="col-12">
                            <label>Help Text</label>
                            <input pInputText [(ngModel)]="dim.helpText"
                                   placeholder="Instructions for this dimension" class="w-full" />
                        </div>
                    </div>
                </div>

                <div *ngIf="!editingProduct.dimensions || editingProduct.dimensions.length === 0"
                     class="text-center py-4 text-600">
                    <p>No dimensions configured. Click "Add Dimension" to create one.</p>
                </div>

                <ng-template pTemplate="footer">
                    <button pButton label="Cancel" icon="pi pi-times"
                            class="p-button-text" (click)="dimensionDialog = false"></button>
                    <button pButton label="Save Dimensions" icon="pi pi-check"
                            (click)="saveDimensions()"></button>
                </ng-template>
            </p-dialog>

            <p-toast></p-toast>
        </div>
    `,
    styles: [`
      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #dee2e6;
      }

      .product-details {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
      }

      .detail-row {
        display: grid;
        grid-template-columns: 200px 1fr;
        gap: 1rem;
      }

      .detail-row label {
        font-weight: 600;
        color: #495057;
      }

      .field label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: #495057;
      }

      .field label.required::after {
        content: " *";
        color: #e74c3c;
      }

      .dimension-card {
        border: 1px solid #dee2e6;
      }

      :host ::ng-deep {
        .p-tree {
          border: none;
          padding: 0;
        }

        .p-tree .p-tree-container .p-treenode {
          padding: 0.25rem 0;
        }
      }
    `]
})
export class ProductCatalogComponent implements OnInit {
    productTreeNodes: TreeNode[] = [];
    selectedNode: TreeNode | null = null;
    loading = false;

    departments: Department[] = [];
    categories: ProductCategory[] = [];
    subCategories: SubCategory[] = [];
    products: Product[] = [];

    selectedCategory: ProductCategory | null = null;
    selectedSubCategory: SubCategory | null = null;
    selectedProduct: Product | null = null;

    categoryDialog = false;
    subCategoryDialog = false;
    productDialog = false;
    dimensionDialog = false;

    editingCategory: ProductCategory = {} as ProductCategory;
    editingSubCategory: SubCategory = {} as SubCategory;
    editingProduct: Product = {dimensions: []} as unknown as Product;

    dataTypes = Object.values(DimensionDataType);
    uiComponents = Object.values(DimensionUIComponent);

    constructor(
        private productService: ProductService,
        private departmentService: DepartmentService,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        this.loadDepartments();
        this.loadProductTree();
    }

    loadDepartments() {
        this.departmentService.getActiveDepartments().subscribe({
            next: (data) => this.departments = data
        });
    }

    loadProductTree() {
        this.loading = true;
        this.productService.getAllCategories().subscribe({
            next: (categories) => {
                this.categories = categories;
                this.buildTree();
                this.loading = false;
            },
            error: () => {
                this.loading = false;
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load product catalog'
                });
            }
        });
    }

    buildTree() {
        this.productTreeNodes = this.categories.map(category => ({
            key: `cat-${category.id}`,
            label: category.categoryName,
            data: { type: 'category', item: category },
            icon: 'pi pi-folder',
            leaf: false,
            children: []
        }));

        // Load sub-categories and products for each category
        this.categories.forEach(category => {
            this.productService.getSubCategoriesByCategory(category.id!).subscribe({
                next: (subCategories) => {
                    const categoryNode = this.productTreeNodes.find(n => n.key === `cat-${category.id}`);
                    if (categoryNode) {
                        categoryNode.children = subCategories.map(subCat => ({
                            key: `sub-${subCat.id}`,
                            label: subCat.subCategoryName,
                            data: { type: 'subcategory', item: subCat },
                            icon: 'pi pi-folder-open',
                            leaf: false,
                            children: []
                        }));

                        // Load products for each sub-category
                        subCategories.forEach(subCat => {
                            this.productService.getProductsBySubCategory(subCat.id!).subscribe({
                                next: (products) => {
                                    const subCatNode = categoryNode.children?.find(n => n.key === `sub-${subCat.id}`);
                                    if (subCatNode) {
                                        subCatNode.children = products.map(product => ({
                                            key: `prod-${product.id}`,
                                            label: product.productName,
                                            data: { type: 'product', item: product },
                                            icon: 'pi pi-tag',
                                            leaf: true
                                        }));
                                    }
                                }
                            });
                        });
                    }
                }
            });
        });
    }

    onNodeSelect(event: any) {
        const nodeData = event.node.data;

        if (nodeData.type === 'category') {
            this.selectedCategory = nodeData.item;
            this.selectedSubCategory = null;
            this.selectedProduct = null;
        } else if (nodeData.type === 'subcategory') {
            this.selectedSubCategory = nodeData.item;
            this.selectedProduct = null;
        } else if (nodeData.type === 'product') {
            // Load full product details with dimensions
            this.productService.getProductById(nodeData.item.id).subscribe({
                next: (product) => {
                    this.selectedProduct = product;
                }
            });
        }
    }

    showCategoryDialog() {
        this.editingCategory = {
            categoryCode: '',
            categoryName: '',
            isActive: true
        };
        this.categoryDialog = true;
    }

    showSubCategoryDialog() {
        if (!this.selectedCategory) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Warning',
                detail: 'Please select a category first'
            });
            return;
        }
        this.editingSubCategory = {
            subCategoryCode: '',
            subCategoryName: '',
            categoryId: this.selectedCategory.id,
            isActive: true
        };
        this.subCategoryDialog = true;
    }

    showProductDialog() {
        if (!this.selectedSubCategory) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Warning',
                detail: 'Please select a sub-category first'
            });
            return;
        }
        this.editingProduct = {
            productCode: '',
            productName: '',
            subCategoryId: this.selectedSubCategory.id,
            isActive: true,
            hasCeilingRate: false,
            dimensions: []
        };
        this.productDialog = true;
    }

    showDimensionDialog() {
        if (!this.selectedProduct) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Warning',
                detail: 'Please select a product first'
            });
            return;
        }
        this.editingProduct = { ...this.selectedProduct };
        if (!this.editingProduct.dimensions) {
            this.editingProduct.dimensions = [];
        }
        this.dimensionDialog = true;
    }

    saveCategory() {
        this.productService.createCategory(this.editingCategory).subscribe({
            next: () => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Category created successfully'
                });
                this.categoryDialog = false;
                this.loadProductTree();
            },
            error: () => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to create category'
                });
            }
        });
    }

    saveSubCategory() {
        this.productService.createSubCategory(this.editingSubCategory).subscribe({
            next: () => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Sub-category created successfully'
                });
                this.subCategoryDialog = false;
                this.loadProductTree();
            },
            error: () => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to create sub-category'
                });
            }
        });
    }

    saveProduct() {
        if (this.editingProduct.id) {
            this.productService.updateProduct(this.editingProduct.id, this.editingProduct).subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Product updated successfully'
                    });
                    this.productDialog = false;
                    this.loadProductTree();
                }
            });
        } else {
            this.productService.createProduct(this.editingProduct).subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Product created successfully'
                    });
                    this.productDialog = false;
                    this.loadProductTree();
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to create product'
                    });
                }
            });
        }
    }

    editProduct(product: Product) {
        this.editingProduct = { ...product };
        this.productDialog = true;
    }

    addNewDimension() {
        if (!this.editingProduct.dimensions) {
            this.editingProduct.dimensions = [];
        }

        const newDimension: DimensionTemplate = {
            dimensionName: '',
            dimensionKey: '',
            dataType: DimensionDataType.STRING,
            uiComponent: DimensionUIComponent.INPUT,
            isMandatory: false,
            usedInPricing: false,
            displayOrder: this.editingProduct.dimensions.length + 1
        };

        this.editingProduct.dimensions.push(newDimension);
    }

    removeDimension(index: number) {
        this.editingProduct.dimensions?.splice(index, 1);
    }

    saveDimensions() {
        // Update product with dimensions
        if (this.editingProduct.id) {
            this.productService.updateProduct(this.editingProduct.id, this.editingProduct).subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Dimensions saved successfully'
                    });
                    this.dimensionDialog = false;
                    this.selectedProduct = this.editingProduct;
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to save dimensions'
                    });
                }
            });
        }
    }
}