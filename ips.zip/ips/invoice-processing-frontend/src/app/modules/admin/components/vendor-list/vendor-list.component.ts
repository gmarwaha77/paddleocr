import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { TagModule } from 'primeng/tag';
import { VendorService } from '../../../../services/vendor.service';
import { Vendor } from '../../../../models/vendor.model';

@Component({
    selector: 'app-vendor-list',
    standalone: true,
    imports: [CommonModule, TableModule, ButtonModule, TagModule],
    template: `
    <div class="p-4">
      <div class="card">
        <div class="card-header">
          <h2 class="text-2xl font-bold m-0">Vendor Management</h2>
          <button pButton label="Add Vendor" icon="pi pi-plus"></button>
        </div>

        <p-table [value]="vendors" [loading]="loading" [paginator]="true" [rows]="10">
          <ng-template pTemplate="header">
            <tr>
              <th>Vendor Code</th>
              <th>Vendor Name</th>
              <th>GSTIN</th>
              <th>State</th>
              <th>Contact</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </ng-template>
          <ng-template pTemplate="body" let-vendor>
            <tr>
              <td>{{ vendor.vendorCode }}</td>
              <td>{{ vendor.vendorName }}</td>
              <td>{{ vendor.gstin }}</td>
              <td>{{ vendor.state }}</td>
              <td>{{ vendor.email }}</td>
              <td>
                <p-tag [value]="vendor.vendorStatus" [severity]="'success'"></p-tag>
              </td>
              <td>
                <button pButton icon="pi pi-pencil" class="p-button-text p-button-sm"></button>
              </td>
            </tr>
          </ng-template>
        </p-table>
      </div>
    </div>
  `
})
export class VendorListComponent implements OnInit {
    vendors: Vendor[] = [];
    loading = false;

    constructor(private vendorService: VendorService) {}

    ngOnInit() {
        this.loading = true;
        this.vendorService.getAllVendors().subscribe({
            next: (data) => {
                this.vendors = data;
                this.loading = false;
            },
            error: () => {
                this.loading = false;
            }
        });
    }
}
