import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { DepartmentService } from '../../../../services/department.service';
import { Department } from '../../../../models/department.model';

@Component({
    selector: 'app-department-list',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        TableModule,
        ButtonModule,
        DialogModule,
        InputTextModule,
        InputNumberModule,
        InputTextareaModule,
        ToastModule
    ],
    providers: [MessageService],
    template: `
    <div class="p-4">
      <div class="card">
        <div class="card-header">
          <h2 class="text-2xl font-bold m-0">Departments</h2>
          <button 
            pButton 
            label="Add Department" 
            icon="pi pi-plus"
            (click)="showDialog()">
          </button>
        </div>

        <p-table 
          [value]="departments" 
          [loading]="loading"
          [paginator]="true" 
          [rows]="10"
          styleClass="p-datatable-striped">
          <ng-template pTemplate="header">
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Annual Budget</th>
              <th>Budget Utilized</th>
              <th>Head</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </ng-template>
          <ng-template pTemplate="body" let-dept>
            <tr>
              <td>{{ dept.departmentCode }}</td>
              <td>{{ dept.departmentName }}</td>
              <td>₹ {{ dept.annualBudget | number:'1.2-2' }}</td>
              <td>₹ {{ dept.budgetUtilized | number:'1.2-2' }}</td>
              <td>{{ dept.headOfDepartment }}</td>
              <td>
                <span class="status-badge" [class.status-approved]="dept.isActive">
                  {{ dept.isActive ? 'Active' : 'Inactive' }}
                </span>
              </td>
              <td>
                <button 
                  pButton 
                  icon="pi pi-pencil" 
                  class="p-button-text p-button-sm"
                  (click)="editDepartment(dept)">
                </button>
              </td>
            </tr>
          </ng-template>
        </p-table>
      </div>

      <p-dialog 
        [(visible)]="displayDialog" 
        [header]="selectedDepartment?.id ? 'Edit Department' : 'Add Department'"
        [modal]="true" 
        [style]="{width: '600px'}">
        <div class="form-grid">
          <div class="form-field">
            <label class="required">Department Code</label>
            <input pInputText [(ngModel)]="selectedDepartment.departmentCode" />
          </div>
          <div class="form-field">
            <label class="required">Department Name</label>
            <input pInputText [(ngModel)]="selectedDepartment.departmentName" />
          </div>
          <div class="form-field col-12">
            <label>Description</label>
            <textarea pInputTextarea [(ngModel)]="selectedDepartment.description" rows="3"></textarea>
          </div>
          <div class="form-field">
            <label class="required">Annual Budget (₹)</label>
            <p-inputNumber 
              [(ngModel)]="selectedDepartment.annualBudget" 
              mode="currency" 
              currency="INR"
              locale="en-IN">
            </p-inputNumber>
          </div>
          <div class="form-field">
            <label>Head of Department</label>
            <input pInputText [(ngModel)]="selectedDepartment.headOfDepartment" />
          </div>
          <div class="form-field">
            <label>Contact Email</label>
            <input pInputText type="email" [(ngModel)]="selectedDepartment.contactEmail" />
          </div>
          <div class="form-field">
            <label>Contact Phone</label>
            <input pInputText [(ngModel)]="selectedDepartment.contactPhone" />
          </div>
        </div>
        <ng-template pTemplate="footer">
          <button 
            pButton 
            label="Cancel" 
            icon="pi pi-times" 
            class="p-button-text"
            (click)="displayDialog = false">
          </button>
          <button 
            pButton 
            label="Save" 
            icon="pi pi-check"
            (click)="saveDepartment()">
          </button>
        </ng-template>
      </p-dialog>

      <p-toast></p-toast>
    </div>
  `
})
export class DepartmentListComponent implements OnInit {
    departments: Department[] = [];
    loading = false;
    displayDialog = false;
    selectedDepartment: Department = {} as Department;

    constructor(
        private departmentService: DepartmentService,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        this.loadDepartments();
    }

    loadDepartments() {
        this.loading = true;
        this.departmentService.getAllDepartments().subscribe({
            next: (data) => {
                this.departments = data;
                this.loading = false;
            },
            error: () => {
                this.loading = false;
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load departments'
                });
            }
        });
    }

    showDialog() {
        this.selectedDepartment = {} as Department;
        this.displayDialog = true;
    }

    editDepartment(dept: Department) {
        this.selectedDepartment = { ...dept };
        this.displayDialog = true;
    }

    saveDepartment() {
        if (this.selectedDepartment.id) {
            this.departmentService.updateDepartment(this.selectedDepartment.id, this.selectedDepartment)
                .subscribe({
                    next: () => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Success',
                            detail: 'Department updated successfully'
                        });
                        this.displayDialog = false;
                        this.loadDepartments();
                    }
                });
        } else {
            this.departmentService.createDepartment(this.selectedDepartment).subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Department created successfully'
                    });
                    this.displayDialog = false;
                    this.loadDepartments();
                }
            });
        }
    }
}
