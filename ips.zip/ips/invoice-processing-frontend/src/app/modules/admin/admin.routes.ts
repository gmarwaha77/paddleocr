import { Routes } from '@angular/router';

export const ADMIN_ROUTES: Routes = [
    {
        path: 'departments',
        loadComponent: () => import('./components/department-list/department-list.component')
            .then(m => m.DepartmentListComponent)
    },
    {
        path: 'products',
        loadComponent: () => import('./components/product-catalog/product-catalog.component')
            .then(m => m.ProductCatalogComponent)
    },
    {
        path: 'vendors',
        loadComponent: () => import('./components/vendor-list/vendor-list.component')
            .then(m => m.VendorListComponent)
    },
    {
        path: '',
        redirectTo: 'departments',
        pathMatch: 'full'
    }
];
