import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploadModule } from 'primeng/fileupload';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ImageModule } from 'primeng/image';
import { GalleriaModule } from 'primeng/galleria';

export interface ProofMetadata {
    publicationName?: string;
    publicationDate?: Date;
    publicationPage?: string;
    state?: string;
    city?: string;
    language?: string;
}

export interface ProofFile {
    id?: number;
    fileName: string;
    fileSize: number;
    fileType: string;
    uploadedAt?: Date;
    thumbnailUrl?: string;
    verificationStatus?: string;
    autoMatchScore?: number;
    metadata?: ProofMetadata;
}

@Component({
    selector: 'app-proof-upload-widget',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        FileUploadModule,
        ButtonModule,
        CardModule,
        DialogModule,
        InputTextModule,
        CalendarModule,
        DropdownModule,
        TagModule,
        ToastModule,
        ImageModule,
        GalleriaModule
    ],
    providers: [MessageService],
    template: `
    <p-card [header]="headerText" styleClass="proof-upload-card">
      <!-- Upload Section -->
      <div class="upload-section">
        <p-fileUpload
          #fileUpload
          [multiple]="allowMultiple"
          [accept]="acceptedFileTypes"
          [maxFileSize]="maxFileSize"
          (onSelect)="onFilesSelected($event)"
          [customUpload]="true"
          (uploadHandler)="uploadFiles($event)"
          [showUploadButton]="false"
          [showCancelButton]="false">
          
          <ng-template pTemplate="header" let-files let-chooseCallback="chooseCallback">
            <div class="flex align-items-center justify-content-between w-full">
              <div class="flex align-items-center gap-2">
                <button pButton type="button" icon="pi pi-images" 
                  label="Choose Files" (click)="chooseCallback()"
                  class="p-button-sm"></button>
                <span class="text-sm text-600">
                  {{ files.length > 0 ? files.length + ' file(s) selected' : 'Upload proof documents' }}
                </span>
              </div>
              <button pButton type="button" icon="pi pi-upload" 
                label="Upload All" (click)="uploadAll()" 
                [disabled]="!hasFilesToUpload"
                class="p-button-sm p-button-success"></button>
            </div>
          </ng-template>

          <ng-template pTemplate="content" let-files>
            <div *ngIf="files.length > 0" class="selected-files-list">
              <div *ngFor="let file of files; let i = index" 
                class="selected-file-item">
                <div class="file-info">
                  <i class="pi pi-file text-2xl mr-2"></i>
                  <div>
                    <p class="font-semibold mb-1">{{ file.name }}</p>
                    <p class="text-sm text-600">{{ formatFileSize(file.size) }}</p>
                  </div>
                </div>
                <div class="file-actions">
                  <button pButton icon="pi pi-info-circle" 
                    class="p-button-text p-button-sm"
                    (click)="showMetadataDialog(file)" 
                    pTooltip="Add Details"></button>
                  <button pButton icon="pi pi-times" 
                    class="p-button-text p-button-sm p-button-danger"
                    (click)="removeFile(i)"></button>
                </div>
              </div>
            </div>
          </ng-template>

          <ng-template pTemplate="file"></ng-template>
        </p-fileUpload>

        <div class="upload-hints mt-2">
          <p class="text-xs text-600 mb-1">
            <i class="pi pi-info-circle mr-1"></i>
            Accepted: Images (JPG, PNG), PDFs (Max {{ maxFileSize / 1048576 }}MB each)
          </p>
          <p class="text-xs text-600" *ngIf="requiresMetadata">
            <i class="pi pi-exclamation-triangle mr-1"></i>
            Please add publication details for each proof
          </p>
        </div>
      </div>

      <!-- Uploaded Proofs Gallery -->
      <div class="uploaded-proofs mt-4" *ngIf="existingProofs.length > 0">
        <div class="section-header">
          <h4 class="m-0">Uploaded Proofs ({{ existingProofs.length }})</h4>
          <p-tag [value]="getVerificationSummary()" 
            [severity]="getVerificationSeverity()"></p-tag>
        </div>

        <div class="proofs-grid">
          <div *ngFor="let proof of existingProofs" class="proof-card">
            <div class="proof-preview" (click)="viewProof(proof)">
              <img *ngIf="isImage(proof)" 
                [src]="proof.thumbnailUrl || 'assets/placeholder.png'" 
                [alt]="proof.fileName" />
              <i *ngIf="isPDF(proof)" class="pi pi-file-pdf text-6xl text-red-500"></i>
            </div>
            
            <div class="proof-info">
              <p class="proof-name" [title]="proof.fileName">
                {{ truncateFileName(proof.fileName) }}
              </p>
              <p class="proof-size text-xs text-600">
                {{ formatFileSize(proof.fileSize) }}
              </p>
              
              <div class="proof-status mt-2">
                <p-tag [value]="proof.verificationStatus || 'Pending'"
                  [severity]="getStatusSeverity(proof.verificationStatus)">
                </p-tag>
                <span *ngIf="proof.autoMatchScore" class="match-score ml-2">
                  {{ proof.autoMatchScore }}% match
                </span>
              </div>

              <div class="proof-metadata mt-2 text-xs" *ngIf="proof.metadata">
                <p *ngIf="proof.metadata.publicationName" class="mb-1">
                  <strong>Publication:</strong> {{ proof.metadata.publicationName }}
                </p>
                <p *ngIf="proof.metadata.publicationDate" class="mb-1">
                  <strong>Date:</strong> {{ proof.metadata.publicationDate | date }}
                </p>
                <p *ngIf="proof.metadata.publicationPage">
                  <strong>Page:</strong> {{ proof.metadata.publicationPage }}
                </p>
              </div>

              <div class="proof-actions mt-2">
                <button pButton icon="pi pi-eye" 
                  class="p-button-text p-button-sm"
                  (click)="viewProof(proof)" 
                  pTooltip="View"></button>
                <button pButton icon="pi pi-download" 
                  class="p-button-text p-button-sm"
                  (click)="downloadProof(proof)" 
                  pTooltip="Download"></button>
                <button pButton icon="pi pi-trash" 
                  class="p-button-text p-button-sm p-button-danger"
                  (click)="deleteProof(proof)" 
                  pTooltip="Delete"></button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <div class="empty-state text-center py-4" 
        *ngIf="existingProofs.length === 0 && !hasFilesToUpload">
        <i class="pi pi-cloud-upload text-6xl text-400 mb-3"></i>
        <p class="text-xl font-semibold mb-2">No Proofs Uploaded Yet</p>
        <p class="text-600">
          Upload proof documents to verify this line item
        </p>
      </div>
    </p-card>

    <!-- Metadata Dialog -->
    <p-dialog [(visible)]="metadataDialog" header="Proof Details" 
      [modal]="true" [style]="{width: '500px'}">
      <div class="flex flex-column gap-3">
        <div class="field">
          <label>Publication Name *</label>
          <p-dropdown [options]="publications" 
            [(ngModel)]="currentMetadata.publicationName"
            [filter]="true" placeholder="Select Publication"
            [editable]="true" [style]="{'width':'100%'}"></p-dropdown>
        </div>

        <div class="field">
          <label>Publication Date *</label>
          <p-calendar [(ngModel)]="currentMetadata.publicationDate"
            dateFormat="dd/mm/yy" [showIcon]="true" 
            [style]="{'width':'100%'}"></p-calendar>
        </div>

        <div class="field">
          <label>Page Number</label>
          <input pInputText [(ngModel)]="currentMetadata.publicationPage" 
            placeholder="e.g., Front Page, Page 5" class="w-full" />
        </div>

        <div class="field">
          <label>State *</label>
          <p-dropdown [options]="indianStates" 
            [(ngModel)]="currentMetadata.state"
            [filter]="true" placeholder="Select State"
            [style]="{'width':'100%'}"></p-dropdown>
        </div>

        <div class="field">
          <label>City</label>
          <input pInputText [(ngModel)]="currentMetadata.city" 
            placeholder="e.g., Mumbai" class="w-full" />
        </div>

        <div class="field">
          <label>Language</label>
          <p-dropdown [options]="languages" 
            [(ngModel)]="currentMetadata.language"
            placeholder="Select Language"
            [style]="{'width':'100%'}"></p-dropdown>
        </div>
      </div>

      <ng-template pTemplate="footer">
        <button pButton label="Cancel" icon="pi pi-times" 
          class="p-button-text" (click)="metadataDialog = false"></button>
        <button pButton label="Save" icon="pi pi-check" 
          (click)="saveMetadata()"></button>
      </ng-template>
    </p-dialog>

    <!-- Proof Viewer Dialog -->
    <p-dialog [(visible)]="viewerDialog" [header]="viewingProof?.fileName" 
      [modal]="true" [maximizable]="true" [style]="{width: '80vw'}">
      <div class="proof-viewer">
        <img *ngIf="isImage(viewingProof)" 
          [src]="viewingProof?.thumbnailUrl" 
          class="w-full" />
        <iframe *ngIf="isPDF(viewingProof)" 
          [src]="getSafeUrl(viewingProof?.thumbnailUrl)" 
          class="w-full" style="height: 70vh"></iframe>
      </div>
    </p-dialog>

    <p-toast></p-toast>
  `,
    styles: [`
    .proof-upload-card {
      border: 2px dashed #dee2e6;
    }

    .upload-section {
      padding: 1rem;
      background: #f8f9fa;
      border-radius: 8px;
    }

    .selected-files-list {
      margin-top: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .selected-file-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem;
      background: white;
      border: 1px solid #dee2e6;
      border-radius: 6px;
    }

    .file-info {
      display: flex;
      align-items: center;
    }

    .file-actions {
      display: flex;
      gap: 0.25rem;
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
      padding-bottom: 0.5rem;
      border-bottom: 1px solid #dee2e6;
    }

    .proofs-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 1rem;
    }

    .proof-card {
      border: 1px solid #dee2e6;
      border-radius: 8px;
      overflow: hidden;
      transition: box-shadow 0.2s;
    }

    .proof-card:hover {
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .proof-preview {
      height: 150px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f8f9fa;
      cursor: pointer;
    }

    .proof-preview img {
      max-width: 100%;
      max-height: 100%;
      object-fit: cover;
    }

    .proof-info {
      padding: 0.75rem;
    }

    .proof-name {
      font-weight: 600;
      margin: 0 0 0.25rem 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .proof-status {
      display: flex;
      align-items: center;
    }

    .match-score {
      font-size: 0.75rem;
      color: #22c55e;
      font-weight: 600;
    }

    .proof-metadata {
      background: #f8f9fa;
      padding: 0.5rem;
      border-radius: 4px;
    }

    .proof-actions {
      display: flex;
      gap: 0.25rem;
    }

    .empty-state {
      border: 2px dashed #dee2e6;
      border-radius: 8px;
      padding: 2rem;
    }

    .upload-hints {
      background: #fff3cd;
      padding: 0.5rem;
      border-radius: 4px;
      border-left: 3px solid #ffc107;
    }

    .field label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 600;
    }

    :host ::ng-deep {
      .p-fileupload .p-fileupload-buttonbar {
        background: transparent;
        border: none;
        padding: 0;
      }

      .p-fileupload-content {
        border: none;
        padding: 0;
      }
    }
  `]
})
export class ProofUploadWidgetComponent implements OnInit {
    @Input() lineItemId!: number;
    @Input() existingProofs: ProofFile[] = [];
    @Input() allowMultiple = true;
    @Input() maxFileSize = 10485760; // 10MB default
    @Input() acceptedFileTypes = 'image/*,application/pdf';
    @Input() requiresMetadata = true;
    @Input() headerText = 'Proof Documents';

    @Output() proofsUploaded = new EventEmitter<ProofFile[]>();
    @Output() proofDeleted = new EventEmitter<number>();

    selectedFiles: File[] = [];
    fileMetadataMap: Map<string, ProofMetadata> = new Map();
    hasFilesToUpload = false;

    metadataDialog = false;
    viewerDialog = false;
    currentFile: File | null = null;
    currentMetadata: ProofMetadata = {};
    viewingProof: ProofFile | null = null;

    // Master data
    publications = [
        'Times of India',
        'The Hindu',
        'Indian Express',
        'Hindustan Times',
        'Deccan Chronicle'
    ];

    indianStates = [
        'Maharashtra', 'Karnataka', 'Tamil Nadu', 'Kerala',
        'Gujarat', 'Rajasthan', 'Delhi', 'West Bengal'
    ];

    languages = [
        'English', 'Hindi', 'Marathi', 'Tamil', 'Telugu',
        'Kannada', 'Malayalam', 'Gujarati', 'Bengali'
    ];

    constructor(private messageService: MessageService) {}

    ngOnInit() {
        // Initialize component
    }

    onFilesSelected(event: any) {
        this.selectedFiles = event.currentFiles;
        this.hasFilesToUpload = this.selectedFiles.length > 0;
    }

    showMetadataDialog(file: File) {
        this.currentFile = file;
        this.currentMetadata = this.fileMetadataMap.get(file.name) || {};
        this.metadataDialog = true;
    }

    saveMetadata() {
        if (this.currentFile) {
            this.fileMetadataMap.set(this.currentFile.name, { ...this.currentMetadata });
            this.messageService.add({
                severity: 'success',
                summary: 'Saved',
                detail: 'Proof details saved'
            });
        }
        this.metadataDialog = false;
    }

    uploadAll() {
        // Simulated upload - replace with actual HTTP call
        const newProofs: ProofFile[] = this.selectedFiles.map(file => ({
            fileName: file.name,
            fileSize: file.size,
            fileType: file.type,
            uploadedAt: new Date(),
            verificationStatus: 'PENDING',
            metadata: this.fileMetadataMap.get(file.name)
        }));

        this.proofsUploaded.emit(newProofs);

        this.messageService.add({
            severity: 'success',
            summary: 'Uploaded',
            detail: `${this.selectedFiles.length} proof(s) uploaded successfully`
        });

        this.selectedFiles = [];
        this.hasFilesToUpload = false;
        this.fileMetadataMap.clear();
    }

    uploadFiles(event: any) {
        this.uploadAll();
    }

    removeFile(index: number) {
        const fileName = this.selectedFiles[index].name;
        this.fileMetadataMap.delete(fileName);
        this.selectedFiles.splice(index, 1);
        this.hasFilesToUpload = this.selectedFiles.length > 0;
    }

    viewProof(proof: ProofFile) {
        this.viewingProof = proof;
        this.viewerDialog = true;
    }

    downloadProof(proof: ProofFile) {
        // Implement download logic
        this.messageService.add({
            severity: 'info',
            summary: 'Download',
            detail: `Downloading ${proof.fileName}`
        });
    }

    deleteProof(proof: ProofFile) {
        if (proof.id) {
            this.proofDeleted.emit(proof.id);
        }
    }

    formatFileSize(bytes: number): string {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

    truncateFileName(name: string, maxLength = 25): string {
        if (name.length <= maxLength) return name;
        const ext = name.split('.').pop();
        return name.substring(0, maxLength - 5) + '...' + ext;
    }

    isImage(proof: ProofFile | null): boolean {
        return proof?.fileType?.startsWith('image/') || false;
    }

    isPDF(proof: ProofFile | null): boolean {
        return proof?.fileType === 'application/pdf' || false;
    }

    getStatusSeverity(status: string | undefined): string {
        switch (status) {
            case 'VERIFIED':
            case 'AUTO_VERIFIED':
                return 'success';
            case 'PARTIAL_MATCH':
                return 'warning';
            case 'MISMATCH':
            case 'REJECTED':
                return 'danger';
            default:
                return 'info';
        }
    }

    getVerificationSummary(): string {
        const verified = this.existingProofs.filter(p =>
            p.verificationStatus === 'VERIFIED' || p.verificationStatus === 'AUTO_VERIFIED'
        ).length;
        return `${verified}/${this.existingProofs.length} Verified`;
    }

    getVerificationSeverity(): string {
        const allVerified = this.existingProofs.every(p =>
            p.verificationStatus === 'VERIFIED' || p.verificationStatus === 'AUTO_VERIFIED'
        );
        return allVerified ? 'success' : 'warning';
    }

    getSafeUrl(url: string | undefined): any {
        // Sanitize URL for iframe - implement with DomSanitizer
        return url;
    }
}