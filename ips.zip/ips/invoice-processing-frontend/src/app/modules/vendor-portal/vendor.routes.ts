import { Routes } from '@angular/router';

export const VENDOR_ROUTES: Routes = [
    {
        path: 'bids',
        loadComponent: () => import('./components/vendor-bids/vendor-bids.component')
            .then(m => m.VendorBidsComponent)
    },
    {
        path: 'invoices',
        loadComponent: () => import('./components/invoice-upload/invoice-upload.component')
            .then(m => m.InvoiceUploadComponent)
    },
    {
        path: '',
        redirectTo: 'bids',
        pathMatch: 'full'
    }
];
