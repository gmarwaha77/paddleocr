import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardModule } from 'primeng/card';

@Component({
    selector: 'app-vendor-bids',
    standalone: true,
    imports: [CommonModule, CardModule],
    template: `
    <div class="p-4">
      <div class="card">
        <h2 class="text-2xl font-bold mb-4">My Bidding Invitations</h2>
        <div class="text-center py-6">
          <i class="pi pi-money-bill text-6xl text-400 mb-3"></i>
          <p class="text-xl text-600">No active bidding invitations</p>
        </div>
      </div>
    </div>
  `
})
export class VendorBidsComponent {}
