import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploadModule } from 'primeng/fileupload';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MessageService } from 'primeng/api';
import { InvoiceService } from '../../../../services/invoice.service';
import { Invoice, InvoiceStatus } from '../../../../models/invoice.model';

@Component({
    selector: 'app-invoice-upload',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        FileUploadModule,
        ButtonModule,
        CardModule,
        TableModule,
        TagModule,
        ToastModule,
        ProgressSpinnerModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="card mb-4">
                <h2 class="text-2xl font-bold mb-4">Upload Invoice</h2>

                <p-fileUpload
                        name="invoice"
                        [customUpload]="true"
                        (uploadHandler)="onUpload($event)"
                        accept=".pdf"
                        [maxFileSize]="10000000"
                        [showUploadButton]="true"
                        [showCancelButton]="false"
                        chooseLabel="Select PDF Invoice">
                    <ng-template pTemplate="content">
                        <div class="text-center py-4">
                            <i class="pi pi-cloud-upload text-6xl text-400"></i>
                            <p class="mt-3 mb-0">Drag and drop PDF invoice here or click to browse</p>
                            <p class="text-sm text-600">Maximum file size: 10MB</p>
                        </div>
                    </ng-template>
                </p-fileUpload>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2 class="text-2xl font-bold m-0">My Invoices</h2>
                </div>

                <p-table
                        [value]="invoices"
                        [loading]="loading"
                        [paginator]="true"
                        [rows]="10">
                    <ng-template pTemplate="header">
                        <tr>
                            <th>Invoice Number</th>
                            <th>Date</th>
                            <th>Amount (₹)</th>
                            <th>GST (₹)</th>
                            <th>Total (₹)</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="body" let-invoice>
                        <tr>
                            <td><strong>{{ invoice.invoiceNumber || 'Pending' }}</strong></td>
                            <td>{{ invoice.invoiceDate | date:'mediumDate' }}</td>
                            <td>{{ invoice.taxableAmount | number:'1.2-2' }}</td>
                            <td>{{ invoice.totalGstAmount | number:'1.2-2' }}</td>
                            <td><strong>{{ invoice.totalInvoiceAmount | number:'1.2-2' }}</strong></td>
                            <td>
                                <p-tag
                                        *ngIf="invoice.invoiceStatus"
                                        [value]="invoice.invoiceStatus"
                                        [severity]="getStatusSeverity(invoice.invoiceStatus)">
                                </p-tag>
                            </td>
                            <td>
                                <button
                                        *ngIf="invoice.invoiceStatus === 'UPLOADED'"
                                        pButton
                                        label="Parse"
                                        icon="pi pi-cog"
                                        class="p-button-sm p-button-info"
                                        (click)="parseInvoice(invoice.id!)">
                                </button>
                                <button
                                        *ngIf="invoice.invoiceStatus === 'PARSED'"
                                        pButton
                                        label="Validate"
                                        icon="pi pi-check-circle"
                                        class="p-button-sm p-button-success"
                                        (click)="validateInvoice(invoice.id!)">
                                </button>
                            </td>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="emptymessage">
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="pi pi-inbox text-4xl text-400 mb-3"></i>
                                <p class="text-600">No invoices uploaded yet</p>
                            </td>
                        </tr>
                    </ng-template>
                </p-table>
            </div>

            <p-toast></p-toast>
        </div>
    `
})
export class InvoiceUploadComponent implements OnInit {
    invoices: Invoice[] = [];
    loading = false;
    vendorId = 1; // This should come from auth service

    constructor(
        private invoiceService: InvoiceService,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        this.loadInvoices();
    }

    loadInvoices() {
        this.loading = true;
        this.invoiceService.getInvoicesByVendor(this.vendorId).subscribe({
            next: (data) => {
                this.invoices = data;
                this.loading = false;
            },
            error: () => {
                this.loading = false;
            }
        });
    }

    onUpload(event: any) {
        const file = event.files[0];
        this.invoiceService.uploadInvoice(this.vendorId, file).subscribe({
            next: () => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Invoice uploaded successfully'
                });
                this.loadInvoices();
            },
            error: () => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to upload invoice'
                });
            }
        });
    }

    parseInvoice(id: number) {
        this.invoiceService.parseInvoice(id).subscribe({
            next: () => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Invoice parsed successfully'
                });
                this.loadInvoices();
            },
            error: () => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to parse invoice'
                });
            }
        });
    }

    validateInvoice(id: number) {
        this.invoiceService.validateInvoice(id).subscribe({
            next: () => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Invoice validated successfully'
                });
                this.loadInvoices();
            },
            error: () => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to validate invoice'
                });
            }
        });
    }

    getStatusSeverity(status: InvoiceStatus): 'success' | 'info' | 'warning' | 'danger' | 'secondary' {
        const severityMap: { [key in InvoiceStatus]: 'success' | 'info' | 'warning' | 'danger' | 'secondary' } = {
            'UPLOADED': 'info',
            'PARSED': 'warning',
            'VALIDATED': 'success',
            'VALIDATION_FAILED': 'danger',
            'PENDING_APPROVAL': 'warning',
            'APPROVED': 'success',
            'REJECTED': 'danger',
            'PAYMENT_PROCESSED': 'success',
            'CANCELLED': 'secondary'
        };
        return severityMap[status] || 'secondary';
    }
}