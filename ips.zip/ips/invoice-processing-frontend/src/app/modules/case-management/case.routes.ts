import { Routes } from '@angular/router';

export const CASE_ROUTES: Routes = [
    {
        path: 'list',
        loadComponent: () => import('./components/case-list/case-list.component')
            .then(m => m.CaseListComponent)
    },
    {
        path: 'create',
        loadComponent: () => import('./components/case-create/case-create.component')
            .then(m => m.CaseCreateComponent)
    },
    {
        path: 'detail/:id',
        loadComponent: () => import('./components/case-detail/case-detail.component')
            .then(m => m.CaseDetailComponent)
    },
    {
        path: 'scrutiny/:id',
        loadComponent: () => import('./components/invoice-scrutiny/enhanced-scrutiny-dashboard.component')
            .then(m => m.EnhancedScrutinyDashboardComponent)
    },
    {
        path: '',
        redirectTo: 'list',
        pathMatch: 'full'
    }
];