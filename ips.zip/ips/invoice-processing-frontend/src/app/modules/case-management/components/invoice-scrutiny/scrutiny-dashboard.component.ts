import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CardModule } from 'primeng/card';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { TagModule } from 'primeng/tag';
import { ProgressBarModule } from 'primeng/progressbar';
import { ChartModule } from 'primeng/chart';
import { DialogModule } from 'primeng/dialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AccordionModule } from 'primeng/accordion';
import { ImageModule } from 'primeng/image';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { FormsModule } from '@angular/forms';
import {
    ProofService,
    ScrutinySummary,
    LineItemReview,
    ProofFile,
    RedFlag
} from '../../../../services/proof.service';
import { Table } from 'primeng/table';

interface DimensionGroup {
    signature: string;
    count: number;
    sampleItem: LineItemReview;
    allMatched: boolean;
    allProofsAttached: boolean;
}

@Component({
    selector: 'app-scrutiny-dashboard',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        CardModule,
        TableModule,
        ButtonModule,
        TagModule,
        ProgressBarModule,
        ChartModule,
        DialogModule,
        InputTextareaModule,
        AccordionModule,
        ImageModule,
        ToastModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="grid mb-4">
                <div class="col-12">
                    <p-card>
                        <div class="flex justify-content-between align-items-center mb-3">
                            <div>
                                <h2 class="text-2xl font-bold m-0">Invoice Scrutiny Dashboard</h2>
                                <p class="text-600 mt-1">
                                    Invoice: {{ summary.invoiceNumber }} | Vendor: {{ summary.vendorName }}
                                </p>
                            </div>
                            <div class="flex gap-2">
                                <button pButton label="Approve All Matched" icon="pi pi-check"
                                        class="p-button-success" (click)="bulkApproveMatched()"
                                        [disabled]="summary.perfectMatches === 0"></button>
                                <button pButton label="Export Report" icon="pi pi-download"
                                        class="p-button-secondary" (click)="exportReport()"></button>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="flex justify-content-between mb-2">
                                <span class="font-semibold">Overall Progress</span>
                                <span class="font-semibold">{{ summary.overallProgress }}% Complete</span>
                            </div>
                            <p-progressBar [value]="summary.overallProgress"
                                           [showValue]="false"></p-progressBar>
                        </div>

                        <div class="grid">
                            <div class="col-12 md:col-3">
                                <div class="stat-card stat-total">
                                    <div class="stat-value">{{ summary.totalLineItems }}</div>
                                    <div class="stat-label">Total Items</div>
                                </div>
                            </div>
                            <div class="col-12 md:col-3">
                                <div class="stat-card stat-success">
                                    <div class="stat-value">
                                        {{ summary.perfectMatches }}
                                        <span class="stat-percent">({{ getPercentage(summary.perfectMatches) }}%)</span>
                                    </div>
                                    <div class="stat-label">
                                        <i class="pi pi-check-circle mr-1"></i>
                                        Auto-Verified
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 md:col-3">
                                <div class="stat-card stat-warning">
                                    <div class="stat-value">
                                        {{ summary.toleranceMatches }}
                                        <span class="stat-percent">({{ getPercentage(summary.toleranceMatches) }}%)</span>
                                    </div>
                                    <div class="stat-label">
                                        <i class="pi pi-exclamation-triangle mr-1"></i>
                                        Tolerance Matches
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 md:col-3">
                                <div class="stat-card stat-danger">
                                    <div class="stat-value">
                                        {{ summary.mismatches + summary.missingProofs }}
                                        <span class="stat-percent">({{ getPercentage(summary.mismatches + summary.missingProofs) }}%)</span>
                                    </div>
                                    <div class="stat-label">
                                        <i class="pi pi-times-circle mr-1"></i>
                                        Needs Review
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="efficiency-banner mt-3">
                            <i class="pi pi-clock text-2xl mr-2"></i>
                            <div>
                                <strong>Time Saved: {{ summary.timeSaved }} hours</strong>
                                <p class="text-sm mb-0">
                                    With 90% automation, focus only on {{ summary.mismatches + summary.missingProofs }} exception items
                                </p>
                            </div>
                        </div>
                    </p-card>
                </div>
            </div>

            <div class="grid">
                <div class="col-12">
                    <p-card>
                        <div class="scrutiny-tabs mb-3">
                            <button pButton
                                    [label]="'Exceptions (' + exceptionItems.length + ')'"
                                    [class.active]="activeTab === 'exceptions'"
                                    (click)="activeTab = 'exceptions'"
                                    class="tab-button"></button>
                            <button pButton
                                    [label]="'By Groups (' + dimensionGroups.length + ')'"
                                    [class.active]="activeTab === 'groups'"
                                    (click)="activeTab = 'groups'"
                                    class="tab-button"></button>
                            <button pButton
                                    [label]="'All Items (' + allItems.length + ')'"
                                    [class.active]="activeTab === 'all'"
                                    (click)="activeTab = 'all'"
                                    class="tab-button"></button>
                            <button pButton
                                    [label]="'Red Flags (' + summary.redFlags + ')'"
                                    [class.active]="activeTab === 'flags'"
                                    (click)="activeTab = 'flags'"
                                    [severity]="summary.redFlags > 0 ? 'danger' : 'secondary'"
                                    class="tab-button"></button>
                        </div>

                        <div *ngIf="activeTab === 'exceptions'">
                            <div class="mb-3">
                                <h3 class="text-xl font-semibold">Exception Items - Focus Here First</h3>
                                <p class="text-600">Review only items with mismatches or missing proofs</p>
                            </div>

                            <p-table [value]="exceptionItems" [paginator]="true" [rows]="10"
                                     styleClass="p-datatable-sm">
                                <ng-template pTemplate="header">
                                    <tr>
                                        <th style="width: 3rem">#</th>
                                        <th>Item Description</th>
                                        <th>Match Score</th>
                                        <th>Proofs</th>
                                        <th>Red Flags</th>
                                        <th>Actions</th>
                                    </tr>
                                </ng-template>
                                <ng-template pTemplate="body" let-item let-i="rowIndex">
                                    <tr [class.row-danger]="item.matchScore < 50">
                                        <td>{{ i + 1 }}</td>
                                        <td>
                                            <strong>{{ item.itemDescription }}</strong>
                                        </td>
                                        <td>
                                            <div class="flex align-items-center gap-2">
                                                <div class="match-score-bar"
                                                     [style.width.%]="item.matchScore"
                                                     [class.score-danger]="item.matchScore < 50"
                                                     [class.score-warning]="item.matchScore >= 50 && item.matchScore < 80"
                                                     [class.score-success]="item.matchScore >= 80">
                                                </div>
                                                <span class="font-semibold">{{ item.matchScore }}%</span>
                                            </div>
                                        </td>
                                        <td>
                                            <p-tag [value]="item.proofCount + ' attached'"
                                                   [severity]="item.proofCount > 0 ? 'success' : 'danger'">
                                            </p-tag>
                                        </td>
                                        <td>
                                            <p-tag *ngIf="item.redFlags && item.redFlags.length > 0"
                                                   [value]="item.redFlags.length + ' flag(s)'"
                                                   severity="danger">
                                            </p-tag>
                                            <span *ngIf="!item.redFlags || item.redFlags.length === 0">-</span>
                                        </td>
                                        <td>
                                            <button pButton icon="pi pi-eye" label="Review"
                                                    class="p-button-sm" (click)="reviewItem(item)"></button>
                                        </td>
                                    </tr>
                                </ng-template>
                            </p-table>
                        </div>

                        <div *ngIf="activeTab === 'all'">
                            <p-table #dt [value]="allItems" [paginator]="true" [rows]="20"
                                     [globalFilterFields]="['itemDescription']"
                                     styleClass="p-datatable-sm">
                                <ng-template pTemplate="caption">
                                    <div class="flex">
                    <span class="p-input-icon-left ml-auto">
                      <i class="pi pi-search"></i>
                      <input pInputText type="text"
                             (input)="filterGlobal($event, dt)"
                             placeholder="Search items..." />
                    </span>
                                    </div>
                                </ng-template>
                                <ng-template pTemplate="header">
                                    <tr>
                                        <th style="width: 3rem">#</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Match Score</th>
                                        <th>Proofs</th>
                                        <th>Actions</th>
                                    </tr>
                                </ng-template>
                                <ng-template pTemplate="body" let-item let-i="rowIndex">
                                    <tr>
                                        <td>{{ i + 1 }}</td>
                                        <td>{{ item.itemDescription }}</td>
                                        <td>
                                            <p-tag [value]="item.matchStatus"
                                                   [severity]="getMatchStatusSeverity(item.matchStatus)">
                                            </p-tag>
                                        </td>
                                        <td>{{ item.matchScore }}%</td>
                                        <td>{{ item.proofCount }}</td>
                                        <td>
                                            <button pButton icon="pi pi-eye"
                                                    class="p-button-text p-button-sm"
                                                    (click)="reviewItem(item)"></button>
                                        </td>
                                    </tr>
                                </ng-template>
                            </p-table>
                        </div>

                    </p-card>
                </div>
            </div>
        </div>

        <p-dialog [(visible)]="reviewDialog" [header]="'Review: ' + reviewingItem?.itemDescription"
                  [modal]="true" [maximizable]="true" [style]="{width: '90vw'}">
            <div *ngIf="reviewingItem" class="review-content">
                <div class="grid">
                    <div class="col-12 md:col-6">
                        <p-card header="Dimension Comparison">
                            <p-table [value]="reviewingItem.matchResult?.comparisons || []"
                                     styleClass="p-datatable-sm">
                                <ng-template pTemplate="header">
                                    <tr>
                                        <th>Dimension</th>
                                        <th>Expected</th>
                                        <th>Actual</th>
                                        <th>Status</th>
                                    </tr>
                                </ng-template>
                                <ng-template pTemplate="body" let-comp>
                                    <tr [class.bg-red-50]="comp.redFlag">
                                        <td><strong>{{ comp.dimensionName }}</strong></td>
                                        <td>{{ comp.expectedValue }}</td>
                                        <td>{{ comp.actualValue }}</td>
                                        <td>
                                            <p-tag [value]="comp.matchStatus"
                                                   [severity]="getComparisonSeverity(comp.matchStatus)">
                                            </p-tag>
                                            <span *ngIf="comp.variancePercentage" class="ml-2 text-sm">
                        ({{ comp.variancePercentage.toFixed(1) }}% variance)
                      </span>
                                        </td>
                                    </tr>
                                </ng-template>
                            </p-table>
                        </p-card>
                    </div>

                    <div class="col-12 md:col-6">
                        <p-card header="Proof Documents">
                            <div class="proofs-gallery">
                                <div *ngFor="let proof of reviewingItem.proofs"
                                     class="proof-preview-card">
                                    <img [src]="proof.thumbnailPath || 'assets/placeholder.png'" [alt]="proof.fileName"
                                         class="proof-thumbnail" (click)="viewLargeProof(proof)" />
                                    <div class="proof-info">
                                        <p class="text-sm font-semibold">{{ proof.fileName }}</p>
                                        <p class="text-xs text-600" *ngIf="proof.publicationName">
                                            {{ proof.publicationName }} - {{ proof.publicationDate | date }}
                                        </p>
                                        <p-tag [value]="proof.verificationStatus"
                                               [severity]="getProofStatusSeverity(proof.verificationStatus)">
                                        </p-tag>
                                    </div>
                                </div>
                            </div>

                            <div *ngIf="reviewingItem.proofCount === 0"
                                 class="text-center py-4 text-red-600">
                                <i class="pi pi-exclamation-triangle text-4xl mb-2"></i>
                                <p>No proofs attached - Follow up with vendor</p>
                            </div>
                        </p-card>
                    </div>

                    <div class="col-12">
                        <p-card header="Review Comments">
              <textarea pInputTextarea [(ngModel)]="reviewComments"
                        rows="4" class="w-full"
                        placeholder="Add comments about this review..."></textarea>
                        </p-card>
                    </div>
                </div>
            </div>

            <ng-template pTemplate="footer">
                <button pButton label="Reject" icon="pi pi-times"
                        class="p-button-danger" (click)="rejectItem()"></button>
                <button pButton label="Request Clarification" icon="pi pi-question"
                        class="p-button-warning" (click)="requestClarification()"></button>
                <button pButton label="Approve" icon="pi pi-check"
                        class="p-button-success" (click)="approveItem()"></button>
            </ng-template>
        </p-dialog>

        <p-toast></p-toast>
    `,
    styles: [`
      .stat-card {
        padding: 1.5rem;
        border-radius: 8px;
        text-align: center;
      }
      .stat-value {
        font-size: 2rem;
        font-weight: bold;
        margin-bottom: 0.5rem;
      }
      .stat-percent {
        font-size: 1rem;
        opacity: 0.8;
      }
      .stat-label {
        font-size: 0.875rem;
        color: #64748b;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .stat-total { background: #f8f9fa; color: #1e293b; }
      .stat-success { background: #d1fae5; color: #065f46; }
      .stat-warning { background: #fef3c7; color: #92400e; }
      .stat-danger { background: #fee2e2; color: #991b1b; }
      .efficiency-banner {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1rem;
        border-radius: 8px;
        display: flex;
        align-items: center;
      }
      .scrutiny-tabs {
        display: flex;
        gap: 0.5rem;
        border-bottom: 2px solid #e2e8f0;
        padding-bottom: 0.5rem;
      }
      .tab-button {
        background: transparent !important;
        border: none !important;
        color: #64748b !important;
      }
      .tab-button.active {
        color: #3b82f6 !important;
        border-bottom: 2px solid #3b82f6 !important;
      }
      .match-score-bar {
        height: 8px;
        border-radius: 4px;
        min-width: 20px;
      }
      .score-success { background: #22c55e; }
      .score-warning { background: #f59e0b; }
      .score-danger { background: #ef4444; }
      .row-danger {
        background-color: #fee2e2 !important;
      }
      .group-content {
        padding: 1rem;
      }
      .sample-item {
        border-left: 4px solid #3b82f6;
      }
      .flag-item {
        border-left: 4px solid #ef4444;
      }
      .flag-detail {
        display: flex;
        align-items: center;
      }
      .proofs-gallery {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 1rem;
      }
      .proof-preview-card {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        overflow: hidden;
      }
      .proof-thumbnail {
        width: 100%;
        height: 120px;
        object-fit: cover;
        cursor: pointer;
      }
      .proof-info {
        padding: 0.5rem;
      }
      :host ::ng-deep {
        .p-datatable .p-datatable-tbody > tr.row-danger > td {
          background-color: #fee2e2 !important;
        }
      }
    `]
})
export class ScrutinyDashboardComponent implements OnInit {
    invoiceId!: number;

    summary: ScrutinySummary = {
        invoiceId: 0,
        invoiceNumber: '',
        vendorName: '',
        totalLineItems: 0,
        perfectMatches: 0,
        toleranceMatches: 0,
        mismatches: 0,
        missingProofs: 0,
        redFlags: 0,
        overallProgress: 0,
        timeSaved: 0
    };

    allItems: LineItemReview[] = [];
    exceptionItems: LineItemReview[] = [];
    dimensionGroups: DimensionGroup[] = [];

    activeTab = 'exceptions';
    reviewDialog = false;
    reviewingItem: LineItemReview | null = null;
    reviewComments = '';

    constructor(
        private route: ActivatedRoute,
        private messageService: MessageService,
        private proofService: ProofService
    ) {}

    ngOnInit() {
        this.invoiceId = +this.route.snapshot.params['id'];
        this.loadScrutinyData();
    }

    loadScrutinyData() {
        this.proofService.getScrutinySummary(this.invoiceId).subscribe(summary => {
            this.summary = summary;
        });

        this.loadAllItems();
        this.loadExceptionItems();
        this.loadDimensionGroups();
    }

    loadAllItems() {
        this.proofService.getAllLineItemsForReview(this.invoiceId).subscribe(items => {
            this.allItems = items;
        });
    }

    loadExceptionItems() {
        this.proofService.getReviewQueue(this.invoiceId).subscribe(items => {
            this.exceptionItems = items;
        });
    }

    loadDimensionGroups() {
        // TODO: API call - get grouped items
    }

    reviewItem(item: LineItemReview) {
        this.reviewingItem = item;
        this.reviewComments = '';
        this.reviewDialog = true;
    }

    approveItem() {
        this.messageService.add({
            severity: 'success',
            summary: 'Approved',
            detail: 'Line item approved successfully'
        });
        this.reviewDialog = false;
    }

    rejectItem() {
        this.messageService.add({
            severity: 'error',
            summary: 'Rejected',
            detail: 'Line item rejected'
        });
        this.reviewDialog = false;
    }

    requestClarification() {
        this.messageService.add({
            severity: 'info',
            summary: 'Clarification Requested',
            detail: 'Vendor will be notified'
        });
        this.reviewDialog = false;
    }

    bulkApproveMatched() {
        this.messageService.add({
            severity: 'success',
            summary: 'Bulk Approved',
            detail: `${this.summary.perfectMatches} items approved automatically`
        });
    }

    bulkApproveGroup(group: DimensionGroup) {
        this.messageService.add({
            severity: 'success',
            summary: 'Group Approved',
            detail: `${group.count} similar items approved`
        });
    }

    exportReport() {
        this.messageService.add({
            severity: 'info',
            summary: 'Exporting',
            detail: 'Scrutiny report is being generated'
        });
    }

    getPercentage(count: number): number {
        if (!this.summary.totalLineItems) return 0;
        return Math.round((count / this.summary.totalLineItems) * 100);
    }

    getMatchStatusSeverity(status: string): 'success' | 'info' | 'warning' | 'danger' {
        switch (status) {
            case 'EXACT_MATCH': return 'success';
            case 'WITHIN_TOLERANCE': return 'warning';
            case 'MISMATCH': return 'danger';
            default: return 'info';
        }
    }

    getComparisonSeverity(status: string): 'success' | 'info' | 'warning' | 'danger' {
        return this.getMatchStatusSeverity(status);
    }

    getProofStatusSeverity(status: string | undefined): 'success' | 'info' | 'warning' {
        switch (status || 'PENDING') {
            case 'VERIFIED':
            case 'AUTO_VERIFIED':
                return 'success';
            case 'PENDING':
                return 'info';
            default:
                return 'warning';
        }
    }

    getFlaggedItems(): LineItemReview[] {
        return this.allItems.filter(item => item.redFlags && item.redFlags.length > 0);
    }

    filterGlobal(event: Event, dt: Table) {
        const input = event.target as HTMLInputElement | null;
        if (input) {
            dt.filterGlobal(input.value, 'contains');
        }
    }

    viewLargeProof(proof: ProofFile) {
        // Open proof in large view
    }
}