import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CardModule } from 'primeng/card';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { BadgeModule } from 'primeng/badge';
import { TagModule } from 'primeng/tag';
import { ProgressBarModule } from 'primeng/progressbar';
import { DialogModule } from 'primeng/dialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { CheckboxModule } from 'primeng/checkbox';
import { AccordionModule } from 'primeng/accordion';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { TabViewModule } from 'primeng/tabview';
import { DividerModule } from 'primeng/divider';

interface InvoiceLineItem {
    id: number;
    description: string;
    product: string;
    taxableValue: number;
    dimensions: any;
    proofCount: number;
    autoMatchScore: number;
    requiresReview: boolean;
    redFlagCount: number;
    matchStatus: 'PERFECT' | 'TOLERANCE' | 'MISMATCH' | 'NO_PROOF';
    redFlags: string[];
}

@Component({
    selector: 'app-enhanced-scrutiny',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        CardModule,
        TableModule,
        ButtonModule,
        TagModule,
        ProgressBarModule,
        DialogModule,
        InputTextareaModule,
        CheckboxModule,
        AccordionModule,
        ToastModule,
        TabViewModule,
        DividerModule,
        BadgeModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <!-- Header with Smart Insights -->
            <div class="card mb-3" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <div class="flex justify-content-between align-items-center mb-3">
                    <div>
                        <h2 class="text-3xl font-bold m-0">AI-Powered Invoice Scrutiny</h2>
                        <p class="mt-2 mb-0">Invoice: {{ invoiceNumber }} | Vendor: {{ vendorName }}</p>
                    </div>
                    <div class="text-right">
                        <div class="text-sm opacity-90">AI Confidence Score</div>
                        <div class="text-4xl font-bold">{{ overallConfidence }}%</div>
                    </div>
                </div>

                <!-- Smart Progress Bar -->
                <div class="mt-3">
                    <div class="flex justify-content-between mb-2">
                        <span class="font-semibold">Automated Scrutiny Progress</span>
                        <span class="font-semibold">{{ scrutinyProgress }}% Complete</span>
                    </div>
                    <p-progressBar [value]="scrutinyProgress" [showValue]="false"></p-progressBar>
                    <div class="flex justify-content-between mt-2 text-sm opacity-90">
                        <span>{{ processedItems }}/{{ totalItems }} items processed</span>
                        <span>⚡ {{ timeSaved }}min saved by AI</span>
                    </div>
                </div>
            </div>

            <!-- Quick Action Bar -->
            <div class="card mb-3">
                <div class="flex gap-2 flex-wrap">
                    <button pButton label="Approve All Perfect Matches ({{ perfectMatchCount }})" 
                            icon="pi pi-check-circle"
                            class="p-button-success"
                            [disabled]="perfectMatchCount === 0"
                            (click)="bulkApprovePerfect()"></button>
                    <button pButton label="Smart Group Review" 
                            icon="pi pi-objects-column"
                            class="p-button-info"
                            (click)="activeTab = 1"></button>
                    <button pButton pBadge
                            label="AI Recommendations"
                            icon="pi pi-bolt"
                            class="p-button-warning"
                            [value]="aiRecommendations"
                            (click)="showAIRecommendations()"></button>
                    <button pButton label="Export Report" 
                            icon="pi pi-download"
                            class="p-button-secondary"
                            (click)="exportReport()"></button>
                    <button pButton label="Final Approval" 
                            icon="pi pi-thumbs-up"
                            class="p-button-lg"
                            [disabled]="hasUnresolvedFlags"
                            (click)="finalApproval()"></button>
                </div>
            </div>

            <!-- Smart Summary Cards -->
            <div class="grid mb-3">
                <div class="col-12 md:col-3">
                    <div class="card mb-0 bg-green-50">
                        <div class="text-green-800">
                            <div class="flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-sm font-semibold mb-1">✓ Perfect Matches</div>
                                    <div class="text-3xl font-bold">{{ perfectMatchCount }}</div>
                                    <div class="text-xs mt-1">Auto-approvable</div>
                                </div>
                                <i class="pi pi-check-circle text-4xl opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 bg-yellow-50">
                        <div class="text-yellow-800">
                            <div class="flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-sm font-semibold mb-1">⚠ Tolerance Matches</div>
                                    <div class="text-3xl font-bold">{{ toleranceMatchCount }}</div>
                                    <div class="text-xs mt-1">Within 5% variance</div>
                                </div>
                                <i class="pi pi-exclamation-triangle text-4xl opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 bg-red-50">
                        <div class="text-red-800">
                            <div class="flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-sm font-semibold mb-1">🚩 Critical Issues</div>
                                    <div class="text-3xl font-bold">{{ criticalIssuesCount }}</div>
                                    <div class="text-xs mt-1">Needs attention</div>
                                </div>
                                <i class="pi pi-times-circle text-4xl opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 bg-blue-50">
                        <div class="text-blue-800">
                            <div class="flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-sm font-semibold mb-1">📎 Total Proofs</div>
                                    <div class="text-3xl font-bold">{{ totalProofs }}</div>
                                    <div class="text-xs mt-1">Documents attached</div>
                                </div>
                                <i class="pi pi-paperclip text-4xl opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabbed Interface -->
            <p-tabView [(activeIndex)]="activeTab">
                <!-- Tab 1: Exception Items -->
                <p-tabPanel header="Priority Review Queue" leftIcon="pi pi-exclamation-circle">
                    <div class="card">
                        <div class="mb-3">
                            <div class="flex align-items-center gap-2 mb-2">
                                <i class="pi pi-info-circle text-blue-500"></i>
                                <span class="font-semibold">Smart Tip:</span>
                                <span class="text-sm text-600">Items sorted by AI confidence - review red flags first</span>
                            </div>
                        </div>

                        <p-table [value]="exceptionItems" 
                                 [rowHover]="true"
                                 responsiveLayout="scroll"
                                 styleClass="p-datatable-sm">
                            <ng-template pTemplate="header">
                                <tr>
                                    <th style="width: 50px">Status</th>
                                    <th>Item Description</th>
                                    <th>Amount (₹)</th>
                                    <th>Match Score</th>
                                    <th>Red Flags</th>
                                    <th>Proofs</th>
                                    <th style="width: 150px">Actions</th>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="body" let-item>
                                <tr [class.row-critical]="item.redFlagCount > 1">
                                    <td>
                                        <i [class]="getStatusIcon(item.matchStatus)" 
                                           [style.color]="getStatusColor(item.matchStatus)"></i>
                                    </td>
                                    <td>
                                        <div class="font-semibold">{{ item.description }}</div>
                                        <div class="text-xs text-600">Product: {{ item.product }}</div>
                                    </td>
                                    <td>₹{{ item.taxableValue | number:'1.2-2' }}</td>
                                    <td>
                                        <div class="flex align-items-center gap-2">
                                            <div class="progress-bar-sm" 
                                                 [style.width.%]="item.autoMatchScore"
                                                 [class.bg-success]="item.autoMatchScore >= 90"
                                                 [class.bg-warning]="item.autoMatchScore >= 60 && item.autoMatchScore < 90"
                                                 [class.bg-danger]="item.autoMatchScore < 60"></div>
                                            <span class="text-sm">{{ item.autoMatchScore }}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <p-tag *ngIf="item.redFlagCount > 0" 
                                               [value]="item.redFlagCount + ' Flag' + (item.redFlagCount > 1 ? 's' : '')"
                                               severity="danger"></p-tag>
                                        <span *ngIf="item.redFlagCount === 0" class="text-green-600">
                                            <i class="pi pi-check"></i> Clean
                                        </span>
                                    </td>
                                    <td>
                                        <p-tag [value]="item.proofCount + ' Docs'" 
                                               [severity]="item.proofCount > 0 ? 'success' : 'danger'"></p-tag>
                                    </td>
                                    <td>
                                        <div class="flex gap-1">
                                            <button pButton icon="pi pi-eye" 
                                                    class="p-button-text p-button-sm"
                                                    pTooltip="Review Details"
                                                    (click)="reviewItem(item)"></button>
                                            <button pButton icon="pi pi-check" 
                                                    class="p-button-text p-button-sm p-button-success"
                                                    pTooltip="Quick Approve"
                                                    [disabled]="item.redFlagCount > 0"
                                                    (click)="quickApprove(item)"></button>
                                            <button pButton icon="pi pi-times" 
                                                    class="p-button-text p-button-sm p-button-danger"
                                                    pTooltip="Reject"
                                                    (click)="rejectItem(item)"></button>
                                        </div>
                                    </td>
                                </tr>
                            </ng-template>
                        </p-table>
                    </div>
                </p-tabPanel>

                <!-- Tab 2: Grouped Review -->
                <p-tabPanel header="Smart Group Review" leftIcon="pi pi-objects-column">
                    <div class="card">
                        <div class="mb-3">
                            <div class="flex align-items-center gap-2 mb-2">
                                <i class="pi pi-lightbulb text-yellow-500"></i>
                                <span class="font-semibold">AI Insight:</span>
                                <span class="text-sm text-600">{{ groupedItems.length }} similar item groups detected - approve in bulk!</span>
                            </div>
                        </div>

                        <p-accordion [multiple]="true">
                            <p-accordionTab *ngFor="let group of groupedItems; let i = index"
                                           [header]="'Group ' + (i + 1) + ': ' + group.signature + ' (' + group.count + ' items)'">
                                <div class="p-3">
                                    <div class="grid mb-3">
                                        <div class="col-12 md:col-6">
                                            <div class="text-sm">
                                                <strong>Common Dimensions:</strong>
                                                <ul class="mt-2">
                                                    <li *ngFor="let dim of group.commonDimensions">
                                                        {{ dim.key }}: {{ dim.value }}
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-12 md:col-6">
                                            <div class="text-sm">
                                                <strong>Group Status:</strong>
                                                <ul class="mt-2">
                                                    <li>All Matched: <p-tag [value]="group.allMatched ? 'Yes' : 'No'" 
                                                                            [severity]="group.allMatched ? 'success' : 'warning'"></p-tag></li>
                                                    <li>All Proofs Attached: <p-tag [value]="group.allProofsAttached ? 'Yes' : 'No'" 
                                                                                    [severity]="group.allProofsAttached ? 'success' : 'warning'"></p-tag></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <p-divider></p-divider>

                                    <div class="flex justify-content-between align-items-center">
                                        <span class="text-sm text-600">{{ group.items.length }} items in this group</span>
                                        <button pButton label="Approve Entire Group" 
                                                icon="pi pi-check-circle"
                                                class="p-button-success p-button-sm"
                                                [disabled]="!group.allMatched || !group.allProofsAttached"
                                                (click)="approveGroup(group)"></button>
                                    </div>
                                </div>
                            </p-accordionTab>
                        </p-accordion>
                    </div>
                </p-tabPanel>

                <!-- Tab 3: All Items -->
                <p-tabPanel header="All Line Items" leftIcon="pi pi-list">
                    <div class="card">
                        <p-table [value]="allItems" 
                                 [rows]="10"
                                 [paginator]="true"
                                 responsiveLayout="scroll">
                            <ng-template pTemplate="header">
                                <tr>
                                    <th>
                                        <p-checkbox [(ngModel)]="selectAll" 
                                                   [binary]="true"
                                                   (onChange)="toggleSelectAll()"></p-checkbox>
                                    </th>
                                    <th>Description</th>
                                    <th>Amount (₹)</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="body" let-item>
                                <tr>
                                    <td>
                                        <p-checkbox [(ngModel)]="item.selected" [binary]="true"></p-checkbox>
                                    </td>
                                    <td>{{ item.description }}</td>
                                    <td>₹{{ item.taxableValue | number:'1.2-2' }}</td>
                                    <td>
                                        <p-tag [value]="item.matchStatus" 
                                               [severity]="getMatchStatusSeverity(item.matchStatus)"></p-tag>
                                    </td>
                                    <td>
                                        <button pButton icon="pi pi-eye" 
                                                class="p-button-text p-button-sm"
                                                (click)="reviewItem(item)"></button>
                                    </td>
                                </tr>
                            </ng-template>
                        </p-table>
                    </div>
                </p-tabPanel>

                <!-- Tab 4: AI Insights -->
                <p-tabPanel header="AI Insights & Analytics" leftIcon="pi pi-chart-line">
                    <div class="grid">
                        <div class="col-12 md:col-6">
                            <div class="card">
                                <h4>Key Findings</h4>
                                <ul class="list-none p-0">
                                    <li class="mb-3 p-3 bg-green-50 border-round">
                                        <i class="pi pi-check-circle text-green-600 mr-2"></i>
                                        <strong>{{ perfectMatchCount }} items ({{ (perfectMatchCount/totalItems*100).toFixed(0) }}%)</strong> 
                                        match perfectly with case requirements
                                    </li>
                                    <li class="mb-3 p-3 bg-yellow-50 border-round">
                                        <i class="pi pi-exclamation-triangle text-yellow-600 mr-2"></i>
                                        <strong>{{ toleranceMatchCount }} items</strong> have minor variances within acceptable tolerance
                                    </li>
                                    <li class="mb-3 p-3 bg-red-50 border-round">
                                        <i class="pi pi-times-circle text-red-600 mr-2"></i>
                                        <strong>{{ criticalIssuesCount }} items</strong> require manual verification
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-12 md:col-6">
                            <div class="card">
                                <h4>Efficiency Metrics</h4>
                                <div class="mb-4">
                                    <div class="flex justify-content-between mb-2">
                                        <span>Automation Rate</span>
                                        <span class="font-bold text-primary">{{ automationRate }}%</span>
                                    </div>
                                    <p-progressBar [value]="automationRate" [showValue]="false"></p-progressBar>
                                </div>
                                <div class="mb-4">
                                    <div class="flex justify-content-between mb-2">
                                        <span>Time Saved</span>
                                        <span class="font-bold text-green-600">{{ timeSaved }} minutes</span>
                                    </div>
                                    <p class="text-sm text-600">Traditional review would take {{ traditionalTime }} minutes</p>
                                </div>
                                <div class="p-3 bg-blue-50 border-round">
                                    <i class="pi pi-info-circle text-blue-600 mr-2"></i>
                                    <span class="text-sm">AI has reduced manual review effort by <strong>{{ efficiencyGain }}%</strong></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </p-tabPanel>
            </p-tabView>

            <!-- Review Dialog -->
            <p-dialog header="Review Line Item" [(visible)]="reviewDialog" 
                     [modal]="true" [style]="{width: '70vw'}" [draggable]="false">
                <div *ngIf="selectedItem" class="grid">
                    <div class="col-12 md:col-8">
                        <h4>Item Details</h4>
                        <table class="w-full">
                            <tr>
                                <td class="font-semibold p-2">Description:</td>
                                <td class="p-2">{{ selectedItem.description }}</td>
                            </tr>
                            <tr>
                                <td class="font-semibold p-2">Product:</td>
                                <td class="p-2">{{ selectedItem.product }}</td>
                            </tr>
                            <tr>
                                <td class="font-semibold p-2">Taxable Value:</td>
                                <td class="p-2">₹{{ selectedItem.taxableValue | number:'1.2-2' }}</td>
                            </tr>
                        </table>

                        <h4 class="mt-4">Dimensions</h4>
                        <div class="p-3 bg-gray-50 border-round">
                            <div *ngFor="let dim of parseDimensions(selectedItem.dimensions)" class="mb-2">
                                <strong>{{ dim.key }}:</strong> {{ dim.value }}
                            </div>
                        </div>

                        <h4 class="mt-4">Red Flags</h4>
                        <div *ngIf="selectedItem.redFlags && selectedItem.redFlags.length > 0">
                            <div *ngFor="let flag of selectedItem.redFlags" 
                                 class="p-3 mb-2 bg-red-50 border-round border-left-3 border-red-500">
                                <i class="pi pi-exclamation-triangle text-red-600 mr-2"></i>
                                {{ flag }}
                            </div>
                        </div>
                        <div *ngIf="!selectedItem.redFlags || selectedItem.redFlags.length === 0" 
                             class="p-3 bg-green-50 border-round">
                            <i class="pi pi-check-circle text-green-600 mr-2"></i>
                            No red flags detected
                        </div>
                    </div>

                    <div class="col-12 md:col-4">
                        <h4>AI Analysis</h4>
                        <div class="card bg-blue-50 mb-3">
                            <div class="text-center">
                                <div class="text-4xl font-bold text-primary mb-2">{{ selectedItem.autoMatchScore }}%</div>
                                <div class="text-sm">Match Confidence</div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <strong>Attached Proofs:</strong>
                            <p-tag [value]="selectedItem.proofCount + ' documents'" 
                                   [severity]="selectedItem.proofCount > 0 ? 'success' : 'danger'"
                                   class="mt-2"></p-tag>
                        </div>
                    </div>
                </div>

                <div class="mt-4">
                    <label for="comments" class="font-semibold">Comments/Remarks</label>
                    <textarea pInputTextarea id="comments" [(ngModel)]="reviewComments" 
                              rows="3" class="w-full mt-2"></textarea>
                </div>

                <ng-template pTemplate="footer">
                    <button pButton label="Reject" icon="pi pi-times" 
                            class="p-button-danger" (click)="rejectWithComments()"></button>
                    <button pButton label="Request Clarification" icon="pi pi-comment" 
                            class="p-button-warning" (click)="requestClarification()"></button>
                    <button pButton label="Approve" icon="pi pi-check" 
                            class="p-button-success" (click)="approveWithComments()"></button>
                </ng-template>
            </p-dialog>
        </div>
    `,
    styles: [`
        .row-critical {
            background-color: #fee2e2 !important;
            border-left: 4px solid #ef4444;
        }
        .progress-bar-sm {
            height: 8px;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        .bg-success { background: linear-gradient(90deg, #10b981, #059669); }
        .bg-warning { background: linear-gradient(90deg, #f59e0b, #d97706); }
        .bg-danger { background: linear-gradient(90deg, #ef4444, #dc2626); }
        :host ::ng-deep {
            .p-tabview-nav-link {
                font-weight: 600;
            }
        }
    `]
})
export class EnhancedScrutinyDashboardComponent implements OnInit {
    invoiceNumber = 'INV-TOI-2025-1234';
    vendorName = 'Times of India Publications';
    overallConfidence = 78;
    scrutinyProgress = 65;
    processedItems = 4;
    totalItems = 6;
    timeSaved = 45;

    perfectMatchCount = 1;
    toleranceMatchCount = 1;
    criticalIssuesCount = 3;
    totalProofs = 5;
    aiRecommendations = 3;
    hasUnresolvedFlags = true;

    automationRate = 85;
    traditionalTime = 120;
    efficiencyGain = 62;

    activeTab = 0;
    reviewDialog = false;
    selectedItem: InvoiceLineItem | null = null;
    reviewComments = '';
    selectAll = false;

    allItems: InvoiceLineItem[] = [];
    exceptionItems: InvoiceLineItem[] = [];
    groupedItems: any[] = [];

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        this.loadInvoiceData();
    }

    loadInvoiceData() {
        // Mock data - in real app, load from API
        this.allItems = [
            {
                id: 1,
                description: 'TOI Mumbai Main Edition - Page 3',
                product: 'Print Advertisement',
                taxableValue: 35000,
                dimensions: { publication: 'Times of India Mumbai', page: '3', size: 200 },
                proofCount: 2,
                autoMatchScore: 100,
                requiresReview: false,
                redFlagCount: 0,
                matchStatus: 'PERFECT',
                redFlags: []
            },
            {
                id: 2,
                description: 'TOI Delhi Edition - Page 5',
                product: 'Print Advertisement',
                taxableValue: 31500,
                dimensions: { publication: 'Times of India Delhi', page: '5', size: 178 },
                proofCount: 1,
                autoMatchScore: 95,
                requiresReview: true,
                redFlagCount: 0,
                matchStatus: 'TOLERANCE',
                redFlags: []
            },
            {
                id: 3,
                description: 'Economic Times - Page 2',
                product: 'Print Advertisement',
                taxableValue: 28000,
                dimensions: { publication: 'Economic Times', page: '2', size: 150 },
                proofCount: 1,
                autoMatchScore: 60,
                requiresReview: true,
                redFlagCount: 1,
                matchStatus: 'MISMATCH',
                redFlags: ['Price exceeds approved rate by 15%']
            },
            {
                id: 4,
                description: 'Hindustan Times - Page 1',
                product: 'Print Advertisement',
                taxableValue: 42000,
                dimensions: { publication: 'Hindustan Times', page: '1', size: 250 },
                proofCount: 0,
                autoMatchScore: 0,
                requiresReview: true,
                redFlagCount: 2,
                matchStatus: 'NO_PROOF',
                redFlags: ['No proof documents attached', 'Item not found in case']
            },
            {
                id: 5,
                description: 'TOI Mumbai - Page 7 (Case says Page 3)',
                product: 'Print Advertisement',
                taxableValue: 35000,
                dimensions: { publication: 'Times of India Mumbai', page: '7', size: 200 },
                proofCount: 1,
                autoMatchScore: 40,
                requiresReview: true,
                redFlagCount: 1,
                matchStatus: 'MISMATCH',
                redFlags: ['Page number mismatch: Invoice shows Page 7, Case requires Page 3']
            },
            {
                id: 6,
                description: 'Indian Express - Not in Case',
                product: 'Print Advertisement',
                taxableValue: 38000,
                dimensions: { publication: 'Indian Express', page: '4', size: 220 },
                proofCount: 1,
                autoMatchScore: 0,
                requiresReview: true,
                redFlagCount: 3,
                matchStatus: 'MISMATCH',
                redFlags: [
                    'Item not found in approved case',
                    'Vendor not authorized for this publication',
                    'Price verification pending'
                ]
            }
        ];

        this.exceptionItems = this.allItems.filter(item => item.requiresReview);
        this.createSmartGroups();
    }

    createSmartGroups() {
        // Group similar items for bulk processing
        this.groupedItems = [
            {
                signature: 'TOI Print Ads - Page 3, 200 sqcm',
                count: 2,
                allMatched: false,
                allProofsAttached: true,
                commonDimensions: [
                    { key: 'Publication', value: 'Times of India' },
                    { key: 'Size', value: '200 sqcm' }
                ],
                items: [this.allItems[0], this.allItems[4]]
            }
        ];
    }

    getStatusIcon(status: string): string {
        const icons: any = {
            'PERFECT': 'pi pi-check-circle',
            'TOLERANCE': 'pi pi-exclamation-triangle',
            'MISMATCH': 'pi pi-times-circle',
            'NO_PROOF': 'pi pi-ban'
        };
        return icons[status] || 'pi pi-question-circle';
    }

    getStatusColor(status: string): string {
        const colors: any = {
            'PERFECT': '#10b981',
            'TOLERANCE': '#f59e0b',
            'MISMATCH': '#ef4444',
            'NO_PROOF': '#dc2626'
        };
        return colors[status] || '#6b7280';
    }

    getMatchStatusSeverity(status: string): 'success' | 'warning' | 'danger' {
        const map: any = {
            'PERFECT': 'success',
            'TOLERANCE': 'warning',
            'MISMATCH': 'danger',
            'NO_PROOF': 'danger'
        };
        return map[status] || 'info';
    }

    parseDimensions(dimensions: any): any[] {
        return Object.keys(dimensions).map(key => ({ key, value: dimensions[key] }));
    }

    reviewItem(item: InvoiceLineItem) {
        this.selectedItem = item;
        this.reviewComments = '';
        this.reviewDialog = true;
    }

    quickApprove(item: InvoiceLineItem) {
        this.messageService.add({
            severity: 'success',
            summary: 'Approved',
            detail: `Item ${item.id} approved successfully`
        });
    }

    rejectItem(item: InvoiceLineItem) {
        if (confirm('Are you sure you want to reject this item?')) {
            this.messageService.add({
                severity: 'error',
                summary: 'Rejected',
                detail: `Item ${item.id} rejected`
            });
        }
    }

    approveWithComments() {
        this.messageService.add({
            severity: 'success',
            summary: 'Approved',
            detail: 'Item approved with comments'
        });
        this.reviewDialog = false;
    }

    rejectWithComments() {
        this.messageService.add({
            severity: 'error',
            summary: 'Rejected',
            detail: 'Item rejected with comments'
        });
        this.reviewDialog = false;
    }

    requestClarification() {
        this.messageService.add({
            severity: 'info',
            summary: 'Clarification Requested',
            detail: 'Vendor will be notified'
        });
        this.reviewDialog = false;
    }

    bulkApprovePerfect() {
        if (confirm(`Approve all ${this.perfectMatchCount} perfect matches?`)) {
            this.messageService.add({
                severity: 'success',
                summary: 'Bulk Approved',
                detail: `${this.perfectMatchCount} items approved automatically`
            });
        }
    }

    approveGroup(group: any) {
        this.messageService.add({
            severity: 'success',
            summary: 'Group Approved',
            detail: `${group.count} items approved`
        });
    }

    showAIRecommendations() {
        alert('AI Recommendations:\n\n1. Approve all perfect matches immediately\n2. Review tolerance items in bulk\n3. Request clarification for items with missing proofs');
    }

    exportReport() {
        this.messageService.add({
            severity: 'info',
            summary: 'Exporting',
            detail: 'Detailed scrutiny report is being generated'
        });
    }

    finalApproval() {
        if (confirm('Approve this invoice for payment processing?')) {
            this.messageService.add({
                severity: 'success',
                summary: 'Invoice Approved',
                detail: 'Invoice forwarded to payment processing'
            });
            setTimeout(() => this.router.navigate(['/cases/list']), 1500);
        }
    }

    toggleSelectAll() {
        //this.allItems.forEach(item => item.selected = this.selectAll);
    }
}