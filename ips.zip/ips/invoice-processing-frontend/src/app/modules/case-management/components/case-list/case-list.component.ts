import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { CaseService } from '../../../../services/case.service';
import { AuthService } from '../../../../services/auth.service';
import { ProcurementCase, CaseStatus } from '../../../../models/case.model';

@Component({
    selector: 'app-case-list',
    standalone: true,
    imports: [CommonModule, TableModule, ButtonModule, TagModule, ToastModule],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-2xl font-bold m-0">Procurement Cases</h2>
                    <button
                            *ngIf="isMaker"
                            pButton
                            label="Create Case"
                            icon="pi pi-plus"
                            routerLink="/cases/create">
                    </button>
                </div>

                <p-table
                        [value]="cases"
                        [loading]="loading"
                        [paginator]="true"
                        [rows]="10"
                        styleClass="p-datatable-striped">
                    <ng-template pTemplate="header">
                        <tr>
                            <th>Case Number</th>
                            <th>Case Name</th>
                            <th>Department</th>
                            <th>Budget (₹)</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="body" let-case>
                        <tr>
                            <td><strong>{{ case.caseNumber }}</strong></td>
                            <td>{{ case.caseName }}</td>
                            <td>{{ case.departmentName }}</td>
                            <td>₹ {{ case.totalApprovedBudget | number:'1.2-2' }}</td>
                            <td>
                                <p-tag
                                        *ngIf="case.caseStatus"
                                        [value]="case.caseStatus"
                                        [severity]="getStatusSeverity(case.caseStatus)">
                                </p-tag>
                            </td>
                            <td>{{ case.createdAt | date:'short' }}</td>
                            <td>
                                <button
                                        pButton
                                        icon="pi pi-eye"
                                        class="p-button-text p-button-sm mr-2"
                                        (click)="viewCase(case.id!)">
                                </button>
                                <button
                                        *ngIf="isChecker && case.caseStatus === 'SUBMITTED'"
                                        pButton
                                        label="Review"
                                        icon="pi pi-check"
                                        class="p-button-sm p-button-success"
                                        (click)="viewCase(case.id!)">
                                </button>
                            </td>
                        </tr>
                    </ng-template>
                </p-table>
            </div>
            <p-toast></p-toast>
        </div>
    `
})
export class CaseListComponent implements OnInit {
    cases: ProcurementCase[] = [];
    loading = false;
    isMaker = false;
    isChecker = false;

    constructor(
        private caseService: CaseService,
        private authService: AuthService,
        private router: Router,
        private messageService: MessageService
    ) {
        this.isMaker = this.authService.hasRole('MAKER');
        this.isChecker = this.authService.hasRole('CHECKER');
    }

    ngOnInit() {
        this.loadCases();
    }

    loadCases() {
        this.loading = true;
        this.caseService.getAllCases().subscribe({
            next: (data) => {
                this.cases = data;
                this.loading = false;
            },
            error: () => {
                this.loading = false;
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load cases'
                });
            }
        });
    }

    viewCase(id: number) {
        this.router.navigate(['/cases/detail', id]);
    }

    getStatusSeverity(status: CaseStatus): 'success' | 'info' | 'warning' | 'danger' | 'secondary' {
        const severityMap: { [key in CaseStatus]: 'success' | 'info' | 'warning' | 'danger' | 'secondary' } = {
            'DRAFT': 'secondary',
            'SUBMITTED': 'info',
            'UNDER_REVIEW': 'info',
            'APPROVED': 'success',
            'REJECTED': 'danger',
            'BIDDING_IN_PROGRESS': 'warning',
            'VENDOR_SELECTED': 'success',
            'COMPLETED': 'success',
            'CANCELLED': 'secondary',
            'PENDING_APPROVAL': 'info'
        };
        return severityMap[status] || 'secondary';
    }
}