import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { DialogModule } from 'primeng/dialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { FormsModule } from '@angular/forms';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { CaseService } from '../../../../services/case.service';
import { AuthService } from '../../../../services/auth.service';
import { ProcurementCase, CaseApproval, CaseStatus } from '../../../../models/case.model';

@Component({
    selector: 'app-case-detail',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        CardModule,
        ButtonModule,
        TableModule,
        TagModule,
        DialogModule,
        InputTextareaModule,
        ToastModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="card">
                <div class="flex justify-content-between align-items-center mb-4">
                    <div>
                        <button
                                pButton
                                icon="pi pi-arrow-left"
                                class="p-button-text"
                                (click)="goBack()">
                        </button>
                        <span class="text-2xl font-bold ml-2">{{ case?.caseNumber }}</span>
                    </div>
                    <p-tag
                            *ngIf="case && case.caseStatus"
                            [value]="case.caseStatus"
                            [severity]="getStatusSeverity(case.caseStatus)">
                    </p-tag>
                </div>

                <div class="grid" *ngIf="case">
                    <div class="col-12 md:col-6">
                        <div class="mb-3">
                            <label class="font-semibold text-600">Case Name</label>
                            <p class="text-xl">{{ case.caseName }}</p>
                        </div>
                        <div class="mb-3">
                            <label class="font-semibold text-600">Department</label>
                            <p>{{ case.departmentName }}</p>
                        </div>
                        <div class="mb-3">
                            <label class="font-semibold text-600">Category</label>
                            <p>{{ case.categoryName || 'N/A' }}</p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="mb-3">
                            <label class="font-semibold text-600">Total Approved Budget</label>
                            <p class="text-xl text-primary">₹ {{ case.totalApprovedBudget | number:'1.2-2' }}</p>
                        </div>
                        <div class="mb-3">
                            <label class="font-semibold text-600">Fund Type</label>
                            <p>{{ case.fundType || 'N/A' }}</p>
                        </div>
                        <div class="mb-3">
                            <label class="font-semibold text-600">Budget Name</label>
                            <p>{{ case.budgetName || 'N/A' }}</p>
                        </div>
                    </div>
                </div>

                <div class="mt-4" *ngIf="case && case.edApprovalNote">
                    <label class="font-semibold text-600">ED Approval Note</label>
                    <p class="surface-100 p-3 border-round">{{ case.edApprovalNote }}</p>
                </div>

                <div class="mt-4" *ngIf="case && case.lineItems && case.lineItems.length > 0">
                    <h3 class="text-xl font-semibold mb-3">Line Items</h3>
                    <p-table [value]="case.lineItems">
                        <ng-template pTemplate="header">
                            <tr>
                                <th>Product</th>
                                <th>Ceiling Amount</th>
                                <th>Additional Budget</th>
                                <th>Total Amount</th>
                                <th>Vendor</th>
                            </tr>
                        </ng-template>
                        <ng-template pTemplate="body" let-item>
                            <tr>
                                <td>{{ item.productName }}</td>
                                <td>₹ {{ item.ceilingAmount | number:'1.2-2' }}</td>
                                <td>₹ {{ item.additionalBudgetAmount | number:'1.2-2' }}</td>
                                <td><strong>₹ {{ item.totalAmount | number:'1.2-2' }}</strong></td>
                                <td>{{ item.selectedVendorName || 'Not Selected' }}</td>
                            </tr>
                        </ng-template>
                    </p-table>
                </div>

                <div class="flex justify-content-end gap-2 mt-4 pt-3 border-top-1 surface-border">
                    <button
                            *ngIf="isChecker && case?.caseStatus === 'SUBMITTED'"
                            pButton
                            label="Reject"
                            icon="pi pi-times"
                            class="p-button-danger"
                            (click)="showApprovalDialog(false)">
                    </button>
                    <button
                            *ngIf="isChecker && case?.caseStatus === 'SUBMITTED'"
                            pButton
                            label="Approve"
                            icon="pi pi-check"
                            class="p-button-success"
                            (click)="showApprovalDialog(true)">
                    </button>
                </div>
            </div>

            <p-dialog
                    [(visible)]="displayApprovalDialog"
                    [header]="approvalData.approved ? 'Approve Case' : 'Reject Case'"
                    [modal]="true"
                    [style]="{width: '500px'}">
                <div class="field">
                    <label>Comments</label>
                    <textarea
                            pInputTextarea
                            [(ngModel)]="approvalData.comments"
                            rows="4"
                            class="w-full">
          </textarea>
                </div>
                <ng-template pTemplate="footer">
                    <button
                            pButton
                            label="Cancel"
                            icon="pi pi-times"
                            class="p-button-text"
                            (click)="displayApprovalDialog = false">
                    </button>
                    <button
                            pButton
                            [label]="approvalData.approved ? 'Approve' : 'Reject'"
                            [icon]="approvalData.approved ? 'pi pi-check' : 'pi pi-times'"
                            (click)="processApproval()">
                    </button>
                </ng-template>
            </p-dialog>

            <p-toast></p-toast>
        </div>
    `
})
export class CaseDetailComponent implements OnInit {
    case?: ProcurementCase;
    isChecker = false;
    displayApprovalDialog = false;
    approvalData: CaseApproval = {
        approved: false,
        comments: ''
    };

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private caseService: CaseService,
        private authService: AuthService,
        private messageService: MessageService
    ) {
        this.isChecker = this.authService.hasRole('CHECKER');
    }

    ngOnInit() {
        const id = this.route.snapshot.params['id'];
        this.loadCase(id);
    }

    loadCase(id: number) {
        this.caseService.getCaseById(id).subscribe({
            next: (data) => {
                this.case = data;
            },
            error: () => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load case details'
                });
            }
        });
    }

    showApprovalDialog(approve: boolean) {
        this.approvalData = {
            caseId: this.case?.id,
            approved: approve,
            comments: ''
        };
        this.displayApprovalDialog = true;
    }

    processApproval() {
        if (this.approvalData.approved) {
            this.caseService.approveCase(this.approvalData).subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Case approved successfully'
                    });
                    this.displayApprovalDialog = false;
                    this.loadCase(this.case!.id!);
                }
            });
        } else {
            this.caseService.rejectCase(this.approvalData).subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Case rejected'
                    });
                    this.displayApprovalDialog = false;
                    this.loadCase(this.case!.id!);
                }
            });
        }
    }

    getStatusSeverity(status: CaseStatus): 'success' | 'info' | 'warning' | 'danger' | 'secondary' {
        const severityMap: { [key in CaseStatus]: 'success' | 'info' | 'warning' | 'danger' | 'secondary' } = {
            'DRAFT': 'secondary',
            'SUBMITTED': 'info',
            'UNDER_REVIEW': 'info',
            'APPROVED': 'success',
            'REJECTED': 'danger',
            'BIDDING_IN_PROGRESS': 'warning',
            'VENDOR_SELECTED': 'success',
            'COMPLETED': 'success',
            'CANCELLED': 'secondary',
            'PENDING_APPROVAL': 'info',
        };
        return severityMap[status] || 'secondary';
    }

    goBack() {
        this.router.navigate(['/cases/list']);
    }
}