import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CardModule } from 'primeng/card';
import { StepsModule } from 'primeng/steps';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { MessageService, MenuItem } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { CaseService } from '../../../../services/case.service';
import { DepartmentService } from '../../../../services/department.service';
import { ProductService } from '../../../../services/product.service';
import { ProcurementCase, CaseLineItem } from '../../../../models/case.model';
import { Department } from '../../../../models/department.model';
import { ProductCategory, SubCategory, Product } from '../../../../models/product.model';

@Component({
    selector: 'app-case-create',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        CardModule,
        StepsModule,
        ButtonModule,
        InputTextModule,
        InputNumberModule,
        DropdownModule,
        InputTextareaModule,
        TableModule,
        DialogModule,
        CalendarModule,
        CheckboxModule,
        ToastModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="card">
                <h2 class="text-2xl font-bold mb-4">Create Procurement Case</h2>

                <p-steps [model]="steps" [activeIndex]="activeIndex" [readonly]="false"></p-steps>

                <div class="mt-4" [ngSwitch]="activeIndex">

                    <!-- Step 1: Case Details -->
                    <div *ngSwitchCase="0" class="mt-4">
                        <div class="formgrid grid">
                            <div class="field col-12 md:col-6">
                                <label for="caseName" class="font-semibold">Case Name *</label>
                                <input pInputText id="caseName" [(ngModel)]="case.caseName"
                                       class="w-full" placeholder="e.g., Q4 Marketing Campaign" />
                            </div>

                            <div class="field col-12 md:col-6">
                                <label for="department" class="font-semibold">Department *</label>
                                <p-dropdown
                                        [options]="departments"
                                        [(ngModel)]="case.departmentId"
                                        optionLabel="departmentName"
                                        optionValue="id"
                                        placeholder="Select Department"
                                        (onChange)="onDepartmentChange()"
                                        [showClear]="true"
                                        class="w-full">
                                </p-dropdown>
                            </div>

                            <div class="field col-12 md:col-6">
                                <label for="category" class="font-semibold">Category *</label>
                                <p-dropdown
                                        [options]="categories"
                                        [(ngModel)]="case.categoryId"
                                        optionLabel="categoryName"
                                        optionValue="id"
                                        placeholder="Select Category"
                                        (onChange)="onCategoryChange()"
                                        [disabled]="!case.departmentId"
                                        [showClear]="true"
                                        class="w-full">
                                </p-dropdown>
                            </div>

                            <div class="field col-12 md:col-6">
                                <label for="subCategory" class="font-semibold">Sub-Category *</label>
                                <p-dropdown
                                        [options]="subCategories"
                                        [(ngModel)]="case.subCategoryId"
                                        optionLabel="subCategoryName"
                                        optionValue="id"
                                        placeholder="Select Sub-Category"
                                        [disabled]="!case.categoryId"
                                        [showClear]="true"
                                        class="w-full">
                                </p-dropdown>
                            </div>

                            <div class="field col-12 md:col-6">
                                <label for="budget" class="font-semibold">Total Approved Budget (₹) *</label>
                                <p-inputNumber
                                        [(ngModel)]="case.totalApprovedBudget"
                                        mode="currency"
                                        currency="INR"
                                        locale="en-IN"
                                        [minFractionDigits]="0"
                                        class="w-full">
                                </p-inputNumber>
                            </div>

                            <div class="field col-12 md:col-6">
                                <label for="budgetName" class="font-semibold">Budget Head</label>
                                <input pInputText id="budgetName" [(ngModel)]="case.budgetName"
                                       class="w-full" placeholder="e.g., Marketing - Q4" />
                            </div>

                            <div class="field col-12">
                                <label for="edApprovalNote" class="font-semibold">ED Approval Note</label>
                                <textarea pInputTextarea id="edApprovalNote" [(ngModel)]="case.edApprovalNote"
                                          rows="3" class="w-full"
                                          placeholder="Executive Director approval notes"></textarea>
                            </div>
                        </div>

                        <div class="flex justify-content-end gap-2 mt-4">
                            <button pButton label="Next" icon="pi pi-arrow-right"
                                    iconPos="right" (click)="nextStep()"
                                    [disabled]="!isStep1Valid()">
                            </button>
                        </div>
                    </div>

                    <!-- Step 2: Line Items -->
                    <div *ngSwitchCase="1" class="mt-4">
                        <div class="flex justify-content-between align-items-center mb-3">
                            <h3 class="m-0">Line Items</h3>
                            <button pButton label="Add Line Item" icon="pi pi-plus"
                                    (click)="showAddItemDialog()"></button>
                        </div>

                        <p-table [value]="lineItems" [tableStyle]="{'min-width': '50rem'}">
                            <ng-template pTemplate="header">
                                <tr>
                                    <th>Product</th>
                                    <th>Dimensions</th>
                                    <th>Estimated Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="body" let-item let-i="rowIndex">
                                <tr>
                                    <td>{{ getProductName(item.productId) }}</td>
                                    <td>
                                        <div class="text-sm">
                                            <div *ngFor="let dim of parseDimensions(item.dimensionValues)">
                                                <strong>{{ dim.key }}:</strong> {{ dim.value }}
                                            </div>
                                        </div>
                                    </td>
                                    <td>₹{{ item.totalAmount | number:'1.2-2' }}</td>
                                    <td>
                                        <button pButton icon="pi pi-trash"
                                                class="p-button-danger p-button-text"
                                                (click)="removeLineItem(i)"></button>
                                    </td>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="emptymessage">
                                <tr>
                                    <td colspan="4" class="text-center">No line items added yet. Click "Add Line Item" to begin.</td>
                                </tr>
                            </ng-template>
                        </p-table>

                        <div class="flex justify-content-between gap-2 mt-4">
                            <button pButton label="Previous" icon="pi pi-arrow-left"
                                    class="p-button-secondary" (click)="prevStep()"></button>
                            <button pButton label="Next" icon="pi pi-arrow-right"
                                    iconPos="right" (click)="nextStep()"
                                    [disabled]="lineItems.length === 0">
                            </button>
                        </div>
                    </div>

                    <!-- Step 3: Review & Submit -->
                    <div *ngSwitchCase="2" class="mt-4">
                        <div class="card mb-3" style="background-color: #f8f9fa;">
                            <h3 class="mt-0">Case Summary</h3>
                            <div class="grid">
                                <div class="col-12 md:col-6">
                                    <p><strong>Case Name:</strong> {{ case.caseName }}</p>
                                    <p><strong>Department:</strong> {{ getDepartmentName() }}</p>
                                    <p><strong>Category:</strong> {{ getCategoryName() }}</p>
                                    <p><strong>Sub-Category:</strong> {{ getSubCategoryName() }}</p>
                                </div>
                                <div class="col-12 md:col-6">
                                    <p><strong>Budget:</strong> ₹{{ case.totalApprovedBudget | number:'1.2-2' }}</p>
                                    <p><strong>Budget Head:</strong> {{ case.budgetName || 'N/A' }}</p>
                                    <p><strong>Total Line Items:</strong> {{ lineItems.length }}</p>
                                    <p><strong>Total Estimated Value:</strong> ₹{{ getTotalEstimatedValue() | number:'1.2-2' }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="card mb-3">
                            <h4 class="mt-0">Line Items Summary</h4>
                            <p-table [value]="lineItems" [tableStyle]="{'min-width': '50rem'}">
                                <ng-template pTemplate="header">
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>Key Dimensions</th>
                                        <th class="text-right">Amount (₹)</th>
                                    </tr>
                                </ng-template>
                                <ng-template pTemplate="body" let-item let-i="rowIndex">
                                    <tr>
                                        <td>{{ i + 1 }}</td>
                                        <td>{{ getProductName(item.productId) }}</td>
                                        <td>
                      <span class="text-sm text-600">
                        {{ getFirstThreeDimensions(item.dimensionValues) }}
                      </span>
                                        </td>
                                        <td class="text-right">{{ item.totalAmount | number:'1.2-2' }}</td>
                                    </tr>
                                </ng-template>
                            </p-table>
                        </div>

                        <div class="flex justify-content-between gap-2 mt-4">
                            <button pButton label="Previous" icon="pi pi-arrow-left"
                                    class="p-button-secondary" (click)="prevStep()"></button>
                            <div class="flex gap-2">
                                <button pButton label="Save as Draft" icon="pi pi-save"
                                        class="p-button-secondary" (click)="saveDraft()"></button>
                                <button pButton label="Submit for Approval" icon="pi pi-check"
                                        class="p-button-success" (click)="submitCase()"></button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Add Line Item Dialog -->
            <p-dialog header="Add Line Item" [(visible)]="showItemDialog" [modal]="true"
                      [style]="{width: '50vw'}" [draggable]="false" [resizable]="false">
                <div class="formgrid grid">
                    <div class="field col-12">
                        <label for="product" class="font-semibold">Product *</label>
                        <p-dropdown
                                [options]="products"
                                [(ngModel)]="currentItem.productId"
                                optionLabel="productName"
                                optionValue="id"
                                placeholder="Select Product"
                                (onChange)="onProductChange()"
                                class="w-full">
                        </p-dropdown>
                    </div>

                    <!-- Dynamic Dimensions -->
                    <div *ngFor="let dimension of selectedProductDimensions"
                         class="field col-12 md:col-6">
                        <label [for]="dimension.dimensionKey" class="font-semibold">
                            {{ dimension.dimensionName }}
                            <span *ngIf="dimension.isMandatory" class="text-red-500">*</span>
                        </label>

                        <!-- Text Input -->
                        <input *ngIf="dimension.uiComponent === 'INPUT' && dimension.dataType === 'STRING'"
                               pInputText
                               [id]="dimension.dimensionKey"
                               [(ngModel)]="currentItemDimensions[dimension.dimensionKey]"
                               class="w-full"
                               [placeholder]="dimension.helpText" />

                        <!-- Number Input -->
                        <p-inputNumber *ngIf="dimension.uiComponent === 'INPUT' && dimension.dataType === 'NUMBER'"
                                       [(ngModel)]="currentItemDimensions[dimension.dimensionKey]"
                                       [min]="dimension.minValue"
                                       [max]="dimension.maxValue"
                                       [placeholder]="dimension.helpText"
                                       class="w-full">
                        </p-inputNumber>

                        <!-- Dropdown -->
                        <p-dropdown *ngIf="dimension.uiComponent === 'DROPDOWN'"
                                    [options]="getEnumOptions(dimension)"
                                    [(ngModel)]="currentItemDimensions[dimension.dimensionKey]"
                                    [placeholder]="'Select ' + dimension.dimensionName"
                                    class="w-full">
                        </p-dropdown>

                        <!-- Date Picker -->
                        <p-calendar *ngIf="dimension.uiComponent === 'DATEPICKER'"
                                    [(ngModel)]="currentItemDimensions[dimension.dimensionKey]"
                                    dateFormat="yy-mm-dd"
                                    [showIcon]="true"
                                    class="w-full">
                        </p-calendar>

                        <!-- Checkbox -->
                        <p-checkbox *ngIf="dimension.uiComponent === 'CHECKBOX'"
                                    [(ngModel)]="currentItemDimensions[dimension.dimensionKey]"
                                    [binary]="true">
                        </p-checkbox>
                    </div>

                    <div class="field col-12">
                        <label for="amount" class="font-semibold">Estimated Amount (₹) *</label>
                        <p-inputNumber
                                [(ngModel)]="currentItem.totalAmount"
                                mode="currency"
                                currency="INR"
                                locale="en-IN"
                                [minFractionDigits]="0"
                                class="w-full">
                        </p-inputNumber>
                    </div>
                </div>

                <ng-template pTemplate="footer">
                    <button pButton label="Cancel" icon="pi pi-times"
                            class="p-button-text" (click)="showItemDialog = false"></button>
                    <button pButton label="Add Item" icon="pi pi-check"
                            (click)="addLineItem()"
                            [disabled]="!isItemValid()"></button>
                </ng-template>
            </p-dialog>

            <p-toast></p-toast>
        </div>
    `,
    styles: [`
      :host ::ng-deep {
        .p-steps .p-steps-item .p-menuitem-link {
          background: transparent;
        }
        .p-dropdown, .p-inputnumber, .p-calendar {
          width: 100%;
        }
      }
    `]
})
export class CaseCreateComponent implements OnInit {
    case: ProcurementCase = {
        caseName: '',
        departmentId: 0,
        categoryId: 0,
        subCategoryId: 0,
        totalApprovedBudget: 0,
        budgetName: '',
        edApprovalNote: ''
    };

    lineItems: CaseLineItem[] = [];
    currentItem: CaseLineItem = this.getEmptyLineItem();
    currentItemDimensions: any = {};

    departments: Department[] = [];
    categories: ProductCategory[] = [];
    subCategories: SubCategory[] = [];
    products: Product[] = [];
    selectedProductDimensions: any[] = [];

    activeIndex = 0;
    showItemDialog = false;

    steps: MenuItem[] = [
        { label: 'Case Details' },
        { label: 'Line Items' },
        { label: 'Review & Submit' }
    ];

    constructor(
        private caseService: CaseService,
        private departmentService: DepartmentService,
        private productService: ProductService,
        private router: Router,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        this.loadDepartments();
    }

    loadDepartments() {
        this.departmentService.getActiveDepartments().subscribe({
            next: (data) => {
                this.departments = data;
                console.log('Loaded departments:', data);
            },
            error: (err) => {
                console.error('Error loading departments:', err);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load departments'
                });
            }
        });
    }

    onDepartmentChange() {
        this.categories = [];
        this.subCategories = [];
        this.products = [];
        this.case.categoryId = 0;
        this.case.subCategoryId = 0;

        if (this.case.departmentId) {
            this.productService.getCategoriesByDepartment(this.case.departmentId).subscribe({
                next: (data) => {
                    this.categories = data;
                    console.log('Loaded categories:', data);
                }
            });
        }
    }

    onCategoryChange() {
        this.subCategories = [];
        this.products = [];
        this.case.subCategoryId = 0;

        if (this.case.categoryId) {
            this.productService.getSubCategoriesByCategory(this.case.categoryId).subscribe({
                next: (data) => {
                    this.subCategories = data;
                    console.log('Loaded sub-categories:', data);
                }
            });
        }
    }

    onSubCategoryChange() {
        this.products = [];

        if (this.case.subCategoryId) {
            this.productService.getProductsBySubCategory(this.case.subCategoryId).subscribe({
                next: (data) => {
                    this.products = data;
                    console.log('Loaded products:', data);
                }
            });
        }
    }

    onProductChange() {
        if (this.currentItem.productId) {
            this.productService.getProductById(this.currentItem.productId).subscribe({
                next: (product) => {
                    this.selectedProductDimensions = product.dimensions || [];
                    this.currentItemDimensions = {};
                    console.log('Loaded dimensions:', this.selectedProductDimensions);
                }
            });
        }
    }

    showAddItemDialog() {
        // Load products for current sub-category
        if (this.case.subCategoryId) {
            this.onSubCategoryChange();
        }
        this.currentItem = this.getEmptyLineItem();
        this.currentItemDimensions = {};
        this.selectedProductDimensions = [];
        this.showItemDialog = true;
    }

    addLineItem() {
        this.currentItem.dimensionValues = this.currentItemDimensions;
        this.lineItems.push({...this.currentItem});

        this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Line item added'
        });

        this.showItemDialog = false;
        this.currentItem = this.getEmptyLineItem();
        this.currentItemDimensions = {};
    }

    removeLineItem(index: number) {
        this.lineItems.splice(index, 1);
        this.messageService.add({
            severity: 'info',
            summary: 'Removed',
            detail: 'Line item removed'
        });
    }

    getEmptyLineItem(): CaseLineItem {
        return {
            productId: 0,
            dimensionValues: {},
            totalAmount: 0
        };
    }

    isStep1Valid(): boolean {
        return !!(
            this.case.caseName &&
            this.case.departmentId &&
            this.case.categoryId &&
            this.case.subCategoryId &&
            this.case.totalApprovedBudget > 0
        );
    }

    isItemValid(): boolean {
        if (!this.currentItem.productId || !this.currentItem.totalAmount) {
            return false;
        }

        // Check mandatory dimensions
        for (const dim of this.selectedProductDimensions) {
            if (dim.isMandatory && !this.currentItemDimensions[dim.dimensionKey]) {
                return false;
            }
        }

        return true;
    }

    nextStep() {
        if (this.activeIndex < this.steps.length - 1) {
            this.activeIndex++;
        }
    }

    prevStep() {
        if (this.activeIndex > 0) {
            this.activeIndex--;
        }
    }

    saveDraft() {
        const caseData = this.prepareCaseData();

        this.caseService.createCase(caseData).subscribe({
            next: (created) => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Case saved as draft'
                });
                setTimeout(() => this.router.navigate(['/cases/list']), 1500);
            },
            error: (err) => {
                console.error('Error saving case:', err);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to save case'
                });
            }
        });
    }

    submitCase() {
        const caseData = this.prepareCaseData();

        this.caseService.createCase(caseData).subscribe({
            next: (created) => {
                if (created.id) {
                    // Add line items first
                    this.addLineItemsToCase(created.id).then(() => {
                        // Then submit for approval
                        this.caseService.submitForApproval(created.id!).subscribe({
                            next: () => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Success',
                                    detail: 'Case submitted for approval'
                                });
                                setTimeout(() => this.router.navigate(['/cases/list']), 1500);
                            }
                        });
                    });
                }
            },
            error: (err) => {
                console.error('Error submitting case:', err);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to submit case'
                });
            }
        });
    }

    prepareCaseData(): ProcurementCase {
        return {
            ...this.case,
            // Don't include line items in the initial creation
        };
    }

    async addLineItemsToCase(caseId: number): Promise<void> {
        const promises = this.lineItems.map(item =>
            this.caseService.addLineItem(caseId, item).toPromise()
        );
        await Promise.all(promises);
    }

    getDepartmentName(): string {
        const dept = this.departments.find(d => d.id === this.case.departmentId);
        return dept ? dept.departmentName : '';
    }

    getCategoryName(): string {
        const cat = this.categories.find(c => c.id === this.case.categoryId);
        return cat ? cat.categoryName : '';
    }

    getSubCategoryName(): string {
        const sub = this.subCategories.find(s => s.id === this.case.subCategoryId);
        return sub ? sub.subCategoryName : '';
    }

    getProductName(productId: number): string {
        const product = this.products.find(p => p.id === productId);
        return product ? product.productName : 'Unknown Product';
    }

    parseDimensions(dimensionValues: { [key: string]: any }): Array<{key: string, value: any}> {
        if (!dimensionValues || Object.keys(dimensionValues).length === 0) {
            return [];
        }
        return Object.keys(dimensionValues).map(key => ({ key, value: dimensionValues[key] }));
    }

    getFirstThreeDimensions(dimensionValues: { [key: string]: any }): string {
        if (!dimensionValues || Object.keys(dimensionValues).length === 0) {
            return 'N/A';
        }
        const dims = dimensionValues;
        const keys = Object.keys(dims).slice(0, 3);
        return keys.map(k => `${k}: ${dims[k]}`).join(', ');
    }

    getTotalEstimatedValue(): number {
        return this.lineItems.reduce((sum, item) => sum + (item.totalAmount || 0), 0);
    }

    getEnumOptions(dimension: any): any[] {
        // Common enum options based on dimension
        const enumMap: any = {
            'colorType': [
                { label: 'Full Color', value: 'Full Color' },
                { label: 'B&W', value: 'B&W' }
            ],
            'timeSlot': [
                { label: 'Prime Time', value: 'Prime Time' },
                { label: 'Non-Prime Time', value: 'Non-Prime Time' }
            ],
            'screenSize': [
                { label: '13 inch', value: '13 inch' },
                { label: '14 inch', value: '14 inch' },
                { label: '15 inch', value: '15 inch' },
                { label: '17 inch', value: '17 inch' }
            ]
        };

        return enumMap[dimension.dimensionKey] || [];
    }
}