import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Router, RouterLink} from '@angular/router';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ChartModule } from 'primeng/chart';
import { CaseService } from '../../services/case.service';
import { ProcurementCase, CaseStatus } from '../../models/case.model';

@Component({
    selector: 'app-maker-dashboard',
    standalone: true,
    imports: [CommonModule, CardModule, ButtonModule, TableModule, TagModule, ChartModule, RouterLink],
    template: `
        <div class="p-4">
            <div class="flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="text-3xl font-bold m-0">Maker Dashboard</h1>
                    <p class="text-600 mt-1">Welcome back! Here's your procurement overview</p>
                </div>
                <button pButton label="Create New Case" icon="pi pi-plus" 
                        class="p-button-lg" routerLink="/cases/create"></button>
            </div>

            <!-- Key Metrics -->
            <div class="grid mb-4">
                <div class="col-12 md:col-3">
                    <div class="card mb-0" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Total Cases</div>
                                <div class="text-4xl font-bold">{{ totalCases }}</div>
                            </div>
                            <i class="pi pi-briefcase text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">In Draft</div>
                                <div class="text-4xl font-bold">{{ draftCases }}</div>
                            </div>
                            <i class="pi pi-file-edit text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Pending Approval</div>
                                <div class="text-4xl font-bold">{{ pendingCases }}</div>
                            </div>
                            <i class="pi pi-clock text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Approved</div>
                                <div class="text-4xl font-bold">{{ approvedCases }}</div>
                            </div>
                            <i class="pi pi-check-circle text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="grid mb-4">
                <div class="col-12 md:col-8">
                    <p-card header="Case Status Distribution">
                        <p-chart type="bar" [data]="caseStatusChart" [options]="chartOptions"></p-chart>
                    </p-card>
                </div>
                <div class="col-12 md:col-4">
                    <p-card header="Budget Utilization">
                        <p-chart type="doughnut" [data]="budgetChart" [options]="doughnutOptions"></p-chart>
                    </p-card>
                </div>
            </div>

            <!-- Recent Cases -->
            <div class="card">
                <div class="flex justify-content-between align-items-center mb-3">
                    <h3 class="m-0">My Recent Cases</h3>
                    <button pButton label="View All" icon="pi pi-arrow-right" 
                            iconPos="right" class="p-button-text" routerLink="/cases/list"></button>
                </div>

                <p-table [value]="recentCases" [rows]="5" responsiveLayout="scroll">
                    <ng-template pTemplate="header">
                        <tr>
                            <th>Case Number</th>
                            <th>Case Name</th>
                            <th>Department</th>
                            <th>Budget (₹)</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="body" let-case>
                        <tr>
                            <td><span class="font-semibold">{{ case.caseNumber }}</span></td>
                            <td>{{ case.caseName }}</td>
                            <td>{{ case.departmentName }}</td>
                            <td>₹{{ case.totalApprovedBudget | number:'1.0-0' }}</td>
                            <td>
                                <p-tag [value]="case.caseStatus" 
                                       [severity]="getStatusSeverity(case.caseStatus)"></p-tag>
                            </td>
                            <td>{{ case.createdAt | date:'MMM d, y' }}</td>
                            <td>
                                <button pButton icon="pi pi-eye" 
                                        class="p-button-text p-button-rounded"
                                        [routerLink]="['/cases/detail', case.id]"></button>
                                <button *ngIf="case.caseStatus === 'DRAFT'" 
                                        pButton icon="pi pi-pencil" 
                                        class="p-button-text p-button-rounded"
                                        [routerLink]="['/cases/create']"></button>
                            </td>
                        </tr>
                    </ng-template>
                </p-table>
            </div>

            <!-- Quick Actions -->
            <div class="grid mt-4">
                <div class="col-12 md:col-4">
                    <p-card>
                        <div class="text-center p-3">
                            <i class="pi pi-file text-5xl text-primary mb-3"></i>
                            <h4 class="mt-0">Draft Cases</h4>
                            <p class="text-600">{{ draftCases }} cases waiting to be completed</p>
                            <button pButton label="View Drafts" 
                                    class="p-button-outlined w-full"
                                    (click)="viewDraftCases()"></button>
                        </div>
                    </p-card>
                </div>
                <div class="col-12 md:col-4">
                    <p-card>
                        <div class="text-center p-3">
                            <i class="pi pi-clock text-5xl" style="color: #f59e0b;" class="mb-3"></i>
                            <h4 class="mt-0">Pending Review</h4>
                            <p class="text-600">{{ pendingCases }} cases under checker review</p>
                            <button pButton label="Track Status" 
                                    class="p-button-outlined w-full"
                                    (click)="viewPendingCases()"></button>
                        </div>
                    </p-card>
                </div>
                <div class="col-12 md:col-4">
                    <p-card>
                        <div class="text-center p-3">
                            <i class="pi pi-info-circle text-5xl" style="color: #3b82f6;" class="mb-3"></i>
                            <h4 class="mt-0">Need Help?</h4>
                            <p class="text-600">View guidelines for case creation</p>
                            <button pButton label="View Guide" 
                                    class="p-button-outlined w-full"
                                    (click)="viewGuide()"></button>
                        </div>
                    </p-card>
                </div>
            </div>
        </div>
    `,
    styles: [`
        :host ::ng-deep {
            .card {
                border-radius: 12px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
        }
    `]
})
export class MakerDashboardComponent implements OnInit {
    totalCases = 0;
    draftCases = 0;
    pendingCases = 0;
    approvedCases = 0;
    recentCases: ProcurementCase[] = [];

    caseStatusChart: any;
    budgetChart: any;
    chartOptions: any;
    doughnutOptions: any;

    constructor(
        private caseService: CaseService,
        private router: Router
    ) {}

    ngOnInit() {
        this.loadDashboardData();
        this.initializeCharts();
    }

    loadDashboardData() {
        this.caseService.getAllCases().subscribe({
            next: (cases) => {
                this.totalCases = cases.length;
                this.draftCases = cases.filter(c => c.caseStatus === CaseStatus.DRAFT).length;
                this.pendingCases = cases.filter(c => c.caseStatus === CaseStatus.PENDING_APPROVAL).length;
                this.approvedCases = cases.filter(c => c.caseStatus === CaseStatus.APPROVED).length;
                this.recentCases = cases.slice(0, 5);
                this.updateCharts(cases);
            }
        });
    }

    initializeCharts() {
        this.chartOptions = {
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        };

        this.doughnutOptions = {
            plugins: {
                legend: { position: 'bottom' }
            }
        };
    }

    updateCharts(cases: ProcurementCase[]) {
        // Status chart
        this.caseStatusChart = {
            labels: ['Draft', 'Pending', 'Approved', 'Vendor Selected', 'Completed'],
            datasets: [{
                label: 'Cases',
                data: [
                    cases.filter(c => c.caseStatus === CaseStatus.DRAFT).length,
                    cases.filter(c => c.caseStatus === CaseStatus.PENDING_APPROVAL).length,
                    cases.filter(c => c.caseStatus === CaseStatus.APPROVED).length,
                    cases.filter(c => c.caseStatus === CaseStatus.VENDOR_SELECTED).length,
                    cases.filter(c => c.caseStatus === CaseStatus.COMPLETED).length
                ],
                backgroundColor: ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6']
            }]
        };

        // Budget chart
        const totalBudget = cases.reduce((sum, c) => sum + (c.totalApprovedBudget || 0), 0);
        const approvedBudget = cases
            .filter(c => c.caseStatus === CaseStatus.APPROVED || c.caseStatus === CaseStatus.VENDOR_SELECTED)
            .reduce((sum, c) => sum + (c.totalApprovedBudget || 0), 0);

        this.budgetChart = {
            labels: ['Utilized', 'Available'],
            datasets: [{
                data: [approvedBudget, totalBudget - approvedBudget],
                backgroundColor: ['#10b981', '#e5e7eb']
            }]
        };
    }

    getStatusSeverity(status: string): 'success' | 'info' | 'warning' | 'danger' {
        const severityMap: any = {
            'DRAFT': 'warning',
            'PENDING_APPROVAL': 'info',
            'APPROVED': 'success',
            'REJECTED': 'danger',
            'VENDOR_SELECTED': 'success',
            'COMPLETED': 'success'
        };
        return severityMap[status] || 'info';
    }

    viewDraftCases() {
        this.router.navigate(['/cases/list'], { queryParams: { status: 'DRAFT' } });
    }

    viewPendingCases() {
        this.router.navigate(['/cases/list'], { queryParams: { status: 'PENDING_APPROVAL' } });
    }

    viewGuide() {
        // Navigate to help/guide section
        alert('Guide feature - Navigate to documentation');
    }
}