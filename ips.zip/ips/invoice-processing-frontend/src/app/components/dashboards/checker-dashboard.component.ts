import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Router, RouterLink} from '@angular/router';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ChartModule } from 'primeng/chart';
import { TimelineModule } from 'primeng/timeline';
import { CaseService } from '../../services/case.service';
import { ProcurementCase, CaseStatus } from '../../models/case.model';

@Component({
    selector: 'app-checker-dashboard',
    standalone: true,
    imports: [
        CommonModule,
        CardModule,
        ButtonModule,
        TableModule,
        TagModule,
        ChartModule,
        TimelineModule,
        RouterLink
    ],
    template: `
        <div class="p-4">
            <div class="flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="text-3xl font-bold m-0">Checker Dashboard</h1>
                    <p class="text-600 mt-1">Review and approve procurement cases</p>
                </div>
            </div>

            <!-- Alert Banner for Pending Items -->
            <div *ngIf="pendingApprovalCount > 0" class="card mb-4" 
                 style="background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); color: white;">
                <div class="flex align-items-center justify-content-between">
                    <div class="flex align-items-center">
                        <i class="pi pi-exclamation-triangle text-4xl mr-3"></i>
                        <div>
                            <div class="text-xl font-bold">{{ pendingApprovalCount }} Cases Awaiting Approval</div>
                            <div class="text-sm opacity-90">Please review and take action</div>
                        </div>
                    </div>
                    <button pButton label="Review Now" icon="pi pi-arrow-right" 
                            iconPos="right" class="p-button-rounded"
                            (click)="reviewPendingCases()"></button>
                </div>
            </div>

            <!-- Key Metrics -->
            <div class="grid mb-4">
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-pending">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Pending Approval</div>
                                <div class="text-4xl font-bold">{{ pendingApprovalCount }}</div>
                            </div>
                            <i class="pi pi-clock text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-approved">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Approved Today</div>
                                <div class="text-4xl font-bold">{{ approvedTodayCount }}</div>
                            </div>
                            <i class="pi pi-check-circle text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-scrutiny">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Invoices for Scrutiny</div>
                                <div class="text-4xl font-bold">{{ invoiceScrutinyCount }}</div>
                            </div>
                            <i class="pi pi-search text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-total">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Total Reviewed</div>
                                <div class="text-4xl font-bold">{{ totalReviewedCount }}</div>
                            </div>
                            <i class="pi pi-list text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Priority Queues -->
            <div class="grid mb-4">
                <div class="col-12 md:col-8">
                    <p-card>
                        <div class="flex justify-content-between align-items-center mb-3">
                            <h3 class="m-0">Cases Pending Approval</h3>
                            <button pButton label="View All" icon="pi pi-external-link" 
                                    class="p-button-text p-button-sm"
                                    (click)="viewAllPending()"></button>
                        </div>

                        <p-table [value]="pendingCases" [rows]="5" responsiveLayout="scroll">
                            <ng-template pTemplate="header">
                                <tr>
                                    <th>Priority</th>
                                    <th>Case Number</th>
                                    <th>Case Name</th>
                                    <th>Submitted By</th>
                                    <th>Budget (₹)</th>
                                    <th>Age (Days)</th>
                                    <th>Actions</th>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="body" let-case let-i="rowIndex">
                                <tr [class.row-high-priority]="case.priority === 'HIGH'">
                                    <td>
                                        <p-tag [value]="case.priority || 'NORMAL'" 
                                               [severity]="getPrioritySeverity(case.priority)"></p-tag>
                                    </td>
                                    <td><span class="font-semibold">{{ case.caseNumber }}</span></td>
                                    <td>{{ case.caseName }}</td>
                                    <td>{{ case.createdBy || 'Maker User' }}</td>
                                    <td>₹{{ case.totalApprovedBudget | number:'1.0-0' }}</td>
                                    <td>
                                        <span [class.text-red-500]="getDaysOld(case.createdAt) > 3">
                                            {{ getDaysOld(case.createdAt) }}
                                        </span>
                                    </td>
                                    <td>
                                        <button pButton icon="pi pi-eye" 
                                                class="p-button-text p-button-sm p-button-rounded"
                                                pTooltip="Review Case"
                                                [routerLink]="['/cases/detail', case.id]"></button>
                                        <button pButton icon="pi pi-check" 
                                                class="p-button-text p-button-sm p-button-rounded p-button-success"
                                                pTooltip="Quick Approve"
                                                (click)="quickApprove(case)"></button>
                                    </td>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="emptymessage">
                                <tr>
                                    <td colspan="7" class="text-center p-4">
                                        <i class="pi pi-check-circle text-4xl text-green-500 mb-2"></i>
                                        <p class="text-lg">No cases pending approval</p>
                                    </td>
                                </tr>
                            </ng-template>
                        </p-table>
                    </p-card>
                </div>

                <div class="col-12 md:col-4">
                    <p-card header="My Activity Timeline">
                        <p-timeline [value]="recentActivity" align="left">
                            <ng-template pTemplate="content" let-event>
                                <small class="text-600">{{ event.time }}</small>
                                <p class="mt-1 mb-0">{{ event.action }}</p>
                            </ng-template>
                        </p-timeline>
                    </p-card>
                </div>
            </div>

            <!-- Invoice Scrutiny Queue -->
            <div class="card mb-4">
                <div class="flex justify-content-between align-items-center mb-3">
                    <h3 class="m-0">Invoices Requiring Scrutiny</h3>
                    <button pButton label="View All" icon="pi pi-external-link" 
                            class="p-button-text p-button-sm"></button>
                </div>

                <p-table [value]="scrutinyQueue" [rows]="5" responsiveLayout="scroll">
                    <ng-template pTemplate="header">
                        <tr>
                            <th>Invoice #</th>
                            <th>Vendor</th>
                            <th>Case</th>
                            <th>Amount (₹)</th>
                            <th>Red Flags</th>
                            <th>Review %</th>
                            <th>Actions</th>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="body" let-invoice>
                        <tr>
                            <td><span class="font-semibold">{{ invoice.invoiceNumber }}</span></td>
                            <td>{{ invoice.vendorName }}</td>
                            <td>{{ invoice.caseNumber }}</td>
                            <td>₹{{ invoice.totalAmount | number:'1.0-0' }}</td>
                            <td>
                                <p-tag *ngIf="invoice.redFlags > 0" 
                                       [value]="invoice.redFlags + ' Flags'" 
                                       severity="danger"></p-tag>
                                <span *ngIf="invoice.redFlags === 0" class="text-green-600">
                                    <i class="pi pi-check"></i> Clean
                                </span>
                            </td>
                            <td>
                                <div class="flex align-items-center gap-2">
                                    <div class="flex-1">
                                        <div class="progress-bar" [style.width.%]="invoice.reviewProgress"></div>
                                    </div>
                                    <span class="text-sm">{{ invoice.reviewProgress }}%</span>
                                </div>
                            </td>
                            <td>
                                <button pButton label="Scrutinize" icon="pi pi-search" 
                                        class="p-button-sm"
                                        [routerLink]="['/cases/scrutiny', invoice.id]"></button>
                            </td>
                        </tr>
                    </ng-template>
                </p-table>
            </div>

            <!-- Performance Analytics -->
            <div class="grid">
                <div class="col-12 md:col-6">
                    <p-card header="Approval Trends (Last 7 Days)">
                        <p-chart type="line" [data]="approvalTrendsChart" [options]="lineChartOptions"></p-chart>
                    </p-card>
                </div>
                <div class="col-12 md:col-6">
                    <p-card header="Decision Distribution">
                        <p-chart type="pie" [data]="decisionChart" [options]="pieChartOptions"></p-chart>
                    </p-card>
                </div>
            </div>
        </div>
    `,
    styles: [`
        .stat-card {
            border-radius: 12px;
            color: white;
        }
        .stat-pending { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
        .stat-approved { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .stat-scrutiny { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); }
        .stat-total { background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); }
        
        .row-high-priority {
            background-color: #fef2f2 !important;
            border-left: 4px solid #ef4444;
        }

        .progress-bar {
            height: 8px;
            background: linear-gradient(90deg, #10b981, #3b82f6);
            border-radius: 4px;
            transition: width 0.3s ease;
        }

        :host ::ng-deep {
            .p-timeline-event-content {
                line-height: 1.3;
            }
        }
    `]
})
export class CheckerDashboardComponent implements OnInit {
    pendingApprovalCount = 0;
    approvedTodayCount = 0;
    invoiceScrutinyCount = 1;
    totalReviewedCount = 0;

    pendingCases: any[] = [];
    scrutinyQueue: any[] = [];
    recentActivity: any[] = [];

    approvalTrendsChart: any;
    decisionChart: any;
    lineChartOptions: any;
    pieChartOptions: any;

    constructor(
        private caseService: CaseService,
        private router: Router
    ) {}

    ngOnInit() {
        this.loadDashboardData();
        this.initializeCharts();
        this.loadRecentActivity();
    }

    loadDashboardData() {
        this.caseService.getAllCases().subscribe({
            next: (cases) => {
                this.pendingCases = cases.filter(c => c.caseStatus === CaseStatus.PENDING_APPROVAL);
                this.pendingApprovalCount = this.pendingCases.length;

                // Mock data for approved today (in real app, filter by date)
                this.approvedTodayCount = 3;
                this.totalReviewedCount = cases.filter(c =>
                    c.caseStatus === CaseStatus.APPROVED ||
                    c.caseStatus === CaseStatus.REJECTED
                ).length;

                this.updateCharts();
            }
        });

        // Mock scrutiny queue data
        this.scrutinyQueue = [
            {
                id: 1,
                invoiceNumber: 'INV-TOI-2025-1234',
                vendorName: 'Times of India Publications',
                caseNumber: 'CASE-DOC-004',
                totalAmount: 100300,
                redFlags: 3,
                reviewProgress: 45
            }
        ];
    }

    initializeCharts() {
        this.lineChartOptions = {
            plugins: {
                legend: { display: true, position: 'top' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        };

        this.pieChartOptions = {
            plugins: {
                legend: { position: 'right' }
            }
        };

        // Mock approval trends
        this.approvalTrendsChart = {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [
                {
                    label: 'Approved',
                    data: [5, 8, 6, 9, 7, 4, 3],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Rejected',
                    data: [1, 2, 1, 0, 1, 1, 0],
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    tension: 0.4
                }
            ]
        };

        // Decision distribution
        this.decisionChart = {
            labels: ['Approved', 'Rejected', 'Returned for Clarification'],
            datasets: [{
                data: [85, 10, 5],
                backgroundColor: ['#10b981', '#ef4444', '#f59e0b']
            }]
        };
    }

    loadRecentActivity() {
        this.recentActivity = [
            { time: '10 min ago', action: 'Approved CASE-DOC-002' },
            { time: '1 hour ago', action: 'Reviewed invoice INV-TOI-1234' },
            { time: '2 hours ago', action: 'Returned CASE-DIT-003 for clarification' },
            { time: '3 hours ago', action: 'Approved CASE-DAD-005' }
        ];
    }

    getDaysOld(createdAt: any): number {
        if (!createdAt) return 0;
        const created = new Date(createdAt);
        const now = new Date();
        const diff = now.getTime() - created.getTime();
        return Math.floor(diff / (1000 * 60 * 60 * 24));
    }

    getPrioritySeverity(priority: string): 'info' | 'warning' | 'danger' {
        const map: any = {
            'HIGH': 'danger',
            'MEDIUM': 'warning',
            'NORMAL': 'info'
        };
        return map[priority] || 'info';
    }

    reviewPendingCases() {
        this.router.navigate(['/cases/list'], { queryParams: { status: 'PENDING_APPROVAL' } });
    }

    viewAllPending() {
        this.router.navigate(['/cases/list'], { queryParams: { status: 'PENDING_APPROVAL' } });
    }

    quickApprove(caseItem: any) {
        if (confirm(`Quick approve case ${caseItem.caseNumber}?`)) {
            // Call approval API
            alert('Case approved! (implement actual API call)');
            this.loadDashboardData();
        }
    }

    updateCharts() {
        // Update charts based on real data
    }
}