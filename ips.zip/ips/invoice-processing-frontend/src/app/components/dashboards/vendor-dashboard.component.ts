import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ChartModule } from 'primeng/chart';
import { ProgressBarModule } from 'primeng/progressbar';
import { TimelineModule } from 'primeng/timeline';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-vendor-dashboard',
    standalone: true,
    imports: [
        CommonModule,
        CardModule,
        ButtonModule,
        TableModule,
        TagModule,
        ChartModule,
        ProgressBarModule,
        TimelineModule,
        ToastModule
    ],
    providers: [MessageService],
    template: `
        <div class="p-4">
            <div class="flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="text-3xl font-bold m-0">Vendor Portal</h1>
                    <p class="text-600 mt-1">Welcome, {{ vendorName }}</p>
                </div>
                <button pButton label="Upload Invoice" icon="pi pi-upload" 
                        class="p-button-lg" routerLink="/vendor/invoices"></button>
            </div>

            <!-- Quick Stats -->
            <div class="grid mb-4">
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-active">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Active Bids</div>
                                <div class="text-4xl font-bold">{{ activeBidsCount }}</div>
                            </div>
                            <i class="pi pi-money-bill text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-won">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Contracts Won</div>
                                <div class="text-4xl font-bold">{{ contractsWonCount }}</div>
                            </div>
                            <i class="pi pi-trophy text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-pending">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Pending Invoices</div>
                                <div class="text-4xl font-bold">{{ pendingInvoicesCount }}</div>
                            </div>
                            <i class="pi pi-file text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 md:col-3">
                    <div class="card mb-0 stat-card stat-revenue">
                        <div class="flex justify-content-between align-items-center">
                            <div>
                                <div class="text-lg font-semibold mb-1">Total Revenue</div>
                                <div class="text-2xl font-bold">₹{{ totalRevenue | number:'1.0-0' }}</div>
                            </div>
                            <i class="pi pi-chart-line text-5xl opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Required Banner -->
            <div *ngIf="actionRequiredCount > 0" class="card mb-4" 
                 style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white;">
                <div class="flex align-items-center justify-content-between">
                    <div class="flex align-items-center">
                        <i class="pi pi-exclamation-circle text-4xl mr-3"></i>
                        <div>
                            <div class="text-xl font-bold">{{ actionRequiredCount }} Items Need Your Attention</div>
                            <div class="text-sm opacity-90">Bid deadlines approaching and invoice clarifications needed</div>
                        </div>
                    </div>
                    <button pButton label="View Now" icon="pi pi-arrow-right" 
                            iconPos="right" class="p-button-rounded"></button>
                </div>
            </div>

            <!-- Main Content Sections -->
            <div class="grid mb-4">
                <!-- Active Bidding Opportunities -->
                <div class="col-12 md:col-8">
                    <p-card>
                        <div class="flex justify-content-between align-items-center mb-3">
                            <h3 class="m-0">Active Bidding Opportunities</h3>
                            <button pButton label="View All Bids" icon="pi pi-external-link" 
                                    class="p-button-text p-button-sm" routerLink="/vendor/bids"></button>
                        </div>

                        <p-table [value]="activeBids" responsiveLayout="scroll">
                            <ng-template pTemplate="header">
                                <tr>
                                    <th>Case Number</th>
                                    <th>Product/Service</th>
                                    <th>Budget (₹)</th>
                                    <th>Deadline</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="body" let-bid>
                                <tr>
                                    <td><span class="font-semibold">{{ bid.caseNumber }}</span></td>
                                    <td>{{ bid.productName }}</td>
                                    <td>₹{{ bid.budget | number:'1.0-0' }}</td>
                                    <td>
                                        <span [class.text-red-500]="isDeadlineNear(bid.deadline)">
                                            {{ bid.deadline | date:'MMM d, y' }}
                                        </span>
                                    </td>
                                    <td>
                                        <p-tag [value]="bid.status" 
                                               [severity]="getBidStatusSeverity(bid.status)"></p-tag>
                                    </td>
                                    <td>
                                        <button *ngIf="bid.status === 'OPEN'" 
                                                pButton label="Submit Bid" 
                                                class="p-button-sm p-button-success"
                                                (click)="submitBid(bid)"></button>
                                        <button *ngIf="bid.status === 'SUBMITTED'" 
                                                pButton label="View" icon="pi pi-eye"
                                                class="p-button-sm p-button-text"
                                                (click)="viewBidDetails(bid)"></button>
                                    </td>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="emptymessage">
                                <tr>
                                    <td colspan="6" class="text-center p-4">
                                        <i class="pi pi-inbox text-4xl text-600 mb-2"></i>
                                        <p class="text-lg">No active bidding opportunities</p>
                                    </td>
                                </tr>
                            </ng-template>
                        </p-table>
                    </p-card>
                </div>

                <!-- Recent Updates -->
                <div class="col-12 md:col-4">
                    <p-card header="Recent Updates">
                        <p-timeline [value]="recentUpdates" align="left">
                            <ng-template pTemplate="content" let-event>
                                <small class="text-600">{{ event.time }}</small>
                                <p class="mt-1 mb-0">
                                    <i [class]="event.icon + ' mr-2'"></i>
                                    {{ event.message }}
                                </p>
                            </ng-template>
                        </p-timeline>
                    </p-card>
                </div>
            </div>

            <!-- Invoice Status Section -->
            <div class="card mb-4">
                <div class="flex justify-content-between align-items-center mb-3">
                    <h3 class="m-0">My Invoices</h3>
                    <button pButton label="Upload New Invoice" icon="pi pi-plus" 
                            class="p-button-sm" routerLink="/vendor/invoices"></button>
                </div>

                <p-table [value]="myInvoices" [rows]="5" responsiveLayout="scroll">
                    <ng-template pTemplate="header">
                        <tr>
                            <th>Invoice #</th>
                            <th>Case</th>
                            <th>Amount (₹)</th>
                            <th>Submit Date</th>
                            <th>Status</th>
                            <th>Scrutiny Progress</th>
                            <th>Actions</th>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="body" let-invoice>
                        <tr>
                            <td><span class="font-semibold">{{ invoice.invoiceNumber }}</span></td>
                            <td>{{ invoice.caseNumber }}</td>
                            <td>₹{{ invoice.amount | number:'1.0-0' }}</td>
                            <td>{{ invoice.submitDate | date:'MMM d, y' }}</td>
                            <td>
                                <p-tag [value]="invoice.status" 
                                       [severity]="getInvoiceStatusSeverity(invoice.status)"></p-tag>
                            </td>
                            <td>
                                <div class="flex align-items-center gap-2">
                                    <div class="progress-container">
                                        <p-progressBar [value]="invoice.scrutinyProgress" 
                                                      [showValue]="false"></p-progressBar>
                                    </div>
                                    <span class="text-sm">{{ invoice.scrutinyProgress }}%</span>
                                </div>
                            </td>
                            <td>
                                <button pButton icon="pi pi-eye" 
                                        class="p-button-text p-button-sm"
                                        pTooltip="View Details"
                                        (click)="viewInvoiceDetails(invoice)"></button>
                                <button *ngIf="invoice.clarificationNeeded" 
                                        pButton icon="pi pi-comment" 
                                        class="p-button-text p-button-sm p-button-warning"
                                        pTooltip="Clarification Needed"
                                        (click)="viewInvoiceDetails(invoice)"></button>
                            </td>
                        </tr>
                    </ng-template>
                </p-table>
            </div>

            <!-- Performance Analytics -->
            <div class="grid">
                <div class="col-12 md:col-6">
                    <p-card header="Bid Win Rate">
                        <p-chart type="doughnut" [data]="winRateChart" [options]="doughnutOptions"></p-chart>
                        <div class="mt-3 text-center">
                            <div class="text-4xl font-bold text-primary">{{ winRate }}%</div>
                            <div class="text-sm text-600">Overall Win Rate</div>
                        </div>
                    </p-card>
                </div>
                <div class="col-12 md:col-6">
                    <p-card header="Revenue Trend (Last 6 Months)">
                        <p-chart type="bar" [data]="revenueChart" [options]="barChartOptions"></p-chart>
                    </p-card>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="grid mt-4">
                <div class="col-12 md:col-4">
                    <p-card>
                        <div class="text-center p-3">
                            <i class="pi pi-send text-5xl text-primary mb-3"></i>
                            <h4 class="mt-0">Submit Bid</h4>
                            <p class="text-600">{{ activeBidsCount }} opportunities available</p>
                            <button pButton label="Browse Opportunities" 
                                    class="p-button-outlined w-full" routerLink="/vendor/bids"></button>
                        </div>
                    </p-card>
                </div>
                <div class="col-12 md:col-4">
                    <p-card>
                        <div class="text-center p-3">
                            <i class="pi pi-upload text-5xl" style="color: #10b981;" class="mb-3"></i>
                            <h4 class="mt-0">Upload Invoice</h4>
                            <p class="text-600">Submit invoices for won contracts</p>
                            <button pButton label="Upload Now" 
                                    class="p-button-outlined w-full" 
                                    (click)="uploadNewInvoice()"></button>
                        </div>
                    </p-card>
                </div>
                <div class="col-12 md:col-4">
                    <p-card>
                        <div class="text-center p-3">
                            <i class="pi pi-chart-bar text-5xl" style="color: #f59e0b;" class="mb-3"></i>
                            <h4 class="mt-0">Performance Report</h4>
                            <p class="text-600">View detailed analytics</p>
                            <button pButton label="View Report" 
                                    class="p-button-outlined w-full"
                                    (click)="viewPerformanceReport()"></button>
                        </div>
                    </p-card>
                </div>
            </div>
            
            <p-toast></p-toast>
        </div>
    `,
    styles: [`
      .stat-card {
        border-radius: 12px;
        color: white;
      }
      .stat-active { background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); }
      .stat-won { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
      .stat-pending { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
      .stat-revenue { background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); }

      .progress-container {
        flex: 1;
        max-width: 100px;
      }

      :host ::ng-deep {
        .p-progressbar {
          height: 8px;
          border-radius: 4px;
        }
        .p-timeline-event-content {
          line-height: 1.3;
        }
      }
    `]
})
export class VendorDashboardComponent implements OnInit {
    vendorName = 'Times of India Publications';
    activeBidsCount = 2;
    contractsWonCount = 5;
    pendingInvoicesCount = 1;
    totalRevenue = 5850000;
    actionRequiredCount = 1;
    winRate = 67;

    activeBids: any[] = [];
    myInvoices: any[] = [];
    recentUpdates: any[] = [];

    winRateChart: any;
    revenueChart: any;
    doughnutOptions: any;
    barChartOptions: any;

    constructor(
        private router: Router,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        this.loadDashboardData();
        this.initializeCharts();
    }

    loadDashboardData() {
        // Mock active bids
        this.activeBids = [
            {
                caseNumber: 'CASE-DOC-006',
                productName: 'FM Radio Campaign',
                budget: 3000000,
                deadline: new Date(2025, 9, 20),
                status: 'OPEN'
            }
        ];

        // Mock invoices
        this.myInvoices = [
            {
                invoiceNumber: 'INV-TOI-2025-1234',
                caseNumber: 'CASE-DOC-004',
                amount: 100300,
                submitDate: new Date(2025, 9, 13),
                status: 'UNDER_SCRUTINY',
                scrutinyProgress: 45,
                clarificationNeeded: true
            }
        ];

        // Mock recent updates
        this.recentUpdates = [
            {
                time: '2 hours ago',
                message: 'Bid submitted for CASE-DOC-006',
                icon: 'pi pi-check-circle text-green-500'
            },
            {
                time: '1 day ago',
                message: 'Invoice INV-TOI-1234 under scrutiny',
                icon: 'pi pi-clock text-blue-500'
            },
            {
                time: '2 days ago',
                message: 'Won contract for CASE-DOC-004',
                icon: 'pi pi-trophy text-yellow-500'
            },
            {
                time: '3 days ago',
                message: 'Payment received ₹4.5L',
                icon: 'pi pi-money-bill text-green-500'
            }
        ];
    }

    initializeCharts() {
        this.doughnutOptions = {
            plugins: {
                legend: { position: 'bottom' }
            }
        };

        this.barChartOptions = {
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        };

        // Win rate chart
        this.winRateChart = {
            labels: ['Won', 'Lost'],
            datasets: [{
                data: [67, 33],
                backgroundColor: ['#10b981', '#e5e7eb']
            }]
        };

        // Revenue chart
        this.revenueChart = {
            labels: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
            datasets: [{
                label: 'Revenue (₹)',
                data: [850000, 920000, 1050000, 980000, 1150000, 900000],
                backgroundColor: '#8b5cf6'
            }]
        };
    }

    isDeadlineNear(deadline: Date): boolean {
        const days = Math.ceil((deadline.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
        return days <= 3;
    }

    getBidStatusSeverity(status: string): 'success' | 'info' | 'warning' | 'danger' {
        const map: any = {
            'OPEN': 'warning',
            'SUBMITTED': 'info',
            'WON': 'success',
            'LOST': 'danger'
        };
        return map[status] || 'info';
    }

    getInvoiceStatusSeverity(status: string): 'success' | 'info' | 'warning' | 'danger' {
        const map: any = {
            'DRAFT': 'secondary',
            'SUBMITTED': 'info',
            'UNDER_SCRUTINY': 'warning',
            'APPROVED': 'success',
            'REJECTED': 'danger'
        };
        return map[status] || 'info';
    }

    submitBid(bid: any) {
        // For demo, show success message
        // In production, would navigate to bid form
        if (confirm(`Submit bid for ${bid.caseNumber}?`)) {
            this.messageService.add({
                severity: 'success',
                summary: 'Bid Submitted',
                detail: `Your bid for ${bid.caseNumber} has been submitted successfully`
            });

            // Update the bid status
            bid.status = 'SUBMITTED';
            this.activeBidsCount--;
        }
    }

    viewBidDetails(bid: any) {
        alert(`Bid Details:\nCase: ${bid.caseNumber}\nProduct: ${bid.productName}\nBudget: ₹${bid.budget}\nDeadline: ${bid.deadline}`);
    }

    viewInvoiceDetails(invoice: any) {
        this.router.navigate(['/cases/scrutiny', invoice.id]);
    }

    viewPerformanceReport() {
        // This will navigate the user to a detailed performance report page.
        // Make sure you have a corresponding route set up in your application's routing configuration.
        this.router.navigate(['/vendor/performance']);
    }

    uploadNewInvoice() {
        this.router.navigate(['/vendor/invoices']);
    }
}