import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';

@Component({
    selector: 'app-unauthorized',
    standalone: true,
    imports: [CommonModule, ButtonModule],
    template: `
    <div class="flex align-items-center justify-content-center" style="min-height: 80vh;">
      <div class="text-center">
        <i class="pi pi-lock text-6xl text-red-500 mb-4"></i>
        <h1 class="text-4xl font-bold mb-3">Access Denied</h1>
        <p class="text-xl text-600 mb-4">You don't have permission to access this page.</p>
        <button pButton label="Go Back" icon="pi pi-arrow-left" (click)="goBack()"></button>
      </div>
    </div>
  `
})
export class UnauthorizedComponent {
    constructor(private router: Router) {}

    goBack() {
        this.router.navigate(['/']);
    }
}
