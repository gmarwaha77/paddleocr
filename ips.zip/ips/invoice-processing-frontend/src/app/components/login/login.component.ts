import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        CardModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        MessageModule
    ],
    template: `
        <div class="flex align-items-center justify-content-center"
             style="min-height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <p-card class="shadow-4" [style]="{ 'width': '450px' }">
                <ng-template pTemplate="header">
                    <div class="text-center pt-4">
                        <h1 class="text-4xl font-bold text-primary mb-2">
                            <i class="pi pi-building mr-2"></i>
                            IPS Portal
                        </h1>
                        <p class="text-600">Invoice Processing System</p>
                    </div>
                </ng-template>

                <div class="p-fluid">
                    <form (ngSubmit)="login()">
                        <div class="field mb-4">
                            <label for="username" class="block font-semibold mb-2">Username</label>
                            <input
                                    pInputText
                                    id="username"
                                    [(ngModel)]="username"
                                    name="username"
                                    placeholder="Enter username"
                                    required
                                    autofocus>
                        </div>

                        <div class="field mb-4">
                            <label for="password" class="block font-semibold mb-2">Password</label>
                            <p-password
                                    [(ngModel)]="password"
                                    name="password"
                                    [feedback]="false"
                                    [toggleMask]="true"
                                    styleClass="w-full"
                                    inputStyleClass="w-full"
                                    required>
                            </p-password>
                        </div>

                        <p-message
                                *ngIf="errorMessage"
                                severity="error"
                                [text]="errorMessage">
                        </p-message>

                        <button
                                pButton
                                type="submit"
                                label="Login"
                                icon="pi pi-sign-in"
                                class="w-full mt-3"
                                [loading]="loading"
                                [disabled]="!username || !password">
                        </button>
                    </form>
                </div>

                <ng-template pTemplate="footer">
                    <div class="pt-3 border-top-1 surface-border">
                        <p class="text-sm text-600 mb-3 font-semibold">Demo Credentials:</p>
                        <div class="grid text-xs">
                            <div class="col-6">
                                <div class="mb-3">
                                    <strong class="text-purple-600">Master:</strong>
                                    <div>master / master123</div>
                                    <small class="text-500">Manage all masters</small>
                                </div>
                                <div class="mb-3">
                                    <strong class="text-blue-600">Maker:</strong>
                                    <div>maker / maker123</div>
                                    <small class="text-500">Create procurement cases</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="mb-3">
                                    <strong class="text-green-600">Checker:</strong>
                                    <div>checker / checker123</div>
                                    <small class="text-500">Approve & scrutinize</small>
                                </div>
                                <div class="mb-3">
                                    <strong class="text-orange-600">Vendor:</strong>
                                    <div>vendor / vendor123</div>
                                    <small class="text-500">Submit bids & invoices</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </ng-template>
            </p-card>
        </div>
    `,
    styles: [`
      :host ::ng-deep {
        .p-card-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
        }
        .p-card-body {
          padding-top: 0;
        }
      }
    `]
})
export class LoginComponent {
    username = '';
    password = '';
    loading = false;
    errorMessage = '';

    constructor(
        private authService: AuthService,
        private router: Router
    ) {}

    login() {
        this.loading = true;
        this.errorMessage = '';

        this.authService.login(this.username, this.password).subscribe({
            next: (user) => {
                this.loading = false;

                // Redirect to role-specific dashboard
                if (user.roles.includes('ROLE_MASTER')) {
                    this.router.navigate(['/admin/departments']);
                } else if (user.roles.includes('ROLE_MAKER')) {
                    this.router.navigate(['/dashboard/maker']);
                } else if (user.roles.includes('ROLE_CHECKER')) {
                    this.router.navigate(['/dashboard/checker']);
                } else if (user.roles.includes('ROLE_VENDOR')) {
                    this.router.navigate(['/dashboard/vendor']);
                } else {
                    this.router.navigate(['/']);
                }
            },
            error: (error) => {
                this.loading = false;
                this.errorMessage = 'Invalid username or password';
                console.error('Login error:', error);
            }
        });
    }
}