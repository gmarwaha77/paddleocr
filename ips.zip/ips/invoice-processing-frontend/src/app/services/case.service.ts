import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { ProcurementCase, CaseLineItem, CaseApproval, CaseStatus } from '../models/case.model';

@Injectable({
    providedIn: 'root'
})
export class CaseService {
    private apiUrl = `${environment.apiUrl}/cases`;

    constructor(private http: HttpClient) {}

    getAllCases(): Observable<ProcurementCase[]> {
        return this.http.get<ApiResponse<ProcurementCase[]>>(this.apiUrl)
            .pipe(map(response => response.data));
    }

    getCasesByDepartment(departmentId: number): Observable<ProcurementCase[]> {
        return this.http.get<ApiResponse<ProcurementCase[]>>(`${this.apiUrl}/department/${departmentId}`)
            .pipe(map(response => response.data));
    }

    getCasesByStatus(status: CaseStatus): Observable<ProcurementCase[]> {
        return this.http.get<ApiResponse<ProcurementCase[]>>(`${this.apiUrl}/status/${status}`)
            .pipe(map(response => response.data));
    }

    getCaseById(id: number): Observable<ProcurementCase> {
        return this.http.get<ApiResponse<ProcurementCase>>(`${this.apiUrl}/${id}`)
            .pipe(map(response => response.data));
    }

    createCase(procurementCase: ProcurementCase): Observable<ProcurementCase> {
        return this.http.post<ApiResponse<ProcurementCase>>(this.apiUrl, procurementCase)
            .pipe(map(response => response.data));
    }

    updateCase(id: number, procurementCase: ProcurementCase): Observable<ProcurementCase> {
        return this.http.put<ApiResponse<ProcurementCase>>(`${this.apiUrl}/${id}`, procurementCase)
            .pipe(map(response => response.data));
    }

    addLineItem(caseId: number, lineItem: CaseLineItem): Observable<CaseLineItem> {
        return this.http.post<ApiResponse<CaseLineItem>>(`${this.apiUrl}/${caseId}/items`, lineItem)
            .pipe(map(response => response.data));
    }

    submitForApproval(id: number): Observable<ProcurementCase> {
        return this.http.put<ApiResponse<ProcurementCase>>(`${this.apiUrl}/${id}/submit-approval`, {})
            .pipe(map(response => response.data));
    }

    approveCase(approval: CaseApproval): Observable<ProcurementCase> {
        return this.http.put<ApiResponse<ProcurementCase>>(`${this.apiUrl}/${approval.caseId}/approve`, approval)
            .pipe(map(response => response.data));
    }

    rejectCase(approval: CaseApproval): Observable<ProcurementCase> {
        return this.http.put<ApiResponse<ProcurementCase>>(`${this.apiUrl}/${approval.caseId}/reject`, approval)
            .pipe(map(response => response.data));
    }
}
