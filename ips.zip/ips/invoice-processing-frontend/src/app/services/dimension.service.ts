import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { DimensionTemplate } from '../models/product.model';

@Injectable({
    providedIn: 'root'
})
export class DimensionService {
    private apiUrl = `${environment.apiUrl}/master/dimensions`;

    constructor(private http: HttpClient) {}

    getDimensionsByProduct(productId: number): Observable<DimensionTemplate[]> {
        return this.http.get<ApiResponse<DimensionTemplate[]>>(`${this.apiUrl}/product/${productId}`)
            .pipe(map(response => response.data));
    }

    createDimension(dimension: DimensionTemplate): Observable<DimensionTemplate> {
        return this.http.post<ApiResponse<DimensionTemplate>>(this.apiUrl, dimension)
            .pipe(map(response => response.data));
    }

    updateDimension(id: number, dimension: DimensionTemplate): Observable<DimensionTemplate> {
        return this.http.put<ApiResponse<DimensionTemplate>>(`${this.apiUrl}/${id}`, dimension)
            .pipe(map(response => response.data));
    }

    deleteDimension(id: number): Observable<void> {
        return this.http.delete<ApiResponse<void>>(`${this.apiUrl}/${id}`)
            .pipe(map(response => response.data));
    }

    calculatePrice(productId: number, dimensionValues: { [key: string]: any }): Observable<any> {
        return this.http.post<ApiResponse<any>>(`${this.apiUrl}/calculate-price`, {
            productId,
            dimensionValues
        }).pipe(map(response => response.data));
    }
}