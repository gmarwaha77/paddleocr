import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { User } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private apiUrl = environment.apiUrl;
    private currentUserSubject = new BehaviorSubject<User | null>(null);
    public currentUser$ = this.currentUserSubject.asObservable();

    constructor(private http: HttpClient) {
        this.loadCurrentUser();
    }

    login(username: string, password: string): Observable<User> {
        const credentials = btoa(username + ':' + password);
        const headers = new HttpHeaders({
            'Authorization': 'Basic ' + credentials,
            'Content-Type': 'application/json'
        });

        return this.http.get<any>(`${this.apiUrl}/auth/current-user`, {
            headers: headers,
            withCredentials: true
        }).pipe(
            map(response => {
                // Transform the response to User model
                const user: User = {
                    username: response.username,
                    roles: response.roles.map((r: any) =>
                        typeof r === 'string' ? r : r.authority
                    ),
                    authenticated: response.authenticated
                };
                return user;
            }),
            tap(user => {
                // Store credentials in localStorage
                localStorage.setItem('credentials', credentials);

                // Update current user subject
                this.currentUserSubject.next(user);

                console.log('Login successful:', user);
            })
        );
    }

    logout(): void {
        localStorage.removeItem('credentials');
        this.currentUserSubject.next(null);
    }

    isAuthenticated(): boolean {
        return !!localStorage.getItem('credentials');
    }

    getAuthHeader(): HttpHeaders {
        const credentials = localStorage.getItem('credentials');
        if (!credentials) {
            return new HttpHeaders({
                'Content-Type': 'application/json'
            });
        }
        return new HttpHeaders({
            'Authorization': `Basic ${credentials}`,
            'Content-Type': 'application/json'
        });
    }

    getCurrentUser(): Observable<User> {
        const headers = this.getAuthHeader();
        return this.http.get<any>(`${this.apiUrl}/auth/current-user`, {
            headers: headers,
            withCredentials: true
        }).pipe(
            map(response => ({
                username: response.username,
                roles: response.roles.map((r: any) =>
                    typeof r === 'string' ? r : r.authority
                ),
                authenticated: response.authenticated
            }))
        );
    }

    hasRole(role: string): boolean {
        const user = this.currentUserSubject.value;
        if (!user) return false;

        return user.roles.some(r => {
            const roleStr = typeof r === 'string' ? r : r;
            return roleStr.includes(role) || roleStr.includes(`ROLE_${role}`);
        });
    }

    private loadCurrentUser(): void {
        if (this.isAuthenticated()) {
            this.getCurrentUser().subscribe({
                next: user => this.currentUserSubject.next(user),
                error: () => this.logout()
            });
        }
    }
}