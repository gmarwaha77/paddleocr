import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';

// ===================================
// UPDATED & EXPORTED INTERFACES
// ===================================

export interface ProofMetadata {
    proofType?: string;
    publicationName?: string;
    publicationDate?: Date;
    publicationPage?: string;
    state?: string;
    city?: string;
    language?: string;
}

export interface ProofFile {
    id: number;
    lineItemId: number;
    fileName: string;
    fileSize: number;
    contentType: string;
    filePath?: string;
    thumbnailPath?: string;
    publicationName?: string;
    publicationDate?: string;
    publicationPage?: string;
    state?: string;
    city?: string;
    language?: string;
    verificationStatus: string;
    autoMatchScore?: number;
    requiresManualReview: boolean;
}

export interface RedFlag {
    type: string;
    severity: 'HIGH' | 'MEDIUM' | 'LOW';
    description: string;
}

export interface DimensionComparison {
    dimensionKey: string;
    dimensionName: string;
    expectedValue: any;
    actualValue: any;
    matchStatus: 'EXACT_MATCH' | 'WITHIN_TOLERANCE' | 'MISMATCH' | 'MISSING_VALUE';
    variancePercentage?: number;
    redFlag: boolean;
}

export interface LineItemReview {
    id: number;
    itemDescription: string;
    matchScore: number;
    matchStatus: string;
    matchResult?: {
        comparisons: DimensionComparison[];
    };
    proofCount: number;
    proofs: ProofFile[];
    requiresReview: boolean;
    redFlags?: RedFlag[];
}

export interface ProofUploadResponse {
    proofId: number;
    fileName: string;
    uploadSuccess: boolean;
    message: string;
}

export interface ScrutinySummary {
    invoiceId: number;
    invoiceNumber: string;
    vendorName: string;
    totalLineItems: number;
    perfectMatches: number;
    toleranceMatches: number;
    mismatches: number;
    missingProofs: number;
    redFlags: number;
    overallProgress: number;
    timeSaved: number;
}


@Injectable({
    providedIn: 'root'
})
export class ProofService {
    private apiUrl = `${environment.apiUrl}/invoices/proofs`;

    constructor(private http: HttpClient) {}

    /**
     * Upload proof document
     */
    uploadProof(
        file: File,
        lineItemId: number,
        metadata: ProofMetadata
    ): Observable<ProofUploadResponse> {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('lineItemId', lineItemId.toString());

        // Append metadata
        if (metadata.proofType) formData.append('proofType', metadata.proofType);
        if (metadata.publicationName) formData.append('publicationName', metadata.publicationName);
        if (metadata.publicationDate) formData.append('publicationDate', metadata.publicationDate.toISOString());
        if (metadata.publicationPage) formData.append('publicationPage', metadata.publicationPage);
        if (metadata.state) formData.append('state', metadata.state);
        if (metadata.city) formData.append('city', metadata.city);
        if (metadata.language) formData.append('language', metadata.language);

        return this.http.post<ApiResponse<ProofUploadResponse>>(`${this.apiUrl}/upload`, formData)
            .pipe(map(response => response.data));
    }

    /**
     * Get proofs for a line item
     */
    getProofsByLineItem(lineItemId: number): Observable<ProofFile[]> {
        return this.http.get<ApiResponse<ProofFile[]>>(`${this.apiUrl}/line-item/${lineItemId}`)
            .pipe(map(response => response.data));
    }

    /**
     * Trigger auto-verification for an invoice
     */
    autoVerifyProofs(invoiceId: number): Observable<void> {
        return this.http.post<ApiResponse<void>>(`${this.apiUrl}/auto-verify/${invoiceId}`, {})
            .pipe(map(response => response.data));
    }

    /**
     * Get scrutiny summary for dashboard
     */
    getScrutinySummary(invoiceId: number): Observable<ScrutinySummary> {
        return this.http.get<ApiResponse<ScrutinySummary>>(`${this.apiUrl}/scrutiny-summary/${invoiceId}`)
            .pipe(map(response => response.data));
    }

    /**
     * Get line items requiring review (exceptions only)
     */
    getReviewQueue(invoiceId: number): Observable<LineItemReview[]> {
        return this.http.get<ApiResponse<LineItemReview[]>>(`${this.apiUrl}/review-queue/${invoiceId}`)
            .pipe(map(response => response.data));
    }

    /**
     * Get all line items for review tab
     */
    getAllLineItemsForReview(invoiceId: number): Observable<LineItemReview[]> {
        return this.http.get<ApiResponse<LineItemReview[]>>(`${this.apiUrl}/all-items-for-review/${invoiceId}`)
            .pipe(map(response => response.data));
    }

    /**
     * Bulk approve items by dimension signature
     */
    bulkApprove(dimensionSignature: string, invoiceId: number): Observable<void> {
        return this.http.post<ApiResponse<void>>(`${this.apiUrl}/bulk-approve`, null, {
            params: {
                dimensionSignature,
                invoiceId: invoiceId.toString()
            }
        }).pipe(map(response => response.data));
    }

    /**
     * Delete a proof
     */
    deleteProof(proofId: number): Observable<void> {
        return this.http.delete<ApiResponse<void>>(`${this.apiUrl}/${proofId}`)
            .pipe(map(response => response.data));
    }

    /**
     * Download proof file
     */
    downloadProof(proofId: number): Observable<Blob> {
        return this.http.get(`${this.apiUrl}/download/${proofId}`, {
            responseType: 'blob'
        });
    }

    /**
     * Verify a proof manually
     */
    verifyProof(
        proofId: number,
        status: string,
        comments: string
    ): Observable<void> {
        return this.http.post<ApiResponse<void>>(`${this.apiUrl}/${proofId}/verify`, {
            verificationStatus: status,
            comments: comments
        }).pipe(map(response => response.data));
    }
}