import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { Invoice, InvoiceApproval, InvoiceStatus, GSTCalculationResult } from '../models/invoice.model';

@Injectable({
    providedIn: 'root'
})
export class InvoiceService {
    private apiUrl = `${environment.apiUrl}/invoices`;

    constructor(private http: HttpClient) {}

    getAllInvoices(): Observable<Invoice[]> {
        return this.http.get<ApiResponse<Invoice[]>>(this.apiUrl)
            .pipe(map(response => response.data));
    }

    getInvoicesByVendor(vendorId: number): Observable<Invoice[]> {
        return this.http.get<ApiResponse<Invoice[]>>(`${this.apiUrl}/vendor/${vendorId}`)
            .pipe(map(response => response.data));
    }

    getInvoicesByStatus(status: InvoiceStatus): Observable<Invoice[]> {
        return this.http.get<ApiResponse<Invoice[]>>(`${this.apiUrl}/status/${status}`)
            .pipe(map(response => response.data));
    }

    getInvoiceById(id: number): Observable<Invoice> {
        return this.http.get<ApiResponse<Invoice>>(`${this.apiUrl}/${id}`)
            .pipe(map(response => response.data));
    }

    uploadInvoice(vendorId: number, file: File, caseId?: number): Observable<Invoice> {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('vendorId', vendorId.toString());
        if (caseId) {
            formData.append('caseId', caseId.toString());
        }

        return this.http.post<ApiResponse<Invoice>>(`${this.apiUrl}/upload`, formData)
            .pipe(map(response => response.data));
    }

    parseInvoice(id: number): Observable<Invoice> {
        return this.http.post<ApiResponse<Invoice>>(`${this.apiUrl}/${id}/parse`, {})
            .pipe(map(response => response.data));
    }

    validateInvoice(id: number): Observable<Invoice> {
        return this.http.post<ApiResponse<Invoice>>(`${this.apiUrl}/${id}/validate`, {})
            .pipe(map(response => response.data));
    }

    approveInvoice(approval: InvoiceApproval): Observable<Invoice> {
        return this.http.put<ApiResponse<Invoice>>(`${this.apiUrl}/${approval.invoiceId}/approve`, approval)
            .pipe(map(response => response.data));
    }

    getGSTBreakup(id: number): Observable<GSTCalculationResult> {
        return this.http.get<ApiResponse<GSTCalculationResult>>(`${this.apiUrl}/${id}/gst-breakup`)
            .pipe(map(response => response.data));
    }
}
