import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { Product, ProductCategory, SubCategory } from '../models/product.model';

@Injectable({
    providedIn: 'root'
})
export class ProductService {
    private apiUrl = `${environment.apiUrl}/master/product-hierarchies`;

    constructor(private http: HttpClient) {}

    // Categories
    getAllCategories(): Observable<ProductCategory[]> {
        return this.http.get<ApiResponse<ProductCategory[]>>(`${this.apiUrl}/categories`)
            .pipe(map(response => response.data));
    }

    getCategoriesByDepartment(departmentId: number): Observable<ProductCategory[]> {
        return this.http.get<ApiResponse<ProductCategory[]>>(`${this.apiUrl}/categories/department/${departmentId}`)
            .pipe(map(response => response.data));
    }

    createCategory(category: ProductCategory): Observable<ProductCategory> {
        return this.http.post<ApiResponse<ProductCategory>>(`${this.apiUrl}/categories`, category)
            .pipe(map(response => response.data));
    }

    // SubCategories
    getSubCategoriesByCategory(categoryId: number): Observable<SubCategory[]> {
        return this.http.get<ApiResponse<SubCategory[]>>(`${this.apiUrl}/sub-categories/category/${categoryId}`)
            .pipe(map(response => response.data));
    }

    createSubCategory(subCategory: SubCategory): Observable<SubCategory> {
        return this.http.post<ApiResponse<SubCategory>>(`${this.apiUrl}/sub-categories`, subCategory)
            .pipe(map(response => response.data));
    }

    // Products
    getProductsBySubCategory(subCategoryId: number): Observable<Product[]> {
        return this.http.get<ApiResponse<Product[]>>(`${this.apiUrl}/products/sub-category/${subCategoryId}`)
            .pipe(map(response => response.data));
    }

    getProductById(id: number): Observable<Product> {
        return this.http.get<ApiResponse<Product>>(`${this.apiUrl}/products/${id}`)
            .pipe(map(response => response.data));
    }

    createProduct(product: Product): Observable<Product> {
        return this.http.post<ApiResponse<Product>>(`${this.apiUrl}/products`, product)
            .pipe(map(response => response.data));
    }

    updateProduct(id: number, product: Product): Observable<Product> {
        return this.http.put<ApiResponse<Product>>(`${this.apiUrl}/products/${id}`, product)
            .pipe(map(response => response.data));
    }
}
