import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { Department } from '../models/department.model';

@Injectable({
    providedIn: 'root'
})
export class DepartmentService {
    private apiUrl = `${environment.apiUrl}/master/departments`;

    constructor(private http: HttpClient) {}

    getAllDepartments(): Observable<Department[]> {
        return this.http.get<ApiResponse<Department[]>>(this.apiUrl)
            .pipe(map(response => response.data));
    }

    getActiveDepartments(): Observable<Department[]> {
        return this.http.get<ApiResponse<Department[]>>(`${this.apiUrl}/active`)
            .pipe(map(response => response.data));
    }

    getDepartmentById(id: number): Observable<Department> {
        return this.http.get<ApiResponse<Department>>(`${this.apiUrl}/${id}`)
            .pipe(map(response => response.data));
    }

    createDepartment(department: Department): Observable<Department> {
        return this.http.post<ApiResponse<Department>>(this.apiUrl, department)
            .pipe(map(response => response.data));
    }

    updateDepartment(id: number, department: Department): Observable<Department> {
        return this.http.put<ApiResponse<Department>>(`${this.apiUrl}/${id}`, department)
            .pipe(map(response => response.data));
    }
}
