import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { Vendor } from '../models/vendor.model';

@Injectable({
    providedIn: 'root'
})
export class VendorService {
    private apiUrl = `${environment.apiUrl}/master/vendors`;

    constructor(private http: HttpClient) {}

    getAllVendors(): Observable<Vendor[]> {
        return this.http.get<ApiResponse<Vendor[]>>(this.apiUrl)
            .pipe(map(response => response.data));
    }

    getActiveVendors(): Observable<Vendor[]> {
        return this.http.get<ApiResponse<Vendor[]>>(`${this.apiUrl}/active`)
            .pipe(map(response => response.data));
    }

    getVendorsByProduct(productId: number): Observable<Vendor[]> {
        return this.http.get<ApiResponse<Vendor[]>>(`${this.apiUrl}/product/${productId}`)
            .pipe(map(response => response.data));
    }

    getVendorById(id: number): Observable<Vendor> {
        return this.http.get<ApiResponse<Vendor>>(`${this.apiUrl}/${id}`)
            .pipe(map(response => response.data));
    }

    createVendor(vendor: Vendor): Observable<Vendor> {
        return this.http.post<ApiResponse<Vendor>>(this.apiUrl, vendor)
            .pipe(map(response => response.data));
    }

    updateVendor(id: number, vendor: Vendor): Observable<Vendor> {
        return this.http.put<ApiResponse<Vendor>>(`${this.apiUrl}/${id}`, vendor)
            .pipe(map(response => response.data));
    }
}
