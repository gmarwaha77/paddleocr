export enum InvoiceStatus {
    UPLOADED = 'UPLOADED',
    PARSED = 'PARSED',
    VALIDATED = 'VALIDATED',
    VALIDATION_FAILED = 'VALIDATION_FAILED',
    PENDING_APPROVAL = 'PENDING_APPROVAL',
    APPROVED = 'APPROVED',
    REJECTED = 'REJECTED',
    PAYMENT_PROCESSED = 'PAYMENT_PROCESSED',
    CANCELLED = 'CANCELLED'
}

export interface Invoice {
    id?: number;
    invoiceNumber?: string;
    vendorId: number;
    vendorName?: string;
    vendorGstin?: string;
    caseId?: number;
    caseNumber?: string;
    invoiceDate?: string;
    dueDate?: string;
    placeOfSupply?: string;
    isInterState?: boolean;
    taxableAmount?: number;
    cgstAmount?: number;
    sgstAmount?: number;
    igstAmount?: number;
    totalGstAmount?: number;
    totalInvoiceAmount?: number;
    invoiceStatus?: InvoiceStatus;
    uploadedFilePath?: string;
    parsedAt?: string;
    validatedAt?: string;
    approvedAt?: string;
    approvedBy?: string;
    rejectionReason?: string;
    lineItems?: InvoiceLineItem[];
}

export interface InvoiceLineItem {
    id?: number;
    invoiceId?: number;
    productId?: number;
    productName?: string;
    itemDescription?: string;
    hsnSacCode?: string;
    quantity?: number;
    unitPrice?: number;
    taxableValue?: number;
    gstRate?: number;
    cgstAmount?: number;
    sgstAmount?: number;
    igstAmount?: number;
    totalAmount?: number;
    dimensionValues?: { [key: string]: any };
    isValidated?: boolean;
    validationErrors?: string;
}

export interface InvoiceApproval {
    invoiceId?: number;
    approved: boolean;
    comments?: string;
}

export interface GSTCalculationResult {
    taxableAmount: number;
    cgstRate?: number;
    sgstRate?: number;
    igstRate?: number;
    cgstAmount: number;
    sgstAmount: number;
    igstAmount: number;
    totalGstAmount: number;
    totalAmount: number;
    isInterState: boolean;
    placeOfSupply: string;
}
