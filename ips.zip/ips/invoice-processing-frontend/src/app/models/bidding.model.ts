export enum BidStatus {
    PENDING = 'PENDING',
    SUBMITTED = 'SUBMITTED',
    UNDER_EVALUATION = 'UNDER_EVALUATION',
    SELECTED = 'SELECTED',
    REJECTED = 'REJECTED',
    EXPIRED = 'EXPIRED'
}

export interface VendorBid {
    id?: number;
    bidNumber?: string;
    caseId: number;
    caseNumber?: string;
    lineItemId: number;
    vendorId?: number;
    vendorName?: string;
    bidAmount: number;
    quotedPrice?: number;
    bidStatus?: BidStatus;
    submittedAt?: string;
    validTill?: string;
    bidRemarks?: string;
    isSelected?: boolean;
}

export interface BiddingInvitation {
    caseId?: number;
    vendorIds: number[];
}
