export interface ProductCategory {
    id?: number;
    categoryCode: string;
    categoryName: string;
    description?: string;
    departmentId?: number;
    departmentName?: string;
    isActive?: boolean;
}

export interface SubCategory {
    id?: number;
    subCategoryCode: string;
    subCategoryName: string;
    description?: string;
    categoryId?: number;
    categoryName?: string;
    isActive?: boolean;
}

export interface Product {
    id?: number;
    productCode: string;
    productName: string;
    description?: string;
    subCategoryId?: number;
    subCategoryName?: string;
    hsnSacCode?: string;
    classificationType?: string;
    unitOfMeasurement?: string;
    ceilingRate?: number;
    hasCeilingRate?: boolean;
    isActive?: boolean;
    dimensions?: DimensionTemplate[];
}

export enum DimensionDataType {
    NUMBER = 'NUMBER',
    STRING = 'STRING',
    ENUM = 'ENUM',
    BOOLEAN = 'BOOLEAN',
    DATE = 'DATE',
    DECIMAL = 'DECIMAL'
}

export enum DimensionUIComponent {
    INPUT = 'INPUT',
    TEXTAREA = 'TEXTAREA',
    DROPDOWN = 'DROPDOWN',
    CHECKBOX = 'CHECKBOX',
    RADIO = 'RADIO',
    DATEPICKER = 'DATEPICKER',
    NUMBER_INPUT = 'NUMBER_INPUT'
}

export interface DimensionTemplate {
    id?: number;
    productId?: number;
    dimensionName: string;
    dimensionKey: string;
    dataType: DimensionDataType;
    uiComponent: DimensionUIComponent;
    isMandatory?: boolean;
    enumValues?: string;
    minValue?: number;
    maxValue?: number;
    defaultValue?: string;
    validationRegex?: string;
    displayOrder?: number;
    helpText?: string;
    usedInPricing?: boolean;
}