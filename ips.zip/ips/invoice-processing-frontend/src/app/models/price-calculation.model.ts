export interface PriceCalculationRequest {
    productId: number;
    dimensionValues: { [key: string]: any };
}

export interface PriceCalculationResponse {
    calculatedPrice: number;
    minPrice: number;
    maxPrice: number;
    formula?: string;
    withinRange: boolean;
}
