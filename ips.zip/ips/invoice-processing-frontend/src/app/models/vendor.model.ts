export enum VendorStatus {
    ACTIVE = 'ACTIVE',
    INACTIVE = 'INACTIVE',
    SUSPENDED = 'SUSPENDED',
    BLACKLISTED = 'BLACKLISTED'
}

export interface Vendor {
    id?: number;
    vendorCode: string;
    vendorName: string;
    gstin: string;
    pan?: string;
    contactPerson?: string;
    email?: string;
    phone?: string;
    address?: string;
    city?: string;
    state?: string;
    pincode?: string;
    bankName?: string;
    accountNumber?: string;
    ifscCode?: string;
    vendorStatus?: VendorStatus;
    empanelmentDate?: string;
    empanelmentExpiryDate?: string;
    isActive?: boolean;
}
