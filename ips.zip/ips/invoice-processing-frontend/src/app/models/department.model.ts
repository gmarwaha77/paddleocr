export interface Department {
    id?: number;
    departmentCode: string;
    departmentName: string;
    description?: string;
    annualBudget: number;
    budgetUtilized?: number;
    headOfDepartment?: string;
    contactEmail?: string;
    contactPhone?: string;
    isActive?: boolean;
}
