export enum CaseStatus {
    DRAFT = 'DRAFT',
    SUBMITTED = 'SUBMITTED',
    UNDER_REVIEW = 'UNDER_REVIEW',
    APPROVED = 'APPROVED',
    REJECTED = 'REJECTED',
    BIDDING_IN_PROGRESS = 'BIDDING_IN_PROGRESS',
    VENDOR_SELECTED = 'VENDOR_SELECTED',
    COMPLETED = 'COMPLETED',
    CANCELLED = 'CANCELLED',
    PENDING_APPROVAL = 'PENDING_APPROVAL'
}

export interface ProcurementCase {
    id?: number;
    caseNumber?: string;
    caseName: string;
    departmentId: number;
    departmentName?: string;
    categoryId?: number;
    categoryName?: string;
    subCategoryId?: number;
    subCategoryName?: string;
    budgetName?: string;
    totalApprovedBudget: number;
    fundType?: string;
    edApprovalNote?: string;
    edApprovalFilePath?: string;
    caseStatus?: CaseStatus;
    submittedAt?: string;
    approvedAt?: string;
    approvedBy?: string;
    rejectedAt?: string;
    rejectedBy?: string;
    rejectionReason?: string;
    totalCaseAmount?: number;
    requiresBidding?: boolean;
    lineItems?: CaseLineItem[];
}

export interface CaseLineItem {
    id?: number;
    caseId?: number;
    productId: number;
    productName?: string;
    dimensionValues?: { [key: string]: any };
    ceilingAmount?: number;
    additionalBudgetAmount?: number;
    totalAmount?: number;
    calculatedPrice?: number;
    selectedVendorId?: number;
    selectedVendorName?: string;
    comments?: string;
    itemOrder?: number;
}

export interface CaseApproval {
    caseId?: number;
    approved: boolean;
    comments?: string;
}
