export const environment = {
    production: true,
    apiUrl: 'http://your-production-server:8080/api'
};
