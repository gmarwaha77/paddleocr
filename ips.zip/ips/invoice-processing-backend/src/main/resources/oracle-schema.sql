-- ================================================================
-- INVOICE PROCESSING SYSTEM - ORACLE DATABASE DDL
-- Version: 1.0
-- Database: Oracle 19c+
-- Generated: October 15, 2025
-- ================================================================

-- ================================================================
-- SECTION 1: DROP EXISTING OBJECTS (Optional - for clean install)
-- ================================================================

-- Drop tables in reverse order of dependencies
DROP TABLE invoice_line_item_proof CASCADE CONSTRAINTS;
DROP TABLE invoice_line_item CASCADE CONSTRAINTS;
DROP TABLE invoice CASCADE CONSTRAINTS;
DROP TABLE vendor_bid CASCADE CONSTRAINTS;
DROP TABLE case_audit_log CASCADE CONSTRAINTS;
DROP TABLE case_line_item CASCADE CONSTRAINTS;
DROP TABLE procurement_case CASCADE CONSTRAINTS;
DROP TABLE rate_matrix CASCADE CONSTRAINTS;
DROP TABLE product_vendor_mapping CASCADE CONSTRAINTS;
DROP TABLE dimension_template CASCADE CONSTRAINTS;
DROP TABLE product_master CASCADE CONSTRAINTS;
DROP TABLE sub_category CASCADE CONSTRAINTS;
DROP TABLE product_category CASCADE CONSTRAINTS;
DROP TABLE vendor_master CASCADE CONSTRAINTS;
DROP TABLE department_master CASCADE CONSTRAINTS;

-- Drop sequences
DROP SEQUENCE seq_department;
DROP SEQUENCE seq_product_category;
DROP SEQUENCE seq_sub_category;
DROP SEQUENCE seq_product;
DROP SEQUENCE seq_dimension;
DROP SEQUENCE seq_vendor;
DROP SEQUENCE seq_vendor_mapping;
DROP SEQUENCE seq_rate_matrix;
DROP SEQUENCE seq_case;
DROP SEQUENCE seq_case_line_item;
DROP SEQUENCE seq_case_audit;
DROP SEQUENCE seq_bid;
DROP SEQUENCE seq_invoice;
DROP SEQUENCE seq_invoice_item;
DROP SEQUENCE seq_invoice_proof;

-- ================================================================
-- SECTION 2: CREATE SEQUENCES
-- ================================================================

CREATE SEQUENCE seq_department START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_product_category START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_sub_category START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_product START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_dimension START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_vendor START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_vendor_mapping START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_rate_matrix START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_case START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_case_line_item START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_case_audit START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_bid START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_invoice START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_invoice_item START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_invoice_proof START WITH 1 INCREMENT BY 1 NOCACHE;

-- ================================================================
-- SECTION 3: MASTER DATA TABLES
-- ================================================================

-- Department Master
CREATE TABLE department_master (
                                   id NUMBER(19) PRIMARY KEY,
                                   department_code VARCHAR2(50) NOT NULL UNIQUE,
                                   department_name VARCHAR2(255) NOT NULL,
                                   description VARCHAR2(500),
                                   annual_budget NUMBER(19,2),
                                   head_of_department VARCHAR2(255),
                                   is_active NUMBER(1) DEFAULT 1,
                                   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                   created_by VARCHAR2(100),
                                   updated_by VARCHAR2(100)
);

CREATE INDEX idx_dept_code ON department_master(department_code);
CREATE INDEX idx_dept_active ON department_master(is_active);

-- Product Category
CREATE TABLE product_category (
                                  id NUMBER(19) PRIMARY KEY,
                                  category_code VARCHAR2(50) NOT NULL UNIQUE,
                                  category_name VARCHAR2(255) NOT NULL,
                                  description VARCHAR2(500),
                                  department_id NUMBER(19) NOT NULL,
                                  is_active NUMBER(1) DEFAULT 1,
                                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                  CONSTRAINT fk_category_dept FOREIGN KEY (department_id)
                                      REFERENCES department_master(id)
);

CREATE INDEX idx_category_dept ON product_category(department_id);
CREATE INDEX idx_category_active ON product_category(is_active);

-- Sub Category
CREATE TABLE sub_category (
                              id NUMBER(19) PRIMARY KEY,
                              sub_category_code VARCHAR2(50) NOT NULL UNIQUE,
                              sub_category_name VARCHAR2(255) NOT NULL,
                              description VARCHAR2(500),
                              category_id NUMBER(19) NOT NULL,
                              is_active NUMBER(1) DEFAULT 1,
                              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                              updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                              CONSTRAINT fk_subcategory_category FOREIGN KEY (category_id)
                                  REFERENCES product_category(id)
);

CREATE INDEX idx_subcategory_cat ON sub_category(category_id);
CREATE INDEX idx_subcategory_active ON sub_category(is_active);

-- Product Master
CREATE TABLE product_master (
                                id NUMBER(19) PRIMARY KEY,
                                product_code VARCHAR2(50) NOT NULL UNIQUE,
                                product_name VARCHAR2(255) NOT NULL,
                                description VARCHAR2(1000),
                                sub_category_id NUMBER(19) NOT NULL,
                                hsn_sac_code VARCHAR2(20),
                                classification_type VARCHAR2(50),
                                unit_of_measurement VARCHAR2(50),
                                has_ceiling_rate NUMBER(1) DEFAULT 0,
                                ceiling_rate NUMBER(19,2),
                                is_active NUMBER(1) DEFAULT 1,
                                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                CONSTRAINT fk_product_subcategory FOREIGN KEY (sub_category_id)
                                    REFERENCES sub_category(id)
);

CREATE INDEX idx_product_code ON product_master(product_code);
CREATE INDEX idx_product_subcat ON product_master(sub_category_id);
CREATE INDEX idx_product_active ON product_master(is_active);
CREATE INDEX idx_product_hsn ON product_master(hsn_sac_code);

-- Dimension Template (Dynamic Product Attributes)
CREATE TABLE dimension_template (
                                    id NUMBER(19) PRIMARY KEY,
                                    product_id NUMBER(19) NOT NULL,
                                    dimension_name VARCHAR2(255) NOT NULL,
                                    dimension_key VARCHAR2(100) NOT NULL,
                                    data_type VARCHAR2(50) NOT NULL,
                                    ui_component VARCHAR2(50) NOT NULL,
                                    is_mandatory NUMBER(1) DEFAULT 0,
                                    min_value NUMBER(19,4),
                                    max_value NUMBER(19,4),
                                    default_value VARCHAR2(500),
                                    validation_regex VARCHAR2(500),
                                    help_text VARCHAR2(1000),
                                    enum_values CLOB,
                                    used_in_pricing NUMBER(1) DEFAULT 0,
                                    display_order NUMBER(10) DEFAULT 0,
                                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                    CONSTRAINT fk_dimension_product FOREIGN KEY (product_id)
                                        REFERENCES product_master(id),
                                    CONSTRAINT chk_data_type CHECK (data_type IN ('STRING', 'NUMBER', 'DATE', 'BOOLEAN', 'ENUM')),
                                    CONSTRAINT chk_ui_component CHECK (ui_component IN ('INPUT', 'DROPDOWN', 'CHECKBOX', 'DATEPICKER', 'TEXTAREA'))
);

CREATE INDEX idx_dimension_product ON dimension_template(product_id);
CREATE INDEX idx_dimension_order ON dimension_template(display_order);

-- Vendor Master
CREATE TABLE vendor_master (
                               id NUMBER(19) PRIMARY KEY,
                               vendor_code VARCHAR2(50) NOT NULL UNIQUE,
                               vendor_name VARCHAR2(255) NOT NULL,
                               gstin VARCHAR2(15) NOT NULL UNIQUE,
                               pan VARCHAR2(10) NOT NULL,
                               tan VARCHAR2(10),
                               contact_person VARCHAR2(255),
                               email VARCHAR2(255) NOT NULL,
                               phone VARCHAR2(20),
                               address_line1 VARCHAR2(500),
                               address_line2 VARCHAR2(500),
                               city VARCHAR2(100),
                               state VARCHAR2(100) NOT NULL,
                               pincode VARCHAR2(10),
                               country VARCHAR2(100) DEFAULT 'India',
                               bank_name VARCHAR2(255),
                               bank_account_number VARCHAR2(50),
                               bank_ifsc_code VARCHAR2(15),
                               vendor_status VARCHAR2(50) DEFAULT 'ACTIVE',
                               empanelment_date DATE,
                               empanelment_valid_till DATE,
                               is_active NUMBER(1) DEFAULT 1,
                               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                               updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                               CONSTRAINT chk_vendor_status CHECK (vendor_status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'BLACKLISTED'))
);

CREATE INDEX idx_vendor_code ON vendor_master(vendor_code);
CREATE INDEX idx_vendor_gstin ON vendor_master(gstin);
CREATE INDEX idx_vendor_status ON vendor_master(vendor_status);
CREATE INDEX idx_vendor_state ON vendor_master(state);

-- Product-Vendor Mapping
CREATE TABLE product_vendor_mapping (
                                        id NUMBER(19) PRIMARY KEY,
                                        product_id NUMBER(19) NOT NULL,
                                        vendor_id NUMBER(19) NOT NULL,
                                        is_preferred NUMBER(1) DEFAULT 0,
                                        is_active NUMBER(1) DEFAULT 1,
                                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                        CONSTRAINT fk_pvm_product FOREIGN KEY (product_id) REFERENCES product_master(id),
                                        CONSTRAINT fk_pvm_vendor FOREIGN KEY (vendor_id) REFERENCES vendor_master(id),
                                        CONSTRAINT uk_product_vendor UNIQUE (product_id, vendor_id)
);

CREATE INDEX idx_pvm_product ON product_vendor_mapping(product_id);
CREATE INDEX idx_pvm_vendor ON product_vendor_mapping(vendor_id);

-- Rate Matrix (Dimension-based Pricing)
CREATE TABLE rate_matrix (
                             id NUMBER(19) PRIMARY KEY,
                             product_id NUMBER(19) NOT NULL,
                             rate_name VARCHAR2(255) NOT NULL,
                             minimum_rate NUMBER(19,2) NOT NULL,
                             maximum_rate NUMBER(19,2) NOT NULL,
                             applicable_conditions VARCHAR2(1000),
                             pricing_formula VARCHAR2(1000),
                             effective_from DATE DEFAULT SYSDATE,
                             effective_to DATE,
                             is_active NUMBER(1) DEFAULT 1,
                             created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                             updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                             CONSTRAINT fk_rate_product FOREIGN KEY (product_id) REFERENCES product_master(id)
);

CREATE INDEX idx_rate_product ON rate_matrix(product_id);
CREATE INDEX idx_rate_active ON rate_matrix(is_active);
CREATE INDEX idx_rate_dates ON rate_matrix(effective_from, effective_to);

-- ================================================================
-- SECTION 4: TRANSACTIONAL TABLES
-- ================================================================

-- Procurement Case
CREATE TABLE procurement_case (
                                  id NUMBER(19) PRIMARY KEY,
                                  case_number VARCHAR2(100) NOT NULL UNIQUE,
                                  case_name VARCHAR2(500) NOT NULL,
                                  department_id NUMBER(19) NOT NULL,
                                  category_id NUMBER(19),
                                  sub_category_id NUMBER(19),
                                  budget_name VARCHAR2(255),
                                  total_approved_budget NUMBER(19,2) NOT NULL,
                                  fund_type VARCHAR2(100),
                                  ed_approval_note VARCHAR2(2000),
                                  ed_approval_file_path VARCHAR2(500),
                                  case_status VARCHAR2(50) DEFAULT 'DRAFT',
                                  requires_bidding NUMBER(1) DEFAULT 0,
                                  bidding_start_date DATE,
                                  bidding_end_date DATE,
                                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                  created_by VARCHAR2(100),
                                  updated_by VARCHAR2(100),
                                  CONSTRAINT fk_case_dept FOREIGN KEY (department_id) REFERENCES department_master(id),
                                  CONSTRAINT fk_case_category FOREIGN KEY (category_id) REFERENCES product_category(id),
                                  CONSTRAINT fk_case_subcategory FOREIGN KEY (sub_category_id) REFERENCES sub_category(id),
                                  CONSTRAINT chk_case_status CHECK (case_status IN ('DRAFT', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'VENDOR_SELECTED', 'COMPLETED', 'CANCELLED'))
);

CREATE INDEX idx_case_number ON procurement_case(case_number);
CREATE INDEX idx_case_dept ON procurement_case(department_id);
CREATE INDEX idx_case_status ON procurement_case(case_status);
CREATE INDEX idx_case_created ON procurement_case(created_at);

-- Case Line Item
CREATE TABLE case_line_item (
                                id NUMBER(19) PRIMARY KEY,
                                procurement_case_id NUMBER(19) NOT NULL,
                                product_id NUMBER(19) NOT NULL,
                                selected_vendor_id NUMBER(19),
                                item_description VARCHAR2(1000),
                                dimension_values CLOB NOT NULL,
                                quantity NUMBER(19,4) DEFAULT 1,
                                unit_price NUMBER(19,2),
                                total_amount NUMBER(19,2) NOT NULL,
                                remarks VARCHAR2(2000),
                                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                CONSTRAINT fk_lineitem_case FOREIGN KEY (procurement_case_id) REFERENCES procurement_case(id),
                                CONSTRAINT fk_lineitem_product FOREIGN KEY (product_id) REFERENCES product_master(id),
                                CONSTRAINT fk_lineitem_vendor FOREIGN KEY (selected_vendor_id) REFERENCES vendor_master(id)
);

CREATE INDEX idx_lineitem_case ON case_line_item(procurement_case_id);
CREATE INDEX idx_lineitem_product ON case_line_item(product_id);
CREATE INDEX idx_lineitem_vendor ON case_line_item(selected_vendor_id);

-- Case Audit Log
CREATE TABLE case_audit_log (
                                id NUMBER(19) PRIMARY KEY,
                                procurement_case_id NUMBER(19) NOT NULL,
                                action_type VARCHAR2(100) NOT NULL,
                                old_value VARCHAR2(1000),
                                new_value VARCHAR2(1000),
                                action_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                performed_by VARCHAR2(100),
                                remarks VARCHAR2(2000),
                                CONSTRAINT fk_audit_case FOREIGN KEY (procurement_case_id) REFERENCES procurement_case(id)
);

CREATE INDEX idx_audit_case ON case_audit_log(procurement_case_id);
CREATE INDEX idx_audit_timestamp ON case_audit_log(action_timestamp);

-- Vendor Bid
CREATE TABLE vendor_bid (
                            id NUMBER(19) PRIMARY KEY,
                            procurement_case_id NUMBER(19) NOT NULL,
                            vendor_id NUMBER(19) NOT NULL,
                            bid_amount NUMBER(19,2) NOT NULL,
                            bid_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            bid_status VARCHAR2(50) DEFAULT 'SUBMITTED',
                            technical_score NUMBER(5,2),
                            financial_score NUMBER(5,2),
                            total_score NUMBER(5,2),
                            remarks VARCHAR2(2000),
                            is_selected NUMBER(1) DEFAULT 0,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            CONSTRAINT fk_bid_case FOREIGN KEY (procurement_case_id) REFERENCES procurement_case(id),
                            CONSTRAINT fk_bid_vendor FOREIGN KEY (vendor_id) REFERENCES vendor_master(id),
                            CONSTRAINT chk_bid_status CHECK (bid_status IN ('SUBMITTED', 'UNDER_EVALUATION', 'ACCEPTED', 'REJECTED'))
);

CREATE INDEX idx_bid_case ON vendor_bid(procurement_case_id);
CREATE INDEX idx_bid_vendor ON vendor_bid(vendor_id);
CREATE INDEX idx_bid_selected ON vendor_bid(is_selected);

-- Invoice
CREATE TABLE invoice (
                         id NUMBER(19) PRIMARY KEY,
                         invoice_number VARCHAR2(100) NOT NULL UNIQUE,
                         vendor_id NUMBER(19) NOT NULL,
                         procurement_case_id NUMBER(19),
                         invoice_date DATE NOT NULL,
                         due_date DATE,
                         taxable_amount NUMBER(19,2) NOT NULL,
                         cgst_amount NUMBER(19,2) DEFAULT 0,
                         sgst_amount NUMBER(19,2) DEFAULT 0,
                         igst_amount NUMBER(19,2) DEFAULT 0,
                         total_gst_amount NUMBER(19,2) DEFAULT 0,
                         tds_amount NUMBER(19,2) DEFAULT 0,
                         other_charges NUMBER(19,2) DEFAULT 0,
                         total_invoice_amount NUMBER(19,2) NOT NULL,
                         invoice_status VARCHAR2(50) DEFAULT 'DRAFT',
                         vendor_gstin VARCHAR2(15) NOT NULL,
                         place_of_supply VARCHAR2(100),
                         irn VARCHAR2(100),
                         acknowledgement_number VARCHAR2(100),
                         acknowledgement_date DATE,
                         payment_status VARCHAR2(50) DEFAULT 'PENDING',
                         payment_date DATE,
                         payment_reference VARCHAR2(255),
                         file_path VARCHAR2(500),
                         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                         created_by VARCHAR2(100),
                         updated_by VARCHAR2(100),
                         CONSTRAINT fk_invoice_vendor FOREIGN KEY (vendor_id) REFERENCES vendor_master(id),
                         CONSTRAINT fk_invoice_case FOREIGN KEY (procurement_case_id) REFERENCES procurement_case(id),
                         CONSTRAINT chk_invoice_status CHECK (invoice_status IN ('DRAFT', 'SUBMITTED', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'PAID', 'CANCELLED')),
                         CONSTRAINT chk_payment_status CHECK (payment_status IN ('PENDING', 'PROCESSING', 'PAID', 'FAILED'))
);

CREATE INDEX idx_invoice_number ON invoice(invoice_number);
CREATE INDEX idx_invoice_vendor ON invoice(vendor_id);
CREATE INDEX idx_invoice_case ON invoice(procurement_case_id);
CREATE INDEX idx_invoice_status ON invoice(invoice_status);
CREATE INDEX idx_invoice_date ON invoice(invoice_date);

-- Invoice Line Item
CREATE TABLE invoice_line_item (
                                   id NUMBER(19) PRIMARY KEY,
                                   invoice_id NUMBER(19) NOT NULL,
                                   product_id NUMBER(19),
                                   item_description VARCHAR2(1000) NOT NULL,
                                   dimension_values CLOB,
                                   hsn_sac_code VARCHAR2(20),
                                   quantity NUMBER(19,4) DEFAULT 1,
                                   unit_price NUMBER(19,2),
                                   taxable_value NUMBER(19,2) NOT NULL,
                                   cgst_rate NUMBER(5,2),
                                   cgst_amount NUMBER(19,2),
                                   sgst_rate NUMBER(5,2),
                                   sgst_amount NUMBER(19,2),
                                   igst_rate NUMBER(5,2),
                                   igst_amount NUMBER(19,2),
                                   total_gst_amount NUMBER(19,2),
                                   total_amount NUMBER(19,2) NOT NULL,
                                   auto_match_score NUMBER(3) DEFAULT 0,
                                   proof_count NUMBER(10) DEFAULT 0,
                                   requires_review NUMBER(1) DEFAULT 1,
                                   red_flag_count NUMBER(10) DEFAULT 0,
                                   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                   CONSTRAINT fk_inv_lineitem_invoice FOREIGN KEY (invoice_id) REFERENCES invoice(id),
                                   CONSTRAINT fk_inv_lineitem_product FOREIGN KEY (product_id) REFERENCES product_master(id),
                                   CONSTRAINT chk_match_score CHECK (auto_match_score BETWEEN 0 AND 100)
);

CREATE INDEX idx_inv_lineitem_invoice ON invoice_line_item(invoice_id);
CREATE INDEX idx_inv_lineitem_product ON invoice_line_item(product_id);
CREATE INDEX idx_inv_lineitem_score ON invoice_line_item(auto_match_score);
CREATE INDEX idx_inv_lineitem_review ON invoice_line_item(requires_review);

-- Invoice Line Item Proof
CREATE TABLE invoice_line_item_proof (
                                         id NUMBER(19) PRIMARY KEY,
                                         line_item_id NUMBER(19) NOT NULL,
                                         proof_type VARCHAR2(50) NOT NULL,
                                         file_name VARCHAR2(500) NOT NULL,
                                         file_path VARCHAR2(1000),
                                         file_size NUMBER(19),
                                         mime_type VARCHAR2(100),
                                         verification_status VARCHAR2(50) DEFAULT 'PENDING',
                                         publication_name VARCHAR2(255),
                                         publication_date DATE,
                                         publication_page VARCHAR2(50),
                                         city VARCHAR2(100),
                                         state VARCHAR2(100),
                                         requires_manual_review NUMBER(1) DEFAULT 0,
                                         verified_at TIMESTAMP,
                                         verified_by VARCHAR2(100),
                                         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                         CONSTRAINT fk_proof_lineitem FOREIGN KEY (line_item_id) REFERENCES invoice_line_item(id),
                                         CONSTRAINT chk_proof_type CHECK (proof_type IN ('IMAGE', 'PDF', 'VIDEO', 'DOCUMENT')),
                                         CONSTRAINT chk_verification_status CHECK (verification_status IN ('PENDING', 'VERIFIED', 'FAILED', 'REJECTED'))
);

CREATE INDEX idx_proof_lineitem ON invoice_line_item_proof(line_item_id);
CREATE INDEX idx_proof_status ON invoice_line_item_proof(verification_status);

-- ================================================================
-- SECTION 5: CREATE TRIGGERS FOR AUTO-INCREMENT AND AUDIT
-- ================================================================

-- Trigger for department_master
CREATE OR REPLACE TRIGGER trg_department_bi
BEFORE INSERT ON department_master
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
SELECT seq_department.NEXTVAL INTO :NEW.id FROM dual;
END IF;
    :NEW.created_at := SYSTIMESTAMP;
    :NEW.updated_at := SYSTIMESTAMP;
END;
/

CREATE OR REPLACE TRIGGER trg_department_bu
BEFORE UPDATE ON department_master
                  FOR EACH ROW
BEGIN
    :NEW.updated_at := SYSTIMESTAMP;
END;
/

-- Similar triggers for other tables (abbreviated for brevity)
-- In production, create triggers for all tables following the same pattern

-- ================================================================
-- SECTION 6: GRANTS (Optional - based on user setup)
-- ================================================================

-- Grant privileges to application user
-- GRANT SELECT, INSERT, UPDATE, DELETE ON department_master TO ips_app_user;
-- (Repeat for all tables)

-- ================================================================
-- SECTION 7: COMMENTS
-- ================================================================

COMMENT ON TABLE department_master IS 'Bank departments with budget allocation';
COMMENT ON TABLE product_master IS 'Product catalog with dynamic dimension support';
COMMENT ON TABLE dimension_template IS 'Dynamic product attributes for flexible procurement';
COMMENT ON TABLE vendor_master IS 'GST-compliant vendor information';
COMMENT ON TABLE rate_matrix IS 'Dimension-based pricing rules';
COMMENT ON TABLE procurement_case IS 'Procurement cases with approval workflow';
COMMENT ON TABLE invoice IS 'Vendor invoices with GST compliance';
COMMENT ON TABLE invoice_line_item IS 'Invoice line items with AI match scores';
COMMENT ON TABLE invoice_line_item_proof IS 'Supporting documents for invoice verification';

-- ================================================================
-- END OF DDL SCRIPT
-- ================================================================