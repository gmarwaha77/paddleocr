-- ================================================================
-- INVOICE PROCESSING SYSTEM - ORACLE SAMPLE DATA
-- Version: 1.0
-- Database: Oracle 19c+
-- Generated: October 15, 2025
-- Note: This mirrors the H2 sample data for consistent demo experience
-- ================================================================

SET DEFINE OFF;

-- ================================================================
-- SECTION 1: DEPARTMENTS
-- ================================================================

INSERT INTO department_master (id, department_code, department_name, annual_budget, head_of_department, is_active)
VALUES (seq_department.NEXTVAL, 'DOC', 'Department Of Communication', 500000000, 'Mr. Rajesh Kumar', 1);

INSERT INTO department_master (id, department_code, department_name, annual_budget, head_of_department, is_active)
VALUES (seq_department.NEXTVAL, 'DIT', 'IT Department', 250000000, 'Ms. Priya Sharma', 1);

INSERT INTO department_master (id, department_code, department_name, annual_budget, head_of_department, is_active)
VALUES (seq_department.NEXTVAL, 'DAD', 'Administration', 100000000, 'Mr. Vikram Singh', 1);

-- ================================================================
-- SECTION 2: PRODUCT CATEGORIES
-- ================================================================

-- Categories for Communication Department
INSERT INTO product_category (id, category_code, category_name, description, department_id, is_active)
VALUES (seq_product_category.NEXTVAL, 'ADV', 'Advertisements', 'All types of advertisements', 1, 1);

-- Categories for IT Department
INSERT INTO product_category (id, category_code, category_name, description, department_id, is_active)
VALUES (seq_product_category.NEXTVAL, 'ITC', 'IT Infrastructure', 'IT hardware and services', 2, 1);

-- Categories for Administration
INSERT INTO product_category (id, category_code, category_name, description, department_id, is_active)
VALUES (seq_product_category.NEXTVAL, 'ADM', 'Administrative Services', 'Administrative support', 3, 1);

-- ================================================================
-- SECTION 3: SUB-CATEGORIES
-- ================================================================

-- Advertisement sub-categories
INSERT INTO sub_category (id, sub_category_code, sub_category_name, description, category_id, is_active)
VALUES (seq_sub_category.NEXTVAL, 'PAC', 'Public Awareness Campaign', 'Public awareness campaigns', 1, 1);

INSERT INTO sub_category (id, sub_category_code, sub_category_name, description, category_id, is_active)
VALUES (seq_sub_category.NEXTVAL, 'BRD', 'Brand Promotion', 'Brand promotion activities', 1, 1);

-- IT sub-categories
INSERT INTO sub_category (id, sub_category_code, sub_category_name, description, category_id, is_active)
VALUES (seq_sub_category.NEXTVAL, 'SRV', 'Servers', 'Server hardware', 2, 1);

INSERT INTO sub_category (id, sub_category_code, sub_category_name, description, category_id, is_active)
VALUES (seq_sub_category.NEXTVAL, 'LAP', 'Laptops', 'Laptop computers', 2, 1);

-- Admin sub-categories
INSERT INTO sub_category (id, sub_category_code, sub_category_name, description, category_id, is_active)
VALUES (seq_sub_category.NEXTVAL, 'STN', 'Stationery', 'Office stationery', 3, 1);

-- ================================================================
-- SECTION 4: PRODUCTS
-- ================================================================

-- Product 1: Print Advertisement
INSERT INTO product_master (id, product_code, product_name, description, sub_category_id, hsn_sac_code, has_ceiling_rate, ceiling_rate, is_active)
VALUES (seq_product.NEXTVAL, 'PRINT-001', 'Print Advertisement', 'Newspaper ads', 1, '998311', 1, 100, 1);

-- Product 2: TV Advertisement
INSERT INTO product_master (id, product_code, product_name, description, sub_category_id, hsn_sac_code, has_ceiling_rate, ceiling_rate, is_active)
VALUES (seq_product.NEXTVAL, 'TV-001', 'Television Advertisement', 'TV commercials', 1, '998311', 1, 15000, 1);

-- Product 3: Radio Advertisement
INSERT INTO product_master (id, product_code, product_name, description, sub_category_id, hsn_sac_code, has_ceiling_rate, ceiling_rate, is_active)
VALUES (seq_product.NEXTVAL, 'RADIO-001', 'Radio Advertisement', 'Radio spots', 2, '998311', 1, 5000, 1);

-- Product 4: Enterprise Server
INSERT INTO product_master (id, product_code, product_name, description, sub_category_id, hsn_sac_code, has_ceiling_rate, ceiling_rate, is_active)
VALUES (seq_product.NEXTVAL, 'SRV-001', 'Enterprise Server', 'Rack-mounted servers', 3, '847130', 1, 500000, 1);

-- Product 5: Business Laptop
INSERT INTO product_master (id, product_code, product_name, description, sub_category_id, hsn_sac_code, has_ceiling_rate, ceiling_rate, is_active)
VALUES (seq_product.NEXTVAL, 'LAP-001', 'Business Laptop', 'Employee laptops', 4, '847130', 1, 80000, 1);

-- Product 6: Office Stationery
INSERT INTO product_master (id, product_code, product_name, description, sub_category_id, hsn_sac_code, has_ceiling_rate, ceiling_rate, is_active)
VALUES (seq_product.NEXTVAL, 'STN-001', 'Office Stationery', 'Bulk stationery', 5, '482010', 1, 50, 1);

-- ================================================================
-- SECTION 5: DIMENSION TEMPLATES
-- ================================================================

-- Dimensions for Print Advertisement (Product ID 1)
INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 1, 'Publication Name', 'publication', 'STRING', 'INPUT', 1, 'Name of newspaper/magazine', 0, 1);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 1, 'Page Number', 'page', 'STRING', 'INPUT', 1, 'Page number', 0, 2);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 1, 'Size (sqcm)', 'size', 'NUMBER', 'INPUT', 1, 50, 5000, 'Size in square centimeters', 1, 3);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 1, 'Color Type', 'colorType', 'ENUM', 'DROPDOWN', 1, 'Full color or B&W', 1, 4);

-- Dimensions for TV Advertisement (Product ID 2)
INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 2, 'Channel Name', 'channel', 'STRING', 'INPUT', 1, 'TV channel name', 1);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 2, 'Duration (seconds)', 'duration', 'NUMBER', 'INPUT', 1, 10, 60, 'Duration in seconds', 1, 2);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 2, 'Time Slot', 'timeSlot', 'ENUM', 'DROPDOWN', 1, 'Prime/Non-prime time', 1, 3);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 2, 'Telecast Date', 'telecastDate', 'DATE', 'DATEPICKER', 1, 'Date of telecast', 4);

-- Dimensions for Radio Advertisement (Product ID 3)
INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 3, 'Radio Station', 'station', 'STRING', 'INPUT', 1, 'Radio station name', 1);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 3, 'Duration (seconds)', 'duration', 'NUMBER', 'INPUT', 1, 10, 60, 'Duration in seconds', 1, 2);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 3, 'Frequency', 'frequency', 'STRING', 'INPUT', 1, 'FM frequency', 3);

-- Dimensions for Enterprise Server (Product ID 4)
INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 4, 'Brand', 'brand', 'STRING', 'INPUT', 1, 'Server brand', 1);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 4, 'Processor Cores', 'cores', 'NUMBER', 'INPUT', 1, 4, 128, 'Number of processor cores', 1, 2);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 4, 'RAM (GB)', 'ram', 'NUMBER', 'INPUT', 1, 16, 1024, 'RAM in GB', 1, 3);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 4, 'Storage (TB)', 'storage', 'NUMBER', 'INPUT', 1, 1, 100, 'Storage in TB', 1, 4);

-- Dimensions for Business Laptop (Product ID 5)
INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 5, 'Brand', 'brand', 'STRING', 'INPUT', 1, 'Laptop brand', 1);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 5, 'Processor', 'processor', 'STRING', 'INPUT', 1, 'Processor model', 2);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 5, 'RAM (GB)', 'ram', 'NUMBER', 'INPUT', 1, 8, 64, 'RAM in GB', 1, 3);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 5, 'Screen Size', 'screenSize', 'ENUM', 'DROPDOWN', 1, 'Screen size in inches', 4);

-- Dimensions for Office Stationery (Product ID 6)
INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, help_text, display_order)
VALUES (seq_dimension.NEXTVAL, 6, 'Item Type', 'itemType', 'STRING', 'INPUT', 1, 'Type of item', 1);

INSERT INTO dimension_template (id, product_id, dimension_name, dimension_key, data_type, ui_component, is_mandatory, min_value, max_value, help_text, used_in_pricing, display_order)
VALUES (seq_dimension.NEXTVAL, 6, 'Quantity', 'quantity', 'NUMBER', 'INPUT', 1, 1, 10000, 'Number of units', 1, 2);

-- ================================================================
-- SECTION 6: VENDORS
-- ================================================================

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN001', 'Times of India Publications', '27AADCT2332M1Z2', 'AADCT2332M', 'Maharashtra', 'contact@timesofindia.com', 'ACTIVE', 1);

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN002', 'Hindustan Times Media', '07AABCH6394J1Z5', 'AABCH6394J', 'Delhi', 'billing@hindustantimes.com', 'ACTIVE', 1);

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN003', 'Zee Entertainment', '27AAECZ1234M1Z1', 'AAECZ1234M', 'Maharashtra', 'finance@zee.com', 'ACTIVE', 1);

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN004', 'Radio Mirchi Network', '29AAFCR5678K1Z3', 'AAFCR5678K', 'Karnataka', 'accounts@radiomirchi.com', 'ACTIVE', 1);

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN005', 'Dell Technologies India', '29AAACA1234D1Z5', 'AAACA1234D', 'Karnataka', 'india.sales@dell.com', 'ACTIVE', 1);

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN006', 'HP India Sales', '27AABCH5678P1Z1', 'AABCH5678P', 'Maharashtra', 'hpindia@hp.com', 'ACTIVE', 1);

INSERT INTO vendor_master (id, vendor_code, vendor_name, gstin, pan, state, email, vendor_status, is_active)
VALUES (seq_vendor.NEXTVAL, 'VEN007', 'Odisha Stationery Mart', '21AABCO1234S1Z7', 'AABCO1234S', 'Odisha', 'sales@odishastationery.com', 'ACTIVE', 1);

-- ================================================================
-- SECTION 7: PRODUCT-VENDOR MAPPING
-- ================================================================

-- Print ads vendors
INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 1, 1, 1); -- TOI for Print

INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 1, 2, 1); -- HT for Print

-- TV ads vendor
INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 2, 3, 1); -- Zee for TV

-- Radio ads vendor
INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 3, 4, 1); -- Mirchi for Radio

-- Server vendors
INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 4, 5, 1); -- Dell for Servers

-- Laptop vendors
INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 5, 5, 1); -- Dell for Laptops

INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 5, 6, 1); -- HP for Laptops

-- Stationery vendor
INSERT INTO product_vendor_mapping (id, product_id, vendor_id, is_active)
VALUES (seq_vendor_mapping.NEXTVAL, 6, 7, 1); -- Odisha for Stationery

-- ================================================================
-- SECTION 8: RATE MATRICES (Pricing based on dimensions)
-- ================================================================

-- Print Advertisement Rates
INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 1, 'Full Color Print Rate', 150, 200, 'colorType=Full Color', 'basePrice * size', 1);

INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 1, 'B&W Print Rate', 75, 100, 'colorType=B&W', 'basePrice * size', 1);

-- TV Advertisement Rates
INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 2, 'Prime Time TV Rate', 10000, 15000, 'timeSlot=Prime Time', 'basePrice * duration', 1);

INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 2, 'Non-Prime TV Rate', 5000, 7000, 'timeSlot=Non-Prime Time', 'basePrice * duration', 1);

-- Radio Advertisement Rates
INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 3, 'Radio Spot Rate', 500, 1000, 'all', 'basePrice * duration', 1);

-- Server Rates
INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 4, 'Standard Server Rate', 50000, 100000, 'cores>=16,ram>=64', 'basePrice * (cores/16) * (ram/64)', 1);

INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 4, 'High-End Server Rate', 100000, 500000, 'cores>=64,ram>=256', 'basePrice * (cores/16) * (ram/64)', 1);

-- Laptop Rates
INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 5, 'Standard Laptop Rate', 50000, 70000, 'ram>=8,ram<=16', 'basePrice + (ram * 2000)', 1);

INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 5, 'High-End Laptop Rate', 70000, 150000, 'ram>16', 'basePrice + (ram * 3000)', 1);

-- Stationery Rates
INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 6, 'Bulk Stationery Rate', 10, 50, 'quantity>=100', 'basePrice * quantity * 0.8', 1);

INSERT INTO rate_matrix (id, product_id, rate_name, minimum_rate, maximum_rate, applicable_conditions, pricing_formula, is_active)
VALUES (seq_rate_matrix.NEXTVAL, 6, 'Small Order Rate', 15, 50, 'quantity<100', 'basePrice * quantity', 1);

-- ================================================================
-- COMMIT
-- ================================================================

COMMIT;

-- ================================================================
-- VERIFICATION QUERIES (Run these to verify data loaded)
-- ================================================================

-- SELECT COUNT(*) FROM department_master; -- Should return 3
-- SELECT COUNT(*) FROM product_category; -- Should return 3
-- SELECT COUNT(*) FROM product_master; -- Should return 6
-- SELECT COUNT(*) FROM vendor_master; -- Should return 7
-- SELECT COUNT(*) FROM rate_matrix; -- Should return 11

-- ================================================================
-- END OF SAMPLE DATA SCRIPT
-- ================================================================