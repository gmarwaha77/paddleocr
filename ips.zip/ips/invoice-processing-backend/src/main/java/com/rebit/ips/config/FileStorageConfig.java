package com.rebit.ips.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;
import java.io.File;

@Configuration
public class FileStorageConfig {

    @Value("${ips.file-storage.base-path}")
    private String basePath;

    @PostConstruct
    public void init() {
        File baseDir = new File(basePath);
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }
    }

    public String getBasePath() {
        return basePath;
    }
}
