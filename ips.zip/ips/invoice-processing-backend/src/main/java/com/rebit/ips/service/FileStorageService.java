package com.rebit.ips.service;

import com.rebit.ips.config.FileStorageConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    @Autowired
    private FileStorageConfig fileStorageConfig;

    public String storeFile(MultipartFile file, String caseNumber) throws IOException {
        // Create case-specific directory
        Path caseDirectory = Paths.get(fileStorageConfig.getBasePath(), caseNumber);
        Files.createDirectories(caseDirectory);

        // Generate unique filename
        String originalFilename = file.getOriginalFilename();
        String extension = originalFilename != null && originalFilename.contains(".")
                ? originalFilename.substring(originalFilename.lastIndexOf("."))
                : "";
        String filename = UUID.randomUUID().toString() + extension;

        // Store file
        Path targetLocation = caseDirectory.resolve(filename);
        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

        return caseNumber + "/" + filename;
    }

    public File getFile(String filePath) {
        Path path = Paths.get(fileStorageConfig.getBasePath(), filePath);
        return path.toFile();
    }

    public void deleteFile(String filePath) throws IOException {
        Path path = Paths.get(fileStorageConfig.getBasePath(), filePath);
        Files.deleteIfExists(path);
    }
}
