package com.rebit.ips.enums;

public enum GSTType {
    CGST,
    SGST,
    IGST
}

