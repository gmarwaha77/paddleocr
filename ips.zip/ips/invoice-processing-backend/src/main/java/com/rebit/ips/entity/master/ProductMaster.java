package com.rebit.ips.entity.master;

import com.rebit.ips.entity.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "product_master", indexes = {
        @Index(name = "idx_product_code", columnList = "product_code"),
        @Index(name = "idx_hsn_sac", columnList = "hsn_sac_code")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ProductMaster extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "product_code", unique = true, length = 50)
    private String productCode;

    @NotBlank
    @Column(name = "product_name", length = 200)
    private String productName;

    @Column(name = "description", length = 500)
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sub_category_id", nullable = false)
    private SubCategory subCategory;

    @Column(name = "hsn_sac_code", length = 20)
    private String hsnSacCode;

    @Column(name = "classification_type", length = 50)
    private String classificationType;

    @Column(name = "unit_of_measurement", length = 20)
    private String unitOfMeasurement;

    @Column(name = "ceiling_rate", precision = 19, scale = 2)
    private BigDecimal ceilingRate;

    @Column(name = "has_ceiling_rate")
    private Boolean hasCeilingRate = false;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<DimensionTemplate> dimensions = new ArrayList<>();

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<ProductVendorMapping> vendorMappings = new ArrayList<>();
}
