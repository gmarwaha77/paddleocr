package com.rebit.ips.entity.cases;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.entity.master.DepartmentMaster;
import com.rebit.ips.entity.master.ProductCategory;
import com.rebit.ips.entity.master.SubCategory;
import com.rebit.ips.enums.CaseStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "procurement_case", indexes = {
        @Index(name = "idx_case_number", columnList = "case_number"),
        @Index(name = "idx_case_status", columnList = "case_status"),
        @Index(name = "idx_case_dept", columnList = "department_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ProcurementCase extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "case_number", unique = true, length = 50)
    private String caseNumber;

    @NotBlank
    @Column(name = "case_name", length = 200)
    private String caseName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private DepartmentMaster department;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private ProductCategory category;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sub_category_id")
    private SubCategory subCategory;

    @Column(name = "budget_name", length = 100)
    private String budgetName;

    @NotNull
    @Column(name = "total_approved_budget", precision = 19, scale = 2)
    private BigDecimal totalApprovedBudget;

    @Column(name = "fund_type", length = 50)
    private String fundType;

    @Column(name = "ed_approval_note", length = 1000)
    private String edApprovalNote;

    @Column(name = "ed_approval_file_path", length = 500)
    private String edApprovalFilePath;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "case_status", length = 20)
    private CaseStatus caseStatus = CaseStatus.DRAFT;

    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;

    @Column(name = "approved_at")
    private LocalDateTime approvedAt;

    @Column(name = "approved_by", length = 50)
    private String approvedBy;

    @Column(name = "rejected_at")
    private LocalDateTime rejectedAt;

    @Column(name = "rejected_by", length = 50)
    private String rejectedBy;

    @Column(name = "rejection_reason", length = 1000)
    private String rejectionReason;

    @Column(name = "total_case_amount", precision = 19, scale = 2)
    private BigDecimal totalCaseAmount = BigDecimal.ZERO;

    @Column(name = "requires_bidding")
    private Boolean requiresBidding = false;

    @OneToMany(mappedBy = "procurementCase", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<CaseLineItem> lineItems = new ArrayList<>();

    @OneToMany(mappedBy = "procurementCase", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<CaseAuditLog> auditLogs = new ArrayList<>();
}
