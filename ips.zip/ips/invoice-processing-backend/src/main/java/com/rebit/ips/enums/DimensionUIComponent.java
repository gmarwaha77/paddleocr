package com.rebit.ips.enums;

public enum DimensionUIComponent {
    INPUT,
    TEXTAREA,
    DROPDOWN,
    CHECKBOX,
    RADIO,
    DATEPICKER,
    NUMBER_INPUT
}
