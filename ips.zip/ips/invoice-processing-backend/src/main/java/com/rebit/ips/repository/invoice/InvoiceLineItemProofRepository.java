package com.rebit.ips.repository.invoice;

import com.rebit.ips.entity.invoice.InvoiceLineItemProof;
import com.rebit.ips.enums.VerificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvoiceLineItemProofRepository extends JpaRepository<InvoiceLineItemProof, Long> {

    List<InvoiceLineItemProof> findByLineItemId(Long lineItemId);

    List<InvoiceLineItemProof> findByLineItemInvoiceId(Long invoiceId);

    List<InvoiceLineItemProof> findByVerificationStatus(VerificationStatus status);

    @Query("SELECT p FROM InvoiceLineItemProof p WHERE p.lineItem.id = :lineItemId " +
            "AND p.verificationStatus IN :statuses")
    List<InvoiceLineItemProof> findByLineItemIdAndStatusIn(Long lineItemId, List<VerificationStatus> statuses);

    @Query("SELECT COUNT(p) FROM InvoiceLineItemProof p WHERE p.lineItem.invoice.id = :invoiceId")
    Long countByInvoiceId(Long invoiceId);

    @Query("SELECT COUNT(p) FROM InvoiceLineItemProof p WHERE p.lineItem.invoice.id = :invoiceId " +
            "AND p.verificationStatus = :status")
    Long countByInvoiceIdAndStatus(Long invoiceId, VerificationStatus status);
}