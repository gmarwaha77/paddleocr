package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineItemReviewDTO {
    private Long id;
    private String itemDescription;
    private Integer matchScore;
    private String matchStatus;

    // Dimension comparison
    private DimensionMatchResultDTO matchResult;

    // Proofs
    private Integer proofCount;
    private List<ProofDTO> proofs;

    // Review flags
    private Boolean requiresReview;
    private List<RedFlagDTO> redFlags;
}