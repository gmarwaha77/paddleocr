package com.rebit.ips.dto.master;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductMasterDTO {
    private Long id;
    @NotBlank
    private String productCode;
    @NotBlank
    private String productName;
    private String description;
    private Long subCategoryId;
    private String subCategoryName;
    private String hsnSacCode;
    private String classificationType;
    private String unitOfMeasurement;
    private BigDecimal ceilingRate;
    private Boolean hasCeilingRate;
    private Boolean isActive;
    private List<DimensionTemplateDTO> dimensions;
}
