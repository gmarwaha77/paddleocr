package com.rebit.ips.controller.cases;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.cases.CaseApprovalDTO;
import com.rebit.ips.dto.cases.CaseLineItemDTO;
import com.rebit.ips.dto.cases.ProcurementCaseDTO;
import com.rebit.ips.enums.CaseStatus;
import com.rebit.ips.service.cases.CaseManagementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cases")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class CaseManagementController {

    private final CaseManagementService caseManagementService;

    @GetMapping
    public ApiResponse<List<ProcurementCaseDTO>> getAllCases() {
        return ApiResponse.success("Cases retrieved successfully",
                caseManagementService.getAllCases());
    }

    @GetMapping("/department/{departmentId}")
    public ApiResponse<List<ProcurementCaseDTO>> getCasesByDepartment(@PathVariable Long departmentId) {
        return ApiResponse.success("Cases retrieved successfully",
                caseManagementService.getCasesByDepartment(departmentId));
    }

    @GetMapping("/status/{status}")
    public ApiResponse<List<ProcurementCaseDTO>> getCasesByStatus(@PathVariable CaseStatus status) {
        return ApiResponse.success("Cases retrieved successfully",
                caseManagementService.getCasesByStatus(status));
    }

    @GetMapping("/{id}")
    public ApiResponse<ProcurementCaseDTO> getCaseById(@PathVariable Long id) {
        return ApiResponse.success("Case retrieved successfully",
                caseManagementService.getCaseById(id));
    }

    @PostMapping
    public ApiResponse<ProcurementCaseDTO> createCase(@Valid @RequestBody ProcurementCaseDTO dto) {
        return ApiResponse.success("Case created successfully",
                caseManagementService.createCase(dto));
    }

    @PutMapping("/{id}")
    public ApiResponse<ProcurementCaseDTO> updateCase(@PathVariable Long id,
                                                      @Valid @RequestBody ProcurementCaseDTO dto) {
        return ApiResponse.success("Case updated successfully",
                caseManagementService.updateCase(id, dto));
    }

    @PostMapping("/{caseId}/items")
    public ApiResponse<CaseLineItemDTO> addLineItem(@PathVariable Long caseId,
                                                    @Valid @RequestBody CaseLineItemDTO dto) {
        return ApiResponse.success("Line item added successfully",
                caseManagementService.addLineItem(caseId, dto));
    }

    @PutMapping("/{id}/submit-approval")
    public ApiResponse<ProcurementCaseDTO> submitForApproval(@PathVariable Long id) {
        return ApiResponse.success("Case submitted for approval",
                caseManagementService.submitForApproval(id));
    }

    @PutMapping("/{id}/approve")
    public ApiResponse<ProcurementCaseDTO> approveCase(@PathVariable Long id,
                                                       @Valid @RequestBody CaseApprovalDTO dto) {
        dto.setCaseId(id);
        return ApiResponse.success("Case processed successfully",
                caseManagementService.approveCase(dto));
    }

    @PutMapping("/{id}/reject")
    public ApiResponse<ProcurementCaseDTO> rejectCase(@PathVariable Long id,
                                                      @Valid @RequestBody CaseApprovalDTO dto) {
        dto.setCaseId(id);
        dto.setApproved(false);
        return ApiResponse.success("Case rejected successfully",
                caseManagementService.approveCase(dto));
    }
}
