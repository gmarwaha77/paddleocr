package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RedFlagDTO {
    private String type;
    private String severity; // HIGH, MEDIUM, LOW
    private String description;
    private String recommendation;
}
