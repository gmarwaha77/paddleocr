package com.rebit.ips.repository.master;

import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.enums.VendorStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VendorMasterRepository extends JpaRepository<VendorMaster, Long> {
    Optional<VendorMaster> findByVendorCode(String vendorCode);
    Optional<VendorMaster> findByGstin(String gstin);
    List<VendorMaster> findByVendorStatus(VendorStatus status);
    List<VendorMaster> findByIsActiveTrue();

    @Query("SELECT DISTINCT v FROM VendorMaster v JOIN v.productMappings pvm WHERE pvm.product.id = :productId AND v.vendorStatus = 'ACTIVE'")
    List<VendorMaster> findActiveVendorsByProductId(Long productId);
}
