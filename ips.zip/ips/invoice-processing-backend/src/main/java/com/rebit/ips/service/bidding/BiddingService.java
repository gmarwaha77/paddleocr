package com.rebit.ips.service.bidding;

import com.rebit.ips.dto.bidding.BiddingInvitationDTO;
import com.rebit.ips.dto.bidding.VendorBidDTO;
import com.rebit.ips.entity.bidding.BiddingInvitation;
import com.rebit.ips.entity.bidding.VendorBid;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.enums.BidStatus;
import com.rebit.ips.enums.CaseStatus;
import com.rebit.ips.enums.InvitationStatus;
import com.rebit.ips.repository.bidding.BiddingInvitationRepository;
import com.rebit.ips.repository.bidding.VendorBidRepository;
import com.rebit.ips.repository.cases.CaseLineItemRepository;
import com.rebit.ips.repository.cases.ProcurementCaseRepository;
import com.rebit.ips.repository.master.VendorMasterRepository;
import com.rebit.ips.service.NotificationService;
import com.rebit.ips.util.CaseNumberGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class BiddingService {

    private final VendorBidRepository bidRepository;
    private final BiddingInvitationRepository invitationRepository;
    private final ProcurementCaseRepository caseRepository;
    private final CaseLineItemRepository lineItemRepository;
    private final VendorMasterRepository vendorRepository;
    private final NotificationService notificationService;
    private final CaseNumberGenerator caseNumberGenerator;

    public void inviteVendorsForBidding(BiddingInvitationDTO dto) {
        ProcurementCase procurementCase = caseRepository.findById(dto.getCaseId())
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (procurementCase.getCaseStatus() != CaseStatus.APPROVED &&
                procurementCase.getCaseStatus() != CaseStatus.BIDDING_IN_PROGRESS) {
            throw new RuntimeException("Case must be approved before inviting vendors");
        }

        for (Long vendorId : dto.getVendorIds()) {
            VendorMaster vendor = vendorRepository.findById(vendorId)
                    .orElseThrow(() -> new RuntimeException("Vendor not found: " + vendorId));

            BiddingInvitation invitation = BiddingInvitation.builder()
                    .procurementCase(procurementCase)
                    .vendor(vendor)
                    .invitedAt(LocalDateTime.now())
                    .invitationExpiresAt(LocalDateTime.now().plusDays(7))
                    .invitationStatus(InvitationStatus.SENT)
                    .notificationSent(true)
                    .build();

            invitationRepository.save(invitation);

            // Send notification
            notificationService.sendBiddingInvitation(vendor.getEmail(), procurementCase.getCaseNumber());
        }

        // Update case status
        if (procurementCase.getCaseStatus() == CaseStatus.APPROVED) {
            procurementCase.setCaseStatus(CaseStatus.BIDDING_IN_PROGRESS);
            caseRepository.save(procurementCase);
        }
    }

    public List<VendorBidDTO> getBidsByCase(Long caseId) {
        return bidRepository.findByProcurementCaseId(caseId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<VendorBidDTO> getBidsByVendor(Long vendorId) {
        return bidRepository.findByVendorId(vendorId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public VendorBidDTO submitBid(VendorBidDTO dto) {
        ProcurementCase procurementCase = caseRepository.findById(dto.getCaseId())
                .orElseThrow(() -> new RuntimeException("Case not found"));

        CaseLineItem lineItem = lineItemRepository.findById(dto.getLineItemId())
                .orElseThrow(() -> new RuntimeException("Line item not found"));

        VendorMaster vendor = vendorRepository.findById(dto.getVendorId())
                .orElseThrow(() -> new RuntimeException("Vendor not found"));

        String bidNumber = caseNumberGenerator.generateBidNumber(
                procurementCase.getCaseNumber(), vendor.getVendorCode());

        VendorBid bid = VendorBid.builder()
                .bidNumber(bidNumber)
                .procurementCase(procurementCase)
                .lineItem(lineItem)
                .vendor(vendor)
                .bidAmount(dto.getBidAmount())
                .quotedPrice(dto.getQuotedPrice())
                .bidStatus(BidStatus.SUBMITTED)
                .submittedAt(LocalDateTime.now())
                .validTill(LocalDateTime.now().plusDays(30))
                .bidRemarks(dto.getBidRemarks())
                .build();

        bid = bidRepository.save(bid);
        return convertToDTO(bid);
    }

    public void selectVendorBid(Long caseId, Long lineItemId, Long bidId) {
        VendorBid selectedBid = bidRepository.findById(bidId)
                .orElseThrow(() -> new RuntimeException("Bid not found"));

        CaseLineItem lineItem = lineItemRepository.findById(lineItemId)
                .orElseThrow(() -> new RuntimeException("Line item not found"));

        // Mark bid as selected
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        selectedBid.setIsSelected(true);
        selectedBid.setSelectedAt(LocalDateTime.now());
        selectedBid.setSelectedBy(username);
        selectedBid.setBidStatus(BidStatus.SELECTED);
        bidRepository.save(selectedBid);

        // Update line item with selected vendor
        lineItem.setSelectedVendor(selectedBid.getVendor());
        lineItemRepository.save(lineItem);

        // Mark other bids as rejected
        List<VendorBid> otherBids = bidRepository.findByLineItemId(lineItemId);
        for (VendorBid bid : otherBids) {
            if (!bid.getId().equals(bidId)) {
                bid.setBidStatus(BidStatus.REJECTED);
                bidRepository.save(bid);
            }
        }

        // Check if all line items have selected vendors
        ProcurementCase procurementCase = caseRepository.findByIdWithLineItems(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        boolean allSelected = procurementCase.getLineItems().stream()
                .allMatch(item -> item.getSelectedVendor() != null);

        if (allSelected) {
            procurementCase.setCaseStatus(CaseStatus.VENDOR_SELECTED);
            caseRepository.save(procurementCase);
        }
    }

    private VendorBidDTO convertToDTO(VendorBid entity) {
        return VendorBidDTO.builder()
                .id(entity.getId())
                .bidNumber(entity.getBidNumber())
                .caseId(entity.getProcurementCase().getId())
                .caseNumber(entity.getProcurementCase().getCaseNumber())
                .lineItemId(entity.getLineItem().getId())
                .vendorId(entity.getVendor().getId())
                .vendorName(entity.getVendor().getVendorName())
                .bidAmount(entity.getBidAmount())
                .quotedPrice(entity.getQuotedPrice())
                .bidStatus(entity.getBidStatus())
                .submittedAt(entity.getSubmittedAt())
                .validTill(entity.getValidTill())
                .bidRemarks(entity.getBidRemarks())
                .isSelected(entity.getIsSelected())
                .build();
    }
}
