package com.rebit.ips.entity.invoice;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.enums.InvoiceStatus;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "invoice", indexes = {
        @Index(name = "idx_invoice_number", columnList = "invoice_number"),
        @Index(name = "idx_invoice_vendor", columnList = "vendor_id"),
        @Index(name = "idx_invoice_case", columnList = "case_id"),
        @Index(name = "idx_invoice_status", columnList = "invoice_status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Invoice extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "invoice_number", unique = true, length = 50)
    private String invoiceNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id", nullable = false)
    private VendorMaster vendor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id")
    private ProcurementCase procurementCase;

    @Column(name = "invoice_date")
    private LocalDate invoiceDate;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "vendor_gstin", length = 15)
    private String vendorGstin;

    @Column(name = "place_of_supply", length = 100)
    private String placeOfSupply;

    @Column(name = "is_inter_state")
    private Boolean isInterState;

    @Column(name = "taxable_amount", precision = 19, scale = 2)
    private BigDecimal taxableAmount;

    @Column(name = "cgst_amount", precision = 19, scale = 2)
    private BigDecimal cgstAmount;

    @Column(name = "sgst_amount", precision = 19, scale = 2)
    private BigDecimal sgstAmount;

    @Column(name = "igst_amount", precision = 19, scale = 2)
    private BigDecimal igstAmount;

    @Column(name = "total_gst_amount", precision = 19, scale = 2)
    private BigDecimal totalGstAmount;

    @Column(name = "total_invoice_amount", precision = 19, scale = 2)
    private BigDecimal totalInvoiceAmount;

    @Enumerated(EnumType.STRING)
    @Column(name = "invoice_status", length = 20)
    private InvoiceStatus invoiceStatus = InvoiceStatus.UPLOADED;

    @Column(name = "uploaded_file_path", length = 500)
    private String uploadedFilePath;

    @Column(name = "parsed_at")
    private LocalDateTime parsedAt;

    @Column(name = "validated_at")
    private LocalDateTime validatedAt;

    @Column(name = "approved_at")
    private LocalDateTime approvedAt;

    @Column(name = "approved_by", length = 50)
    private String approvedBy;

    @Column(name = "rejected_at")
    private LocalDateTime rejectedAt;

    @Column(name = "rejected_by", length = 50)
    private String rejectedBy;

    @Column(name = "rejection_reason", length = 1000)
    private String rejectionReason;

    @Column(name = "payment_reference", length = 100)
    private String paymentReference;

    @Column(name = "payment_date")
    private LocalDate paymentDate;

    @OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<InvoiceLineItem> lineItems = new ArrayList<>();
}
