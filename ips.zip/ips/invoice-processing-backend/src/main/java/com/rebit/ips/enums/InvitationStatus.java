package com.rebit.ips.enums;

public enum InvitationStatus {
    SENT,
    VIEWED,
    ACCEPTED,
    DECLINED,
    EXPIRED
}
