package com.rebit.ips.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PriceCalculationResponse {
    private BigDecimal calculatedPrice;
    private BigDecimal minPrice;
    private BigDecimal maxPrice;
    private String formula;
    private Boolean withinRange;
}
