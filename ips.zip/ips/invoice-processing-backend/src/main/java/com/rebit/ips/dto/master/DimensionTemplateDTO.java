package com.rebit.ips.dto.master;

import com.rebit.ips.enums.DimensionDataType;
import com.rebit.ips.enums.DimensionUIComponent;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionTemplateDTO {
    private Long id;
    private Long productId;
    @NotBlank
    private String dimensionName;
    @NotBlank
    private String dimensionKey;
    private DimensionDataType dataType;
    private DimensionUIComponent uiComponent;
    private Boolean isMandatory;
    private String enumValues;
    private Double minValue;
    private Double maxValue;
    private String defaultValue;
    private String validationRegex;
    private Integer displayOrder;
    private String helpText;
    private Boolean usedInPricing;
}
