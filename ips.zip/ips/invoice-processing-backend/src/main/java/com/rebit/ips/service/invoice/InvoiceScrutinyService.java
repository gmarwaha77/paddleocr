package com.rebit.ips.service.invoice;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.dto.invoice.InvoiceLineItemDTO;
import com.rebit.ips.dto.invoice.ScrutinySummaryDTO;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.invoice.Invoice;
import com.rebit.ips.entity.invoice.InvoiceLineItem;
import com.rebit.ips.repository.cases.CaseLineItemRepository;
import com.rebit.ips.repository.invoice.InvoiceLineItemRepository;
import com.rebit.ips.repository.invoice.InvoiceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class InvoiceScrutinyService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceLineItemRepository lineItemRepository;
    private final CaseLineItemRepository caseLineItemRepository;
    private final ObjectMapper objectMapper;

    /**
     * AI-Powered Invoice Scrutiny
     * Automatically matches invoice line items with case requirements
     * Generates intelligent red flags and match scores
     */
    public ScrutinySummaryDTO performAutomatedScrutiny(Long invoiceId) {
        log.info("Starting automated scrutiny for invoice: {}", invoiceId);

        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        List<InvoiceLineItem> invoiceItems = lineItemRepository.findByInvoiceId(invoiceId);
        List<CaseLineItem> caseItems = caseLineItemRepository
                .findByProcurementCaseId(invoice.getProcurementCase().getId());

        ScrutinySummaryDTO summary = new ScrutinySummaryDTO();
        summary.setInvoiceId(invoiceId);
        summary.setInvoiceNumber(invoice.getInvoiceNumber());
        summary.setVendorName(invoice.getVendor().getVendorName());
        summary.setTotalLineItems(invoiceItems.size());

        int perfectMatches = 0;
        int toleranceMatches = 0;
        int mismatches = 0;
        int missingProofs = 0;
        int totalRedFlags = 0;
        int totalTimeSaved = 0;

        // Process each invoice line item
        for (InvoiceLineItem invoiceItem : invoiceItems) {
            // Find matching case line item using AI algorithm
            MatchResult matchResult = findBestMatch(invoiceItem, caseItems);

            // Update invoice item with match results
            invoiceItem.setAutoMatchScore(matchResult.getScore());
            invoiceItem.setRequiresReview(matchResult.getScore() < 100);
            invoiceItem.setRedFlagCount(matchResult.getRedFlags().size());

            // Categorize based on score
            if (matchResult.getScore() == 100 && invoiceItem.getProofCount() > 0) {
                perfectMatches++;
                totalTimeSaved += 5; // 5 minutes saved per perfect match
            } else if (matchResult.getScore() >= 90) {
                toleranceMatches++;
                totalTimeSaved += 3; // 3 minutes saved
            } else if (matchResult.getScore() < 90 && matchResult.getScore() > 0) {
                mismatches++;
                totalTimeSaved += 1; // 1 minute saved (still automated detection)
            }

            if (invoiceItem.getProofCount() == 0) {
                missingProofs++;
            }

            totalRedFlags += matchResult.getRedFlags().size();

            lineItemRepository.save(invoiceItem);
        }

        // Build summary
        summary.setPerfectMatches(perfectMatches);
        summary.setToleranceMatches(toleranceMatches);
        summary.setMismatches(mismatches);
        summary.setMissingProofs(missingProofs);
        summary.setRedFlags(totalRedFlags);
        summary.setTimeSaved(totalTimeSaved);

        // Calculate progress
        int processed = perfectMatches + toleranceMatches + mismatches;
        int progress = (processed * 100) / invoiceItems.size();
        summary.setOverallProgress(progress);

        log.info("Scrutiny complete. Perfect: {}, Tolerance: {}, Mismatches: {}, Time Saved: {} min",
                perfectMatches, toleranceMatches, mismatches, totalTimeSaved);

        return summary;
    }

    /**
     * AI Matching Algorithm
     * Compares invoice item with case items using multiple criteria
     */
    private MatchResult findBestMatch(InvoiceLineItem invoiceItem, List<CaseLineItem> caseItems) {
        MatchResult bestMatch = new MatchResult();
        bestMatch.setScore(0);
        bestMatch.setRedFlags(new ArrayList<>());

        if (caseItems.isEmpty()) {
            bestMatch.getRedFlags().add("No matching items found in procurement case");
            return bestMatch;
        }

        for (CaseLineItem caseItem : caseItems) {
            // Skip if different product
            if (!invoiceItem.getProduct().getId().equals(caseItem.getProduct().getId())) {
                continue;
            }

            MatchResult currentMatch = compareItems(invoiceItem, caseItem);
            if (currentMatch.getScore() > bestMatch.getScore()) {
                bestMatch = currentMatch;
                bestMatch.setMatchedCaseItem(caseItem);
            }
        }

        if (bestMatch.getScore() == 0) {
            bestMatch.getRedFlags().add("Item not found in approved case");
            bestMatch.getRedFlags().add("Product mismatch or unauthorized item");
        }

        return bestMatch;
    }

    /**
     * Compare invoice item with case item using AI-like scoring
     */
    private MatchResult compareItems(InvoiceLineItem invoiceItem, CaseLineItem caseItem) {
        MatchResult result = new MatchResult();
        result.setRedFlags(new ArrayList<>());

        try {
            Map<String, Object> invoiceDims = objectMapper.readValue(
                    invoiceItem.getDimensionValues(), Map.class);
            Map<String, Object> caseDims = objectMapper.readValue(
                    caseItem.getDimensionValues(), Map.class);

            int totalDimensions = caseDims.size();
            int matchedDimensions = 0;
            int criticalMismatches = 0;

            // Compare each dimension
            for (Map.Entry<String, Object> entry : caseDims.entrySet()) {
                String key = entry.getKey();
                Object caseValue = entry.getValue();
                Object invoiceValue = invoiceDims.get(key);

                if (invoiceValue == null) {
                    result.getRedFlags().add("Missing dimension: " + key);
                    criticalMismatches++;
                    continue;
                }

                // Handle numeric dimensions with tolerance
                if (caseValue instanceof Number && invoiceValue instanceof Number) {
                    double caseNum = ((Number) caseValue).doubleValue();
                    double invoiceNum = ((Number) invoiceValue).doubleValue();
                    double variance = Math.abs((invoiceNum - caseNum) / caseNum * 100);

                    if (variance == 0) {
                        matchedDimensions++;
                    } else if (variance <= 5) {
                        // Within 5% tolerance
                        matchedDimensions++;
                        result.getRedFlags().add(String.format(
                                "Minor variance in %s: %.1f%% (within tolerance)", key, variance));
                    } else {
                        result.getRedFlags().add(String.format(
                                "Significant variance in %s: %.1f%% (exceeds tolerance)", key, variance));
                        criticalMismatches++;
                    }
                } else if (caseValue.toString().equalsIgnoreCase(invoiceValue.toString())) {
                    matchedDimensions++;
                } else {
                    result.getRedFlags().add(String.format(
                            "Dimension mismatch - %s: Invoice '%s', Case '%s'",
                            key, invoiceValue, caseValue));
                    criticalMismatches++;
                }
            }

            // Calculate match score
            int baseScore = (matchedDimensions * 100) / Math.max(totalDimensions, 1);

            // Penalty for critical mismatches
            int penalty = criticalMismatches * 15;
            int finalScore = Math.max(0, baseScore - penalty);

            // Price validation
            BigDecimal invoiceAmount = invoiceItem.getTaxableValue();
            BigDecimal caseAmount = caseItem.getTotalAmount();

            if (caseAmount != null && invoiceAmount != null) {
                BigDecimal variance = invoiceAmount.subtract(caseAmount)
                        .divide(caseAmount, 4, RoundingMode.HALF_UP)
                        .multiply(new BigDecimal("100"));

                double variancePercent = variance.doubleValue();

                if (Math.abs(variancePercent) > 10) {
                    result.getRedFlags().add(String.format(
                            "Price variance: %.1f%% (Invoice: ₹%s, Case: ₹%s)",
                            variancePercent, invoiceAmount, caseAmount));
                    finalScore = Math.max(0, finalScore - 20);
                }
            }

            result.setScore(finalScore);

        } catch (Exception e) {
            log.error("Error comparing items", e);
            result.setScore(0);
            result.getRedFlags().add("Error in dimension comparison");
        }

        return result;
    }

    /**
     * Get items requiring manual review
     */
    public List<InvoiceLineItemDTO> getReviewQueue(Long invoiceId) {
        List<InvoiceLineItem> items = lineItemRepository.findByInvoiceId(invoiceId);
        return items.stream()
                .filter(InvoiceLineItem::getRequiresReview)
                .sorted(Comparator.comparingInt(InvoiceLineItem::getAutoMatchScore))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get all line items with match scores
     */
    public List<InvoiceLineItemDTO> getAllLineItems(Long invoiceId) {
        List<InvoiceLineItem> items = lineItemRepository.findByInvoiceId(invoiceId);
        return items.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Bulk approve perfect matches
     */
    public int bulkApprovePerfectMatches(Long invoiceId) {
        List<InvoiceLineItem> items = lineItemRepository.findByInvoiceId(invoiceId);
        int approvedCount = 0;

        for (InvoiceLineItem item : items) {
            if (item.getAutoMatchScore() == 100 && item.getProofCount() > 0) {
                // Auto-approve logic here
                approvedCount++;
            }
        }

        log.info("Bulk approved {} perfect matches for invoice {}", approvedCount, invoiceId);
        return approvedCount;
    }

    private InvoiceLineItemDTO convertToDTO(InvoiceLineItem item) {
        InvoiceLineItemDTO dto = new InvoiceLineItemDTO();
        dto.setId(item.getId());
        dto.setItemDescription(item.getItemDescription());
        dto.setTaxableValue(item.getTaxableValue());
        dto.setAutoMatchScore(item.getAutoMatchScore());
        dto.setProofCount(item.getProofCount());
        dto.setRequiresReview(item.getRequiresReview());
        dto.setRedFlagCount(item.getRedFlagCount());
        return dto;
    }

    /**
     * Inner class for match results
     */
    private static class MatchResult {
        private int score;
        private List<String> redFlags;
        private CaseLineItem matchedCaseItem;

        public int getScore() { return score; }
        public void setScore(int score) { this.score = score; }
        public List<String> getRedFlags() { return redFlags; }
        public void setRedFlags(List<String> redFlags) { this.redFlags = redFlags; }
        public CaseLineItem getMatchedCaseItem() { return matchedCaseItem; }
        public void setMatchedCaseItem(CaseLineItem item) { this.matchedCaseItem = item; }
    }
}