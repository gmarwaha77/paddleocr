package com.rebit.ips.repository.master;

import com.rebit.ips.entity.master.RateMatrix;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface RateMatrixRepository extends JpaRepository<RateMatrix, Long> {
    List<RateMatrix> findByProductId(Long productId);

    @Query("SELECT r FROM RateMatrix r WHERE r.product.id = :productId AND " +
            "r.effectiveFrom <= :date AND (r.effectiveTo IS NULL OR r.effectiveTo >= :date)")
    Optional<RateMatrix> findActiveRateForProduct(Long productId, LocalDate date);
}
