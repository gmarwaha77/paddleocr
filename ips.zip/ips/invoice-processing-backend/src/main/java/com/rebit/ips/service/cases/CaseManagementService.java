package com.rebit.ips.service.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.dto.cases.CaseApprovalDTO;
import com.rebit.ips.dto.cases.CaseLineItemDTO;
import com.rebit.ips.dto.cases.ProcurementCaseDTO;
import com.rebit.ips.entity.cases.CaseAuditLog;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.master.*;
import com.rebit.ips.enums.CaseStatus;
import com.rebit.ips.repository.cases.CaseAuditLogRepository;
import com.rebit.ips.repository.cases.CaseLineItemRepository;
import com.rebit.ips.repository.cases.ProcurementCaseRepository;
import com.rebit.ips.repository.master.*;
import com.rebit.ips.service.NotificationService;
import com.rebit.ips.util.CaseNumberGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class CaseManagementService {

    private final ProcurementCaseRepository caseRepository;
    private final CaseLineItemRepository lineItemRepository;
    private final CaseAuditLogRepository auditLogRepository;
    private final DepartmentRepository departmentRepository;
    private final ProductCategoryRepository categoryRepository;
    private final SubCategoryRepository subCategoryRepository;
    private final ProductMasterRepository productRepository;
    private final VendorMasterRepository vendorRepository;
    private final ProductVendorMappingRepository vendorMappingRepository;
    private final CaseNumberGenerator caseNumberGenerator;
    private final NotificationService notificationService;
    private final ObjectMapper objectMapper;

    public List<ProcurementCaseDTO> getAllCases() {
        return caseRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<ProcurementCaseDTO> getCasesByDepartment(Long departmentId) {
        return caseRepository.findByDepartmentId(departmentId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<ProcurementCaseDTO> getCasesByStatus(CaseStatus status) {
        return caseRepository.findByCaseStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public ProcurementCaseDTO getCaseById(Long id) {
        return caseRepository.findByIdWithLineItems(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("Case not found"));
    }

    public ProcurementCaseDTO createCase(ProcurementCaseDTO dto) {
        DepartmentMaster department = departmentRepository.findById(dto.getDepartmentId())
                .orElseThrow(() -> new RuntimeException("Department not found"));

        ProductCategory category = dto.getCategoryId() != null
                ? categoryRepository.findById(dto.getCategoryId()).orElse(null)
                : null;

        SubCategory subCategory = dto.getSubCategoryId() != null
                ? subCategoryRepository.findById(dto.getSubCategoryId()).orElse(null)
                : null;

        String caseNumber = caseNumberGenerator.generateCaseNumber(department.getDepartmentCode());

        ProcurementCase procurementCase = ProcurementCase.builder()
                .caseNumber(caseNumber)
                .caseName(dto.getCaseName())
                .department(department)
                .category(category)
                .subCategory(subCategory)
                .budgetName(dto.getBudgetName())
                .totalApprovedBudget(dto.getTotalApprovedBudget())
                .fundType(dto.getFundType())
                .edApprovalNote(dto.getEdApprovalNote())
                .edApprovalFilePath(dto.getEdApprovalFilePath())
                .caseStatus(CaseStatus.DRAFT)
                .requiresBidding(false)
                .build();

        procurementCase = caseRepository.save(procurementCase);

        // Add audit log
        addAuditLog(procurementCase, "Case Created", null, CaseStatus.DRAFT.name());

        return convertToDTO(procurementCase);
    }

    public ProcurementCaseDTO updateCase(Long id, ProcurementCaseDTO dto) {
        ProcurementCase procurementCase = caseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (procurementCase.getCaseStatus() != CaseStatus.DRAFT) {
            throw new RuntimeException("Can only update cases in DRAFT status");
        }

        procurementCase.setCaseName(dto.getCaseName());
        procurementCase.setBudgetName(dto.getBudgetName());
        procurementCase.setTotalApprovedBudget(dto.getTotalApprovedBudget());
        procurementCase.setFundType(dto.getFundType());
        procurementCase.setEdApprovalNote(dto.getEdApprovalNote());

        procurementCase = caseRepository.save(procurementCase);
        addAuditLog(procurementCase, "Case Updated", null, null);

        return convertToDTO(procurementCase);
    }

    public CaseLineItemDTO addLineItem(Long caseId, CaseLineItemDTO dto) {
        ProcurementCase procurementCase = caseRepository.findById(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (procurementCase.getCaseStatus() != CaseStatus.DRAFT) {
            throw new RuntimeException("Can only add line items to cases in DRAFT status");
        }

        ProductMaster product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        VendorMaster vendor = dto.getSelectedVendorId() != null
                ? vendorRepository.findById(dto.getSelectedVendorId()).orElse(null)
                : null;

        String dimensionJson = convertDimensionsToJson(dto.getDimensionValues());

        CaseLineItem lineItem = CaseLineItem.builder()
                .procurementCase(procurementCase)
                .product(product)
                .dimensionValues(dimensionJson)
                .ceilingAmount(dto.getCeilingAmount())
                .additionalBudgetAmount(dto.getAdditionalBudgetAmount())
                .totalAmount(dto.getTotalAmount())
                .calculatedPrice(dto.getCalculatedPrice())
                .selectedVendor(vendor)
                .comments(dto.getComments())
                .itemOrder(dto.getItemOrder())
                .build();

        lineItem = lineItemRepository.save(lineItem);

        // Update case total
        updateCaseTotal(procurementCase);

        // Check if bidding is required
        checkBiddingRequirement(procurementCase, product);

        addAuditLog(procurementCase, "Line Item Added", null, null);

        return convertLineItemToDTO(lineItem);
    }

    public ProcurementCaseDTO submitForApproval(Long id) {
        ProcurementCase procurementCase = caseRepository.findByIdWithLineItems(id)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (procurementCase.getCaseStatus() != CaseStatus.DRAFT) {
            throw new RuntimeException("Can only submit cases in DRAFT status");
        }

        if (procurementCase.getLineItems().isEmpty()) {
            throw new RuntimeException("Cannot submit case without line items");
        }

        String oldStatus = procurementCase.getCaseStatus().name();
        procurementCase.setCaseStatus(CaseStatus.SUBMITTED);
        procurementCase.setSubmittedAt(LocalDateTime.now());

        procurementCase = caseRepository.save(procurementCase);
        addAuditLog(procurementCase, "Case Submitted for Approval", oldStatus, CaseStatus.SUBMITTED.name());

        // Send notification
        notificationService.sendCaseSubmissionNotification("checker@bank.com", procurementCase.getCaseNumber());

        return convertToDTO(procurementCase);
    }

    public ProcurementCaseDTO approveCase(CaseApprovalDTO approvalDTO) {
        ProcurementCase procurementCase = caseRepository.findById(approvalDTO.getCaseId())
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (procurementCase.getCaseStatus() != CaseStatus.SUBMITTED) {
            throw new RuntimeException("Can only approve cases in SUBMITTED status");
        }

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        String oldStatus = procurementCase.getCaseStatus().name();

        if (approvalDTO.getApproved()) {
            CaseStatus newStatus = procurementCase.getRequiresBidding()
                    ? CaseStatus.BIDDING_IN_PROGRESS
                    : CaseStatus.APPROVED;

            procurementCase.setCaseStatus(newStatus);
            procurementCase.setApprovedAt(LocalDateTime.now());
            procurementCase.setApprovedBy(username);

            addAuditLog(procurementCase, "Case Approved", oldStatus, newStatus.name());
            notificationService.sendCaseApprovalNotification(procurementCase.getCreatedBy(),
                    procurementCase.getCaseNumber());
        } else {
            procurementCase.setCaseStatus(CaseStatus.REJECTED);
            procurementCase.setRejectedAt(LocalDateTime.now());
            procurementCase.setRejectedBy(username);
            procurementCase.setRejectionReason(approvalDTO.getComments());

            addAuditLog(procurementCase, "Case Rejected", oldStatus, CaseStatus.REJECTED.name());
            notificationService.sendCaseRejectionNotification(procurementCase.getCreatedBy(),
                    procurementCase.getCaseNumber(), approvalDTO.getComments());
        }

        procurementCase = caseRepository.save(procurementCase);
        return convertToDTO(procurementCase);
    }

    private void updateCaseTotal(ProcurementCase procurementCase) {
        BigDecimal total = procurementCase.getLineItems().stream()
                .map(CaseLineItem::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        procurementCase.setTotalCaseAmount(total);
        caseRepository.save(procurementCase);
    }

    private void checkBiddingRequirement(ProcurementCase procurementCase, ProductMaster product) {
        List<ProductVendorMapping> mappings = vendorMappingRepository.findByProductId(product.getId());

        if (mappings.size() > 1) {
            procurementCase.setRequiresBidding(true);
            caseRepository.save(procurementCase);
        }
    }

    private void addAuditLog(ProcurementCase procurementCase, String action, String oldStatus, String newStatus) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        CaseAuditLog auditLog = CaseAuditLog.builder()
                .procurementCase(procurementCase)
                .action(action)
                .actionBy(username)
                .actionTimestamp(LocalDateTime.now())
                .oldStatus(oldStatus)
                .newStatus(newStatus)
                .build();

        auditLogRepository.save(auditLog);
    }

    private String convertDimensionsToJson(Map<String, Object> dimensions) {
        try {
            return objectMapper.writeValueAsString(dimensions);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting dimensions to JSON", e);
        }
    }

    private Map<String, Object> convertJsonToDimensions(String json) {
        try {
            return objectMapper.readValue(json, Map.class);
        } catch (JsonProcessingException e) {
            return Map.of();
        }
    }

    private ProcurementCaseDTO convertToDTO(ProcurementCase entity) {
        return ProcurementCaseDTO.builder()
                .id(entity.getId())
                .caseNumber(entity.getCaseNumber())
                .caseName(entity.getCaseName())
                .departmentId(entity.getDepartment().getId())
                .departmentName(entity.getDepartment().getDepartmentName())
                .categoryId(entity.getCategory() != null ? entity.getCategory().getId() : null)
                .categoryName(entity.getCategory() != null ? entity.getCategory().getCategoryName() : null)
                .subCategoryId(entity.getSubCategory() != null ? entity.getSubCategory().getId() : null)
                .subCategoryName(entity.getSubCategory() != null ? entity.getSubCategory().getSubCategoryName() : null)
                .budgetName(entity.getBudgetName())
                .totalApprovedBudget(entity.getTotalApprovedBudget())
                .fundType(entity.getFundType())
                .edApprovalNote(entity.getEdApprovalNote())
                .edApprovalFilePath(entity.getEdApprovalFilePath())
                .caseStatus(entity.getCaseStatus())
                .submittedAt(entity.getSubmittedAt())
                .approvedAt(entity.getApprovedAt())
                .approvedBy(entity.getApprovedBy())
                .rejectedAt(entity.getRejectedAt())
                .rejectedBy(entity.getRejectedBy())
                .rejectionReason(entity.getRejectionReason())
                .totalCaseAmount(entity.getTotalCaseAmount())
                .requiresBidding(entity.getRequiresBidding())
                .lineItems(entity.getLineItems().stream()
                        .map(this::convertLineItemToDTO)
                        .collect(Collectors.toList()))
                .build();
    }

    private CaseLineItemDTO convertLineItemToDTO(CaseLineItem entity) {
        return CaseLineItemDTO.builder()
                .id(entity.getId())
                .caseId(entity.getProcurementCase().getId())
                .productId(entity.getProduct().getId())
                .productName(entity.getProduct().getProductName())
                .dimensionValues(convertJsonToDimensions(entity.getDimensionValues()))
                .ceilingAmount(entity.getCeilingAmount())
                .additionalBudgetAmount(entity.getAdditionalBudgetAmount())
                .totalAmount(entity.getTotalAmount())
                .calculatedPrice(entity.getCalculatedPrice())
                .selectedVendorId(entity.getSelectedVendor() != null ? entity.getSelectedVendor().getId() : null)
                .selectedVendorName(entity.getSelectedVendor() != null ? entity.getSelectedVendor().getVendorName() : null)
                .comments(entity.getComments())
                .itemOrder(entity.getItemOrder())
                .build();
    }
}
