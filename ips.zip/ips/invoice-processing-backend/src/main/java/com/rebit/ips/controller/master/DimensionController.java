package com.rebit.ips.controller.master;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.PriceCalculationRequest;
import com.rebit.ips.dto.PriceCalculationResponse;
import com.rebit.ips.dto.master.DimensionTemplateDTO;
import com.rebit.ips.service.master.DimensionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/master/dimensions")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class DimensionController {

    private final DimensionService dimensionService;

    @GetMapping("/product/{productId}")
    public ApiResponse<List<DimensionTemplateDTO>> getDimensionsByProduct(@PathVariable Long productId) {
        return ApiResponse.success("Dimensions retrieved successfully",
                dimensionService.getDimensionsByProduct(productId));
    }

    @PostMapping
    public ApiResponse<DimensionTemplateDTO> createDimension(@Valid @RequestBody DimensionTemplateDTO dto) {
        return ApiResponse.success("Dimension created successfully",
                dimensionService.createDimension(dto));
    }

    @PutMapping("/{id}")
    public ApiResponse<DimensionTemplateDTO> updateDimension(@PathVariable Long id,
                                                             @Valid @RequestBody DimensionTemplateDTO dto) {
        return ApiResponse.success("Dimension updated successfully",
                dimensionService.updateDimension(id, dto));
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteDimension(@PathVariable Long id) {
        dimensionService.deleteDimension(id);
        return ApiResponse.success("Dimension deleted successfully", null);
    }

    @PostMapping("/calculate-price")
    public ApiResponse<PriceCalculationResponse> calculatePrice(@Valid @RequestBody PriceCalculationRequest request) {
        return ApiResponse.success("Price calculated successfully",
                dimensionService.calculatePrice(request));
    }
}
