package com.rebit.ips.controller.bidding;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.bidding.BiddingInvitationDTO;
import com.rebit.ips.dto.bidding.VendorBidDTO;
import com.rebit.ips.service.bidding.BiddingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bids")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class BiddingController {

    private final BiddingService biddingService;

    @PostMapping("/cases/{caseId}/invite-vendors")
    public ApiResponse<Void> inviteVendors(@PathVariable Long caseId,
                                           @Valid @RequestBody BiddingInvitationDTO dto) {
        dto.setCaseId(caseId);
        biddingService.inviteVendorsForBidding(dto);
        return ApiResponse.success("Vendors invited successfully", null);
    }

    @GetMapping("/cases/{caseId}")
    public ApiResponse<List<VendorBidDTO>> getBidsByCase(@PathVariable Long caseId) {
        return ApiResponse.success("Bids retrieved successfully",
                biddingService.getBidsByCase(caseId));
    }

    @GetMapping("/vendor/{vendorId}")
    public ApiResponse<List<VendorBidDTO>> getBidsByVendor(@PathVariable Long vendorId) {
        return ApiResponse.success("Bids retrieved successfully",
                biddingService.getBidsByVendor(vendorId));
    }

    @PostMapping
    public ApiResponse<VendorBidDTO> submitBid(@Valid @RequestBody VendorBidDTO dto) {
        return ApiResponse.success("Bid submitted successfully",
                biddingService.submitBid(dto));
    }

    @PutMapping("/cases/{caseId}/line-items/{lineItemId}/select-vendor/{bidId}")
    public ApiResponse<Void> selectVendor(@PathVariable Long caseId,
                                          @PathVariable Long lineItemId,
                                          @PathVariable Long bidId) {
        biddingService.selectVendorBid(caseId, lineItemId, bidId);
        return ApiResponse.success("Vendor selected successfully", null);
    }
}
