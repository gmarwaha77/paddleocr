package com.rebit.ips.controller.master;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.master.ProductCategoryDTO;
import com.rebit.ips.dto.master.ProductMasterDTO;
import com.rebit.ips.dto.master.SubCategoryDTO;
import com.rebit.ips.service.master.ProductHierarchyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/master/product-hierarchies")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class ProductHierarchyController {

    private final ProductHierarchyService productHierarchyService;

    // Category endpoints
    @GetMapping("/categories")
    public ApiResponse<List<ProductCategoryDTO>> getAllCategories() {
        return ApiResponse.success("Categories retrieved successfully",
                productHierarchyService.getAllCategories());
    }

    @GetMapping("/categories/department/{departmentId}")
    public ApiResponse<List<ProductCategoryDTO>> getCategoriesByDepartment(@PathVariable Long departmentId) {
        return ApiResponse.success("Categories retrieved successfully",
                productHierarchyService.getCategoriesByDepartment(departmentId));
    }

    @PostMapping("/categories")
    public ApiResponse<ProductCategoryDTO> createCategory(@Valid @RequestBody ProductCategoryDTO dto) {
        return ApiResponse.success("Category created successfully",
                productHierarchyService.createCategory(dto));
    }

    // SubCategory endpoints
    @GetMapping("/sub-categories/category/{categoryId}")
    public ApiResponse<List<SubCategoryDTO>> getSubCategoriesByCategory(@PathVariable Long categoryId) {
        return ApiResponse.success("Sub-categories retrieved successfully",
                productHierarchyService.getSubCategoriesByCategory(categoryId));
    }

    @PostMapping("/sub-categories")
    public ApiResponse<SubCategoryDTO> createSubCategory(@Valid @RequestBody SubCategoryDTO dto) {
        return ApiResponse.success("Sub-category created successfully",
                productHierarchyService.createSubCategory(dto));
    }

    // Product endpoints
    @GetMapping("/products/sub-category/{subCategoryId}")
    public ApiResponse<List<ProductMasterDTO>> getProductsBySubCategory(@PathVariable Long subCategoryId) {
        return ApiResponse.success("Products retrieved successfully",
                productHierarchyService.getProductsBySubCategory(subCategoryId));
    }

    @GetMapping("/products/{id}")
    public ApiResponse<ProductMasterDTO> getProductById(@PathVariable Long id) {
        return ApiResponse.success("Product retrieved successfully",
                productHierarchyService.getProductById(id));
    }

    @PostMapping("/products")
    public ApiResponse<ProductMasterDTO> createProduct(@Valid @RequestBody ProductMasterDTO dto) {
        return ApiResponse.success("Product created successfully",
                productHierarchyService.createProduct(dto));
    }

    @PutMapping("/products/{id}")
    public ApiResponse<ProductMasterDTO> updateProduct(@PathVariable Long id,
                                                       @Valid @RequestBody ProductMasterDTO dto) {
        return ApiResponse.success("Product updated successfully",
                productHierarchyService.updateProduct(id, dto));
    }
}
