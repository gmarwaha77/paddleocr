package com.rebit.ips.dto.invoice;

import com.rebit.ips.enums.MatchStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionComparisonDTO {
    private String dimensionKey;
    private String dimensionName;
    private Object expectedValue;
    private Object actualValue;
    private MatchStatus matchStatus;
    private Boolean redFlag;
    private Double variancePercentage;
    private String comments;
}
