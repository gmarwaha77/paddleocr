package com.rebit.ips.dto.cases;

import com.rebit.ips.enums.CaseStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcurementCaseDTO {
    private Long id;
    private String caseNumber;
    @NotBlank
    private String caseName;
    @NotNull
    private Long departmentId;
    private String departmentName;
    private Long categoryId;
    private String categoryName;
    private Long subCategoryId;
    private String subCategoryName;
    private String budgetName;
    @NotNull
    private BigDecimal totalApprovedBudget;
    private String fundType;
    private String edApprovalNote;
    private String edApprovalFilePath;
    private CaseStatus caseStatus;
    private LocalDateTime submittedAt;
    private LocalDateTime approvedAt;
    private String approvedBy;
    private LocalDateTime rejectedAt;
    private String rejectedBy;
    private String rejectionReason;
    private BigDecimal totalCaseAmount;
    private Boolean requiresBidding;
    private List<CaseLineItemDTO> lineItems;
}

