package com.rebit.ips.entity.master;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.enums.DimensionDataType;
import com.rebit.ips.enums.DimensionUIComponent;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Table(name = "dimension_template")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class DimensionTemplate extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster product;

    @NotBlank
    @Column(name = "dimension_name", length = 100)
    private String dimensionName;

    @NotBlank
    @Column(name = "dimension_key", length = 50)
    private String dimensionKey;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "data_type", length = 20)
    private DimensionDataType dataType;

    @Enumerated(EnumType.STRING)
    @Column(name = "ui_component", length = 20)
    private DimensionUIComponent uiComponent;

    @Column(name = "is_mandatory")
    private Boolean isMandatory = false;

    @Column(name = "enum_values", length = 1000)
    private String enumValues;

    @Column(name = "min_value")
    private Double minValue;

    @Column(name = "max_value")
    private Double maxValue;

    @Column(name = "default_value", length = 100)
    private String defaultValue;

    @Column(name = "validation_regex", length = 500)
    private String validationRegex;

    @Column(name = "display_order")
    private Integer displayOrder;

    @Column(name = "help_text", length = 500)
    private String helpText;

    @Column(name = "used_in_pricing")
    private Boolean usedInPricing = false;
}
