package com.rebit.ips.enums;

public enum InvoiceStatus {
    UPLOADED,
    PARSED,
    VALIDATED,
    VALIDATION_FAILED,
    PENDING_APPROVAL,
    APPROVED,
    REJECTED,
    PAYMENT_PROCESSED,
    CANCELLED
}
