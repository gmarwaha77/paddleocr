package com.rebit.ips.entity.master;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.enums.VendorStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "vendor_master", indexes = {
        @Index(name = "idx_vendor_code", columnList = "vendor_code"),
        @Index(name = "idx_gstin", columnList = "gstin")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class VendorMaster extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "vendor_code", unique = true, length = 50)
    private String vendorCode;

    @NotBlank
    @Column(name = "vendor_name", length = 200)
    private String vendorName;

    @NotBlank
    @Column(name = "gstin", unique = true, length = 15)
    private String gstin;

    @Column(name = "pan", length = 10)
    private String pan;

    @Column(name = "contact_person", length = 100)
    private String contactPerson;

    @Email
    @Column(name = "email", length = 100)
    private String email;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "address", length = 500)
    private String address;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "state", length = 100)
    private String state;

    @Column(name = "pincode", length = 10)
    private String pincode;

    @Column(name = "bank_name", length = 100)
    private String bankName;

    @Column(name = "account_number", length = 30)
    private String accountNumber;

    @Column(name = "ifsc_code", length = 15)
    private String ifscCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "vendor_status", length = 20)
    private VendorStatus vendorStatus = VendorStatus.ACTIVE;

    @Column(name = "empanelment_date")
    private LocalDate empanelmentDate;

    @Column(name = "empanelment_expiry_date")
    private LocalDate empanelmentExpiryDate;

    @OneToMany(mappedBy = "vendor", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<ProductVendorMapping> productMappings = new ArrayList<>();
}
