package com.rebit.ips.dto.bidding;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiddingInvitationDTO {
    private Long caseId;
    private List<Long> vendorIds;
}
