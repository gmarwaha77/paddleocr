package com.rebit.ips.dto.master;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentDTO {
    private Long id;
    @NotBlank
    private String departmentCode;
    @NotBlank
    private String departmentName;
    private String description;
    @NotNull
    private BigDecimal annualBudget;
    private BigDecimal budgetUtilized;
    private String headOfDepartment;
    private String contactEmail;
    private String contactPhone;
    private Boolean isActive;
}
