package com.rebit.ips.util;

import com.rebit.ips.dto.GSTCalculationResult;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Component
public class GSTCalculator {

    // Indian states for place of supply determination
    private static final String BANK_STATE = "Maharashtra";

    public GSTCalculationResult calculateGST(BigDecimal taxableAmount,
                                             BigDecimal gstRate,
                                             String vendorState) {

        boolean isInterState = !BANK_STATE.equalsIgnoreCase(vendorState);

        BigDecimal totalGstAmount = taxableAmount.multiply(gstRate)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

        BigDecimal cgstAmount = BigDecimal.ZERO;
        BigDecimal sgstAmount = BigDecimal.ZERO;
        BigDecimal igstAmount = BigDecimal.ZERO;
        BigDecimal cgstRate = BigDecimal.ZERO;
        BigDecimal sgstRate = BigDecimal.ZERO;
        BigDecimal igstRate = BigDecimal.ZERO;

        if (isInterState) {
            // Inter-state: IGST
            igstAmount = totalGstAmount;
            igstRate = gstRate;
        } else {
            // Intra-state: CGST + SGST
            cgstAmount = totalGstAmount.divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
            sgstAmount = totalGstAmount.subtract(cgstAmount);
            cgstRate = gstRate.divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
            sgstRate = gstRate.subtract(cgstRate);
        }

        BigDecimal totalAmount = taxableAmount.add(totalGstAmount);

        return GSTCalculationResult.builder()
                .taxableAmount(taxableAmount)
                .cgstRate(cgstRate)
                .sgstRate(sgstRate)
                .igstRate(igstRate)
                .cgstAmount(cgstAmount)
                .sgstAmount(sgstAmount)
                .igstAmount(igstAmount)
                .totalGstAmount(totalGstAmount)
                .totalAmount(totalAmount)
                .isInterState(isInterState)
                .placeOfSupply(vendorState)
                .build();
    }

    public boolean validateGSTIN(String gstin) {
        if (gstin == null || gstin.length() != 15) {
            return false;
        }

        // Basic GSTIN format validation
        // Format: 2 digits (state code) + 10 digits (PAN) + 1 digit (entity number) + 1 letter (Z) + 1 check digit
        String pattern = "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$";
        return gstin.matches(pattern);
    }

    public String extractStateFromGSTIN(String gstin) {
        if (gstin != null && gstin.length() >= 2) {
            String stateCode = gstin.substring(0, 2);
            return getStateNameFromCode(stateCode);
        }
        return "Unknown";
    }

    private String getStateNameFromCode(String code) {
        // Mapping of state codes to names (partial list)
        return switch (code) {
            case "01" -> "Jammu and Kashmir";
            case "02" -> "Himachal Pradesh";
            case "03" -> "Punjab";
            case "04" -> "Chandigarh";
            case "05" -> "Uttarakhand";
            case "06" -> "Haryana";
            case "07" -> "Delhi";
            case "08" -> "Rajasthan";
            case "09" -> "Uttar Pradesh";
            case "10" -> "Bihar";
            case "11" -> "Sikkim";
            case "12" -> "Arunachal Pradesh";
            case "13" -> "Nagaland";
            case "14" -> "Manipur";
            case "15" -> "Mizoram";
            case "16" -> "Tripura";
            case "17" -> "Meghalaya";
            case "18" -> "Assam";
            case "19" -> "West Bengal";
            case "20" -> "Jharkhand";
            case "21" -> "Odisha";
            case "22" -> "Chhattisgarh";
            case "23" -> "Madhya Pradesh";
            case "24" -> "Gujarat";
            case "27" -> "Maharashtra";
            case "29" -> "Karnataka";
            case "32" -> "Kerala";
            case "33" -> "Tamil Nadu";
            case "36" -> "Telangana";
            case "37" -> "Andhra Pradesh";
            default -> "Unknown";
        };
    }
}
