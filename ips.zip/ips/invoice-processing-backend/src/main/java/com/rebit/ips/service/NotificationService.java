package com.rebit.ips.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class NotificationService {

    public void sendCaseSubmissionNotification(String checkerEmail, String caseNumber) {
        log.info("MOCK NOTIFICATION: Case {} submitted for approval. Email would be sent to {}",
                caseNumber, checkerEmail);
    }

    public void sendCaseApprovalNotification(String makerEmail, String caseNumber) {
        log.info("MOCK NOTIFICATION: Case {} approved. Email would be sent to {}",
                caseNumber, makerEmail);
    }

    public void sendCaseRejectionNotification(String makerEmail, String caseNumber, String reason) {
        log.info("MOCK NOTIFICATION: Case {} rejected. Reason: {}. Email would be sent to {}",
                caseNumber, reason, makerEmail);
    }

    public void sendBiddingInvitation(String vendorEmail, String caseNumber) {
        log.info("MOCK NOTIFICATION: Bidding invitation for case {} sent to vendor email {}",
                caseNumber, vendorEmail);
    }

    public void sendInvoiceApprovalNotification(String vendorEmail, String invoiceNumber) {
        log.info("MOCK NOTIFICATION: Invoice {} approved. Email would be sent to {}",
                invoiceNumber, vendorEmail);
    }
}
