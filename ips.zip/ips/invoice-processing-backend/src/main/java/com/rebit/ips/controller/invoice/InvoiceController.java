package com.rebit.ips.controller.invoice;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.GSTCalculationResult;
import com.rebit.ips.dto.invoice.InvoiceApprovalDTO;
import com.rebit.ips.dto.invoice.InvoiceDTO;
import com.rebit.ips.enums.InvoiceStatus;
import com.rebit.ips.service.invoice.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/invoices")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    @GetMapping
    public ApiResponse<List<InvoiceDTO>> getAllInvoices() {
        return ApiResponse.success("Invoices retrieved successfully",
                invoiceService.getAllInvoices());
    }

    @GetMapping("/vendor/{vendorId}")
    public ApiResponse<List<InvoiceDTO>> getInvoicesByVendor(@PathVariable Long vendorId) {
        return ApiResponse.success("Invoices retrieved successfully",
                invoiceService.getInvoicesByVendor(vendorId));
    }

    @GetMapping("/case/{caseId}")
    public ApiResponse<List<InvoiceDTO>> getInvoicesByCase(@PathVariable Long caseId) {
        return ApiResponse.success("Invoices retrieved successfully",
                invoiceService.getInvoicesByCase(caseId));
    }

    @GetMapping("/status/{status}")
    public ApiResponse<List<InvoiceDTO>> getInvoicesByStatus(@PathVariable InvoiceStatus status) {
        return ApiResponse.success("Invoices retrieved successfully",
                invoiceService.getInvoicesByStatus(status));
    }

    @GetMapping("/{id}")
    public ApiResponse<InvoiceDTO> getInvoiceById(@PathVariable Long id) {
        return ApiResponse.success("Invoice retrieved successfully",
                invoiceService.getInvoiceById(id));
    }

    @PostMapping("/upload")
    public ApiResponse<InvoiceDTO> uploadInvoice(@RequestParam("vendorId") Long vendorId,
                                                 @RequestParam(value = "caseId", required = false) Long caseId,
                                                 @RequestParam("file") MultipartFile file) {
        return ApiResponse.success("Invoice uploaded successfully",
                invoiceService.uploadInvoice(vendorId, caseId, file));
    }

    @PostMapping("/{id}/parse")
    public ApiResponse<InvoiceDTO> parseInvoice(@PathVariable Long id) {
        return ApiResponse.success("Invoice parsed successfully",
                invoiceService.parseInvoice(id));
    }

    @PostMapping("/{id}/validate")
    public ApiResponse<InvoiceDTO> validateInvoice(@PathVariable Long id) {
        return ApiResponse.success("Invoice validated successfully",
                invoiceService.validateInvoice(id));
    }

    @PutMapping("/{id}/approve")
    public ApiResponse<InvoiceDTO> approveInvoice(@PathVariable Long id,
                                                  @Valid @RequestBody InvoiceApprovalDTO dto) {
        dto.setInvoiceId(id);
        return ApiResponse.success("Invoice processed successfully",
                invoiceService.approveInvoice(dto));
    }

    @GetMapping("/{id}/gst-breakup")
    public ApiResponse<GSTCalculationResult> getGSTBreakup(@PathVariable Long id) {
        return ApiResponse.success("GST breakup retrieved successfully",
                invoiceService.getGSTBreakup(id));
    }
}
