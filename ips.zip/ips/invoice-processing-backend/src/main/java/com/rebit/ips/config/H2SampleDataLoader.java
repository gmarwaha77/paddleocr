package com.rebit.ips.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.invoice.Invoice;
import com.rebit.ips.entity.invoice.InvoiceLineItem;
import com.rebit.ips.entity.invoice.InvoiceLineItemProof;
import com.rebit.ips.entity.master.*;
import com.rebit.ips.enums.*;
import com.rebit.ips.repository.cases.CaseLineItemRepository;
import com.rebit.ips.repository.cases.ProcurementCaseRepository;
import com.rebit.ips.repository.invoice.InvoiceLineItemProofRepository;
import com.rebit.ips.repository.invoice.InvoiceLineItemRepository;
import com.rebit.ips.repository.invoice.InvoiceRepository;
import com.rebit.ips.repository.master.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

@Component
@Profile("dev")
@RequiredArgsConstructor
@Slf4j
public class H2SampleDataLoader implements CommandLineRunner {

    private final DepartmentRepository departmentRepository;
    private final ProductCategoryRepository categoryRepository;
    private final SubCategoryRepository subCategoryRepository;
    private final ProductMasterRepository productRepository;
    private final DimensionTemplateRepository dimensionRepository;
    private final VendorMasterRepository vendorRepository;
    private final ProductVendorMappingRepository vendorMappingRepository;
    private final RateMatrixRepository rateMatrixRepository;
    private final ProcurementCaseRepository caseRepository;
    private final CaseLineItemRepository caseLineItemRepository;
    private final InvoiceRepository invoiceRepository;
    private final InvoiceLineItemRepository invoiceLineItemRepository;
    private final InvoiceLineItemProofRepository invoiceLineItemProofRepository;
    private final ObjectMapper objectMapper;

    @Override
    public void run(String... args) throws JsonProcessingException {
        log.info("=== Loading Comprehensive Sample Data for H2 Database ===");

        // ===== DEPARTMENTS =====
        DepartmentMaster deptComm = createDepartment("DOC", "Department Of Communication",
                new BigDecimal("500000000"), "Mr. Rajesh Kumar");
        DepartmentMaster deptIT = createDepartment("DIT", "IT Department",
                new BigDecimal("250000000"), "Ms. Priya Sharma");
        DepartmentMaster deptAdmin = createDepartment("DAD", "Administration",
                new BigDecimal("100000000"), "Mr. Vikram Singh");

        log.info("Created 3 departments");

        // ===== PRODUCT CATEGORIES & HIERARCHIES =====

        // 1. ADVERTISEMENTS CATEGORY
        ProductCategory categoryAds = createCategory("ADV", "Advertisements",
                "All types of advertisements", deptComm);
        SubCategory subCategoryPAC = createSubCategory("PAC", "Public Awareness Campaign",
                "Public awareness campaigns", categoryAds);
        SubCategory subCategoryBrand = createSubCategory("BRD", "Brand Promotion",
                "Brand promotion activities", categoryAds);

        // Print Advertisement Product
        ProductMaster productPrint = createProduct("PRINT-001", "Print Advertisement",
                "Newspaper ads", subCategoryPAC, "998311", true, new BigDecimal("100"));
        createDimension(productPrint, "Publication Name", "publication", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Name of newspaper/magazine", null, null, false, 1);
        createDimension(productPrint, "Page Number", "page", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Page number", null, null, false, 2);
        createDimension(productPrint, "Size (sqcm)", "size", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "Size in square centimeters", 50.0, 5000.0, true, 3);
        createDimension(productPrint, "Color Type", "colorType", DimensionDataType.ENUM,
                DimensionUIComponent.DROPDOWN, true, "Full color or B&W", null, null, true, 4);

        // TV Advertisement Product
        ProductMaster productTV = createProduct("TV-001", "Television Advertisement",
                "TV commercials", subCategoryPAC, "998311", true, new BigDecimal("15000"));
        createDimension(productTV, "Channel Name", "channel", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "TV channel name", null, null, false, 1);
        createDimension(productTV, "Duration (seconds)", "duration", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "Duration in seconds", 10.0, 60.0, true, 2);
        createDimension(productTV, "Time Slot", "timeSlot", DimensionDataType.ENUM,
                DimensionUIComponent.DROPDOWN, true, "Prime/Non-prime time", null, null, true, 3);
        createDimension(productTV, "Telecast Date", "telecastDate", DimensionDataType.DATE,
                DimensionUIComponent.DATEPICKER, true, "Date of telecast", null, null, false, 4);

        // Radio Advertisement Product
        ProductMaster productRadio = createProduct("RADIO-001", "Radio Advertisement",
                "Radio spots", subCategoryBrand, "998311", true, new BigDecimal("5000"));
        createDimension(productRadio, "Radio Station", "station", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Radio station name", null, null, false, 1);
        createDimension(productRadio, "Duration (seconds)", "duration", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "Duration in seconds", 10.0, 60.0, true, 2);
        createDimension(productRadio, "Frequency", "frequency", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "FM frequency", null, null, false, 3);

        // 2. IT INFRASTRUCTURE CATEGORY
        ProductCategory categoryIT = createCategory("ITC", "IT Infrastructure",
                "IT hardware and services", deptIT);
        SubCategory subCategoryServers = createSubCategory("SRV", "Servers",
                "Server hardware", categoryIT);
        SubCategory subCategoryLaptops = createSubCategory("LAP", "Laptops",
                "Laptop computers", categoryIT);

        // Server Product
        ProductMaster productServer = createProduct("SRV-001", "Enterprise Server",
                "Rack-mounted servers", subCategoryServers, "847130", true, new BigDecimal("500000"));
        createDimension(productServer, "Brand", "brand", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Server brand", null, null, false, 1);
        createDimension(productServer, "Processor Cores", "cores", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "Number of processor cores", 4.0, 128.0, true, 2);
        createDimension(productServer, "RAM (GB)", "ram", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "RAM in GB", 16.0, 1024.0, true, 3);
        createDimension(productServer, "Storage (TB)", "storage", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "Storage in TB", 1.0, 100.0, true, 4);

        // Laptop Product
        ProductMaster productLaptop = createProduct("LAP-001", "Business Laptop",
                "Employee laptops", subCategoryLaptops, "847130", true, new BigDecimal("80000"));
        createDimension(productLaptop, "Brand", "brand", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Laptop brand", null, null, false, 1);
        createDimension(productLaptop, "Processor", "processor", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Processor model", null, null, false, 2);
        createDimension(productLaptop, "RAM (GB)", "ram", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "RAM in GB", 8.0, 64.0, true, 3);
        createDimension(productLaptop, "Screen Size", "screenSize", DimensionDataType.ENUM,
                DimensionUIComponent.DROPDOWN, true, "Screen size in inches", null, null, false, 4);

        // 3. ADMINISTRATIVE CATEGORY
        ProductCategory categoryAdmin = createCategory("ADM", "Administrative Services",
                "Administrative support", deptAdmin);
        SubCategory subCategoryStationery = createSubCategory("STN", "Stationery",
                "Office stationery", categoryAdmin);

        ProductMaster productStationery = createProduct("STN-001", "Office Stationery",
                "Bulk stationery", subCategoryStationery, "482010", true, new BigDecimal("50"));
        createDimension(productStationery, "Item Type", "itemType", DimensionDataType.STRING,
                DimensionUIComponent.INPUT, true, "Type of item", null, null, false, 1);
        createDimension(productStationery, "Quantity", "quantity", DimensionDataType.NUMBER,
                DimensionUIComponent.INPUT, true, "Number of units", 1.0, 10000.0, true, 2);

        log.info("Created 3 categories, 6 sub-categories, and 7 products with dimensions");

        // ===== RATE MATRICES - Pricing based on dimensions =====

        // Print Advertisement - Price per sqcm varies by color type
        createRateMatrix(productPrint, "Full Color Print Rate",
                new BigDecimal("150"), new BigDecimal("200"),
                "colorType=Full Color", "basePrice * size");
        createRateMatrix(productPrint, "B&W Print Rate",
                new BigDecimal("75"), new BigDecimal("100"),
                "colorType=B&W", "basePrice * size");

        // TV Advertisement - Price per second varies by time slot
        createRateMatrix(productTV, "Prime Time TV Rate",
                new BigDecimal("10000"), new BigDecimal("15000"),
                "timeSlot=Prime Time", "basePrice * duration");
        createRateMatrix(productTV, "Non-Prime TV Rate",
                new BigDecimal("5000"), new BigDecimal("7000"),
                "timeSlot=Non-Prime Time", "basePrice * duration");

        // Radio Advertisement - Flat rate per second
        createRateMatrix(productRadio, "Radio Spot Rate",
                new BigDecimal("500"), new BigDecimal("1000"),
                "all", "basePrice * duration");

        // Server - Price based on cores and RAM
        createRateMatrix(productServer, "Standard Server Rate",
                new BigDecimal("50000"), new BigDecimal("100000"),
                "cores>=16,ram>=64", "basePrice * (cores/16) * (ram/64)");
        createRateMatrix(productServer, "High-End Server Rate",
                new BigDecimal("100000"), new BigDecimal("500000"),
                "cores>=64,ram>=256", "basePrice * (cores/16) * (ram/64)");

        // Laptop - Price based on RAM
        createRateMatrix(productLaptop, "Standard Laptop Rate",
                new BigDecimal("50000"), new BigDecimal("70000"),
                "ram>=8,ram<=16", "basePrice + (ram * 2000)");
        createRateMatrix(productLaptop, "High-End Laptop Rate",
                new BigDecimal("70000"), new BigDecimal("150000"),
                "ram>16", "basePrice + (ram * 3000)");

        // Stationery - Price per unit quantity
        createRateMatrix(productStationery, "Bulk Stationery Rate",
                new BigDecimal("10"), new BigDecimal("50"),
                "quantity>=100", "basePrice * quantity * 0.8");
        createRateMatrix(productStationery, "Small Order Rate",
                new BigDecimal("15"), new BigDecimal("50"),
                "quantity<100", "basePrice * quantity");

        log.info("Created rate matrices for dimension-based pricing");

        // ===== VENDORS =====
        VendorMaster vendorTOI = createVendor("VEN001", "Times of India Publications",
                "27AADCT2332M1Z2", "Maharashtra", "contact@timesofindia.com");
        VendorMaster vendorHT = createVendor("VEN002", "Hindustan Times Media",
                "07AABCH6394J1Z5", "Delhi", "billing@hindustantimes.com");
        VendorMaster vendorZeeTV = createVendor("VEN003", "Zee Entertainment",
                "27AAECZ1234M1Z1", "Maharashtra", "finance@zee.com");
        VendorMaster vendorRadioMirchi = createVendor("VEN004", "Radio Mirchi Network",
                "29AAFCR5678K1Z3", "Karnataka", "accounts@radiomirchi.com");
        VendorMaster vendorDell = createVendor("VEN005", "Dell Technologies India",
                "29AAACA1234D1Z5", "Karnataka", "india.sales@dell.com");
        VendorMaster vendorHP = createVendor("VEN006", "HP India Sales",
                "27AABCH5678P1Z1", "Maharashtra", "hpindia@hp.com");
        VendorMaster vendorOdisha = createVendor("VEN007", "Odisha Stationery Mart",
                "21AABCO1234S1Z7", "Odisha", "sales@odishastationery.com");

        // Map vendors to products
        mapVendorToProduct(vendorTOI, productPrint);
        mapVendorToProduct(vendorHT, productPrint);
        mapVendorToProduct(vendorZeeTV, productTV);
        mapVendorToProduct(vendorRadioMirchi, productRadio);
        mapVendorToProduct(vendorDell, productServer);
        mapVendorToProduct(vendorDell, productLaptop);
        mapVendorToProduct(vendorHP, productLaptop);
        mapVendorToProduct(vendorOdisha, productStationery);

        log.info("Created 7 vendors and mapped to products");

        // ===== CASES AT DIFFERENT STAGES =====

        // Case 1: DRAFT - Ready for maker to work on
        ProcurementCase case1 = createCase("CASE-DOC-001", "Q4 Awareness Campaign - Draft",
                deptComm, categoryAds, subCategoryPAC, CaseStatus.DRAFT, new BigDecimal("5000000"));

        // Case 2: PENDING_APPROVAL - Submitted by maker
        ProcurementCase case2 = createCase("CASE-DOC-002", "Financial Literacy Campaign",
                deptComm, categoryAds, subCategoryPAC, CaseStatus.PENDING_APPROVAL, new BigDecimal("8000000"));
        CaseLineItem case2Item1 = createCaseLineItem(case2, productPrint,
                Map.of("publication", "Times of India", "page", "3", "size", 250, "colorType", "Full Color"));
        CaseLineItem case2Item2 = createCaseLineItem(case2, productTV,
                Map.of("channel", "Zee News", "duration", 30, "timeSlot", "Prime Time", "telecastDate", "2025-10-20"));

        // Case 3: APPROVED - Ready for vendor selection
        ProcurementCase case3 = createCase("CASE-DIT-003", "Laptop Procurement FY26",
                deptIT, categoryIT, subCategoryLaptops, CaseStatus.APPROVED, new BigDecimal("12000000"));
        CaseLineItem case3Item1 = createCaseLineItem(case3, productLaptop,
                Map.of("brand", "Dell", "processor", "Intel i7", "ram", 16, "screenSize", "14 inch"));

        // Case 4: VENDOR_SELECTED - Has invoice for scrutiny
        ProcurementCase case4 = createCase("CASE-DOC-004", "Soiled Notes Campaign Q3",
                deptComm, categoryAds, subCategoryPAC, CaseStatus.VENDOR_SELECTED, new BigDecimal("15000000"));
        // Note: Vendor is set at line item level, not case level
        CaseLineItem case4Item1 = createCaseLineItem(case4, productPrint, vendorTOI,
                Map.of("publication", "Times of India Mumbai", "page", "3", "size", 200, "colorType", "Full Color"));
        CaseLineItem case4Item2 = createCaseLineItem(case4, productPrint, vendorTOI,
                Map.of("publication", "Times of India Delhi", "page", "5", "size", 180, "colorType", "Full Color"));
        CaseLineItem case4Item3 = createCaseLineItem(case4, productPrint, vendorTOI,
                Map.of("publication", "Economic Times", "page", "2", "size", 150, "colorType", "B&W"));

        // Case 5: COMPLETED
        ProcurementCase case5 = createCase("CASE-DAD-005", "Office Supplies Q2",
                deptAdmin, categoryAdmin, subCategoryStationery, CaseStatus.COMPLETED, new BigDecimal("500000"));
        // Note: Vendor would be set at line item level in real scenario

        log.info("Created 5 cases at different workflow stages");

        // ===== INVOICE WITH COMPREHENSIVE SCRUTINY SCENARIOS =====
        Invoice invoice = createInvoice(vendorTOI, case4, "INV-TOI-2025-1234",
                LocalDate.now().minusDays(2), new BigDecimal("85000"), new BigDecimal("15300"), new BigDecimal("100300"));

        // Perfect Match - 100% automated approval
        InvoiceLineItem perfectItem = createInvoiceLineItem(invoice, productPrint,
                "TOI Mumbai Main Edition - Page 3", new BigDecimal("35000"),
                Map.of("publication", "Times of India Mumbai", "page", "3", "size", 200, "colorType", "Full Color"));
        perfectItem.setProofCount(2);
        perfectItem.setAutoMatchScore(100);
        perfectItem.setRequiresReview(false);
        perfectItem.setRedFlagCount(0);
        invoiceLineItemRepository.save(perfectItem);
        createProof(perfectItem, "Times of India Mumbai", LocalDate.now().minusDays(3), "Page 3",
                VerificationStatus.VERIFIED, "mumbai_page3.pdf");
        createProof(perfectItem, "Times of India Mumbai", LocalDate.now().minusDays(3), "Page 3",
                VerificationStatus.VERIFIED, "mumbai_page3_closeup.jpg");

        // Tolerance Match - Within acceptable variance (98 sqcm vs 100 sqcm)
        InvoiceLineItem toleranceItem = createInvoiceLineItem(invoice, productPrint,
                "TOI Delhi Edition - Page 5", new BigDecimal("31500"),
                Map.of("publication", "Times of India Delhi", "page", "5", "size", 178, "colorType", "Full Color"));
        toleranceItem.setProofCount(1);
        toleranceItem.setAutoMatchScore(95);
        toleranceItem.setRequiresReview(true);
        toleranceItem.setRedFlagCount(0);
        invoiceLineItemRepository.save(toleranceItem);
        createProof(toleranceItem, "Times of India Delhi", LocalDate.now().minusDays(4), "Page 5",
                VerificationStatus.PENDING, "delhi_page5.pdf");

        // Price Mismatch - Red flag for pricing
        InvoiceLineItem priceItem = createInvoiceLineItem(invoice, productPrint,
                "Economic Times - Page 2", new BigDecimal("28000"),
                Map.of("publication", "Economic Times", "page", "2", "size", 150, "colorType", "B&W"));
        priceItem.setProofCount(1);
        priceItem.setAutoMatchScore(60);
        priceItem.setRequiresReview(true);
        priceItem.setRedFlagCount(1);
        invoiceLineItemRepository.save(priceItem);
        createProof(priceItem, "Economic Times", LocalDate.now().minusDays(5), "Page 2",
                VerificationStatus.FAILED, "et_page2.pdf");

        // Missing Proof - Critical red flag
        InvoiceLineItem noProofItem = createInvoiceLineItem(invoice, productPrint,
                "Hindustan Times - Page 1", new BigDecimal("42000"),
                Map.of("publication", "Hindustan Times", "page", "1", "size", 250, "colorType", "Full Color"));
        noProofItem.setProofCount(0);
        noProofItem.setAutoMatchScore(0);
        noProofItem.setRequiresReview(true);
        noProofItem.setRedFlagCount(2);
        invoiceLineItemRepository.save(noProofItem);

        // Dimension Mismatch - Wrong page number
        InvoiceLineItem dimMismatchItem = createInvoiceLineItem(invoice, productPrint,
                "TOI Mumbai - Page 7 (Case says Page 3)", new BigDecimal("35000"),
                Map.of("publication", "Times of India Mumbai", "page", "7", "size", 200, "colorType", "Full Color"));
        dimMismatchItem.setProofCount(1);
        dimMismatchItem.setAutoMatchScore(40);
        dimMismatchItem.setRequiresReview(true);
        dimMismatchItem.setRedFlagCount(1);
        invoiceLineItemRepository.save(dimMismatchItem);
        createProof(dimMismatchItem, "Times of India Mumbai", LocalDate.now().minusDays(3), "Page 7",
                VerificationStatus.FAILED, "mumbai_page7_notmatched.pdf");

        // Extra Item - Not in case
        InvoiceLineItem extraItem = createInvoiceLineItem(invoice, productPrint,
                "Indian Express - Not in Case", new BigDecimal("38000"),
                Map.of("publication", "Indian Express", "page", "4", "size", 220, "colorType", "Full Color"));
        extraItem.setProofCount(1);
        extraItem.setAutoMatchScore(0);
        extraItem.setRequiresReview(true);
        extraItem.setRedFlagCount(3);
        invoiceLineItemRepository.save(extraItem);
        createProof(extraItem, "Indian Express", LocalDate.now().minusDays(2), "Page 4",
                VerificationStatus.PENDING, "indianexpress_page4.pdf");

        log.info("Created invoice with 6 line items covering all scrutiny scenarios");

        // ===== Additional Cases for Better Demo =====

        // Case for Radio Campaign
        ProcurementCase case6 = createCase("CASE-DOC-006", "FM Radio Campaign - Metro Cities",
                deptComm, categoryAds, subCategoryBrand, CaseStatus.APPROVED, new BigDecimal("3000000"));
        createCaseLineItem(case6, productRadio,
                Map.of("station", "Radio Mirchi", "duration", 30, "frequency", "98.3 FM"));

        // Case for IT Infrastructure
        ProcurementCase case7 = createCase("CASE-DIT-007", "Data Center Server Upgrade",
                deptIT, categoryIT, subCategoryServers, CaseStatus.PENDING_APPROVAL, new BigDecimal("25000000"));
        createCaseLineItem(case7, productServer,
                Map.of("brand", "Dell PowerEdge", "cores", 64, "ram", 512, "storage", 20));

        log.info("=== Sample Data Loading Complete ===");
        log.info("Departments: 3 | Categories: 3 | Products: 7 | Vendors: 7 | Cases: 7 | Invoices: 1");
        log.info("System ready for comprehensive demo across all user roles!");
    }

    // ===== HELPER METHODS =====

    private String toJson(Object obj) throws JsonProcessingException {
        return objectMapper.writeValueAsString(obj);
    }

    private DepartmentMaster createDepartment(String code, String name, BigDecimal budget, String hod) {
        return departmentRepository.save(DepartmentMaster.builder()
                .departmentCode(code)
                .departmentName(name)
                .annualBudget(budget)
                .headOfDepartment(hod)
                .isActive(true)
                .build());
    }

    private ProductCategory createCategory(String code, String name, String desc, DepartmentMaster dept) {
        return categoryRepository.save(ProductCategory.builder()
                .categoryCode(code)
                .categoryName(name)
                .description(desc)
                .department(dept)
                .isActive(true)
                .build());
    }

    private SubCategory createSubCategory(String code, String name, String desc, ProductCategory category) {
        return subCategoryRepository.save(SubCategory.builder()
                .subCategoryCode(code)
                .subCategoryName(name)
                .description(desc)
                .category(category)
                .isActive(true)
                .build());
    }

    private ProductMaster createProduct(String code, String name, String desc, SubCategory subCategory,
                                        String hsnCode, boolean hasCeiling, BigDecimal ceilingRate) {
        return productRepository.save(ProductMaster.builder()
                .productCode(code)
                .productName(name)
                .description(desc)
                .subCategory(subCategory)
                .hsnSacCode(hsnCode)
                .hasCeilingRate(hasCeiling)
                .ceilingRate(ceilingRate)
                .isActive(true)
                .build());
    }

    private void createDimension(ProductMaster product, String name, String key, DimensionDataType dataType,
                                 DimensionUIComponent uiComponent, boolean mandatory, String help,
                                 Double min, Double max, boolean usedInPricing, int order) {
        dimensionRepository.save(DimensionTemplate.builder()
                .product(product)
                .dimensionName(name)
                .dimensionKey(key)
                .dataType(dataType)
                .uiComponent(uiComponent)
                .isMandatory(mandatory)
                .minValue(min)
                .maxValue(max)
                .helpText(help)
                .usedInPricing(usedInPricing)
                .displayOrder(order)
                .build());
    }

    private VendorMaster createVendor(String code, String name, String gstin, String state, String email) {
        return vendorRepository.save(VendorMaster.builder()
                .vendorCode(code)
                .vendorName(name)
                .gstin(gstin)
                .pan(gstin.substring(2, 12))
                .state(state)
                .email(email)
                .vendorStatus(VendorStatus.ACTIVE)
                .isActive(true)
                .build());
    }

    private void mapVendorToProduct(VendorMaster vendor, ProductMaster product) {
        vendorMappingRepository.save(ProductVendorMapping.builder()
                .product(product)
                .vendor(vendor)
                .isActive(true)
                .build());
    }

    private void createRateMatrix(ProductMaster product, String rateName,
                                  BigDecimal minRate, BigDecimal maxRate,
                                  String applicableConditions, String pricingFormula) {
        rateMatrixRepository.save(RateMatrix.builder()
                .product(product)
                .rateName(rateName)
                .minRate(minRate)
                .maxRate(maxRate)
                .pricingFormula(pricingFormula)
                .isActive(true)
                .build());
    }

    private ProcurementCase createCase(String caseNum, String name, DepartmentMaster dept,
                                       ProductCategory cat, SubCategory subCat, CaseStatus status,
                                       BigDecimal budget) {
        return caseRepository.save(ProcurementCase.builder()
                .caseNumber(caseNum)
                .caseName(name)
                .department(dept)
                .category(cat)
                .subCategory(subCat)
                .totalApprovedBudget(budget)
                .caseStatus(status)
                .requiresBidding(false)
                .build());
    }

    private CaseLineItem createCaseLineItem(ProcurementCase pCase, ProductMaster product,
                                            VendorMaster vendor, Map<String, Object> dims) throws JsonProcessingException {
        return caseLineItemRepository.save(CaseLineItem.builder()
                .procurementCase(pCase)
                .product(product)
                .selectedVendor(vendor)
                .dimensionValues(toJson(dims))
                .totalAmount(new BigDecimal("50000"))
                .build());
    }

    // Overloaded method for backward compatibility (when vendor not yet selected)
    private CaseLineItem createCaseLineItem(ProcurementCase pCase, ProductMaster product,
                                            Map<String, Object> dims) throws JsonProcessingException {
        return caseLineItemRepository.save(CaseLineItem.builder()
                .procurementCase(pCase)
                .product(product)
                .dimensionValues(toJson(dims))
                .totalAmount(new BigDecimal("50000"))
                .build());
    }

    private Invoice createInvoice(VendorMaster vendor, ProcurementCase pCase, String invNum,
                                  LocalDate invDate, BigDecimal taxable, BigDecimal gst, BigDecimal total) {
        return invoiceRepository.save(Invoice.builder()
                .invoiceNumber(invNum)
                .vendor(vendor)
                .procurementCase(pCase)
                .invoiceDate(invDate)
                .taxableAmount(taxable)
                .totalGstAmount(gst)
                .totalInvoiceAmount(total)
                .invoiceStatus(InvoiceStatus.PENDING_APPROVAL)
                .vendorGstin(vendor.getGstin())
                .placeOfSupply(vendor.getState())
                .build());
    }

    private InvoiceLineItem createInvoiceLineItem(Invoice invoice, ProductMaster product, String desc,
                                                  BigDecimal value, Map<String, Object> dims)
            throws JsonProcessingException {
        return invoiceLineItemRepository.save(InvoiceLineItem.builder()
                .invoice(invoice)
                .product(product)
                .itemDescription(desc)
                .taxableValue(value)
                .dimensionValues(toJson(dims))
                .build());
    }

    private void createProof(InvoiceLineItem item, String pubName, LocalDate pubDate, String page,
                             VerificationStatus status, String fileName) {
        invoiceLineItemProofRepository.save(InvoiceLineItemProof.builder()
                .lineItem(item)
                .proofType(ProofType.IMAGE)
                .fileName(fileName)
                .verificationStatus(status)
                .publicationName(pubName)
                .publicationDate(pubDate)
                .publicationPage(page)
                .city(pubName.contains("Mumbai") ? "Mumbai" : pubName.contains("Delhi") ? "Delhi" : "Other")
                .state("Maharashtra")
                .requiresManualReview(status == VerificationStatus.FAILED)
                .build());
    }
}