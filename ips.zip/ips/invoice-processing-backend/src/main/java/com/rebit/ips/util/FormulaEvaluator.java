package com.rebit.ips.util;

import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

@Component
public class FormulaEvaluator {

    private final ExpressionParser parser = new SpelExpressionParser();

    public BigDecimal evaluate(String formula, Map<String, Object> variables) {
        try {
            StandardEvaluationContext context = new StandardEvaluationContext();

            // Register all variables
            for (Map.Entry<String, Object> entry : variables.entrySet()) {
                Object value = entry.getValue();
                if (value instanceof Number) {
                    context.setVariable(entry.getKey(), ((Number) value).doubleValue());
                } else if (value instanceof String) {
                    context.setVariable(entry.getKey(), Double.parseDouble((String) value));
                }
            }

            // Replace dimension keys with variable syntax
            String processedFormula = formula;
            for (String key : variables.keySet()) {
                processedFormula = processedFormula.replaceAll("\\b" + key + "\\b", "#" + key);
            }

            Object result = parser.parseExpression(processedFormula).getValue(context);

            if (result instanceof Number) {
                return BigDecimal.valueOf(((Number) result).doubleValue());
            }

            throw new IllegalArgumentException("Formula did not evaluate to a number");

        } catch (Exception e) {
            throw new IllegalArgumentException("Error evaluating formula: " + formula, e);
        }
    }

    public boolean validateFormula(String formula, Map<String, Object> testVariables) {
        try {
            evaluate(formula, testVariables);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
