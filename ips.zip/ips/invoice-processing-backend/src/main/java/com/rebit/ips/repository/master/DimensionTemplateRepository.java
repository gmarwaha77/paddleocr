package com.rebit.ips.repository.master;

import com.rebit.ips.entity.master.DimensionTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DimensionTemplateRepository extends JpaRepository<DimensionTemplate, Long> {
    List<DimensionTemplate> findByProductIdOrderByDisplayOrderAsc(Long productId);
    List<DimensionTemplate> findByProductIdAndUsedInPricingTrue(Long productId);
}
