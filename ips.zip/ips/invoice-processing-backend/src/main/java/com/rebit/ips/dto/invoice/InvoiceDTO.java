package com.rebit.ips.dto.invoice;

import com.rebit.ips.enums.InvoiceStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceDTO {
    private Long id;
    private String invoiceNumber;
    @NotNull
    private Long vendorId;
    private String vendorName;
    private String vendorGstin;
    private Long caseId;
    private String caseNumber;
    private LocalDate invoiceDate;
    private LocalDate dueDate;
    private String placeOfSupply;
    private Boolean isInterState;
    private BigDecimal taxableAmount;
    private BigDecimal cgstAmount;
    private BigDecimal sgstAmount;
    private BigDecimal igstAmount;
    private BigDecimal totalGstAmount;
    private BigDecimal totalInvoiceAmount;
    private InvoiceStatus invoiceStatus;
    private String uploadedFilePath;
    private LocalDateTime parsedAt;
    private LocalDateTime validatedAt;
    private LocalDateTime approvedAt;
    private String approvedBy;
    private String rejectionReason;
    private List<InvoiceLineItemDTO> lineItems;
}
