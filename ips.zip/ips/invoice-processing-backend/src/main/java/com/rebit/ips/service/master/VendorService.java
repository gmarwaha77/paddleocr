package com.rebit.ips.service.master;

import com.rebit.ips.dto.master.VendorMasterDTO;
import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.repository.master.VendorMasterRepository;
import com.rebit.ips.util.GSTCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class VendorService {

    private final VendorMasterRepository vendorRepository;
    private final GSTCalculator gstCalculator;

    public List<VendorMasterDTO> getAllVendors() {
        return vendorRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<VendorMasterDTO> getActiveVendors() {
        return vendorRepository.findByIsActiveTrue().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<VendorMasterDTO> getVendorsByProduct(Long productId) {
        return vendorRepository.findActiveVendorsByProductId(productId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public VendorMasterDTO getVendorById(Long id) {
        return vendorRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("Vendor not found"));
    }

    public VendorMasterDTO createVendor(VendorMasterDTO dto) {
        if (!gstCalculator.validateGSTIN(dto.getGstin())) {
            throw new RuntimeException("Invalid GSTIN format");
        }

        if (vendorRepository.findByGstin(dto.getGstin()).isPresent()) {
            throw new RuntimeException("Vendor with this GSTIN already exists");
        }

        VendorMaster vendor = convertToEntity(dto);
        vendor = vendorRepository.save(vendor);
        return convertToDTO(vendor);
    }

    public VendorMasterDTO updateVendor(Long id, VendorMasterDTO dto) {
        VendorMaster vendor = vendorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vendor not found"));

        vendor.setVendorName(dto.getVendorName());
        vendor.setContactPerson(dto.getContactPerson());
        vendor.setEmail(dto.getEmail());
        vendor.setPhone(dto.getPhone());
        vendor.setAddress(dto.getAddress());
        vendor.setCity(dto.getCity());
        vendor.setState(dto.getState());
        vendor.setPincode(dto.getPincode());
        vendor.setBankName(dto.getBankName());
        vendor.setAccountNumber(dto.getAccountNumber());
        vendor.setIfscCode(dto.getIfscCode());
        vendor.setVendorStatus(dto.getVendorStatus());
        vendor.setIsActive(dto.getIsActive());

        vendor = vendorRepository.save(vendor);
        return convertToDTO(vendor);
    }

    private VendorMasterDTO convertToDTO(VendorMaster entity) {
        return VendorMasterDTO.builder()
                .id(entity.getId())
                .vendorCode(entity.getVendorCode())
                .vendorName(entity.getVendorName())
                .gstin(entity.getGstin())
                .pan(entity.getPan())
                .contactPerson(entity.getContactPerson())
                .email(entity.getEmail())
                .phone(entity.getPhone())
                .address(entity.getAddress())
                .city(entity.getCity())
                .state(entity.getState())
                .pincode(entity.getPincode())
                .bankName(entity.getBankName())
                .accountNumber(entity.getAccountNumber())
                .ifscCode(entity.getIfscCode())
                .vendorStatus(entity.getVendorStatus())
                .empanelmentDate(entity.getEmpanelmentDate())
                .empanelmentExpiryDate(entity.getEmpanelmentExpiryDate())
                .isActive(entity.getIsActive())
                .build();
    }

    private VendorMaster convertToEntity(VendorMasterDTO dto) {
        return VendorMaster.builder()
                .vendorCode(dto.getVendorCode())
                .vendorName(dto.getVendorName())
                .gstin(dto.getGstin())
                .pan(dto.getPan())
                .contactPerson(dto.getContactPerson())
                .email(dto.getEmail())
                .phone(dto.getPhone())
                .address(dto.getAddress())
                .city(dto.getCity())
                .state(dto.getState())
                .pincode(dto.getPincode())
                .bankName(dto.getBankName())
                .accountNumber(dto.getAccountNumber())
                .ifscCode(dto.getIfscCode())
                .vendorStatus(dto.getVendorStatus())
                .empanelmentDate(dto.getEmpanelmentDate())
                .empanelmentExpiryDate(dto.getEmpanelmentExpiryDate())
                .build();
    }
}
