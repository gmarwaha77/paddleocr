package com.rebit.ips.service.invoice;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.dto.invoice.*;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.invoice.Invoice;
import com.rebit.ips.entity.invoice.InvoiceLineItem;
import com.rebit.ips.entity.invoice.InvoiceLineItemProof;
import com.rebit.ips.enums.VerificationStatus;
import com.rebit.ips.repository.cases.CaseLineItemRepository;
import com.rebit.ips.repository.invoice.InvoiceLineItemProofRepository;
import com.rebit.ips.repository.invoice.InvoiceLineItemRepository;
import com.rebit.ips.repository.invoice.InvoiceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ProofManagementService {

    private final InvoiceLineItemProofRepository proofRepository;
    private final InvoiceLineItemRepository lineItemRepository;
    private final InvoiceRepository invoiceRepository;
    private final CaseLineItemRepository caseLineItemRepository;
    private final DimensionMatchingService dimensionMatchingService;
    private final ObjectMapper objectMapper;

    private static final String UPLOAD_DIR = "./uploads/proofs/";

    /**
     * Upload proof document for a line item
     */
    public ProofUploadResponseDTO uploadProof(
            MultipartFile file,
            Long lineItemId,
            ProofMetadataDTO metadata
    ) {
        InvoiceLineItem lineItem = lineItemRepository.findById(lineItemId)
                .orElseThrow(() -> new RuntimeException("Line item not found"));

        try {
            // Save file
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path uploadPath = Paths.get(UPLOAD_DIR);

            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(fileName);
            Files.write(filePath, file.getBytes());

            // Create proof entity
            InvoiceLineItemProof proof = InvoiceLineItemProof.builder()
                    .lineItem(lineItem)
                    .proofType(metadata.getProofType())
                    .filePath(filePath.toString())
                    .fileName(file.getOriginalFilename())
                    .fileSize(file.getSize())
                    .contentType(file.getContentType())
                    .publicationName(metadata.getPublicationName())
                    .publicationDate(metadata.getPublicationDate())
                    .publicationPage(metadata.getPublicationPage())
                    .state(metadata.getState())
                    .city(metadata.getCity())
                    .language(metadata.getLanguage())
                    .verificationStatus(VerificationStatus.PENDING)
                    .requiresManualReview(true)
                    .build();

            proof = proofRepository.save(proof);

            // Update line item proof count
            lineItem.setProofCount((lineItem.getProofCount() != null ? lineItem.getProofCount() : 0) + 1);
            lineItemRepository.save(lineItem);

            log.info("Proof uploaded successfully for line item {}: {}", lineItemId, fileName);

            return ProofUploadResponseDTO.builder()
                    .proofId(proof.getId())
                    .fileName(proof.getFileName())
                    .uploadSuccess(true)
                    .message("Proof uploaded successfully")
                    .build();

        } catch (IOException e) {
            log.error("Error uploading proof", e);
            throw new RuntimeException("Failed to upload proof: " + e.getMessage());
        }
    }

    /**
     * Get all proofs for a line item
     */
    public List<ProofDTO> getProofsByLineItem(Long lineItemId) {
        return proofRepository.findByLineItemId(lineItemId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Auto-verify proofs using dimension matching
     */
    public void autoVerifyProofs(Long invoiceId) {
        Invoice invoice = invoiceRepository.findByIdWithLineItems(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        if (invoice.getProcurementCase() == null) {
            log.warn("Invoice {} not linked to a case, skipping auto-verification", invoiceId);
            return;
        }

        List<CaseLineItem> caseLineItems = caseLineItemRepository
                .findByProcurementCaseId(invoice.getProcurementCase().getId());

        for (InvoiceLineItem invoiceLineItem : invoice.getLineItems()) {
            // Find corresponding case line item
            Optional<CaseLineItem> matchingCaseItem = findMatchingCaseItem(
                    invoiceLineItem,
                    caseLineItems
            );

            if (matchingCaseItem.isPresent()) {
                // Perform dimension matching
                DimensionMatchResultDTO matchResult = dimensionMatchingService
                        .matchDimensions(matchingCaseItem.get(), invoiceLineItem);

                // Update line item with match results
                invoiceLineItem.setAutoMatchScore(matchResult.getMatchPercentage().intValue());

                try {
                    invoiceLineItem.setDimensionMatchResult(
                            objectMapper.writeValueAsString(matchResult)
                    );
                } catch (Exception e) {
                    log.error("Error serializing match result", e);
                }

                // Auto-verify proofs if match score is high
                if (matchResult.getMatchPercentage() >= 80) {
                    List<InvoiceLineItemProof> proofs = proofRepository
                            .findByLineItemId(invoiceLineItem.getId());

                    for (InvoiceLineItemProof proof : proofs) {
                        if (proof.getVerificationStatus() == VerificationStatus.PENDING) {
                            proof.setVerificationStatus(VerificationStatus.AUTO_VERIFIED);
                            proof.setAutoMatchScore(matchResult.getMatchPercentage().intValue());
                            proof.setRequiresManualReview(false);
                            proof.setVerifiedAt(LocalDateTime.now());
                            proof.setVerifiedBy("SYSTEM");
                            proofRepository.save(proof);
                        }
                    }

                    invoiceLineItem.setIsValidated(true);
                } else {
                    // Mark for manual review
                    List<InvoiceLineItemProof> proofs = proofRepository
                            .findByLineItemId(invoiceLineItem.getId());

                    for (InvoiceLineItemProof proof : proofs) {
                        proof.setRequiresManualReview(true);
                        proof.setAutoMatchScore(matchResult.getMatchPercentage().intValue());
                        proofRepository.save(proof);
                    }
                }

                lineItemRepository.save(invoiceLineItem);
            }
        }

        log.info("Auto-verification completed for invoice {}", invoiceId);
    }

    /**
     * Get scrutiny summary for an invoice
     */
    public ScrutinySummaryDTO getScrutinySummary(Long invoiceId) {
        Invoice invoice = invoiceRepository.findByIdWithLineItems(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        List<InvoiceLineItem> lineItems = invoice.getLineItems();

        int perfectMatches = (int) lineItems.stream()
                .filter(item -> item.getAutoMatchScore() != null && item.getAutoMatchScore() >= 80)
                .count();

        int toleranceMatches = (int) lineItems.stream()
                .filter(item -> item.getAutoMatchScore() != null &&
                        item.getAutoMatchScore() >= 50 &&
                        item.getAutoMatchScore() < 80)
                .count();

        int mismatches = (int) lineItems.stream()
                .filter(item -> item.getAutoMatchScore() != null && item.getAutoMatchScore() < 50)
                .count();

        int missingProofs = (int) lineItems.stream()
                .filter(item -> item.getProofCount() == null || item.getProofCount() == 0)
                .count();

        int redFlags = (int) lineItems.stream()
                .filter(item -> item.getRedFlagCount() != null && item.getRedFlagCount() > 0)
                .count();

        int reviewed = (int) lineItems.stream()
                .filter(item -> item.getIsValidated() != null && item.getIsValidated())
                .count();

        double progress = (reviewed * 100.0) / lineItems.size();

        // Estimate time saved: assume 5 min per item manual review
        // With 90% automation, only review 10%
        double timeSaved = (lineItems.size() * 5.0 / 60.0) * 0.9; // hours

        return ScrutinySummaryDTO.builder()
                .invoiceId(invoiceId)
                .invoiceNumber(invoice.getInvoiceNumber())
                .vendorName(invoice.getVendor().getVendorName())
                .totalLineItems(lineItems.size())
                .perfectMatches(perfectMatches)
                .toleranceMatches(toleranceMatches)
                .mismatches(mismatches)
                .missingProofs(missingProofs)
                .redFlags(redFlags)
                .overallProgress((int) progress)
                .timeSaved((int) timeSaved)
                .build();
    }

    /**
     * Get line items requiring review (exceptions only)
     */
    public List<LineItemReviewDTO> getLineItemsRequiringReview(Long invoiceId) {
        Invoice invoice = invoiceRepository.findByIdWithLineItems(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        return invoice.getLineItems().stream()
                .filter(item -> requiresReview(item))
                .map(this::convertToReviewDTO)
                .collect(Collectors.toList());
    }

    /**
     * Bulk approve items by dimension signature
     */
    public void bulkApproveBySignature(String dimensionSignature, Long invoiceId) {
        Invoice invoice = invoiceRepository.findByIdWithLineItems(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        for (InvoiceLineItem item : invoice.getLineItems()) {
            try {
                Map<String, Object> dimensions = objectMapper.readValue(
                        item.getDimensionValues(),
                        Map.class
                );

                String itemSignature = dimensionMatchingService
                        .generateDimensionSignature(dimensions);

                if (itemSignature.equals(dimensionSignature)) {
                    item.setIsValidated(true);
                    lineItemRepository.save(item);

                    // Auto-approve all proofs
                    List<InvoiceLineItemProof> proofs = proofRepository
                            .findByLineItemId(item.getId());
                    for (InvoiceLineItemProof proof : proofs) {
                        proof.setVerificationStatus(VerificationStatus.VERIFIED);
                        proof.setVerifiedBy("BULK_APPROVAL");
                        proof.setVerifiedAt(LocalDateTime.now());
                        proofRepository.save(proof);
                    }
                }
            } catch (Exception e) {
                log.error("Error in bulk approval", e);
            }
        }

        log.info("Bulk approval completed for signature: {}", dimensionSignature);
    }

    // Helper methods

    private boolean requiresReview(InvoiceLineItem item) {
        return (item.getAutoMatchScore() == null || item.getAutoMatchScore() < 80) ||
                (item.getProofCount() == null || item.getProofCount() == 0) ||
                (item.getRedFlagCount() != null && item.getRedFlagCount() > 0);
    }

    private Optional<CaseLineItem> findMatchingCaseItem(
            InvoiceLineItem invoiceItem,
            List<CaseLineItem> caseItems
    ) {
        // Match by product and order
        return caseItems.stream()
                .filter(ci -> ci.getProduct().getId().equals(invoiceItem.getProduct().getId()))
                .findFirst();
    }

    private ProofDTO convertToDTO(InvoiceLineItemProof entity) {
        return ProofDTO.builder()
                .id(entity.getId())
                .lineItemId(entity.getLineItem().getId())
                .fileName(entity.getFileName())
                .fileSize(entity.getFileSize())
                .contentType(entity.getContentType())
                .publicationName(entity.getPublicationName())
                .publicationDate(entity.getPublicationDate())
                .verificationStatus(entity.getVerificationStatus())
                .autoMatchScore(entity.getAutoMatchScore())
                .requiresManualReview(entity.getRequiresManualReview())
                .build();
    }

    private LineItemReviewDTO convertToReviewDTO(InvoiceLineItem entity) {
        // Parse dimension match result
        DimensionMatchResultDTO matchResult = null;
        try {
            if (entity.getDimensionMatchResult() != null) {
                matchResult = objectMapper.readValue(
                        entity.getDimensionMatchResult(),
                        DimensionMatchResultDTO.class
                );
            }
        } catch (Exception e) {
            log.error("Error parsing match result", e);
        }

        List<ProofDTO> proofs = getProofsByLineItem(entity.getId());

        return LineItemReviewDTO.builder()
                .id(entity.getId())
                .itemDescription(entity.getItemDescription())
                .matchScore(entity.getAutoMatchScore() != null ? entity.getAutoMatchScore() : 0)
                .matchResult(matchResult)
                .proofCount(entity.getProofCount() != null ? entity.getProofCount() : 0)
                .proofs(proofs)
                .requiresReview(requiresReview(entity))
                .build();
    }
}