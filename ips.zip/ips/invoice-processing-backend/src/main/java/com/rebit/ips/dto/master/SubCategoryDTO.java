package com.rebit.ips.dto.master;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubCategoryDTO {
    private Long id;
    @NotBlank
    private String subCategoryCode;
    @NotBlank
    private String subCategoryName;
    private String description;
    private Long categoryId;
    private String categoryName;
    private Boolean isActive;
}
