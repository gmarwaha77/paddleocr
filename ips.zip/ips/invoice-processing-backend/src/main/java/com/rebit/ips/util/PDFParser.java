package com.rebit.ips.util;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class PDFParser {

    public Map<String, Object> parseInvoice(File pdfFile) throws IOException {
        Map<String, Object> invoiceData = new HashMap<>();

        try (PDDocument document = Loader.loadPDF(pdfFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            String text = stripper.getText(document);

            // Extract invoice number
            invoiceData.put("invoiceNumber", extractInvoiceNumber(text));

            // Extract dates
            invoiceData.put("invoiceDate", extractInvoiceDate(text));

            // Extract GSTIN
            invoiceData.put("gstin", extractGSTIN(text));

            // Extract amounts
            invoiceData.put("taxableAmount", extractAmount(text, "Taxable Amount|Taxable Value"));
            invoiceData.put("cgst", extractAmount(text, "CGST"));
            invoiceData.put("sgst", extractAmount(text, "SGST"));
            invoiceData.put("igst", extractAmount(text, "IGST"));
            invoiceData.put("totalAmount", extractAmount(text, "Total|Grand Total|Invoice Total"));

            // Extract place of supply
            invoiceData.put("placeOfSupply", extractPlaceOfSupply(text));

            // Extract line items
            invoiceData.put("lineItems", extractLineItems(text));
        }

        return invoiceData;
    }

    private String extractInvoiceNumber(String text) {
        Pattern pattern = Pattern.compile("Invoice\\s*(?:No|Number|#)?\\s*:?\\s*([A-Z0-9/-]+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        return "UNKNOWN";
    }

    private LocalDate extractInvoiceDate(String text) {
        Pattern pattern = Pattern.compile("(?:Invoice\\s*)?Date\\s*:?\\s*(\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4})", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            String dateStr = matcher.group(1);
            try {
                // Try different date formats
                DateTimeFormatter[] formatters = {
                        DateTimeFormatter.ofPattern("dd/MM/yyyy"),
                        DateTimeFormatter.ofPattern("dd-MM-yyyy"),
                        DateTimeFormatter.ofPattern("dd/MM/yy"),
                        DateTimeFormatter.ofPattern("dd-MM-yy")
                };

                for (DateTimeFormatter formatter : formatters) {
                    try {
                        return LocalDate.parse(dateStr.replace("-", "/"), formatter);
                    } catch (Exception e) {
                        // Try next format
                    }
                }
            } catch (Exception e) {
                // Return current date if parsing fails
            }
        }
        return LocalDate.now();
    }

    private String extractGSTIN(String text) {
        Pattern pattern = Pattern.compile("GSTIN?\\s*:?\\s*([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1})", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1).toUpperCase();
        }
        return null;
    }

    private BigDecimal extractAmount(String text, String label) {
        Pattern pattern = Pattern.compile(label + "\\s*:?\\s*(?:Rs\\.?|INR)?\\s*([0-9,]+\\.?[0-9]*)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            String amountStr = matcher.group(1).replace(",", "");
            try {
                return new BigDecimal(amountStr);
            } catch (NumberFormatException e) {
                return BigDecimal.ZERO;
            }
        }
        return BigDecimal.ZERO;
    }

    private String extractPlaceOfSupply(String text) {
        Pattern pattern = Pattern.compile("Place\\s*of\\s*Supply\\s*:?\\s*([A-Za-z\\s]+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        return "Unknown";
    }

    private List<Map<String, Object>> extractLineItems(String text) {
        List<Map<String, Object>> items = new ArrayList<>();

        // Simple line item extraction - can be enhanced
        Pattern pattern = Pattern.compile("(\\d+)\\s+([A-Za-z\\s]+)\\s+([0-9.]+)\\s+([0-9,]+\\.?[0-9]*)");
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            Map<String, Object> item = new HashMap<>();
            item.put("serialNumber", matcher.group(1));
            item.put("description", matcher.group(2).trim());
            item.put("quantity", new BigDecimal(matcher.group(3)));
            item.put("amount", new BigDecimal(matcher.group(4).replace(",", "")));
            items.add(item);
        }

        return items;
    }
}
