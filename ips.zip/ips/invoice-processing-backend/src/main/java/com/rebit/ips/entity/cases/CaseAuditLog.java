package com.rebit.ips.entity.cases;

import com.rebit.ips.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@Table(name = "case_audit_log", indexes = {
        @Index(name = "idx_audit_case", columnList = "case_id"),
        @Index(name = "idx_audit_timestamp", columnList = "action_timestamp")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class CaseAuditLog extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private ProcurementCase procurementCase;

    @Column(name = "action", length = 100)
    private String action;

    @Column(name = "action_by", length = 50)
    private String actionBy;

    @Column(name = "action_timestamp")
    private LocalDateTime actionTimestamp;

    @Column(name = "old_status", length = 20)
    private String oldStatus;

    @Column(name = "new_status", length = 20)
    private String newStatus;

    @Column(name = "comments", length = 2000)
    private String comments;

    @Column(name = "ip_address", length = 50)
    private String ipAddress;
}
