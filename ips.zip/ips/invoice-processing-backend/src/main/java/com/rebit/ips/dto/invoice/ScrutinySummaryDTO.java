package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * DTO for Invoice Scrutiny Summary
 * Contains AI-powered analysis results
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScrutinySummaryDTO {
    private Long invoiceId;
    private String invoiceNumber;
    private String vendorName;

    // Counts
    private Integer totalLineItems;
    private Integer perfectMatches;
    private Integer toleranceMatches;
    private Integer mismatches;
    private Integer missingProofs;
    private Integer redFlags;

    // Metrics
    private Integer overallProgress; // 0-100
    private Integer timeSaved; // in minutes
    private Integer automationRate; // percentage

    // Computed fields for frontend
    public Integer getProcessedItems() {
        return perfectMatches + toleranceMatches + mismatches;
    }

    public Integer getOverallConfidence() {
        if (totalLineItems == 0) return 0;
        return (perfectMatches * 100 + toleranceMatches * 90) / (totalLineItems * 100) * 100;
    }
}