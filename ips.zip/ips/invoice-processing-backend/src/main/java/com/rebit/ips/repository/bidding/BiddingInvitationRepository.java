package com.rebit.ips.repository.bidding;

import com.rebit.ips.entity.bidding.BiddingInvitation;
import com.rebit.ips.enums.InvitationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BiddingInvitationRepository extends JpaRepository<BiddingInvitation, Long> {
    List<BiddingInvitation> findByProcurementCaseId(Long caseId);
    List<BiddingInvitation> findByVendorId(Long vendorId);
    List<BiddingInvitation> findByInvitationStatus(InvitationStatus status);
}

