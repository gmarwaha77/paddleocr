package com.rebit.ips.controller;

import lombok.Data;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {

    @GetMapping("/current-user")
    public Map<String, Object> getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        Map<String, Object> response = new HashMap<>();
        response.put("username", authentication.getName());
        response.put("roles", authentication.getAuthorities());
        response.put("authenticated", authentication.isAuthenticated());

        return response;
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody LoginRequest request) {
        // Basic auth handles actual login, this is just for documentation
        Map<String, String> response = new HashMap<>();
        response.put("message", "Use Basic Authentication with username and password");
        return response;
    }

    @Data
    static class LoginRequest {
        private String username;
        private String password;
    }
}
