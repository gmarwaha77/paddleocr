package com.rebit.ips.dto.cases;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseLineItemDTO {
    private Long id;
    private Long caseId;
    private Long productId;
    private String productName;
    private Map<String, Object> dimensionValues;
    private BigDecimal ceilingAmount;
    private BigDecimal additionalBudgetAmount;
    private BigDecimal totalAmount;
    private BigDecimal calculatedPrice;
    private Long selectedVendorId;
    private String selectedVendorName;
    private String comments;
    private Integer itemOrder;
}
