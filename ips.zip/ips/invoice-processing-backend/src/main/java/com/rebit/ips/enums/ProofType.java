package com.rebit.ips.enums;

public enum ProofType {
    IMAGE,           // Scanned newspaper ad, photo proof
    PDF,             // PDF documents
    URL,             // Online publication link
    VIDEO,           // TV/Radio recordings
    TIMESTAMP,       // Digital timestamp proof
    AFFIDAVIT,       // Sworn statement
    CERTIFICATE      // Publication certificate
}