package com.rebit.ips.service.invoice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.dto.GSTCalculationResult;
import com.rebit.ips.dto.invoice.InvoiceApprovalDTO;
import com.rebit.ips.dto.invoice.InvoiceDTO;
import com.rebit.ips.dto.invoice.InvoiceLineItemDTO;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.invoice.Invoice;
import com.rebit.ips.entity.invoice.InvoiceLineItem;
import com.rebit.ips.entity.master.ProductMaster;
import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.enums.InvoiceStatus;
import com.rebit.ips.repository.cases.ProcurementCaseRepository;
import com.rebit.ips.repository.invoice.InvoiceLineItemRepository;
import com.rebit.ips.repository.invoice.InvoiceRepository;
import com.rebit.ips.repository.master.ProductMasterRepository;
import com.rebit.ips.repository.master.VendorMasterRepository;
import com.rebit.ips.service.FileStorageService;
import com.rebit.ips.service.NotificationService;
import com.rebit.ips.util.GSTCalculator;
import com.rebit.ips.util.PDFParser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceLineItemRepository lineItemRepository;
    private final VendorMasterRepository vendorRepository;
    private final ProcurementCaseRepository caseRepository;
    private final ProductMasterRepository productRepository;
    private final FileStorageService fileStorageService;
    private final PDFParser pdfParser;
    private final GSTCalculator gstCalculator;
    private final NotificationService notificationService;
    private final ObjectMapper objectMapper;

    public List<InvoiceDTO> getAllInvoices() {
        return invoiceRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<InvoiceDTO> getInvoicesByVendor(Long vendorId) {
        return invoiceRepository.findByVendorId(vendorId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<InvoiceDTO> getInvoicesByCase(Long caseId) {
        return invoiceRepository.findByProcurementCaseId(caseId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<InvoiceDTO> getInvoicesByStatus(InvoiceStatus status) {
        return invoiceRepository.findByInvoiceStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public InvoiceDTO getInvoiceById(Long id) {
        return invoiceRepository.findByIdWithLineItems(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));
    }

    public InvoiceDTO uploadInvoice(Long vendorId, Long caseId, MultipartFile file) {
        VendorMaster vendor = vendorRepository.findById(vendorId)
                .orElseThrow(() -> new RuntimeException("Vendor not found"));

        ProcurementCase procurementCase = caseId != null
                ? caseRepository.findById(caseId).orElse(null)
                : null;

        try {
            // Store file
            String caseNumber = procurementCase != null
                    ? procurementCase.getCaseNumber()
                    : "GENERAL_" + System.currentTimeMillis();
            String filePath = fileStorageService.storeFile(file, caseNumber);

            // Create invoice
            Invoice invoice = Invoice.builder()
                    .vendor(vendor)
                    .procurementCase(procurementCase)
                    .vendorGstin(vendor.getGstin())
                    .uploadedFilePath(filePath)
                    .invoiceStatus(InvoiceStatus.UPLOADED)
                    .build();

            invoice = invoiceRepository.save(invoice);

            log.info("Invoice uploaded successfully: {}", invoice.getId());

            return convertToDTO(invoice);

        } catch (Exception e) {
            log.error("Error uploading invoice", e);
            throw new RuntimeException("Failed to upload invoice: " + e.getMessage());
        }
    }

    public InvoiceDTO parseInvoice(Long invoiceId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        if (invoice.getInvoiceStatus() != InvoiceStatus.UPLOADED) {
            throw new RuntimeException("Invoice must be in UPLOADED status to parse");
        }

        try {
            // Get file
            File pdfFile = fileStorageService.getFile(invoice.getUploadedFilePath());

            // Parse PDF
            Map<String, Object> parsedData = pdfParser.parseInvoice(pdfFile);

            // Update invoice with parsed data
            invoice.setInvoiceNumber((String) parsedData.get("invoiceNumber"));
            invoice.setInvoiceDate((java.time.LocalDate) parsedData.get("invoiceDate"));
            invoice.setPlaceOfSupply((String) parsedData.get("placeOfSupply"));

            BigDecimal taxableAmount = (BigDecimal) parsedData.getOrDefault("taxableAmount", BigDecimal.ZERO);
            BigDecimal cgst = (BigDecimal) parsedData.getOrDefault("cgst", BigDecimal.ZERO);
            BigDecimal sgst = (BigDecimal) parsedData.getOrDefault("sgst", BigDecimal.ZERO);
            BigDecimal igst = (BigDecimal) parsedData.getOrDefault("igst", BigDecimal.ZERO);
            BigDecimal totalAmount = (BigDecimal) parsedData.getOrDefault("totalAmount", BigDecimal.ZERO);

            invoice.setTaxableAmount(taxableAmount);
            invoice.setCgstAmount(cgst);
            invoice.setSgstAmount(sgst);
            invoice.setIgstAmount(igst);
            invoice.setTotalGstAmount(cgst.add(sgst).add(igst));
            invoice.setTotalInvoiceAmount(totalAmount);
            invoice.setIsInterState(igst.compareTo(BigDecimal.ZERO) > 0);

            invoice.setInvoiceStatus(InvoiceStatus.PARSED);
            invoice.setParsedAt(LocalDateTime.now());

            // Parse line items
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> lineItemsData = (List<Map<String, Object>>) parsedData.get("lineItems");
            if (lineItemsData != null) {
                for (Map<String, Object> itemData : lineItemsData) {
                    InvoiceLineItem lineItem = InvoiceLineItem.builder()
                            .invoice(invoice)
                            .itemDescription((String) itemData.get("description"))
                            .quantity((BigDecimal) itemData.get("quantity"))
                            .taxableValue((BigDecimal) itemData.get("amount"))
                            .build();

                    lineItemRepository.save(lineItem);
                }
            }

            invoice = invoiceRepository.save(invoice);

            log.info("Invoice parsed successfully: {}", invoice.getId());

            return convertToDTO(invoice);

        } catch (Exception e) {
            log.error("Error parsing invoice", e);
            invoice.setInvoiceStatus(InvoiceStatus.VALIDATION_FAILED);
            invoiceRepository.save(invoice);
            throw new RuntimeException("Failed to parse invoice: " + e.getMessage());
        }
    }

    public InvoiceDTO validateInvoice(Long invoiceId) {
        Invoice invoice = invoiceRepository.findByIdWithLineItems(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        if (invoice.getInvoiceStatus() != InvoiceStatus.PARSED) {
            throw new RuntimeException("Invoice must be parsed before validation");
        }

        try {
            // Validate GSTIN
            if (!gstCalculator.validateGSTIN(invoice.getVendorGstin())) {
                throw new RuntimeException("Invalid GSTIN");
            }

            // Validate GST calculation
            String vendorState = gstCalculator.extractStateFromGSTIN(invoice.getVendorGstin());

            for (InvoiceLineItem lineItem : invoice.getLineItems()) {
                if (lineItem.getGstRate() != null) {
                    GSTCalculationResult gstResult = gstCalculator.calculateGST(
                            lineItem.getTaxableValue(),
                            lineItem.getGstRate(),
                            vendorState);

                    // Update line item with calculated GST
                    lineItem.setCgstAmount(gstResult.getCgstAmount());
                    lineItem.setSgstAmount(gstResult.getSgstAmount());
                    lineItem.setIgstAmount(gstResult.getIgstAmount());
                    lineItem.setTotalAmount(gstResult.getTotalAmount());
                    lineItem.setIsValidated(true);

                    lineItemRepository.save(lineItem);
                }
            }

            invoice.setInvoiceStatus(InvoiceStatus.VALIDATED);
            invoice.setValidatedAt(LocalDateTime.now());

            invoice = invoiceRepository.save(invoice);

            log.info("Invoice validated successfully: {}", invoice.getId());

            return convertToDTO(invoice);

        } catch (Exception e) {
            log.error("Error validating invoice", e);
            invoice.setInvoiceStatus(InvoiceStatus.VALIDATION_FAILED);
            invoiceRepository.save(invoice);
            throw new RuntimeException("Validation failed: " + e.getMessage());
        }
    }

    public InvoiceDTO approveInvoice(InvoiceApprovalDTO approvalDTO) {
        Invoice invoice = invoiceRepository.findById(approvalDTO.getInvoiceId())
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        if (invoice.getInvoiceStatus() != InvoiceStatus.VALIDATED &&
                invoice.getInvoiceStatus() != InvoiceStatus.PENDING_APPROVAL) {
            throw new RuntimeException("Invoice must be validated before approval");
        }

        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        if (approvalDTO.getApproved()) {
            invoice.setInvoiceStatus(InvoiceStatus.APPROVED);
            invoice.setApprovedAt(LocalDateTime.now());
            invoice.setApprovedBy(username);

            log.info("Invoice approved: {}", invoice.getId());

            notificationService.sendInvoiceApprovalNotification(
                    invoice.getVendor().getEmail(),
                    invoice.getInvoiceNumber());
        } else {
            invoice.setInvoiceStatus(InvoiceStatus.REJECTED);
            invoice.setRejectedAt(LocalDateTime.now());
            invoice.setRejectedBy(username);
            invoice.setRejectionReason(approvalDTO.getComments());

            log.info("Invoice rejected: {}", invoice.getId());
        }

        invoice = invoiceRepository.save(invoice);
        return convertToDTO(invoice);
    }

    public GSTCalculationResult getGSTBreakup(Long invoiceId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        return GSTCalculationResult.builder()
                .taxableAmount(invoice.getTaxableAmount())
                .cgstAmount(invoice.getCgstAmount())
                .sgstAmount(invoice.getSgstAmount())
                .igstAmount(invoice.getIgstAmount())
                .totalGstAmount(invoice.getTotalGstAmount())
                .totalAmount(invoice.getTotalInvoiceAmount())
                .isInterState(invoice.getIsInterState())
                .placeOfSupply(invoice.getPlaceOfSupply())
                .build();
    }

    private String convertDimensionsToJson(Map<String, Object> dimensions) {
        try {
            return objectMapper.writeValueAsString(dimensions);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting dimensions to JSON", e);
        }
    }

    private Map<String, Object> convertJsonToDimensions(String json) {
        try {
            return objectMapper.readValue(json, Map.class);
        } catch (JsonProcessingException e) {
            return Map.of();
        }
    }

    private InvoiceDTO convertToDTO(Invoice entity) {
        return InvoiceDTO.builder()
                .id(entity.getId())
                .invoiceNumber(entity.getInvoiceNumber())
                .vendorId(entity.getVendor().getId())
                .vendorName(entity.getVendor().getVendorName())
                .vendorGstin(entity.getVendorGstin())
                .caseId(entity.getProcurementCase() != null ? entity.getProcurementCase().getId() : null)
                .caseNumber(entity.getProcurementCase() != null ? entity.getProcurementCase().getCaseNumber() : null)
                .invoiceDate(entity.getInvoiceDate())
                .dueDate(entity.getDueDate())
                .placeOfSupply(entity.getPlaceOfSupply())
                .isInterState(entity.getIsInterState())
                .taxableAmount(entity.getTaxableAmount())
                .cgstAmount(entity.getCgstAmount())
                .sgstAmount(entity.getSgstAmount())
                .igstAmount(entity.getIgstAmount())
                .totalGstAmount(entity.getTotalGstAmount())
                .totalInvoiceAmount(entity.getTotalInvoiceAmount())
                .invoiceStatus(entity.getInvoiceStatus())
                .uploadedFilePath(entity.getUploadedFilePath())
                .parsedAt(entity.getParsedAt())
                .validatedAt(entity.getValidatedAt())
                .approvedAt(entity.getApprovedAt())
                .approvedBy(entity.getApprovedBy())
                .rejectionReason(entity.getRejectionReason())
                .lineItems(entity.getLineItems().stream()
                        .map(this::convertLineItemToDTO)
                        .collect(Collectors.toList()))
                .build();
    }

    private InvoiceLineItemDTO convertLineItemToDTO(InvoiceLineItem entity) {
        return InvoiceLineItemDTO.builder()
                .id(entity.getId())
                .invoiceId(entity.getInvoice().getId())
                .productId(entity.getProduct() != null ? entity.getProduct().getId() : null)
                .productName(entity.getProduct() != null ? entity.getProduct().getProductName() : null)
                .itemDescription(entity.getItemDescription())
                .hsnSacCode(entity.getHsnSacCode())
                .quantity(entity.getQuantity())
                .unitPrice(entity.getUnitPrice())
                .taxableValue(entity.getTaxableValue())
                .gstRate(entity.getGstRate())
                .cgstAmount(entity.getCgstAmount())
                .sgstAmount(entity.getSgstAmount())
                .igstAmount(entity.getIgstAmount())
                .totalAmount(entity.getTotalAmount())
                .dimensionValuesMap(convertJsonToDimensions(entity.getDimensionValues()))
                .isValidated(entity.getIsValidated())
                .validationErrors(entity.getValidationErrors())
                .build();
    }
}
