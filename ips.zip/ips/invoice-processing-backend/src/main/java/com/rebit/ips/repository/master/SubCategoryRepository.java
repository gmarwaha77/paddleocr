package com.rebit.ips.repository.master;

import com.rebit.ips.entity.master.SubCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubCategoryRepository extends JpaRepository<SubCategory, Long> {
    Optional<SubCategory> findBySubCategoryCode(String subCategoryCode);
    List<SubCategory> findByCategoryId(Long categoryId);
    List<SubCategory> findByIsActiveTrue();
}

