package com.rebit.ips.dto.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RateMatrixDTO {
    private Long id;
    private Long productId;
    private String productName;
    private String rateName;
    private BigDecimal baseRate;
    private BigDecimal minRate;
    private BigDecimal maxRate;
    private String pricingFormula;
    private LocalDate effectiveFrom;
    private LocalDate effectiveTo;
    private String dimensionCriteria;
}
