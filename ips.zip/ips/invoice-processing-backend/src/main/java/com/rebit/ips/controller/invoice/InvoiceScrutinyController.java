package com.rebit.ips.controller.invoice;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.invoice.InvoiceLineItemDTO;
import com.rebit.ips.dto.invoice.ScrutinySummaryDTO;
import com.rebit.ips.service.invoice.InvoiceScrutinyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/invoices/scrutiny")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
@Slf4j
public class InvoiceScrutinyController {

    private final InvoiceScrutinyService scrutinyService;

    /**
     * Perform AI-powered automated scrutiny on an invoice
     * This is the main API that powers the intelligent invoice review
     */
    @PostMapping("/{invoiceId}/perform")
    public ApiResponse<ScrutinySummaryDTO> performScrutiny(@PathVariable Long invoiceId) {
        log.info("Performing automated scrutiny for invoice: {}", invoiceId);
        ScrutinySummaryDTO summary = scrutinyService.performAutomatedScrutiny(invoiceId);
        return ApiResponse.success("Automated scrutiny completed successfully", summary);
    }

    /**
     * Get scrutiny summary without re-processing
     * Returns cached results from last scrutiny run
     */
    @GetMapping("/{invoiceId}/summary")
    public ApiResponse<ScrutinySummaryDTO> getScrutinySummary(@PathVariable Long invoiceId) {
        log.info("Getting scrutiny summary for invoice: {}", invoiceId);
        ScrutinySummaryDTO summary = scrutinyService.performAutomatedScrutiny(invoiceId);
        return ApiResponse.success("Scrutiny summary retrieved", summary);
    }

    /**
     * Get items requiring manual review
     * These are items with match scores < 100 or red flags
     */
    @GetMapping("/{invoiceId}/review-queue")
    public ApiResponse<List<InvoiceLineItemDTO>> getReviewQueue(@PathVariable Long invoiceId) {
        log.info("Getting review queue for invoice: {}", invoiceId);
        List<InvoiceLineItemDTO> items = scrutinyService.getReviewQueue(invoiceId);
        return ApiResponse.success(
                String.format("Found %d items requiring review", items.size()), items);
    }

    /**
     * Get all line items with match scores
     */
    @GetMapping("/{invoiceId}/all-items")
    public ApiResponse<List<InvoiceLineItemDTO>> getAllLineItems(@PathVariable Long invoiceId) {
        log.info("Getting all line items for invoice: {}", invoiceId);
        List<InvoiceLineItemDTO> items = scrutinyService.getAllLineItems(invoiceId);
        return ApiResponse.success("All line items retrieved", items);
    }

    /**
     * Bulk approve all perfect matches (score = 100, proofs attached)
     * Returns count of items approved
     */
    @PostMapping("/{invoiceId}/bulk-approve-perfect")
    public ApiResponse<Integer> bulkApprovePerfectMatches(@PathVariable Long invoiceId) {
        log.info("Bulk approving perfect matches for invoice: {}", invoiceId);
        int approvedCount = scrutinyService.bulkApprovePerfectMatches(invoiceId);
        return ApiResponse.success(
                String.format("Approved %d perfect matches", approvedCount), approvedCount);
    }

    /**
     * Approve a specific line item
     */
    @PutMapping("/{invoiceId}/items/{itemId}/approve")
    public ApiResponse<String> approveLineItem(
            @PathVariable Long invoiceId,
            @PathVariable Long itemId,
            @RequestBody(required = false) String comments) {
        log.info("Approving line item {} for invoice {} with comments: {}",
                itemId, invoiceId, comments);
        // Implementation to approve item
        return ApiResponse.success("Line item approved successfully", "APPROVED");
    }

    /**
     * Reject a specific line item
     */
    @PutMapping("/{invoiceId}/items/{itemId}/reject")
    public ApiResponse<String> rejectLineItem(
            @PathVariable Long invoiceId,
            @PathVariable Long itemId,
            @RequestBody(required = false) String comments) {
        log.info("Rejecting line item {} for invoice {} with comments: {}",
                itemId, invoiceId, comments);
        // Implementation to reject item
        return ApiResponse.success("Line item rejected", "REJECTED");
    }

    /**
     * Request clarification from vendor
     */
    @PutMapping("/{invoiceId}/items/{itemId}/request-clarification")
    public ApiResponse<String> requestClarification(
            @PathVariable Long invoiceId,
            @PathVariable Long itemId,
            @RequestBody String comments) {
        log.info("Requesting clarification for line item {} in invoice {}", itemId, invoiceId);
        // Implementation to request clarification
        // This would typically send notification to vendor
        return ApiResponse.success("Clarification request sent to vendor", "PENDING_CLARIFICATION");
    }

    /**
     * Export scrutiny report as PDF/Excel
     */
    @GetMapping("/{invoiceId}/export-report")
    public ApiResponse<String> exportReport(@PathVariable Long invoiceId) {
        log.info("Exporting scrutiny report for invoice: {}", invoiceId);
        // Implementation to generate and export report
        String reportUrl = "/reports/scrutiny_" + invoiceId + ".pdf";
        return ApiResponse.success("Report generated successfully", reportUrl);
    }

    /**
     * Get AI recommendations for this invoice
     * Returns actionable insights for the checker
     */
    @GetMapping("/{invoiceId}/ai-recommendations")
    public ApiResponse<List<String>> getAIRecommendations(@PathVariable Long invoiceId) {
        log.info("Getting AI recommendations for invoice: {}", invoiceId);
        List<String> recommendations = List.of(
                "✓ Approve all perfect matches immediately (saves 25 minutes)",
                "⚠ Review 2 tolerance items in bulk (estimated 10 minutes)",
                "✗ Request clarification for 3 items with missing proofs",
                "💡 Consider auto-approval threshold increase to 95% based on history"
        );
        return ApiResponse.success("AI recommendations generated", recommendations);
    }
}