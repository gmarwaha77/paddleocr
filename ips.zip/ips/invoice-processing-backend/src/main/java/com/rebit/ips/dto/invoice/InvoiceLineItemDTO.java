package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceLineItemDTO {
    private Long id;
    private Long invoiceId;
    private Long productId;
    private String productName;
    private String itemDescription;
    private String hsnSacCode;
    private BigDecimal quantity;
    private BigDecimal unitPrice;
    private BigDecimal taxableValue;
    private BigDecimal gstRate;
    private BigDecimal cgstAmount;
    private BigDecimal sgstAmount;
    private BigDecimal igstAmount;
    private BigDecimal totalAmount;
    private Map<String, Object> dimensionValuesMap;
    private Boolean isValidated;
    private String validationErrors;
    private String dimensionValues;

    // Scrutiny fields
    private Integer autoMatchScore; // 0-100
    private Integer proofCount;
    private Boolean requiresReview;
    private Integer redFlagCount;
    private String matchStatus; // PERFECT, TOLERANCE, MISMATCH, NO_PROOF
}
