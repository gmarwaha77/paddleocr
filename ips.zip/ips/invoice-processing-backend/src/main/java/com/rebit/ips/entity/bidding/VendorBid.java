package com.rebit.ips.entity.bidding;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.enums.BidStatus;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "vendor_bid", indexes = {
        @Index(name = "idx_bid_case", columnList = "case_id"),
        @Index(name = "idx_bid_vendor", columnList = "vendor_id"),
        @Index(name = "idx_bid_status", columnList = "bid_status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class VendorBid extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bid_number", unique = true, length = 50)
    private String bidNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private ProcurementCase procurementCase;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "line_item_id", nullable = false)
    private CaseLineItem lineItem;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id", nullable = false)
    private VendorMaster vendor;

    @Column(name = "bid_amount", precision = 19, scale = 2)
    private BigDecimal bidAmount;

    @Column(name = "quoted_price", precision = 19, scale = 2)
    private BigDecimal quotedPrice;

    @Enumerated(EnumType.STRING)
    @Column(name = "bid_status", length = 20)
    private BidStatus bidStatus = BidStatus.PENDING;

    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;

    @Column(name = "valid_till")
    private LocalDateTime validTill;

    @Column(name = "bid_remarks", length = 1000)
    private String bidRemarks;

    @Column(name = "is_selected")
    private Boolean isSelected = false;

    @Column(name = "selected_at")
    private LocalDateTime selectedAt;

    @Column(name = "selected_by", length = 50)
    private String selectedBy;
}
