package com.rebit.ips.enums;

public enum DimensionDataType {
    NUMBER,
    STRING,
    ENUM,
    BOOLEAN,
    DATE,
    DECIMAL
}
