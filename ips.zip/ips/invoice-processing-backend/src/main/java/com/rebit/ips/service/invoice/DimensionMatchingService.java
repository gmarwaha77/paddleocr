package com.rebit.ips.service.invoice;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.dto.invoice.DimensionComparisonDTO;
import com.rebit.ips.dto.invoice.DimensionMatchResultDTO;
import com.rebit.ips.entity.cases.CaseLineItem;
import com.rebit.ips.entity.invoice.InvoiceLineItem;
import com.rebit.ips.entity.master.DimensionTemplate;
import com.rebit.ips.enums.MatchStatus;
import com.rebit.ips.repository.master.DimensionTemplateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class DimensionMatchingService {

    private final DimensionTemplateRepository dimensionTemplateRepository;
    private final ObjectMapper objectMapper;

    /**
     * Match dimensions between expected (from case) and actual (from invoice)
     */
    public DimensionMatchResultDTO matchDimensions(
            CaseLineItem expectedItem,
            InvoiceLineItem actualItem
    ) {
        try {
            Map<String, Object> expected = parseJson(expectedItem.getDimensionValues());
            Map<String, Object> actual = parseJson(actualItem.getDimensionValues());

            DimensionMatchResultDTO result = new DimensionMatchResultDTO();
            result.setTotalDimensions(expected.size());
            result.setLineItemId(actualItem.getId());

            List<DimensionComparisonDTO> comparisons = new ArrayList<>();

            // Get dimension templates for tolerance rules
            List<DimensionTemplate> templates = dimensionTemplateRepository
                    .findByProductIdOrderByDisplayOrderAsc(expectedItem.getProduct().getId());

            for (Map.Entry<String, Object> entry : expected.entrySet()) {
                String key = entry.getKey();
                Object expectedValue = entry.getValue();
                Object actualValue = actual.get(key);

                DimensionComparisonDTO comparison = new DimensionComparisonDTO();
                comparison.setDimensionKey(key);
                comparison.setExpectedValue(expectedValue);
                comparison.setActualValue(actualValue);

                // Find dimension template for tolerance rules
                DimensionTemplate template = templates.stream()
                        .filter(t -> t.getDimensionKey().equals(key))
                        .findFirst()
                        .orElse(null);

                if (actualValue == null) {
                    comparison.setMatchStatus(MatchStatus.MISSING_VALUE);
                    comparison.setRedFlag(true);
                    result.incrementMismatchCount();
                } else if (Objects.equals(expectedValue, actualValue)) {
                    comparison.setMatchStatus(MatchStatus.EXACT_MATCH);
                    result.incrementMatchedCount();
                } else if (template != null && isWithinTolerance(template, expectedValue, actualValue)) {
                    comparison.setMatchStatus(MatchStatus.WITHIN_TOLERANCE);
                    comparison.setVariancePercentage(calculateVariance(expectedValue, actualValue));
                    result.incrementToleranceCount();
                } else {
                    comparison.setMatchStatus(MatchStatus.MISMATCH);
                    comparison.setRedFlag(true);
                    comparison.setVariancePercentage(calculateVariance(expectedValue, actualValue));
                    result.incrementMismatchCount();
                }

                comparisons.add(comparison);
            }

            result.setComparisons(comparisons);
            result.calculateMatchPercentage();
            result.setRequiresReview(result.getMatchPercentage() < 80);

            return result;

        } catch (Exception e) {
            log.error("Error matching dimensions", e);
            throw new RuntimeException("Failed to match dimensions: " + e.getMessage());
        }
    }

    /**
     * Check if actual value is within acceptable tolerance of expected value
     */
    private boolean isWithinTolerance(
            DimensionTemplate template,
            Object expected,
            Object actual
    ) {
        try {
            // For numeric values
            if (expected instanceof Number && actual instanceof Number) {
                double expectedNum = ((Number) expected).doubleValue();
                double actualNum = ((Number) actual).doubleValue();

                // Default 5% tolerance for numbers
                double tolerance = 0.05; // 5%

                // Check if template specifies min/max range
                if (template.getMinValue() != null && template.getMaxValue() != null) {
                    double range = template.getMaxValue() - template.getMinValue();
                    tolerance = range * 0.05; // 5% of range
                }

                double variance = Math.abs(expectedNum - actualNum);
                double allowedVariance = expectedNum * tolerance;

                return variance <= allowedVariance;
            }

            // For date values
            if (expected instanceof String && actual instanceof String) {
                try {
                    LocalDate expectedDate = LocalDate.parse((String) expected);
                    LocalDate actualDate = LocalDate.parse((String) actual);

                    // Allow 1 day tolerance for dates
                    long daysDiff = Math.abs(ChronoUnit.DAYS.between(expectedDate, actualDate));
                    return daysDiff <= 1;
                } catch (Exception e) {
                    // Not dates, treat as strings
                }
            }

            // For string values - check similarity
            if (expected instanceof String && actual instanceof String) {
                String expStr = ((String) expected).toLowerCase().trim();
                String actStr = ((String) actual).toLowerCase().trim();

                // Allow minor variations in strings
                return expStr.contains(actStr) || actStr.contains(expStr) ||
                        calculateStringSimilarity(expStr, actStr) > 0.8;
            }

            return false;

        } catch (Exception e) {
            log.warn("Error checking tolerance for dimension", e);
            return false;
        }
    }

    /**
     * Calculate percentage variance between expected and actual values
     */
    private Double calculateVariance(Object expected, Object actual) {
        try {
            if (expected instanceof Number && actual instanceof Number) {
                double expectedNum = ((Number) expected).doubleValue();
                double actualNum = ((Number) actual).doubleValue();

                if (expectedNum == 0) return 100.0;

                double variance = Math.abs(expectedNum - actualNum);
                return (variance / expectedNum) * 100;
            }
        } catch (Exception e) {
            log.warn("Error calculating variance", e);
        }
        return null;
    }

    /**
     * Calculate string similarity using Levenshtein distance
     */
    private double calculateStringSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) return 0.0;
        if (s1.equals(s2)) return 1.0;

        int maxLen = Math.max(s1.length(), s2.length());
        if (maxLen == 0) return 1.0;

        int distance = levenshteinDistance(s1, s2);
        return 1.0 - ((double) distance / maxLen);
    }

    /**
     * Calculate Levenshtein distance between two strings
     */
    private int levenshteinDistance(String s1, String s2) {
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];

        for (int i = 0; i <= s1.length(); i++) {
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) {
                    dp[i][j] = j;
                } else if (j == 0) {
                    dp[i][j] = i;
                } else {
                    dp[i][j] = Math.min(
                            Math.min(
                                    dp[i - 1][j] + 1,
                                    dp[i][j - 1] + 1
                            ),
                            dp[i - 1][j - 1] + (s1.charAt(i - 1) == s2.charAt(j - 1) ? 0 : 1)
                    );
                }
            }
        }

        return dp[s1.length()][s2.length()];
    }

    private Map<String, Object> parseJson(String json) {
        try {
            if (json == null || json.trim().isEmpty()) {
                return new HashMap<>();
            }
            return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            log.error("Error parsing JSON: {}", json, e);
            return new HashMap<>();
        }
    }

    /**
     * Generate dimension signature for grouping similar items
     */
    public String generateDimensionSignature(Map<String, Object> dimensions) {
        // Create a signature based on key dimension values
        // This helps in grouping similar line items for bulk processing
        List<String> keys = new ArrayList<>(dimensions.keySet());
        Collections.sort(keys);

        StringBuilder signature = new StringBuilder();
        for (String key : keys) {
            // Skip time-varying dimensions like dates
            if (!key.toLowerCase().contains("date") &&
                    !key.toLowerCase().contains("time")) {
                signature.append(key).append(":").append(dimensions.get(key)).append("|");
            }
        }

        return signature.toString();
    }
}