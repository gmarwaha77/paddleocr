package com.rebit.ips.util;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class CaseNumberGenerator {

    private final AtomicInteger counter = new AtomicInteger(1000);

    public String generateCaseNumber(String departmentCode) {
        LocalDate now = LocalDate.now();
        String dateStr = now.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int sequence = counter.incrementAndGet();
        return String.format("CASE-%s-%s-%04d", departmentCode, dateStr, sequence);
    }

    public String generateBidNumber(String caseNumber, String vendorCode) {
        return String.format("BID-%s-%s-%d", caseNumber, vendorCode, System.currentTimeMillis());
    }
}
