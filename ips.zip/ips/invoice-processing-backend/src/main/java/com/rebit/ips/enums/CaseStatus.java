package com.rebit.ips.enums;

public enum CaseStatus {
    DRAFT,
    SUBMITTED,
    UNDER_REVIEW,
    APPROVED,
    REJECTED,
    BIDDING_IN_PROGRESS,
    VENDOR_SELECTED,
    COMPLETED,
    CANCELLED,
    PENDING_APPROVAL
}
