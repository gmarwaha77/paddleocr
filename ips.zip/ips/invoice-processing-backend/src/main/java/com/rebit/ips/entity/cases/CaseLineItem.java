package com.rebit.ips.entity.cases;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.entity.master.ProductMaster;
import com.rebit.ips.entity.master.VendorMaster;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Entity
@Table(name = "case_line_item", indexes = {
        @Index(name = "idx_cli_case", columnList = "case_id"),
        @Index(name = "idx_cli_product", columnList = "product_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class CaseLineItem extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private ProcurementCase procurementCase;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster product;

    @Column(name = "dimension_values", length = 4000, columnDefinition = "TEXT")
    private String dimensionValues;

    @Column(name = "ceiling_amount", precision = 19, scale = 2)
    private BigDecimal ceilingAmount;

    @Column(name = "additional_budget_amount", precision = 19, scale = 2)
    private BigDecimal additionalBudgetAmount;

    @Column(name = "total_amount", precision = 19, scale = 2)
    private BigDecimal totalAmount;

    @Column(name = "calculated_price", precision = 19, scale = 2)
    private BigDecimal calculatedPrice;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "selected_vendor_id")
    private VendorMaster selectedVendor;

    @Column(name = "comments", length = 1000)
    private String comments;

    @Column(name = "item_order")
    private Integer itemOrder;
}
