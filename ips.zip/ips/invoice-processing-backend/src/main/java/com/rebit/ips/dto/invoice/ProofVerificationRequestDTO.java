package com.rebit.ips.dto.invoice;

import com.rebit.ips.enums.VerificationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProofVerificationRequestDTO {
    private Long proofId;
    private VerificationStatus newStatus;
    private String verifiedBy;
    private String comments;
    private Boolean approveLineItem;
}
