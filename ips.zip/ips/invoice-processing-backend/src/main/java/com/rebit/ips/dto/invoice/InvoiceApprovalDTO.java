package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceApprovalDTO {
    private Long invoiceId;
    private Boolean approved;
    private String comments;
}
