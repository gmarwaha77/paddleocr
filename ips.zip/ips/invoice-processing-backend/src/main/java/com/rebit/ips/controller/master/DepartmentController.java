package com.rebit.ips.controller.master;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.master.DepartmentDTO;
import com.rebit.ips.service.master.DepartmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/master/departments")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class DepartmentController {

    private final DepartmentService departmentService;

    @GetMapping
    public ApiResponse<List<DepartmentDTO>> getAllDepartments() {
        return ApiResponse.success("Departments retrieved successfully",
                departmentService.getAllDepartments());
    }

    @GetMapping("/active")
    public ApiResponse<List<DepartmentDTO>> getActiveDepartments() {
        return ApiResponse.success("Active departments retrieved successfully",
                departmentService.getActiveDepartments());
    }

    @GetMapping("/{id}")
    public ApiResponse<DepartmentDTO> getDepartmentById(@PathVariable Long id) {
        return ApiResponse.success("Department retrieved successfully",
                departmentService.getDepartmentById(id));
    }

    @PostMapping
    public ApiResponse<DepartmentDTO> createDepartment(@Valid @RequestBody DepartmentDTO dto) {
        return ApiResponse.success("Department created successfully",
                departmentService.createDepartment(dto));
    }

    @PutMapping("/{id}")
    public ApiResponse<DepartmentDTO> updateDepartment(@PathVariable Long id,
                                                       @Valid @RequestBody DepartmentDTO dto) {
        return ApiResponse.success("Department updated successfully",
                departmentService.updateDepartment(id, dto));
    }
}
