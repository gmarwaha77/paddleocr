package com.rebit.ips.dto.cases;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseApprovalDTO {
    private Long caseId;
    private Boolean approved;
    private String comments;
}
