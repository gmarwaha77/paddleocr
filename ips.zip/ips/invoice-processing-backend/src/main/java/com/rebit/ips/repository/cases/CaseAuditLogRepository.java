package com.rebit.ips.repository.cases;

import com.rebit.ips.entity.cases.CaseAuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CaseAuditLogRepository extends JpaRepository<CaseAuditLog, Long> {
    List<CaseAuditLog> findByProcurementCaseIdOrderByActionTimestampDesc(Long caseId);
}
