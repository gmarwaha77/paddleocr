package com.rebit.ips.repository.master;

import com.rebit.ips.entity.master.ProductMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductMasterRepository extends JpaRepository<ProductMaster, Long> {
    Optional<ProductMaster> findByProductCode(String productCode);
    List<ProductMaster> findBySubCategoryId(Long subCategoryId);
    List<ProductMaster> findByIsActiveTrue();

    @Query("SELECT p FROM ProductMaster p LEFT JOIN FETCH p.dimensions WHERE p.id = :id")
    Optional<ProductMaster> findByIdWithDimensions(Long id);
}
