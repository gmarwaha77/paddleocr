package com.rebit.ips.service.master;

import com.rebit.ips.dto.master.ProductCategoryDTO;
import com.rebit.ips.dto.master.ProductMasterDTO;
import com.rebit.ips.dto.master.SubCategoryDTO;
import com.rebit.ips.entity.master.*;
import com.rebit.ips.repository.master.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ProductHierarchyService {

    private final ProductCategoryRepository categoryRepository;
    private final SubCategoryRepository subCategoryRepository;
    private final ProductMasterRepository productRepository;
    private final DepartmentRepository departmentRepository;

    // Category operations
    public List<ProductCategoryDTO> getAllCategories() {
        return categoryRepository.findAll().stream()
                .map(this::convertCategoryToDTO)
                .collect(Collectors.toList());
    }

    public List<ProductCategoryDTO> getCategoriesByDepartment(Long departmentId) {
        return categoryRepository.findByDepartmentId(departmentId).stream()
                .map(this::convertCategoryToDTO)
                .collect(Collectors.toList());
    }

    public ProductCategoryDTO createCategory(ProductCategoryDTO dto) {
        DepartmentMaster department = departmentRepository.findById(dto.getDepartmentId())
                .orElseThrow(() -> new RuntimeException("Department not found"));

        ProductCategory category = ProductCategory.builder()
                .categoryCode(dto.getCategoryCode())
                .categoryName(dto.getCategoryName())
                .description(dto.getDescription())
                .department(department)
                .build();

        category = categoryRepository.save(category);
        return convertCategoryToDTO(category);
    }

    // SubCategory operations
    public List<SubCategoryDTO> getSubCategoriesByCategory(Long categoryId) {
        return subCategoryRepository.findByCategoryId(categoryId).stream()
                .map(this::convertSubCategoryToDTO)
                .collect(Collectors.toList());
    }

    public SubCategoryDTO createSubCategory(SubCategoryDTO dto) {
        ProductCategory category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));

        SubCategory subCategory = SubCategory.builder()
                .subCategoryCode(dto.getSubCategoryCode())
                .subCategoryName(dto.getSubCategoryName())
                .description(dto.getDescription())
                .category(category)
                .build();

        subCategory = subCategoryRepository.save(subCategory);
        return convertSubCategoryToDTO(subCategory);
    }

    // Product operations
    public List<ProductMasterDTO> getProductsBySubCategory(Long subCategoryId) {
        return productRepository.findBySubCategoryId(subCategoryId).stream()
                .map(this::convertProductToDTO)
                .collect(Collectors.toList());
    }

    public ProductMasterDTO getProductById(Long id) {
        return productRepository.findByIdWithDimensions(id)
                .map(this::convertProductToDTO)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public ProductMasterDTO createProduct(ProductMasterDTO dto) {
        SubCategory subCategory = subCategoryRepository.findById(dto.getSubCategoryId())
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        ProductMaster product = ProductMaster.builder()
                .productCode(dto.getProductCode())
                .productName(dto.getProductName())
                .description(dto.getDescription())
                .subCategory(subCategory)
                .hsnSacCode(dto.getHsnSacCode())
                .classificationType(dto.getClassificationType())
                .unitOfMeasurement(dto.getUnitOfMeasurement())
                .ceilingRate(dto.getCeilingRate())
                .hasCeilingRate(dto.getHasCeilingRate())
                .build();

        product = productRepository.save(product);
        return convertProductToDTO(product);
    }

    public ProductMasterDTO updateProduct(Long id, ProductMasterDTO dto) {
        ProductMaster product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        product.setProductName(dto.getProductName());
        product.setDescription(dto.getDescription());
        product.setHsnSacCode(dto.getHsnSacCode());
        product.setClassificationType(dto.getClassificationType());
        product.setUnitOfMeasurement(dto.getUnitOfMeasurement());
        product.setCeilingRate(dto.getCeilingRate());
        product.setHasCeilingRate(dto.getHasCeilingRate());
        product.setIsActive(dto.getIsActive());

        product = productRepository.save(product);
        return convertProductToDTO(product);
    }

    private ProductCategoryDTO convertCategoryToDTO(ProductCategory entity) {
        return ProductCategoryDTO.builder()
                .id(entity.getId())
                .categoryCode(entity.getCategoryCode())
                .categoryName(entity.getCategoryName())
                .description(entity.getDescription())
                .departmentId(entity.getDepartment() != null ? entity.getDepartment().getId() : null)
                .departmentName(entity.getDepartment() != null ? entity.getDepartment().getDepartmentName() : null)
                .isActive(entity.getIsActive())
                .build();
    }

    private SubCategoryDTO convertSubCategoryToDTO(SubCategory entity) {
        return SubCategoryDTO.builder()
                .id(entity.getId())
                .subCategoryCode(entity.getSubCategoryCode())
                .subCategoryName(entity.getSubCategoryName())
                .description(entity.getDescription())
                .categoryId(entity.getCategory() != null ? entity.getCategory().getId() : null)
                .categoryName(entity.getCategory() != null ? entity.getCategory().getCategoryName() : null)
                .isActive(entity.getIsActive())
                .build();
    }

    private ProductMasterDTO convertProductToDTO(ProductMaster entity) {
        return ProductMasterDTO.builder()
                .id(entity.getId())
                .productCode(entity.getProductCode())
                .productName(entity.getProductName())
                .description(entity.getDescription())
                .subCategoryId(entity.getSubCategory() != null ? entity.getSubCategory().getId() : null)
                .subCategoryName(entity.getSubCategory() != null ? entity.getSubCategory().getSubCategoryName() : null)
                .hsnSacCode(entity.getHsnSacCode())
                .classificationType(entity.getClassificationType())
                .unitOfMeasurement(entity.getUnitOfMeasurement())
                .ceilingRate(entity.getCeilingRate())
                .hasCeilingRate(entity.getHasCeilingRate())
                .isActive(entity.getIsActive())
                .build();
    }
}
