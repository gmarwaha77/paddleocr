package com.rebit.ips.entity.invoice;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.entity.master.ProductMaster;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "invoice_line_item", indexes = {
        @Index(name = "idx_ili_invoice", columnList = "invoice_id"),
        @Index(name = "idx_ili_product", columnList = "product_id"),
        @Index(name = "idx_ili_validation", columnList = "is_validated"),
        @Index(name = "idx_ili_match_score", columnList = "auto_match_score")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class InvoiceLineItem extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invoice_id", nullable = false)
    private Invoice invoice;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private ProductMaster product;

    @Column(name = "item_description", length = 500)
    private String itemDescription;

    @Column(name = "hsn_sac_code", length = 20)
    private String hsnSacCode;

    @Column(name = "quantity", precision = 19, scale = 3)
    private BigDecimal quantity;

    @Column(name = "unit_price", precision = 19, scale = 2)
    private BigDecimal unitPrice;

    @Column(name = "taxable_value", precision = 19, scale = 2)
    private BigDecimal taxableValue;

    @Column(name = "gst_rate", precision = 5, scale = 2)
    private BigDecimal gstRate;

    @Column(name = "cgst_amount", precision = 19, scale = 2)
    private BigDecimal cgstAmount;

    @Column(name = "sgst_amount", precision = 19, scale = 2)
    private BigDecimal sgstAmount;

    @Column(name = "igst_amount", precision = 19, scale = 2)
    private BigDecimal igstAmount;

    @Column(name = "total_amount", precision = 19, scale = 2)
    private BigDecimal totalAmount;

    // Dimension values as JSON string
    @Column(name = "dimension_values", length = 4000, columnDefinition = "TEXT")
    private String dimensionValues;

    // Basic validation
    @Column(name = "is_validated")
    private Boolean isValidated = false;

    @Column(name = "validation_errors", length = 2000)
    private String validationErrors;

    // ============================================
    // NEW FIELDS FOR PROOF MANAGEMENT
    // ============================================

    /**
     * Auto-calculated match score (0-100)
     * Compares expected dimensions (from case) with actual (from invoice)
     */
    @Column(name = "auto_match_score")
    private Integer autoMatchScore;

    /**
     * Number of proof documents attached to this line item
     */
    @Column(name = "proof_count")
    private Integer proofCount = 0;

    /**
     * Number of red flags raised for this line item
     */
    @Column(name = "red_flag_count")
    private Integer redFlagCount = 0;

    /**
     * Detailed dimension match result as JSON
     * Contains comparison of each dimension, match status, variance, etc.
     */
    @Column(name = "dimension_match_result", columnDefinition = "TEXT")
    private String dimensionMatchResult;

    /**
     * Overall match status
     * EXACT_MATCH, WITHIN_TOLERANCE, MISMATCH, PENDING
     */
    @Column(name = "match_status", length = 30)
    private String matchStatus;

    /**
     * Whether this line item requires manual review
     * Auto-set based on match score and proof availability
     */
    @Column(name = "requires_review")
    private Boolean requiresReview = true;

    /**
     * Dimension signature for grouping similar items
     * Used for bulk approval of similar line items
     */
    @Column(name = "dimension_signature", length = 500)
    private String dimensionSignature;

    /**
     * Link to corresponding case line item for comparison
     */
    @Column(name = "case_line_item_id")
    private Long caseLineItemId;

    // ============================================
    // RELATIONSHIPS
    // ============================================

    /**
     * One-to-Many relationship with proof documents
     * Each line item can have multiple proofs (images, PDFs, etc.)
     */
    @OneToMany(mappedBy = "lineItem", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<InvoiceLineItemProof> proofs = new ArrayList<>();

    // ============================================
    // HELPER METHODS
    // ============================================

    /**
     * Add a proof document to this line item
     */
    public void addProof(InvoiceLineItemProof proof) {
        proofs.add(proof);
        proof.setLineItem(this);
        this.proofCount = (this.proofCount != null ? this.proofCount : 0) + 1;
    }

    /**
     * Remove a proof document from this line item
     */
    public void removeProof(InvoiceLineItemProof proof) {
        proofs.remove(proof);
        proof.setLineItem(null);
        this.proofCount = Math.max(0, (this.proofCount != null ? this.proofCount : 0) - 1);
    }

    /**
     * Check if line item has sufficient proofs
     */
    public boolean hasProofs() {
        return this.proofCount != null && this.proofCount > 0;
    }

    /**
     * Check if line item has red flags
     */
    public boolean hasRedFlags() {
        return this.redFlagCount != null && this.redFlagCount > 0;
    }

    /**
     * Check if match score is good (>=80%)
     */
    public boolean hasGoodMatch() {
        return this.autoMatchScore != null && this.autoMatchScore >= 80;
    }

    /**
     * Check if match score is within tolerance (50-79%)
     */
    public boolean hasTolerableMatch() {
        return this.autoMatchScore != null &&
                this.autoMatchScore >= 50 &&
                this.autoMatchScore < 80;
    }

    /**
     * Check if match score is poor (<50%)
     */
    public boolean hasPoorMatch() {
        return this.autoMatchScore != null && this.autoMatchScore < 50;
    }

    /**
     * Determine if this line item should be auto-approved
     * Criteria: Match score >= 80%, has proofs, no red flags
     */
    public boolean canAutoApprove() {
        return hasGoodMatch() &&
                hasProofs() &&
                !hasRedFlags() &&
                (this.isValidated == null || !this.isValidated);
    }

    /**
     * Get the count of verified proofs
     */
    public long getVerifiedProofCount() {
        return proofs.stream()
                .filter(p -> "VERIFIED".equals(p.getVerificationStatus().name()) ||
                        "AUTO_VERIFIED".equals(p.getVerificationStatus().name()))
                .count();
    }

    /**
     * Check if all proofs are verified
     */
    public boolean allProofsVerified() {
        if (!hasProofs()) return false;
        return getVerifiedProofCount() == this.proofCount;
    }

    /**
     * Increment red flag count
     */
    public void incrementRedFlagCount() {
        this.redFlagCount = (this.redFlagCount != null ? this.redFlagCount : 0) + 1;
        this.requiresReview = true;
    }

    /**
     * Clear red flags
     */
    public void clearRedFlags() {
        this.redFlagCount = 0;
    }

    /**
     * Update match status based on score
     */
    public void updateMatchStatus() {
        if (this.autoMatchScore == null) {
            this.matchStatus = "PENDING";
        } else if (this.autoMatchScore >= 90) {
            this.matchStatus = "EXACT_MATCH";
        } else if (this.autoMatchScore >= 80) {
            this.matchStatus = "WITHIN_TOLERANCE";
        } else if (this.autoMatchScore >= 50) {
            this.matchStatus = "PARTIAL_MATCH";
        } else {
            this.matchStatus = "MISMATCH";
        }
    }

    /**
     * Determine if manual review is required
     */
    public void evaluateReviewRequirement() {
        this.requiresReview = !canAutoApprove() ||
                hasPoorMatch() ||
                !hasProofs() ||
                hasRedFlags();
    }

    /**
     * Mark as validated and approved
     */
    public void approve(String approvedBy) {
        this.isValidated = true;
        this.requiresReview = false;
        this.validationErrors = null;
        // Set updatedBy from BaseEntity
        this.setUpdatedBy(approvedBy);
    }

    /**
     * Mark as rejected with reason
     */
    public void reject(String rejectedBy, String reason) {
        this.isValidated = false;
        this.requiresReview = true;
        this.validationErrors = reason;
        this.setUpdatedBy(rejectedBy);
    }
}