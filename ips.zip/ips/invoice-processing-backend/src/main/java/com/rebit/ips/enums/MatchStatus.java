package com.rebit.ips.enums;

public enum MatchStatus {
    EXACT_MATCH,      // Values match exactly
    WITHIN_TOLERANCE, // Within acceptable tolerance
    MISMATCH,         // Values don't match
    MISSING_VALUE     // Expected value is missing
}