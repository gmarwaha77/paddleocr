package com.rebit.ips.service.master;

import com.rebit.ips.dto.master.DepartmentDTO;
import com.rebit.ips.entity.master.DepartmentMaster;
import com.rebit.ips.repository.master.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    public List<DepartmentDTO> getAllDepartments() {
        return departmentRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<DepartmentDTO> getActiveDepartments() {
        return departmentRepository.findByIsActiveTrue().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public DepartmentDTO getDepartmentById(Long id) {
        return departmentRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("Department not found"));
    }

    public DepartmentDTO createDepartment(DepartmentDTO dto) {
        if (departmentRepository.findByDepartmentCode(dto.getDepartmentCode()).isPresent()) {
            throw new RuntimeException("Department code already exists");
        }

        DepartmentMaster department = convertToEntity(dto);
        department = departmentRepository.save(department);
        return convertToDTO(department);
    }

    public DepartmentDTO updateDepartment(Long id, DepartmentDTO dto) {
        DepartmentMaster department = departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found"));

        department.setDepartmentName(dto.getDepartmentName());
        department.setDescription(dto.getDescription());
        department.setAnnualBudget(dto.getAnnualBudget());
        department.setHeadOfDepartment(dto.getHeadOfDepartment());
        department.setContactEmail(dto.getContactEmail());
        department.setContactPhone(dto.getContactPhone());
        department.setIsActive(dto.getIsActive());

        department = departmentRepository.save(department);
        return convertToDTO(department);
    }

    private DepartmentDTO convertToDTO(DepartmentMaster entity) {
        return DepartmentDTO.builder()
                .id(entity.getId())
                .departmentCode(entity.getDepartmentCode())
                .departmentName(entity.getDepartmentName())
                .description(entity.getDescription())
                .annualBudget(entity.getAnnualBudget())
                .budgetUtilized(entity.getBudgetUtilized())
                .headOfDepartment(entity.getHeadOfDepartment())
                .contactEmail(entity.getContactEmail())
                .contactPhone(entity.getContactPhone())
                .isActive(entity.getIsActive())
                .build();
    }

    private DepartmentMaster convertToEntity(DepartmentDTO dto) {
        return DepartmentMaster.builder()
                .departmentCode(dto.getDepartmentCode())
                .departmentName(dto.getDepartmentName())
                .description(dto.getDescription())
                .annualBudget(dto.getAnnualBudget())
                .headOfDepartment(dto.getHeadOfDepartment())
                .contactEmail(dto.getContactEmail())
                .contactPhone(dto.getContactPhone())
                .isActive(true)
                .build();
    }
}
