package com.rebit.ips.dto.master;

import com.rebit.ips.enums.VendorStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorMasterDTO {
    private Long id;
    @NotBlank
    private String vendorCode;
    @NotBlank
    private String vendorName;
    @NotBlank
    private String gstin;
    private String pan;
    private String contactPerson;
    @Email
    private String email;
    private String phone;
    private String address;
    private String city;
    private String state;
    private String pincode;
    private String bankName;
    private String accountNumber;
    private String ifscCode;
    private VendorStatus vendorStatus;
    private LocalDate empanelmentDate;
    private LocalDate empanelmentExpiryDate;
    private Boolean isActive;
}
