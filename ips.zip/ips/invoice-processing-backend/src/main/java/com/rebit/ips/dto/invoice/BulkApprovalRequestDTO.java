package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BulkApprovalRequestDTO {
    private Long invoiceId;
    private String dimensionSignature;
    private Integer minMatchScore;
    private String approvedBy;
    private String comments;
}
