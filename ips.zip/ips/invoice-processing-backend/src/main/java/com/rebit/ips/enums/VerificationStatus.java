package com.rebit.ips.enums;

public enum VerificationStatus {
    PENDING,          // Awaiting verification
    AUTO_VERIFIED,    // Automatically verified (match score > 80%)
    VERIFIED,         // Manually verified
    PARTIAL_MATCH,    // Some dimensions match
    MISMATCH,         // Dimensions don't match
    REJECTED,         // Proof rejected
    NEEDS_REVIEW,      // Requires manual review
    FAILED
}