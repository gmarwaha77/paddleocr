package com.rebit.ips.enums;

public enum BidStatus {
    PENDING,
    SUBMITTED,
    UNDER_EVALUATION,
    SELECTED,
    REJECTED,
    EXPIRED
}
