package com.rebit.ips.entity.master;

import com.rebit.ips.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Entity
@Table(name = "product_vendor_mapping", indexes = {
        @Index(name = "idx_pvm_product", columnList = "product_id"),
        @Index(name = "idx_pvm_vendor", columnList = "vendor_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ProductVendorMapping extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster product;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id", nullable = false)
    private VendorMaster vendor;

    @Column(name = "min_rate", precision = 19, scale = 2)
    private BigDecimal minRate;

    @Column(name = "max_rate", precision = 19, scale = 2)
    private BigDecimal maxRate;

    @Column(name = "is_preferred_vendor")
    private Boolean isPreferredVendor = false;

    @Column(name = "pricing_formula", length = 1000)
    private String pricingFormula;
}
