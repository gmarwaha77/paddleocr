package com.rebit.ips.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        UserDetails master = User.builder()
                .username("master")
                .password(passwordEncoder.encode("master123"))
                .roles("MASTER")
                .build();

        UserDetails maker = User.builder()
                .username("maker")
                .password(passwordEncoder.encode("maker123"))
                .roles("MAKER")
                .build();

        UserDetails checker = User.builder()
                .username("checker")
                .password(passwordEncoder.encode("checker123"))
                .roles("CHECKER")
                .build();

        UserDetails vendor = User.builder()
                .username("vendor")
                .password(passwordEncoder.encode("vendor123"))
                .roles("VENDOR")
                .build();

        return new InMemoryUserDetailsManager(master, maker, checker, vendor);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/h2-console/**").permitAll()
                        .requestMatchers("/auth/**").authenticated()
                        .requestMatchers("/master/**").hasRole("MASTER")
                        .requestMatchers("/cases/**").hasAnyRole("MAKER", "CHECKER")
                        .requestMatchers("/cases/*/approve", "/cases/*/reject").hasRole("CHECKER")
                        .requestMatchers("/bids/**").hasAnyRole("VENDOR", "MAKER", "CHECKER")
                        .requestMatchers("/invoices/upload").hasRole("VENDOR")
                        .requestMatchers("/invoices/*/approve").hasRole("CHECKER")
                        .anyRequest().authenticated()
                )
                .httpBasic(basic -> {})
                .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()));

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(List.of("http://localhost:4200"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setExposedHeaders(Arrays.asList("Authorization"));
        configuration.setMaxAge(3600L);
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
