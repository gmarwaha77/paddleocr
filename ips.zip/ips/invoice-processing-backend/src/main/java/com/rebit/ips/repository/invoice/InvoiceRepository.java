package com.rebit.ips.repository.invoice;

import com.rebit.ips.entity.invoice.Invoice;
import com.rebit.ips.enums.InvoiceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    Optional<Invoice> findByInvoiceNumber(String invoiceNumber);
    List<Invoice> findByVendorId(Long vendorId);
    List<Invoice> findByProcurementCaseId(Long caseId);
    List<Invoice> findByInvoiceStatus(InvoiceStatus status);

    @Query("SELECT i FROM Invoice i LEFT JOIN FETCH i.lineItems WHERE i.id = :id")
    Optional<Invoice> findByIdWithLineItems(Long id);
}
