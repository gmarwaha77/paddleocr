package com.rebit.ips.dto.invoice;

import com.rebit.ips.enums.ProofType;
import com.rebit.ips.enums.VerificationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProofUploadResponseDTO {
    private Long proofId;
    private String fileName;
    private Boolean uploadSuccess;
    private String message;
}