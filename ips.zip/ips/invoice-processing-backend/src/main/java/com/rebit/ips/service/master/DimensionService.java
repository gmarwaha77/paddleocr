package com.rebit.ips.service.master;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebit.ips.dto.PriceCalculationRequest;
import com.rebit.ips.dto.PriceCalculationResponse;
import com.rebit.ips.dto.master.DimensionTemplateDTO;
import com.rebit.ips.entity.master.DimensionTemplate;
import com.rebit.ips.entity.master.ProductMaster;
import com.rebit.ips.entity.master.ProductVendorMapping;
import com.rebit.ips.repository.master.DimensionTemplateRepository;
import com.rebit.ips.repository.master.ProductMasterRepository;
import com.rebit.ips.repository.master.ProductVendorMappingRepository;
import com.rebit.ips.util.FormulaEvaluator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class DimensionService {

    private final DimensionTemplateRepository dimensionRepository;
    private final ProductMasterRepository productRepository;
    private final ProductVendorMappingRepository vendorMappingRepository;
    private final FormulaEvaluator formulaEvaluator;
    private final ObjectMapper objectMapper;

    public List<DimensionTemplateDTO> getDimensionsByProduct(Long productId) {
        return dimensionRepository.findByProductIdOrderByDisplayOrderAsc(productId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public DimensionTemplateDTO createDimension(DimensionTemplateDTO dto) {
        ProductMaster product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        DimensionTemplate dimension = DimensionTemplate.builder()
                .product(product)
                .dimensionName(dto.getDimensionName())
                .dimensionKey(dto.getDimensionKey())
                .dataType(dto.getDataType())
                .uiComponent(dto.getUiComponent())
                .isMandatory(dto.getIsMandatory())
                .enumValues(dto.getEnumValues())
                .minValue(dto.getMinValue())
                .maxValue(dto.getMaxValue())
                .defaultValue(dto.getDefaultValue())
                .validationRegex(dto.getValidationRegex())
                .displayOrder(dto.getDisplayOrder())
                .helpText(dto.getHelpText())
                .usedInPricing(dto.getUsedInPricing())
                .build();

        dimension = dimensionRepository.save(dimension);
        return convertToDTO(dimension);
    }

    public DimensionTemplateDTO updateDimension(Long id, DimensionTemplateDTO dto) {
        DimensionTemplate dimension = dimensionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Dimension not found"));

        dimension.setDimensionName(dto.getDimensionName());
        dimension.setDataType(dto.getDataType());
        dimension.setUiComponent(dto.getUiComponent());
        dimension.setIsMandatory(dto.getIsMandatory());
        dimension.setEnumValues(dto.getEnumValues());
        dimension.setMinValue(dto.getMinValue());
        dimension.setMaxValue(dto.getMaxValue());
        dimension.setDefaultValue(dto.getDefaultValue());
        dimension.setValidationRegex(dto.getValidationRegex());
        dimension.setDisplayOrder(dto.getDisplayOrder());
        dimension.setHelpText(dto.getHelpText());
        dimension.setUsedInPricing(dto.getUsedInPricing());

        dimension = dimensionRepository.save(dimension);
        return convertToDTO(dimension);
    }

    public void deleteDimension(Long id) {
        dimensionRepository.deleteById(id);
    }

    public PriceCalculationResponse calculatePrice(PriceCalculationRequest request) {
        ProductMaster product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Get pricing formula from product vendor mapping or use default
        List<ProductVendorMapping> mappings = vendorMappingRepository.findByProductId(request.getProductId());

        BigDecimal calculatedPrice;
        BigDecimal minPrice = BigDecimal.ZERO;
        BigDecimal maxPrice = BigDecimal.ZERO;
        String formula = "";

        if (!mappings.isEmpty()) {
            ProductVendorMapping mapping = mappings.get(0); // Use first mapping for calculation
            formula = mapping.getPricingFormula();
            minPrice = mapping.getMinRate();
            maxPrice = mapping.getMaxRate();

            if (formula != null && !formula.isEmpty()) {
                calculatedPrice = formulaEvaluator.evaluate(formula, request.getDimensionValues());
            } else {
                // Simple multiplication of dimension values if no formula
                calculatedPrice = calculateSimplePrice(request.getDimensionValues());
            }
        } else {
            calculatedPrice = calculateSimplePrice(request.getDimensionValues());
        }

        boolean withinRange = calculatedPrice.compareTo(minPrice) >= 0 &&
                calculatedPrice.compareTo(maxPrice) <= 0;

        return PriceCalculationResponse.builder()
                .calculatedPrice(calculatedPrice)
                .minPrice(minPrice)
                .maxPrice(maxPrice)
                .formula(formula)
                .withinRange(withinRange)
                .build();
    }

    private BigDecimal calculateSimplePrice(Map<String, Object> dimensionValues) {
        BigDecimal result = BigDecimal.ONE;

        for (Object value : dimensionValues.values()) {
            if (value instanceof Number) {
                result = result.multiply(BigDecimal.valueOf(((Number) value).doubleValue()));
            }
        }

        return result;
    }

    private DimensionTemplateDTO convertToDTO(DimensionTemplate entity) {
        return DimensionTemplateDTO.builder()
                .id(entity.getId())
                .productId(entity.getProduct().getId())
                .dimensionName(entity.getDimensionName())
                .dimensionKey(entity.getDimensionKey())
                .dataType(entity.getDataType())
                .uiComponent(entity.getUiComponent())
                .isMandatory(entity.getIsMandatory())
                .enumValues(entity.getEnumValues())
                .minValue(entity.getMinValue())
                .maxValue(entity.getMaxValue())
                .defaultValue(entity.getDefaultValue())
                .validationRegex(entity.getValidationRegex())
                .displayOrder(entity.getDisplayOrder())
                .helpText(entity.getHelpText())
                .usedInPricing(entity.getUsedInPricing())
                .build();
    }
}
