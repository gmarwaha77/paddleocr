package com.rebit.ips.entity.bidding;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.entity.master.VendorMaster;
import com.rebit.ips.enums.InvitationStatus;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@Table(name = "bidding_invitation")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class BiddingInvitation extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private ProcurementCase procurementCase;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id", nullable = false)
    private VendorMaster vendor;

    @Column(name = "invited_at")
    private LocalDateTime invitedAt;

    @Column(name = "invitation_expires_at")
    private LocalDateTime invitationExpiresAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "invitation_status", length = 20)
    private InvitationStatus invitationStatus = InvitationStatus.SENT;

    @Column(name = "viewed_at")
    private LocalDateTime viewedAt;

    @Column(name = "notification_sent")
    private Boolean notificationSent = false;
}
