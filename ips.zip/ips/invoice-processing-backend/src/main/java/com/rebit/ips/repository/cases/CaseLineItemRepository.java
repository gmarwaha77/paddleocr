package com.rebit.ips.repository.cases;

import com.rebit.ips.entity.cases.CaseLineItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CaseLineItemRepository extends JpaRepository<CaseLineItem, Long> {
    List<CaseLineItem> findByProcurementCaseId(Long caseId);
    List<CaseLineItem> findByProductId(Long productId);
}
