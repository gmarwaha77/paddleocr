package com.rebit.ips.dto.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionGroupDTO {
    private String dimensionSignature;
    private Integer itemCount;
    private LineItemReviewDTO sampleItem;
    private Boolean allMatched;
    private Boolean allProofsAttached;
    private Double averageMatchScore;
}
