package com.rebit.ips.repository.invoice;

import com.rebit.ips.entity.invoice.InvoiceLineItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvoiceLineItemRepository extends JpaRepository<InvoiceLineItem, Long> {
    List<InvoiceLineItem> findByInvoiceId(Long invoiceId);
    List<InvoiceLineItem> findByProductId(Long productId);
}
