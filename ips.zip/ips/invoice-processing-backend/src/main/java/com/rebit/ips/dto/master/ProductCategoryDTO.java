package com.rebit.ips.dto.master;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductCategoryDTO {
    private Long id;
    @NotBlank
    private String categoryCode;
    @NotBlank
    private String categoryName;
    private String description;
    private Long departmentId;
    private String departmentName;
    private Boolean isActive;
}
