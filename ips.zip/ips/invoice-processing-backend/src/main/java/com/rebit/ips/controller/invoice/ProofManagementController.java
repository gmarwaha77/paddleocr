package com.rebit.ips.controller.invoice;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.invoice.*;
import com.rebit.ips.service.invoice.ProofManagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/invoices/proofs")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class ProofManagementController {

    private final ProofManagementService proofManagementService;

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<ProofUploadResponseDTO> uploadProof(
            @RequestParam("file") MultipartFile file,
            @RequestParam("lineItemId") Long lineItemId,
            @ModelAttribute ProofMetadataDTO metadata
    ) {
        return ApiResponse.success("Proof uploaded successfully",
                proofManagementService.uploadProof(file, lineItemId, metadata));
    }

    @GetMapping("/line-item/{lineItemId}")
    public ApiResponse<List<ProofDTO>> getProofsByLineItem(@PathVariable Long lineItemId) {
        return ApiResponse.success("Proofs retrieved successfully",
                proofManagementService.getProofsByLineItem(lineItemId));
    }

    @PostMapping("/auto-verify/{invoiceId}")
    public ApiResponse<Void> autoVerifyProofs(@PathVariable Long invoiceId) {
        proofManagementService.autoVerifyProofs(invoiceId);
        return ApiResponse.success("Auto-verification completed", null);
    }

    @GetMapping("/scrutiny-summary/{invoiceId}")
    public ApiResponse<ScrutinySummaryDTO> getScrutinySummary(@PathVariable Long invoiceId) {
        return ApiResponse.success("Scrutiny summary retrieved",
                proofManagementService.getScrutinySummary(invoiceId));
    }

    @GetMapping("/review-queue/{invoiceId}")
    public ApiResponse<List<LineItemReviewDTO>> getReviewQueue(@PathVariable Long invoiceId) {
        return ApiResponse.success("Review queue retrieved",
                proofManagementService.getLineItemsRequiringReview(invoiceId));
    }

    @PostMapping("/bulk-approve")
    public ApiResponse<Void> bulkApprove(
            @RequestParam String dimensionSignature,
            @RequestParam Long invoiceId
    ) {
        proofManagementService.bulkApproveBySignature(dimensionSignature, invoiceId);
        return ApiResponse.success("Bulk approval completed", null);
    }
}