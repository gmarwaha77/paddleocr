package com.rebit.ips.enums;

public enum VendorStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED,
    BLACKLISTED
}
