package com.rebit.ips.entity.master;

import com.rebit.ips.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "rate_matrix")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class RateMatrix extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster product;

    @Column(name = "rate_name", length = 200)
    private String rateName;

    @Column(name = "base_rate", precision = 19, scale = 2)
    private BigDecimal baseRate;

    @Column(name = "min_rate", precision = 19, scale = 2)
    private BigDecimal minRate;

    @Column(name = "max_rate", precision = 19, scale = 2)
    private BigDecimal maxRate;

    @Column(name = "pricing_formula", length = 1000)
    private String pricingFormula;

    @Column(name = "effective_from")
    private LocalDate effectiveFrom;

    @Column(name = "effective_to")
    private LocalDate effectiveTo;

    @Column(name = "dimension_criteria", length = 2000)
    private String dimensionCriteria;
}
