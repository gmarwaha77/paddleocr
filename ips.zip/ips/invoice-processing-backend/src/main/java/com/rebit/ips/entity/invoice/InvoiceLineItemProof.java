package com.rebit.ips.entity.invoice;

import com.rebit.ips.entity.BaseEntity;
import com.rebit.ips.enums.ProofType;
import com.rebit.ips.enums.VerificationStatus;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "invoice_line_item_proof", indexes = {
        @Index(name = "idx_proof_line_item", columnList = "line_item_id"),
        @Index(name = "idx_proof_verification", columnList = "verification_status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class InvoiceLineItemProof extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "line_item_id", nullable = false)
    private InvoiceLineItem lineItem;

    @Enumerated(EnumType.STRING)
    @Column(name = "proof_type", length = 20)
    private ProofType proofType; // IMAGE, PDF, URL, TIMESTAMP, VIDEO

    @Column(name = "file_path", length = 500)
    private String filePath;

    @Column(name = "file_name", length = 255)
    private String fileName;

    @Column(name = "file_size")
    private Long fileSize;

    @Column(name = "content_type", length = 100)
    private String contentType;

    // For media-specific proofs (newspaper, radio, TV, etc.)
    @Column(name = "publication_name", length = 200)
    private String publicationName;

    @Column(name = "publication_date")
    private LocalDate publicationDate;

    @Column(name = "publication_page", length = 50)
    private String publicationPage;

    @Column(name = "publication_section", length = 100)
    private String publicationSection;

    @Column(name = "geo_location", length = 100)
    private String geoLocation; // Lat,Long for verification

    @Column(name = "state", length = 100)
    private String state;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "circulation_number")
    private Integer circulationNumber;

    @Column(name = "language", length = 50)
    private String language;

    @Column(name = "broadcast_time")
    private LocalDateTime broadcastTime;

    @Column(name = "duration_seconds")
    private Integer durationSeconds;

    // Verification details
    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status", length = 20)
    private VerificationStatus verificationStatus;

    @Column(name = "ocr_extracted_text", columnDefinition = "TEXT")
    private String ocrExtractedText;

    @Column(name = "auto_match_score")
    private Integer autoMatchScore; // 0-100%

    @Column(name = "dimension_match_json", columnDefinition = "TEXT")
    private String dimensionMatchJson; // JSON of dimension comparison results

    @Column(name = "verified_by", length = 100)
    private String verifiedBy;

    @Column(name = "verified_at")
    private LocalDateTime verifiedAt;

    @Column(name = "verification_comments", length = 1000)
    private String verificationComments;

    @Column(name = "ai_confidence_score")
    private Integer aiConfidenceScore; // For future AI verification

    @Column(name = "requires_manual_review")
    private Boolean requiresManualReview = false;

    @Column(name = "thumbnail_path", length = 500)
    private String thumbnailPath; // For quick preview
}