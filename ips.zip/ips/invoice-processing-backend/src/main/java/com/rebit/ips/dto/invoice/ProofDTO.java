package com.rebit.ips.dto.invoice;

import com.rebit.ips.enums.VerificationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProofDTO {
    private Long id;
    private Long lineItemId;
    private String fileName;
    private Long fileSize;
    private String contentType;
    private String filePath;
    private String thumbnailPath;

    // Publication details
    private String publicationName;
    private LocalDate publicationDate;
    private String publicationPage;
    private String state;
    private String city;
    private String language;

    // Verification details
    private VerificationStatus verificationStatus;
    private Integer autoMatchScore;
    private String ocrExtractedText;
    private Boolean requiresManualReview;
    private String verifiedBy;
    private String verificationComments;
}