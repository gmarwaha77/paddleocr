package com.rebit.ips.repository.cases;

import com.rebit.ips.entity.cases.ProcurementCase;
import com.rebit.ips.enums.CaseStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProcurementCaseRepository extends JpaRepository<ProcurementCase, Long> {
    Optional<ProcurementCase> findByCaseNumber(String caseNumber);
    List<ProcurementCase> findByDepartmentId(Long departmentId);
    List<ProcurementCase> findByCaseStatus(CaseStatus status);
    List<ProcurementCase> findByCreatedBy(String createdBy);

    @Query("SELECT c FROM ProcurementCase c LEFT JOIN FETCH c.lineItems WHERE c.id = :id")
    Optional<ProcurementCase> findByIdWithLineItems(Long id);

    @Query("SELECT COUNT(c) FROM ProcurementCase c WHERE c.caseStatus = :status")
    Long countByStatus(CaseStatus status);
}
