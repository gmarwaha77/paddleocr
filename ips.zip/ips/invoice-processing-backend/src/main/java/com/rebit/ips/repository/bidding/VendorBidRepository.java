package com.rebit.ips.repository.bidding;

import com.rebit.ips.entity.bidding.VendorBid;
import com.rebit.ips.enums.BidStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VendorBidRepository extends JpaRepository<VendorBid, Long> {
    Optional<VendorBid> findByBidNumber(String bidNumber);
    List<VendorBid> findByProcurementCaseId(Long caseId);
    List<VendorBid> findByVendorId(Long vendorId);
    List<VendorBid> findByBidStatus(BidStatus status);
    List<VendorBid> findByLineItemId(Long lineItemId);

    @Query("SELECT b FROM VendorBid b WHERE b.lineItem.id = :lineItemId ORDER BY b.bidAmount ASC")
    List<VendorBid> findByLineItemIdOrderByBidAmountAsc(Long lineItemId);
}
