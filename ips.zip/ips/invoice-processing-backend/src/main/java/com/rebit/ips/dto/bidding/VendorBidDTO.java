package com.rebit.ips.dto.bidding;

import com.rebit.ips.enums.BidStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorBidDTO {
    private Long id;
    private String bidNumber;
    @NotNull
    private Long caseId;
    private String caseNumber;
    @NotNull
    private Long lineItemId;
    private Long vendorId;
    private String vendorName;
    @NotNull
    private BigDecimal bidAmount;
    private BigDecimal quotedPrice;
    private BidStatus bidStatus;
    private LocalDateTime submittedAt;
    private LocalDateTime validTill;
    private String bidRemarks;
    private Boolean isSelected;
}
