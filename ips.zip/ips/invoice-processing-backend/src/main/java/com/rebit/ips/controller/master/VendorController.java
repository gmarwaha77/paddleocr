package com.rebit.ips.controller.master;

import com.rebit.ips.dto.ApiResponse;
import com.rebit.ips.dto.master.VendorMasterDTO;
import com.rebit.ips.service.master.VendorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/master/vendors")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class VendorController {

    private final VendorService vendorService;

    @GetMapping
    public ApiResponse<List<VendorMasterDTO>> getAllVendors() {
        return ApiResponse.success("Vendors retrieved successfully",
                vendorService.getAllVendors());
    }

    @GetMapping("/active")
    public ApiResponse<List<VendorMasterDTO>> getActiveVendors() {
        return ApiResponse.success("Active vendors retrieved successfully",
                vendorService.getActiveVendors());
    }

    @GetMapping("/product/{productId}")
    public ApiResponse<List<VendorMasterDTO>> getVendorsByProduct(@PathVariable Long productId) {
        return ApiResponse.success("Vendors retrieved successfully",
                vendorService.getVendorsByProduct(productId));
    }

    @GetMapping("/{id}")
    public ApiResponse<VendorMasterDTO> getVendorById(@PathVariable Long id) {
        return ApiResponse.success("Vendor retrieved successfully",
                vendorService.getVendorById(id));
    }

    @PostMapping
    public ApiResponse<VendorMasterDTO> createVendor(@Valid @RequestBody VendorMasterDTO dto) {
        return ApiResponse.success("Vendor created successfully",
                vendorService.createVendor(dto));
    }

    @PutMapping("/{id}")
    public ApiResponse<VendorMasterDTO> updateVendor(@PathVariable Long id,
                                                     @Valid @RequestBody VendorMasterDTO dto) {
        return ApiResponse.success("Vendor updated successfully",
                vendorService.updateVendor(id, dto));
    }
}
