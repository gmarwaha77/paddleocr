package com.rebit.ips.entity.master;

import com.rebit.ips.entity.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Entity
@Table(name = "department_master", indexes = {
        @Index(name = "idx_dept_code", columnList = "department_code"),
        @Index(name = "idx_dept_active", columnList = "is_active")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class DepartmentMaster extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "department_code", unique = true, length = 20)
    private String departmentCode;

    @NotBlank
    @Column(name = "department_name", length = 200)
    private String departmentName;

    @Column(name = "description", length = 500)
    private String description;

    @NotNull
    @Column(name = "annual_budget", precision = 19, scale = 2)
    private BigDecimal annualBudget;

    @Column(name = "budget_utilized", precision = 19, scale = 2)
    private BigDecimal budgetUtilized = BigDecimal.ZERO;

    @Column(name = "head_of_department", length = 100)
    private String headOfDepartment;

    @Column(name = "contact_email", length = 100)
    private String contactEmail;

    @Column(name = "contact_phone", length = 20)
    private String contactPhone;
}
