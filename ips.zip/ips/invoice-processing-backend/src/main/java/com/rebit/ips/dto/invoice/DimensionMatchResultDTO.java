package com.rebit.ips.dto.invoice;

import com.rebit.ips.enums.MatchStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DimensionMatchResultDTO {
    private Long lineItemId;
    private Integer totalDimensions;
    private Integer matchedCount;
    private Integer toleranceCount;
    private Integer mismatchCount;
    private Double matchPercentage;
    private Boolean requiresReview;
    private List<DimensionComparisonDTO> comparisons;

    public void incrementMatchedCount() {
        if (matchedCount == null) matchedCount = 0;
        matchedCount++;
    }

    public void incrementToleranceCount() {
        if (toleranceCount == null) toleranceCount = 0;
        toleranceCount++;
    }

    public void incrementMismatchCount() {
        if (mismatchCount == null) mismatchCount = 0;
        mismatchCount++;
    }

    public void calculateMatchPercentage() {
        if (totalDimensions == null || totalDimensions == 0) {
            matchPercentage = 0.0;
            return;
        }

        int matched = (matchedCount != null ? matchedCount : 0) +
                (toleranceCount != null ? toleranceCount : 0);
        matchPercentage = (matched * 100.0) / totalDimensions;
    }
}