#!/usr/bin/env python
"""
setup_db.py - Complete database setup for RecruitFlow
Initializes database, creates tables, roles, verticals, and admin users
Usage: python setup_db.py
"""
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app, db
from recruitflow.models import Role, User, PositionTitle, Vertical
from werkzeug.security import generate_password_hash


def setup_database():
    """Initialize the database, create roles, verticals, and admin users."""
    with app.app_context():
        print("\n" + "=" * 70)
        print("  🚀 ReBIT Recruitment Tracker - Database Setup")
        print("=" * 70 + "\n")

        # Check if database exists
        db_file = app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
        if os.path.exists(db_file):
            print(f"⚠️  Database file '{db_file}' already exists.")
            recreate = input("Do you want to DELETE it and start fresh? (y/n): ").lower()
            if recreate == 'y':
                os.remove(db_file)
                print("✅ Existing database deleted.\n")
            else:
                print("❌ Setup cancelled. Using existing database.\n")
                return

        # Create all tables
        print("📦 Creating all database tables...")
        db.create_all()
        print("✅ Tables created successfully.\n")

        # 1. Create roles
        print("👥 Creating user roles...")
        roles_data = [
            'CEO',  # Chief Executive Officer
            'Admin',  # System Administrator
            'Vertical_Head',  # Vertical Head (3rd panel member)
            'Hiring_Manager',  # Hiring Manager
            'Recruiter',  # Recruiter
            'IP',  # Interview Panel
            'Employee'  # Internal Employee
        ]

        for role_name in roles_data:
            if not Role.query.filter_by(name=role_name).first():
                role = Role(name=role_name)
                db.session.add(role)
        db.session.commit()
        print(f"✅ Created {len(roles_data)} roles\n")

        # 2. Create verticals
        print("🏢 Creating organizational verticals...")
        verticals_data = [
            {'name': 'PMV1', 'description': 'Project Management Vertical 1'},
            {'name': 'PMV2', 'description': 'Project Management Vertical 2'},
            {'name': 'CC', 'description': 'Corporate Center - Finance, HR & Accounts'},
            {'name': 'SA', 'description': 'Systems Audit Vertical'},
            {'name': 'CS', 'description': 'Cyber Security Vertical'},
        ]

        for v_data in verticals_data:
            if not Vertical.query.filter_by(name=v_data['name']).first():
                vertical = Vertical(
                    name=v_data['name'],
                    description=v_data['description'],
                    is_active=True
                )
                db.session.add(vertical)
        db.session.commit()
        print(f"✅ Created {len(verticals_data)} verticals\n")

        # 3. Create position titles
        print("📋 Creating position titles...")
        position_titles = [
            'Software Engineer',
            'Senior Software Engineer',
            'Data Analyst',
            'Senior Data Analyst',
            'DevOps Engineer',
            'QA Engineer',
            'Business Analyst',
            'Product Manager',
            'UI/UX Designer',
            'System Administrator',
            'Database Administrator',
            'Network Engineer',
            'Security Analyst',
            'Technical Writer',
            'Scrum Master'
        ]

        for title in position_titles:
            if not PositionTitle.query.filter_by(title=title).first():
                pos_title = PositionTitle(title=title)
                db.session.add(pos_title)
        db.session.commit()
        print(f"✅ Created {len(position_titles)} position titles\n")

        # 4. Create default admin users
        print("👤 Creating default admin users...")

        # Get roles
        ceo_role = Role.query.filter_by(name='CEO').first()
        admin_role = Role.query.filter_by(name='Admin').first()

        # Create CEO user
        if not User.query.filter_by(username='ceo').first():
            ceo_user = User(
                username='ceo',
                password_hash=generate_password_hash('CEO@123'),
                role_id=ceo_role.id,
                full_name='Chief Executive Officer',
                email='ceo@rebit.org.in',
                is_active=True
            )
            db.session.add(ceo_user)
            print("   ✓ Created CEO user")

        # Create Admin user
        if not User.query.filter_by(username='admin').first():
            admin_user = User(
                username='admin',
                password_hash=generate_password_hash('Admin@123'),
                role_id=admin_role.id,
                full_name='System Administrator',
                email='admin@rebit.org.in',
                is_active=True
            )
            db.session.add(admin_user)
            print("   ✓ Created Admin user")

        db.session.commit()
        print("✅ Admin users created\n")

        # Summary
        print("=" * 70)
        print("  ✅ DATABASE SETUP COMPLETE!")
        print("=" * 70)
        print("\n📝 Default Credentials:")
        print("   • CEO:   username: ceo   | password: CEO@123")
        print("   • Admin: username: admin | password: Admin@123")
        print("\n🎯 Next Steps:")
        print("   1. Run: python generate_sample_data.py (to populate test data)")
        print("   2. Run: python run.py (to start the application)")
        print("   3. Login with CEO or Admin credentials")
        print("=" * 70 + "\n")


if __name__ == '__main__':
    setup_database()