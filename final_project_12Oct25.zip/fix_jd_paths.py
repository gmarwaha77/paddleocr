#!/usr/bin/env python
"""
fix_jd_paths.py - Fix Job Description file paths in database
Run this if you're getting "Package not found" errors
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app, db
from recruitflow.models import Position

def fix_jd_paths():
    """Fix JD file paths for all positions"""
    with app.app_context():
        print("\n" + "="*60)
        print("  🔧 Fixing Job Description File Paths")
        print("="*60 + "\n")
        
        upload_folder = app.config.get('UPLOAD_FOLDER')
        if not upload_folder:
            print("❌ UPLOAD_FOLDER not configured!")
            return
        
        print(f"Upload folder: {upload_folder}\n")
        
        # Get all positions
        positions = Position.query.all()
        
        if not positions:
            print("ℹ️  No positions found in database.")
            return
        
        fixed_count = 0
        error_count = 0
        
        for pos in positions:
            print(f"\n📋 Position: {pos.position_title.title} (ID: {pos.id})")
            print(f"   Current path: {pos.jd_file_path}")
            
            # Check if current path exists
            if pos.jd_file_path and os.path.exists(pos.jd_file_path):
                print("   ✅ File exists, no fix needed")
                continue
            
            # Try to find the file in uploads folder
            if pos.jd_file_path:
                filename = os.path.basename(pos.jd_file_path)
                new_path = os.path.join(upload_folder, filename)
                
                if os.path.exists(new_path):
                    pos.jd_file_path = new_path
                    print(f"   ✅ Fixed! New path: {new_path}")
                    fixed_count += 1
                else:
                    print(f"   ⚠️  File not found: {filename}")
                    print(f"   Available files in uploads:")
                    
                    # List files in uploads folder
                    if os.path.exists(upload_folder):
                        files = [f for f in os.listdir(upload_folder) if f.endswith(('.docx', '.pdf'))]
                        if files:
                            for f in files:
                                print(f"      - {f}")
                            
                            # Try to match by similarity
                            print(f"\n   💡 Suggestion: Manually re-upload JD for this position")
                        else:
                            print("      (no files found)")
                    error_count += 1
            else:
                print("   ⚠️  No JD file path set")
                error_count += 1
        
        # Commit changes
        if fixed_count > 0:
            try:
                db.session.commit()
                print(f"\n✅ Fixed {fixed_count} position(s)")
            except Exception as e:
                db.session.rollback()
                print(f"\n❌ Error saving changes: {e}")
        
        if error_count > 0:
            print(f"\n⚠️  {error_count} position(s) need manual attention")
            print("\n📝 To fix manually:")
            print("   1. Login as Hiring Manager")
            print("   2. View the position")
            print("   3. Re-upload the Job Description")
        
        print("\n" + "="*60 + "\n")

if __name__ == '__main__':
    fix_jd_paths()