#!/usr/bin/env python
"""
generate_sample_data.py - Generate comprehensive sample data for RecruitFlow
Includes all relationships: InterviewerRole mappings, Interview Feedbacks, etc.
Run after setup_db.py
Usage: python generate_sample_data.py
"""
import os
import sys
from datetime import datetime, timedelta
import random

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app, db
from recruitflow.models import (
    Role, User, PositionTitle, Position, Candidate, Vertical,
    Interview, InterviewFeedback, InterviewPanel, SalaryProposal,
    InterviewerRole, BackgroundCheck, ReferenceCheck, TalentPool
)
from werkzeug.security import generate_password_hash


def generate_sample_data():
    """Generate comprehensive sample data with all relationships"""
    with app.app_context():
        print("\n" + "=" * 70)
        print("  🎲 Generating Comprehensive Sample Data")
        print("=" * 70 + "\n")

        # Get roles
        ceo_role = Role.query.filter_by(name='CEO').first()
        vh_role = Role.query.filter_by(name='Vertical_Head').first()
        hm_role = Role.query.filter_by(name='Hiring_Manager').first()
        recruiter_role = Role.query.filter_by(name='Recruiter').first()
        ip_role = Role.query.filter_by(name='IP').first()
        employee_role = Role.query.filter_by(name='Employee').first()

        # Get verticals
        verticals = Vertical.query.all()
        tech_vertical = Vertical.query.filter_by(name='PMV1').first()
        ops_vertical = Vertical.query.filter_by(name='PMV2').first()

        if not all([vh_role, hm_role, recruiter_role, ip_role, tech_vertical, ops_vertical]):
            print("❌ Error: Required roles/verticals not found. Run setup_db.py first!")
            return

        # ==================== 1. CREATE USERS ====================
        print("👥 Creating sample users...")

        sample_users = [
            # Vertical Heads
            {
                'username': 'gaurav_vh',
                'password': 'Password123',
                'full_name': 'Gaurav Marwaha',
                'email': 'gaurav.marwaha@rebit.org.in',
                'role_id': vh_role.id,
                'vertical_id': tech_vertical.id
            },
            {
                'username': 'jegan_vh',
                'password': 'Password123',
                'full_name': 'Jegan Vijayrajan',
                'email': 'jegan.vijayrajan@rebit.org.in',
                'role_id': vh_role.id,
                'vertical_id': ops_vertical.id
            },
            # Hiring Managers
            {
                'username': 'amit_hm',
                'password': 'Password123',
                'full_name': 'Amit Solanki',
                'email': 'amit.solanki@rebit.org.in',
                'role_id': hm_role.id,
                'vertical_id': tech_vertical.id
            },
            {
                'username': 'kamlesh_hm',
                'password': 'Password123',
                'full_name': 'Kamlesh Ahire',
                'email': 'kamlesh.ahire@rebit.org.in',
                'role_id': hm_role.id,
                'vertical_id': ops_vertical.id
            },
            # Recruiters
            {
                'username': 'deepika_recruiter',
                'password': 'Password123',
                'full_name': 'Deepika Maheshwari',
                'email': 'deepika.maheshwari@rebit.org.in',
                'role_id': recruiter_role.id,
                'vertical_id': None
            },
            {
                'username': 'aditya_recruiter',
                'password': 'Password123',
                'full_name': 'Aditya Sharma',
                'email': 'aditya.sharma@rebit.org.in',
                'role_id': recruiter_role.id,
                'vertical_id': None
            },
            # Interview Panel Members
            {
                'username': 'nitin_ip',
                'password': 'Password123',
                'full_name': 'Nitin Patil',
                'email': 'nitin.patil@rebit.org.in',
                'role_id': ip_role.id,
                'vertical_id': None
            },
            {
                'username': 'anuja_ip',
                'password': 'Password123',
                'full_name': 'Anuja Patil',
                'email': 'anuja.patil@rebit.org.in',
                'role_id': ip_role.id,
                'vertical_id': None
            },
            {
                'username': 'kapil_ip',
                'password': 'Password123',
                'full_name': 'Kapil Gautam',
                'email': 'kapil.gautam@rebit.org.in',
                'role_id': ip_role.id,
                'vertical_id': None
            },
            {
                'username': 'sudarshan_ip',
                'password': 'Password123',
                'full_name': 'Sudarshan Kumar',
                'email': 'sudarshan.kumar@rebit.org.in',
                'role_id': ip_role.id,
                'vertical_id': None
            },
        ]

        users_created = 0
        for user_data in sample_users:
            if not User.query.filter_by(username=user_data['username']).first():
                user = User(
                    username=user_data['username'],
                    password_hash=generate_password_hash(user_data['password']),
                    full_name=user_data['full_name'],
                    email=user_data['email'],
                    role_id=user_data['role_id'],
                    vertical_id=user_data.get('vertical_id'),
                    is_active=True
                )
                db.session.add(user)
                users_created += 1

        db.session.commit()
        print(f"   ✅ Created {users_created} users")

        # ==================== 2. ASSIGN VERTICAL HEADS ====================
        print("\n🏢 Assigning Vertical Heads to Verticals...")

        gaurav = User.query.filter_by(username='gaurav_vh').first()
        jegan = User.query.filter_by(username='jegan_vh').first()

        if gaurav and tech_vertical:
            tech_vertical.vertical_head_id = gaurav.id
        if jegan and ops_vertical:
            ops_vertical.vertical_head_id = jegan.id

        db.session.commit()
        print("   ✅ Vertical Heads assigned")

        # ==================== 3. CREATE INTERVIEWER ROLE MAPPINGS ====================
        print("\n👔 Creating Interviewer Role Mappings...")

        ip_users = User.query.filter_by(role_id=ip_role.id).all()
        interview_roles = ['Technical', 'Managerial', 'HR', 'Domain Expert']

        role_mappings_created = 0
        for idx, ip_user in enumerate(ip_users):
            # Assign 1-2 roles to each interviewer
            roles_to_assign = random.sample(interview_roles, random.randint(1, 2))
            for role_name in roles_to_assign:
                if not InterviewerRole.query.filter_by(user_id=ip_user.id, role_name=role_name).first():
                    mapping = InterviewerRole(
                        user_id=ip_user.id,
                        role_name=role_name
                    )
                    db.session.add(mapping)
                    role_mappings_created += 1

        db.session.commit()
        print(f"   ✅ Created {role_mappings_created} interviewer role mappings")

        # ==================== 4. CREATE POSITIONS ====================
        print("\n💼 Creating sample positions...")

        hm_users = User.query.filter_by(role_id=hm_role.id).all()
        position_titles = PositionTitle.query.all()

        sample_positions = [
            {
                'title': 'Software Engineer',
                'project': 'Digital Banking Platform',
                'openings': 3,
                'status': 'approved',
                'vertical_id': tech_vertical.id,
                'position_type': 'full_time'
            },
            {
                'title': 'Senior Software Engineer',
                'project': 'Mobile Banking App',
                'openings': 2,
                'status': 'approved',
                'vertical_id': tech_vertical.id,
                'position_type': 'full_time'
            },
            {
                'title': 'Data Analyst',
                'project': 'Business Intelligence',
                'openings': 2,
                'status': 'approved',
                'vertical_id': ops_vertical.id,
                'position_type': 'full_time'
            },
            {
                'title': 'DevOps Engineer',
                'project': 'Cloud Infrastructure',
                'openings': 1,
                'status': 'pending_approval',
                'vertical_id': tech_vertical.id,
                'position_type': 'full_time'
            },
            {
                'title': 'QA Engineer',
                'project': 'Quality Assurance Team',
                'openings': 2,
                'status': 'approved',
                'vertical_id': ops_vertical.id,
                'position_type': 'contract',
                'contract_duration': 6
            },
        ]

        positions_created = 0
        created_positions = []
        for pos_data in sample_positions:
            title_obj = PositionTitle.query.filter_by(title=pos_data['title']).first()
            if title_obj and hm_users:
                # Assign HM based on vertical
                hm = next((u for u in hm_users if u.vertical_id == pos_data['vertical_id']), hm_users[0])

                position = Position(
                    title_id=title_obj.id,
                    project_name=pos_data['project'],
                    openings=pos_data['openings'],
                    jd_file_path='sample_jd.docx',
                    status=pos_data['status'],
                    hm_id=hm.id,
                    vertical_id=pos_data['vertical_id'],
                    position_type=pos_data['position_type'],
                    contract_duration_months=pos_data.get('contract_duration'),
                    jd_clarity_score=random.uniform(65, 95),
                    created_at=datetime.utcnow() - timedelta(days=random.randint(5, 45))
                )
                db.session.add(position)
                db.session.flush()

                # Add interview panel (2 members for now, VH will be added automatically)
                panel_members = random.sample(ip_users, 2)
                for panel_member in panel_members:
                    panel = InterviewPanel(
                        position_id=position.id,
                        ip_user_id=panel_member.id
                    )
                    db.session.add(panel)

                created_positions.append(position)
                positions_created += 1

        db.session.commit()
        print(f"   ✅ Created {positions_created} positions with interview panels")

        # ==================== 5. CREATE CANDIDATES ====================
        print("\n📝 Creating sample candidates...")

        approved_positions = [p for p in created_positions if p.status == 'approved']

        sample_candidates = [
            {
                'name': 'Rahul Sharma',
                'email': 'rahul.sharma@email.com',
                'phone': '+91-9876543210',
                'location': 'Mumbai',
                'experience': 4.0,
                'key_skills': 'Python, Django, REST API, PostgreSQL, Docker',
                'education': 'B.Tech Computer Science - IIT Delhi',
                'similarity_score': 85.5,
                'status': 'interview',
                'current_ctc': 800000,
                'expected_ctc': 1200000
            },
            {
                'name': 'Priya Desai',
                'email': 'priya.desai@email.com',
                'phone': '+91-9876543211',
                'location': 'Bangalore',
                'experience': 6.0,
                'key_skills': 'Java, Spring Boot, Microservices, AWS, Kubernetes',
                'education': 'B.E. Information Technology - BITS Pilani',
                'similarity_score': 92.3,
                'status': 'interview_passed',
                'current_ctc': 1200000,
                'expected_ctc': 1800000
            },
            {
                'name': 'Amit Patel',
                'email': 'amit.patel@email.com',
                'phone': '+91-9876543212',
                'location': 'Pune',
                'experience': 3.5,
                'key_skills': 'React, JavaScript, TypeScript, Node.js, MongoDB',
                'education': 'MCA - Pune University',
                'similarity_score': 78.9,
                'status': 'test_passed',
                'current_ctc': 600000,
                'expected_ctc': 900000
            },
            {
                'name': 'Sneha Reddy',
                'email': 'sneha.reddy@email.com',
                'phone': '+91-9876543213',
                'location': 'Hyderabad',
                'experience': 5.0,
                'key_skills': 'Data Analysis, Python, SQL, Tableau, Power BI',
                'education': 'B.Sc Statistics - Delhi University',
                'similarity_score': 81.7,
                'status': 'interview',
                'current_ctc': 900000,
                'expected_ctc': 1200000
            },
            {
                'name': 'Rohan Joshi',
                'email': 'rohan.joshi@email.com',
                'phone': '+91-9876543214',
                'location': 'Chennai',
                'experience': 6.0,
                'key_skills': 'DevOps, Jenkins, Docker, Kubernetes, Terraform, AWS',
                'education': 'B.Tech Electronics - NIT Trichy',
                'similarity_score': 88.3,
                'status': 'interview_passed',
                'current_ctc': 1500000,
                'expected_ctc': 1900000,
                'is_silver': True  # Mark as silver medalist
            },
            {
                'name': 'Kavita Singh',
                'email': 'kavita.singh@email.com',
                'phone': '+91-9876543215',
                'location': 'Delhi',
                'experience': 7.0,
                'key_skills': 'Angular, TypeScript, RxJS, NgRx, Material Design',
                'education': 'M.Tech Software Engineering - IIT Bombay',
                'similarity_score': 90.1,
                'status': 'offer_accepted',
                'current_ctc': 1600000,
                'expected_ctc': 2100000,
                'joining_date': datetime.now().date() + timedelta(days=20)
            },
        ]

        candidates_created = 0
        created_candidates = []
        for cand_data in sample_candidates:
            if approved_positions:
                position = random.choice(approved_positions)
                candidate = Candidate(
                    position_id=position.id,
                    cv_file_path='sample_cv.pdf',
                    name=cand_data['name'],
                    email=cand_data['email'],
                    phone=cand_data['phone'],
                    location=cand_data['location'],
                    experience=cand_data['experience'],
                    key_skills=cand_data['key_skills'],
                    education=cand_data['education'],
                    similarity_score=cand_data['similarity_score'],
                    status=cand_data['status'],
                    current_ctc=cand_data.get('current_ctc'),
                    expected_ctc=cand_data.get('expected_ctc'),
                    joining_date=cand_data.get('joining_date'),
                    is_silver=cand_data.get('is_silver', False),
                    test_score=random.randint(65, 95) if cand_data['status'] in ['test_passed', 'interview',
                                                                                 'interview_passed'] else None,
                    created_at=datetime.utcnow() - timedelta(days=random.randint(3, 30))
                )
                db.session.add(candidate)
                db.session.flush()
                created_candidates.append(candidate)
                candidates_created += 1

        db.session.commit()
        print(f"   ✅ Created {candidates_created} candidates")

        # ==================== 6. CREATE INTERVIEWS ====================
        print("\n📅 Creating sample interviews...")

        interview_candidates = [c for c in created_candidates if c.status in ['interview', 'interview_passed']]

        interviews_created = 0
        created_interviews = []
        for candidate in interview_candidates:
            interview = Interview(
                candidate_id=candidate.id,
                schedule_date=datetime.now().date() + timedelta(days=random.randint(-5, 10)),
                schedule_time=random.choice(['10:00 AM', '2:00 PM', '4:00 PM']),
                interview_mode=random.choice(['Video', 'In-person']),
                meeting_link='https://meet.google.com/abc-defg-hij' if random.choice([True, False]) else None,
                status='completed' if candidate.status == 'interview_passed' else 'scheduled'
            )
            db.session.add(interview)
            db.session.flush()
            created_interviews.append(interview)
            interviews_created += 1

        db.session.commit()
        print(f"   ✅ Created {interviews_created} interviews")

        # ==================== 7. CREATE INTERVIEW FEEDBACKS ====================
        print("\n💬 Creating interview feedbacks...")

        feedbacks_created = 0
        for interview in created_interviews:
            if interview.status == 'completed':
                # Get panel members for this position
                panel_members = InterviewPanel.query.filter_by(
                    position_id=interview.candidate.position_id
                ).all()

                for panel in panel_members[:2]:  # First 2 panel members give feedback
                    # Generate ratings
                    technical = random.randint(3, 5)
                    communication = random.randint(3, 5)
                    problem_solving = random.randint(3, 5)
                    cultural_fit = random.randint(3, 5)
                    team_collab = random.randint(3, 5)
                    overall = (technical + communication + problem_solving + cultural_fit + team_collab) / 5

                    # Determine recommendation based on overall rating
                    if overall >= 4.5:
                        recommendation = 'strongly_recommend'
                    elif overall >= 3.5:
                        recommendation = 'recommend'
                    elif overall >= 2.5:
                        recommendation = 'neutral'
                    else:
                        recommendation = 'do_not_recommend'

                    feedback = InterviewFeedback(
                        interview_id=interview.id,
                        ip_user_id=panel.ip_user_id,
                        technical_rating=technical,
                        communication_rating=communication,
                        problem_solving_rating=problem_solving,
                        cultural_fit_rating=cultural_fit,
                        team_collaboration_rating=team_collab,
                        overall_rating=overall,
                        recommendation=recommendation,
                        strengths='Strong technical skills and good communication' if overall >= 4 else 'Good potential with room for growth',
                        areas_of_concern='None noted' if overall >= 4 else 'Needs more experience in certain areas',
                        comments=f'Overall good candidate with {interview.candidate.experience} years experience',
                        rating=int(overall),
                        created_at=interview.schedule_date
                    )
                    db.session.add(feedback)
                    feedbacks_created += 1

        db.session.commit()
        print(f"   ✅ Created {feedbacks_created} interview feedbacks")

        # ==================== 8. CREATE SALARY PROPOSALS ====================
        print("\n💰 Creating salary proposals...")

        proposal_candidates = [c for c in created_candidates if c.status in ['interview_passed', 'offer_accepted']]
        recruiter_users = User.query.filter_by(role_id=recruiter_role.id).all()

        proposals_created = 0
        for candidate in proposal_candidates:
            if recruiter_users:
                recruiter = random.choice(recruiter_users)
                annual_ctc = candidate.expected_ctc or 1200000

                # Calculate Indian CTC breakup
                basic = annual_ctc * 0.40
                hra = basic * 0.50
                special = annual_ctc * 0.20
                bonus = annual_ctc * 0.10
                pf_employer = min(basic * 0.12, 1800 * 12)
                gratuity = basic * 0.0481
                monthly_gross = (basic + hra + special) / 12
                monthly_net = monthly_gross - (pf_employer / 12) - (2400 / 12)

                proposal = SalaryProposal(
                    candidate_id=candidate.id,
                    proposed_by=recruiter.id,
                    annual_ctc=annual_ctc,
                    basic_salary=basic,
                    hra=hra,
                    special_allowance=special,
                    performance_bonus=bonus,
                    pf_employer=pf_employer,
                    gratuity=gratuity,
                    pf_employee=pf_employer,
                    professional_tax=2400,
                    medical_insurance=5000,
                    monthly_gross=monthly_gross,
                    monthly_net=monthly_net,
                    status='accepted' if candidate.status == 'offer_accepted' else 'pending',
                    version=1,
                    is_final=candidate.status == 'offer_accepted',
                    created_at=datetime.utcnow() - timedelta(days=random.randint(1, 10))
                )
                db.session.add(proposal)
                proposals_created += 1

        db.session.commit()
        print(f"   ✅ Created {proposals_created} salary proposals")

        # ==================== 9. ADD TO TALENT POOL ====================
        print("\n🌟 Adding silver medalists to talent pool...")

        silver_candidates = [c for c in created_candidates if c.is_silver]
        talent_pool_added = 0

        for candidate in silver_candidates:
            if not TalentPool.query.filter_by(candidate_id=candidate.id).first():
                talent_entry = TalentPool(
                    candidate_id=candidate.id,
                    pool_category='High Performer',
                    skills_tags=candidate.key_skills,
                    experience_level='Senior' if candidate.experience >= 5 else 'Mid-Level',
                    added_by=recruiter_users[0].id if recruiter_users else None,
                    availability='Immediate',
                    notes='Strong performer in previous interview'
                )
                db.session.add(talent_entry)
                talent_pool_added += 1

        db.session.commit()
        print(f"   ✅ Added {talent_pool_added} candidates to talent pool")

        # ==================== 10. CREATE BACKGROUND CHECKS ====================
        print("\n🔍 Creating background checks...")

        bgv_candidates = [c for c in created_candidates if c.status in ['offer_accepted', 'interview_passed']]
        bgv_created = 0

        for candidate in bgv_candidates[:3]:  # Just first 3
            check_types = ['education_verification', 'employment_verification', 'criminal_check']
            for check_type in random.sample(check_types, 2):
                bgv = BackgroundCheck(
                    candidate_id=candidate.id,
                    check_type=check_type,
                    status=random.choice(['clear', 'in_progress']),
                    vendor_name='Verify India',
                    initiated_date=datetime.now().date() - timedelta(days=random.randint(3, 15)),
                    completed_date=datetime.now().date() - timedelta(days=random.randint(1, 5)) if random.choice(
                        [True, False]) else None,
                    verified_by=recruiter_users[0].id if recruiter_users else None
                )
                db.session.add(bgv)
                bgv_created += 1

        db.session.commit()
        print(f"   ✅ Created {bgv_created} background checks")

        # ==================== 11. CREATE REFERENCE CHECKS ====================
        print("\n📞 Creating reference checks...")

        ref_candidates = [c for c in created_candidates if c.status in ['offer_accepted', 'interview_passed']]
        refs_created = 0

        for candidate in ref_candidates[:3]:
            for i in range(2):  # 2 references per candidate
                ref = ReferenceCheck(
                    candidate_id=candidate.id,
                    reference_name=f'Reference {i + 1} for {candidate.name.split()[0]}',
                    reference_designation=random.choice(['Manager', 'Team Lead', 'Senior Engineer']),
                    reference_company=random.choice(['TCS', 'Infosys', 'Wipro', 'Tech Corp']),
                    reference_phone='+91-98765432' + str(random.randint(10, 99)),
                    reference_email=f'ref{i}@company.com',
                    relationship=random.choice(['Direct Manager', 'Colleague', 'Project Lead']),
                    contacted_by=recruiter_users[0].id if recruiter_users else None,
                    overall_rating=random.randint(4, 5) if random.choice([True, False]) else None,
                    would_rehire=True if random.choice([True, False]) else None,
                    feedback='Good performer, team player' if random.choice([True, False]) else None,
                    status='completed' if random.choice([True, False]) else 'pending'
                )
                db.session.add(ref)
                refs_created += 1

        db.session.commit()
        print(f"   ✅ Created {refs_created} reference checks")

        # SUMMARY
        print("\n" + "=" * 70)
        print("  ✅ SAMPLE DATA GENERATION COMPLETE!")
        print("=" * 70)
        print("\n📊 Summary:")
        print(f"   • Users Created: {users_created}")
        print(f"   • Interviewer Role Mappings: {role_mappings_created}")
        print(f"   • Positions Created: {positions_created}")
        print(f"   • Candidates Created: {candidates_created}")
        print(f"   • Interviews Scheduled: {interviews_created}")
        print(f"   • Interview Feedbacks: {feedbacks_created}")
        print(f"   • Salary Proposals: {proposals_created}")
        print(f"   • Talent Pool Entries: {talent_pool_added}")
        print(f"   • Background Checks: {bgv_created}")
        print(f"   • Reference Checks: {refs_created}")

        print("\n🔑 Test User Credentials:")
        print("   • CEO: ceo / CEO@123")
        print("   • Admin: admin / Admin@123")
        print("   • Vertical Head: gaurav_vh / Password123")
        print("   • Hiring Manager: amit_hm / Password123")
        print("   • Recruiter: deepika_recruiter / Password123")
        print("   • Interview Panel: rajesh_ip / Password123")

        print("\n🎯 Next Steps:")
        print("   1. Run: python run.py")
        print("   2. Login with any test user")
        print("   3. Explore the fully populated system!")
        print("=" * 70 + "\n")


if __name__ == '__main__':
    generate_sample_data()