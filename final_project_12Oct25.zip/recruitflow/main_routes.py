# recruitflow/main_routes.py (COMPLETE & FIXED)
import os
import re

from flask import (Blueprint, render_template, request, redirect, url_for,
                   flash, current_app, send_from_directory, abort)
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import func
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash  # ADD THIS
from datetime import datetime, date, timedelta  # ADD datetime here too
from .models import (db, User, Role, Position, PositionTitle, Candidate,
                     InterviewPanel, Interview, InterviewFeedback, CandidateNote, Vertical, ReferenceCheck,
                     SalaryProposal, BackgroundCheck)
from .cv_parser import parse_cv, extract_text_from_docx
from .utils.helpers import role_required, log_action
from .utils.ad_auth import ad_authenticator


def analyze_jd_quality(jd_text):
    """
    Analyze JD quality and provide clarity score
    Returns: (score, feedback)
    """
    score = 0.0
    feedback_points = []

    if not jd_text or len(jd_text.strip()) < 100:
        return 20.0, "JD is too short. Please provide detailed job description."

    # 1. Check length (20 points)
    word_count = len(jd_text.split())
    if word_count >= 300:
        score += 20
        feedback_points.append("✓ Adequate detail provided")
    elif word_count >= 150:
        score += 10
        feedback_points.append("⚠ JD could be more detailed")
    else:
        feedback_points.append("✗ JD is too brief, add more details")

    # 2. Key sections present (40 points)
    sections_found = 0
    required_sections = {
        'responsibilities': r'(responsibilit|duties|role)',
        'requirements': r'(requirement|qualification|must have)',
        'experience': r'(experience|years)',
        'skills': r'(skill|technical|proficiency)',
        'education': r'(education|degree|qualification)'
    }

    text_lower = jd_text.lower()
    for section, pattern in required_sections.items():
        if re.search(pattern, text_lower):
            sections_found += 1

    section_score = (sections_found / len(required_sections)) * 40
    score += section_score

    if sections_found == len(required_sections):
        feedback_points.append("✓ All key sections present")
    else:
        missing = len(required_sections) - sections_found
        feedback_points.append(f"⚠ Missing {missing} key section(s)")

    # 3. Specific skills mentioned (20 points)
    skill_keywords = ['python', 'java', 'sql', 'aws', 'azure', 'react', 'angular',
                      'node', 'spring', 'django', 'kubernetes', 'docker']
    skills_mentioned = sum(1 for skill in skill_keywords if skill in text_lower)

    if skills_mentioned >= 5:
        score += 20
        feedback_points.append("✓ Specific technical skills mentioned")
    elif skills_mentioned >= 3:
        score += 10
        feedback_points.append("⚠ Add more specific technical skills")
    else:
        feedback_points.append("✗ Very few specific skills mentioned")

    # 4. Clarity indicators (20 points)
    clarity_score = 0

    # Has numbered lists or bullet points
    if re.search(r'(\d+\.|\*|\-|\•)', jd_text):
        clarity_score += 10
        feedback_points.append("✓ Well-structured with lists/bullets")

    # Not too many jargon/unclear terms
    jargon_words = ['synergy', 'leverage', 'dynamic', 'fast-paced']
    jargon_count = sum(1 for word in jargon_words if word in text_lower)
    if jargon_count < 3:
        clarity_score += 10
        feedback_points.append("✓ Clear language used")

    score += clarity_score

    # Generate overall feedback
    if score >= 80:
        overall = "Excellent JD! Clear, comprehensive and well-structured."
    elif score >= 60:
        overall = "Good JD. Some improvements recommended."
    elif score >= 40:
        overall = "Fair JD. Needs improvement in several areas."
    else:
        overall = "Poor JD. Requires significant revision."

    full_feedback = overall + "\n\n" + "\n".join(feedback_points)

    return round(score, 1), full_feedback

main = Blueprint('main', __name__)


def find_matching_candidates(position):
    """Find matching candidates from silver medalists and talent pool"""
    from .models import TalentPool

    # Get silver medalists and talent pool candidates
    potential_candidates = Candidate.query.filter(
        db.or_(
            Candidate.is_silver == True,
            Candidate.id.in_(
                db.session.query(TalentPool.candidate_id)
            )
        )
    ).all()

    # Simple matching based on position title and skills
    matching = []
    position_title = position.position_title.title.lower()

    for candidate in potential_candidates:
        # Match by title keywords
        candidate_skills = (candidate.key_skills or '').lower()

        # Simple keyword matching - can be enhanced with ML
        if any(word in candidate_skills for word in position_title.split()):
            matching.append(candidate)
        elif candidate.similarity_score and candidate.similarity_score > 70:
            matching.append(candidate)

    return matching[:10]  # Return top 10 matches

# --- Authentication Routes ---

@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        use_ad = request.form.get('use_ad') == 'on'  # Checkbox for AD login
        
        user = None
        
        # Try AD authentication first if enabled
        if use_ad and ad_authenticator.enabled:
            ad_user_info = ad_authenticator.authenticate(username, password)
            
            if ad_user_info:
                # Check if user exists in our system
                user = User.query.filter_by(username=ad_user_info['username']).first()
                
                if not user:
                    # Create new user from AD info
                    # Internal employees get a special "Employee" role
                    employee_role = Role.query.filter_by(name='Employee').first()
                    if not employee_role:
                        employee_role = Role(name='Employee')
                        db.session.add(employee_role)
                        db.session.commit()
                    
                    user = User(
                        username=ad_user_info['username'],
                        password_hash=generate_password_hash(os.urandom(24).hex()),  # Random password
                        full_name=ad_user_info['full_name'],
                        email=ad_user_info['email'],
                        role_id=employee_role.id,
                        is_active=True
                    )
                    # Store employee_id as custom attribute if needed
                    db.session.add(user)
                    db.session.commit()
                    
                    log_action(f'New AD user auto-created: {user.username}')
                
                # Log them in
                login_user(user, remember=True)
                log_action(f'User {user.username} logged in via AD')
                
                # Redirect employees to internal positions
                if user.role.name == 'Employee':
                    return redirect(url_for('internal.open_positions'))
                else:
                    return redirect(url_for('main.dashboard'))
        
        # Fall back to regular authentication
        if not user:
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                if user.is_active:
                    login_user(user, remember=True)
                    log_action(f'User {user.username} logged in successfully.')
                    return redirect(url_for('main.dashboard'))
                else:
                    flash('Your account is inactive. Please contact the administrator.', 'warning')
            else:
                flash('Invalid username or password. Please try again.', 'danger')
    
    # Check if AD is enabled
    ad_enabled = ad_authenticator.enabled
    
    return render_template('login.html', ad_enabled=ad_enabled)


@main.route('/logout')
@login_required
def logout():
    log_action(f'User {current_user.username} logged out.')
    logout_user()
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('main.login'))


# --- Dashboard Route ---

# --- Dashboard Route ---

@main.route('/')
@login_required
def dashboard():
    from datetime import datetime
    role_name = current_user.role.name

    # CEO Dashboard
    if role_name == 'CEO':
        # Basic metrics
        total_positions = Position.query.count()
        active_positions = Position.query.filter_by(status='approved').count()
        total_candidates = Candidate.query.count()
        pending_approvals = Position.query.filter_by(status='pending_approval').count()

        # Salary proposals pending CEO approval
        from .models import SalaryProposal
        pending_salaries = SalaryProposal.query.filter_by(status='pending').count()

        # Upcoming joinings (next 30 days)
        thirty_days_later = datetime.now().date() + timedelta(days=30)
        upcoming_joinings = Candidate.query.filter(
            Candidate.joining_date <= thirty_days_later,
            Candidate.joining_date >= datetime.now().date()
        ).count()

        # Interview metrics
        in_interview = Candidate.query.filter_by(status='interview').count()
        offers_extended = Candidate.query.filter(
            Candidate.status.in_(['offer_accepted', 'offer_declined'])
        ).count()
        offers_accepted = Candidate.query.filter_by(status='offer_accepted').count()

        # Calculate average time to hire (simplified)
        hired_candidates = Candidate.query.filter(
            Candidate.joining_date.isnot(None),
            Candidate.created_at >= datetime.now() - timedelta(days=180)
        ).all()

        if hired_candidates:
            total_days = sum([
                (c.joining_date - c.created_at.date()).days
                for c in hired_candidates
                if c.joining_date > c.created_at.date()
            ])
            avg_time_to_hire = round(total_days / len(hired_candidates))
        else:
            avg_time_to_hire = 0

        # Funnel data for last 90 days
        ninety_days_ago = datetime.now() - timedelta(days=90)
        funnel_query = Candidate.query.filter(Candidate.created_at >= ninety_days_ago)

        funnel_data = [
            funnel_query.count(),  # Applied
            funnel_query.filter(Candidate.status != 'applied').count(),  # Screened
            funnel_query.filter(Candidate.status.in_(
                ['under_hm_review', 'test_allocated', 'test_passed', 'interview', 'offer_accepted', 'hired'])).count(),
            funnel_query.filter(Candidate.status.in_(['test_passed', 'interview', 'offer_accepted', 'hired'])).count(),
            funnel_query.filter(Candidate.status.in_(['interview', 'offer_accepted', 'hired'])).count(),
            funnel_query.filter(Candidate.status.in_(['offer_accepted', 'offer_declined', 'hired'])).count(),
            funnel_query.filter(Candidate.status == 'hired').count()
        ]

        # Conversion rates
        total_applied = funnel_data[0] or 1
        screen_to_interview_rate = round((funnel_data[4] / total_applied) * 100, 1) if total_applied else 0
        interview_to_offer_rate = round((funnel_data[5] / funnel_data[4]) * 100, 1) if funnel_data[4] else 0
        offer_acceptance_rate = round((offers_accepted / offers_extended) * 100, 1) if offers_extended else 0
        overall_conversion_rate = round((funnel_data[6] / total_applied) * 100, 1) if total_applied else 0

        # Vertical-wise statistics
        verticals = Vertical.query.filter_by(is_active=True).all()
        vertical_stats = []

        for vertical in verticals:
            positions = Position.query.filter_by(vertical_id=vertical.id)
            active_pos = positions.filter_by(status='approved').count()
            position_ids = [p.id for p in positions.all()]

            candidates = Candidate.query.filter(Candidate.position_id.in_(position_ids))
            total_cands = candidates.count()
            in_int = candidates.filter_by(status='interview').count()
            offers = candidates.filter(Candidate.status.in_(['offer_accepted', 'offer_declined'])).count()
            hired = candidates.filter_by(status='hired').count()

            # Calculate fill rate
            total_openings = sum([p.openings for p in positions.all()])
            fill_rate = round((hired / total_openings) * 100, 1) if total_openings else 0

            # Average time to hire for this vertical
            hired_in_vertical = candidates.filter(Candidate.joining_date.isnot(None)).all()
            if hired_in_vertical:
                v_total_days = sum([
                    (c.joining_date - c.created_at.date()).days
                    for c in hired_in_vertical
                    if c.joining_date > c.created_at.date()
                ])
                v_avg_time = round(v_total_days / len(hired_in_vertical))
            else:
                v_avg_time = 0

            vertical_stats.append({
                'name': vertical.name,
                'active_positions': active_pos,
                'total_candidates': total_cands,
                'in_interview': in_int,
                'offers': offers,
                'hired': hired,
                'fill_rate': fill_rate,
                'avg_time_to_hire': v_avg_time
            })

        # Recent activities
        from .models import AuditLog
        recent_logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(10).all()
        recent_activities = []

        for log in recent_logs:
            time_diff = datetime.utcnow() - log.timestamp
            if time_diff.days > 0:
                time_ago = f"{time_diff.days}d ago"
            elif time_diff.seconds >= 3600:
                time_ago = f"{time_diff.seconds // 3600}h ago"
            else:
                time_ago = f"{time_diff.seconds // 60}m ago"

            recent_activities.append({
                'title': log.entity_type or 'System Action',
                'description': log.action,
                'time_ago': time_ago
            })

        # Top performing interviewers
        from .models import InterviewFeedback
        interviewer_stats = db.session.query(
            User.full_name,
            func.count(InterviewFeedback.id).label('interview_count'),
            func.avg(InterviewFeedback.overall_rating).label('avg_rating')
        ).join(
            InterviewFeedback, User.id == InterviewFeedback.ip_user_id
        ).group_by(
            User.id, User.full_name
        ).order_by(
            func.count(InterviewFeedback.id).desc()
        ).limit(5).all()

        top_interviewers = []
        for stat in interviewer_stats:
            # Calculate selection rate
            user = User.query.filter_by(full_name=stat.full_name).first()
            if user:
                recommended = InterviewFeedback.query.filter_by(
                    ip_user_id=user.id
                ).filter(
                    InterviewFeedback.recommendation.in_(['strongly_recommend', 'recommend'])
                ).count()
                selection_rate = round((recommended / stat.interview_count) * 100, 1) if stat.interview_count else 0
            else:
                selection_rate = 0

            top_interviewers.append({
                'name': stat.full_name,
                'interviews': stat.interview_count,
                'selection_rate': selection_rate,
                'avg_rating': round(stat.avg_rating, 1) if stat.avg_rating else 0
            })

        return render_template('ceo/dashboard.html',
                               total_positions=total_positions,
                               active_positions=active_positions,
                               total_candidates=total_candidates,
                               pending_approvals=pending_approvals,
                               pending_salaries=pending_salaries,
                               upcoming_joinings=upcoming_joinings,
                               in_interview=in_interview,
                               offers_extended=offers_extended,
                               offers_accepted=offers_accepted,
                               avg_time_to_hire=avg_time_to_hire,
                               funnel_data=funnel_data,
                               screen_to_interview_rate=screen_to_interview_rate,
                               interview_to_offer_rate=interview_to_offer_rate,
                               offer_acceptance_rate=offer_acceptance_rate,
                               overall_conversion_rate=overall_conversion_rate,
                               vertical_stats=vertical_stats,
                               recent_activities=recent_activities,
                               top_interviewers=top_interviewers)

    # Admin Dashboard
    elif role_name == 'Admin':
        # Admin sees user management and system config
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        total_verticals = Vertical.query.count()

        return render_template('admin/dashboard.html',
                               total_users=total_users,
                               active_users=active_users,
                               total_verticals=total_verticals)

    # Vertical Head Dashboard
    elif role_name == 'Vertical_Head':
        # Redirect to vertical head specific dashboard
        return redirect(url_for('vertical_head.dashboard'))

    # Hiring Manager Dashboard
    elif role_name == 'Hiring_Manager':
        positions = Position.query.filter_by(hm_id=current_user.id).all()

        # Check for contract employees needing reviews
        contract_positions = Position.query.filter_by(
            hm_id=current_user.id,
            position_type='contract'
        ).all()

        contract_position_ids = [p.id for p in contract_positions]
        contract_employees = Candidate.query.filter(
            Candidate.position_id.in_(contract_position_ids),
            Candidate.status == 'hired'
        ).count()

        # Check pending reviews
        from .models import ContractPerformanceReview
        current_month = datetime.now().month
        current_year = datetime.now().year

        pending_review_count = 0
        for pos_id in contract_position_ids:
            hired = Candidate.query.filter_by(
                position_id=pos_id,
                status='hired'
            ).all()

            for cand in hired:
                if cand.joining_date:
                    months_working = (
                            (current_year - cand.joining_date.year) * 12 +
                            (current_month - cand.joining_date.month)
                    )

                    if months_working >= 1:
                        review_exists = ContractPerformanceReview.query.filter_by(
                            candidate_id=cand.id,
                            review_month=current_month,
                            review_year=current_year
                        ).first()

                        if not review_exists:
                            pending_review_count += 1

        return render_template('hm_dashboard.html',
                               positions=positions,
                               contract_employees=contract_employees,
                               pending_review_count=pending_review_count)

    # Recruiter Dashboard
    elif role_name == 'Recruiter':
        positions = Position.query.filter(Position.status.in_(['approved', 'open'])).all()
        return render_template('recruiter_dashboard.html', positions=positions)

    # Interview Panel Dashboard
    elif role_name == 'IP':
        panel_positions = [p.position_id for p in InterviewPanel.query.filter_by(ip_user_id=current_user.id).all()]
        candidates = Candidate.query.join(Interview).filter(
            Candidate.position_id.in_(panel_positions),
            Interview.status == 'scheduled'
        ).all()
        return render_template('ip_dashboard.html', candidates=candidates)

    # Employee Dashboard
    elif role_name == 'Employee':
        # Redirect employees to internal positions page
        return redirect(url_for('internal.open_positions'))

    # Fallback for undefined roles
    else:
        flash(f'Dashboard not configured for role: {role_name}. Please contact administrator.', 'warning')
        log_action(f'User {current_user.username} with role {role_name} tried to access dashboard')
        return redirect(url_for('main.logout'))


# --- Position Management (HM & SA) ---

@main.route('/positions/create', methods=['GET', 'POST'])
@login_required
@role_required('Hiring_Manager')
def create_position():
    if request.method == 'POST':
        title_id = request.form.get('title_id')
        project_name = request.form.get('project_name')
        openings = request.form.get('openings')
        vertical_id = request.form.get('vertical_id')
        position_type = request.form.get('position_type', 'full_time')
        contract_duration = request.form.get('contract_duration') if position_type == 'contract' else None
        jd_file = request.files.get('jd_file')

        # Get interview panel selections (exactly 2)
        ip_user_ids = request.form.getlist('interview_panel')

        if len(ip_user_ids) != 2:
            flash('Please select exactly 2 interview panel members.', 'warning')
            return redirect(request.url)

        if not all([title_id, project_name, openings, vertical_id, jd_file]):
            flash('All fields are required.', 'danger')
            return redirect(request.url)

        from .utils.file_manager import FileManager

        # Create position first to get ID
        position = Position(
            title_id=title_id,
            project_name=project_name,
            openings=int(openings),
            hm_id=current_user.id,
            vertical_id=int(vertical_id),
            status='draft',
            position_type=position_type,
            contract_duration_months=int(contract_duration) if contract_duration else None
        )
        db.session.add(position)
        db.session.flush()

        # Save JD file
        jd_path = FileManager.save_file(jd_file, 'jd', position_id=position.id)
        if jd_path:
            position.jd_file_path = jd_path

            # Analyze JD quality
            try:
                base_path = current_app.config.get('UPLOAD_FOLDER', 'recruitflow/static/uploads')
                jd_full_path = os.path.join(base_path, jd_path)
                jd_text = extract_text_from_docx(jd_full_path)

                clarity_score, clarity_feedback = analyze_jd_quality(jd_text)
                position.jd_clarity_score = clarity_score
                position.jd_clarity_feedback = clarity_feedback

                if clarity_score >= 80:
                    flash(f'JD Quality Score: {clarity_score}/100 - Excellent!', 'success')
                elif clarity_score >= 60:
                    flash(f'JD Quality Score: {clarity_score}/100 - Good. Check feedback for improvements.', 'info')
                else:
                    flash(f'JD Quality Score: {clarity_score}/100 - Needs improvement. Please review feedback.',
                          'warning')

            except Exception as e:
                flash(f'Could not analyze JD quality: {str(e)}', 'warning')

        # Add the 2 selected interview panel members
        for ip_id in ip_user_ids:
            if ip_id:
                panel = InterviewPanel(position_id=position.id, ip_user_id=int(ip_id))
                db.session.add(panel)

        # AUTOMATICALLY ADD VERTICAL HEAD AS 3RD PANEL MEMBER
        vertical = Vertical.query.get(int(vertical_id))
        if vertical and vertical.vertical_head_id:
            vh_panel = InterviewPanel(position_id=position.id, ip_user_id=vertical.vertical_head_id)
            db.session.add(vh_panel)
            flash(f'{vertical.vertical_head.full_name} (Vertical Head) automatically added as 3rd panel member', 'info')
        else:
            flash('Warning: No Vertical Head assigned to this vertical. Only 2 panel members added.', 'warning')

        db.session.commit()

        # Find matching candidates from talent pool
        matching_candidates = find_matching_candidates_enhanced(position)

        log_action(f'Position "{position.position_title.title}" created as {position_type}.',
                   entity_type='Position', entity_id=position.id)

        flash('Position created as a draft.', 'success')

        if matching_candidates:
            flash(f'Found {len(matching_candidates)} matching candidates from talent pool!', 'info')
            return redirect(url_for('main.view_matching_candidates', position_id=position.id))

        return redirect(url_for('main.dashboard'))

    # GET request - prepare data with panel performance metrics
    titles = PositionTitle.query.all()
    verticals = Vertical.query.filter_by(is_active=True).all()

    # Get IP users with performance metrics
    from .models import InterviewerRole
    ip_role = Role.query.filter_by(name='IP').first()
    ip_users = User.query.filter_by(role_id=ip_role.id, is_active=True).all() if ip_role else []

    panel_performance = []
    for ip in ip_users:
        # Get assigned roles from InterviewerRole mapping
        role_mappings = InterviewerRole.query.filter_by(user_id=ip.id).all()
        assigned_roles = ', '.join([rm.role_name for rm in role_mappings]) if role_mappings else ''
        role_badges = [rm.role_name for rm in role_mappings][:3]  # Max 3 badges

        # Current open interviews (scheduled but no feedback yet)
        current_open = db.session.query(Interview).join(Candidate).join(
            InterviewPanel, InterviewPanel.position_id == Candidate.position_id
        ).filter(
            InterviewPanel.ip_user_id == ip.id,
            Interview.status == 'scheduled',
            ~Interview.id.in_(
                db.session.query(InterviewFeedback.interview_id).filter_by(ip_user_id=ip.id)
            )
        ).count()

        # Past interviews (completed with feedback)
        past_interviews = InterviewFeedback.query.filter_by(ip_user_id=ip.id).count()

        # Selection rate (candidates recommended / total feedbacks)
        if past_interviews > 0:
            recommended = InterviewFeedback.query.filter_by(
                ip_user_id=ip.id
            ).filter(
                InterviewFeedback.recommendation.in_(['strongly_recommend', 'recommend'])
            ).count()
            selection_rate = round((recommended / past_interviews) * 100, 1)
        else:
            selection_rate = 0

        panel_performance.append({
            'id': ip.id,
            'full_name': ip.full_name,
            'assigned_roles': assigned_roles,
            'role_badges': role_badges,
            'current_open': current_open,
            'past_interviews': past_interviews,
            'selection_rate': selection_rate
        })

    # Sort by current open (ascending) - prefer less busy interviewers
    panel_performance.sort(key=lambda x: (x['current_open'], -x['past_interviews']))

    return render_template('create_position.html',
                           titles=titles,
                           verticals=verticals,
                           panel_performance=panel_performance)


@main.route('/positions/<int:position_id>/matching-candidates')
@login_required
@role_required('Hiring_Manager')
def view_matching_candidates(position_id):
    """View matching candidates from talent pool for a position"""
    position = Position.query.get_or_404(position_id)

    if position.hm_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('main.dashboard'))

    matching = find_matching_candidates(position)

    return render_template('matching_candidates.html',
                           position=position,
                           candidates=matching)

@main.route('/positions/<int:pos_id>/submit', methods=['POST'])
@login_required
@role_required('Hiring_Manager')
def submit_for_approval(pos_id):
    position = Position.query.get_or_404(pos_id)
    if position.hm_id != current_user.id:
        abort(403)
    position.status = 'pending_approval'
    db.session.commit()
    log_action(f'Position "{position.position_title.title}" submitted for approval.', 
               entity_type='Position', entity_id=pos_id)
    flash('Position submitted for approval.', 'success')
    return redirect(url_for('main.dashboard'))


@main.route('/positions/<int:pos_id>/approve', methods=['POST'])
@login_required
@role_required('Vertical_Head')  # CHANGED from SA
def approve_position(pos_id):
    position = Position.query.get_or_404(pos_id)

    # Verify vertical head can approve this position
    if current_user.role.name == 'Vertical_Head':
        if position.vertical_id != current_user.vertical_id:
            flash('You can only approve positions in your vertical', 'danger')
            return redirect(url_for('main.dashboard'))

    action = request.form.get('action')
    if action == 'approve':
        position.status = 'approved'
        flash('Position has been approved and is now active.', 'success')
        log_action(f'Position "{position.position_title.title}" approved.',
                   entity_type='Position', entity_id=pos_id)
    elif action == 'reject':
        position.status = 'rejected'
        flash('Position has been rejected.', 'warning')
        log_action(f'Position "{position.position_title.title}" rejected.',
                   entity_type='Position', entity_id=pos_id)
    db.session.commit()
    return redirect(url_for('main.dashboard'))


# --- Candidate Management (Recruiter & HM) ---

@main.route('/positions/<int:pos_id>/candidates')
@login_required
def candidate_list(pos_id):
    position = Position.query.get_or_404(pos_id)
    candidates = position.candidates.order_by(Candidate.created_at.desc()).all()
    return render_template('candidate_list.html', position=position, candidates=candidates)


@main.route('/positions/<int:pos_id>/upload_cv', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter')
def upload_cv(pos_id):
    position = Position.query.get_or_404(pos_id)

    if request.method == 'POST':
        cv_file = request.files.get('cv_file')
        if not cv_file or cv_file.filename == '':
            flash('No file selected.', 'danger')
            return redirect(request.url)

        # Validate file extension
        if not cv_file.filename.lower().endswith(('.docx', '.pdf')):
            flash('Invalid file type. Please upload .docx or .pdf files only.', 'danger')
            return redirect(request.url)

        try:
            # Create candidate first to get ID
            candidate = Candidate(
                position_id=pos_id,
                status='applied'
            )
            db.session.add(candidate)
            db.session.flush()  # Get candidate.id

            # Use FileManager for organized storage
            from .utils.file_manager import FileManager
            cv_path = FileManager.save_file(cv_file, 'cv', position_id=pos_id, candidate_id=candidate.id)

            if not cv_path:
                raise ValueError("Failed to save CV file")

            # Get full path for parsing
            base_path = current_app.config.get('UPLOAD_FOLDER', 'recruitflow/static/uploads')
            full_cv_path = os.path.join(base_path, cv_path)

            # Check if JD file exists
            if not position.jd_file_path:
                jd_text = ""
                flash('Warning: Job Description file not found. CV will be processed without similarity matching.',
                      'warning')
            else:
                jd_full_path = os.path.join(base_path, position.jd_file_path)
                if os.path.exists(jd_full_path):
                    jd_text = extract_text_from_docx(jd_full_path)
                else:
                    jd_text = ""
                    flash('Warning: Job Description file not found.', 'warning')

            # Parse CV
            cv_data = parse_cv(full_cv_path, jd_text)

            # Update candidate with parsed data
            candidate.cv_file_path = cv_path
            candidate.name = cv_data.get('name', 'Name not detected')
            candidate.location = cv_data.get('location')
            candidate.phone = cv_data.get('phone')
            candidate.email = cv_data.get('email')
            candidate.linkedin = cv_data.get('linkedin')
            candidate.experience = cv_data.get('experience')
            candidate.key_skills = cv_data.get('key_skills')
            candidate.education = cv_data.get('education')
            candidate.employment_history = cv_data.get('employment_history')
            candidate.similarity_score = cv_data.get('similarity_score')

            # Create pipeline metrics entry
            from .models import PipelineMetrics
            metric = PipelineMetrics(
                candidate_id=candidate.id,
                stage='cv_uploaded',
                entered_at=datetime.utcnow()
            )
            db.session.add(metric)

            db.session.commit()

            log_action(
                f'CV uploaded for candidate "{candidate.name}" to position "{position.position_title.title}".',
                entity_type='Candidate', entity_id=candidate.id)

            flash(
                f'CV processed successfully! Candidate {cv_data["name"]} added with match score of {cv_data["similarity_score"]:.2f}%.',
                'success')
            return redirect(url_for('main.candidate_list', pos_id=pos_id))

        except Exception as e:
            db.session.rollback()
            flash(f'Error processing CV: {str(e)}', 'danger')
            return redirect(request.url)

    # GET request - show matching candidates from talent pool and silver medalists
    from .models import TalentPool

    # Get matching candidates
    matching_candidates = find_matching_candidates_enhanced(position)

    # Get talent pool IDs for badge display
    talent_pool_ids = [tp.candidate_id for tp in TalentPool.query.all()]

    return render_template('upload_cv.html',
                           position=position,
                           matching_candidates=matching_candidates,
                           talent_pool_ids=talent_pool_ids)


def find_matching_candidates_enhanced(position):
    """Enhanced matching with better scoring"""
    from .models import TalentPool
    import re

    # Get silver medalists and talent pool candidates
    potential_candidates = Candidate.query.filter(
        db.or_(
            Candidate.is_silver == True,
            Candidate.id.in_(
                db.session.query(TalentPool.candidate_id)
            )
        )
    ).all()

    if not potential_candidates:
        return []

    position_title = position.position_title.title.lower()
    position_title_words = set(re.findall(r'\w+', position_title))

    # Score each candidate
    scored_candidates = []
    for candidate in potential_candidates:
        score = 0
        candidate_skills = (candidate.key_skills or '').lower()
        candidate_skills_words = set(re.findall(r'\w+', candidate_skills))

        # Title keyword matching (30 points)
        title_matches = len(position_title_words & candidate_skills_words)
        score += min(title_matches * 10, 30)

        # Similarity score (40 points)
        if candidate.similarity_score:
            score += (candidate.similarity_score / 100) * 40

        # Experience match (20 points)
        if candidate.experience:
            # Prefer candidates with relevant experience
            if 2 <= candidate.experience <= 8:
                score += 20
            elif candidate.experience > 8:
                score += 15
            else:
                score += 10

        # Silver medalist bonus (10 points)
        if candidate.is_silver:
            score += 10

        if score >= 30:  # Only include candidates with 30+ score
            scored_candidates.append((candidate, score))

    # Sort by score descending and return top 10
    scored_candidates.sort(key=lambda x: x[1], reverse=True)
    return [c[0] for c in scored_candidates[:10]]

@main.route('/candidates/<int:cand_id>/review', methods=['POST'])
@login_required
@role_required('Hiring_Manager')
def hm_review(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    action = request.form.get('action')
    if action == 'accept':
        candidate.status = 'under_hm_review'
        flash('Candidate accepted for the next round.', 'success')
    else:
        candidate.status = 'rejected_by_hm'
        flash('Candidate has been rejected.', 'info')
    db.session.commit()
    log_action(f'HM reviewed candidate "{candidate.name}" with action: {action}.', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- Test Allocation & Updates (MISSING ROUTES - NOW ADDED) ---

@main.route('/candidates/<int:cand_id>/allocate_test', methods=['POST'])
@login_required
@role_required('Recruiter')
def allocate_test(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    candidate.status = 'test_allocated'
    db.session.commit()
    
    flash(f'Test allocated to {candidate.name}. Update status after completion.', 'success')
    log_action(f'Test allocated to candidate "{candidate.name}".', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


@main.route('/candidates/<int:cand_id>/update_test', methods=['POST'])
@login_required
@role_required('Recruiter')
def update_test(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    status = request.form.get('status')
    score = request.form.get('score')
    
    if status == 'passed':
        candidate.status = 'test_passed'
        if score:
            candidate.test_score = float(score)
        flash(f'{candidate.name} passed the test! Ready for interview.', 'success')
    elif status == 'failed':
        candidate.status = 'test_failed'
        if score:
            candidate.test_score = float(score)
        flash(f'{candidate.name} did not pass the test.', 'info')
    
    db.session.commit()
    log_action(f'Test status updated for candidate "{candidate.name}": {status}.', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- Interview & Feedback ---

@main.route('/candidates/<int:cand_id>/schedule_interview', methods=['POST'])
@login_required
@role_required('Recruiter')
def schedule_interview(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    schedule_date_str = request.form.get('date')
    
    # Convert string to date object
    from datetime import datetime
    try:
        schedule_date = datetime.strptime(schedule_date_str, '%Y-%m-%d').date()
    except ValueError:
        flash('Invalid date format', 'danger')
        return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))

    interview = Interview(
        candidate_id=cand_id, 
        schedule_date=schedule_date,
        schedule_time=request.form.get('time', '10:00 AM'),
        interview_mode='Video',
        status='scheduled'
    )
    candidate.status = 'interview'
    db.session.add(interview)
    db.session.commit()
    
    flash(f'Interview scheduled for {candidate.name} on {schedule_date.strftime("%d %b %Y")}', 'success')
    log_action(f'Interview scheduled for candidate "{candidate.name}".', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


@main.route('/interviews/<int:interview_id>/feedback', methods=['GET', 'POST'])
@login_required
@role_required('IP')
def provide_feedback(interview_id):
    interview = Interview.query.get_or_404(interview_id)
    candidate = interview.candidate

    # Check if this IP has already submitted feedback
    existing_feedback = InterviewFeedback.query.filter_by(
        interview_id=interview_id,
        ip_user_id=current_user.id
    ).first()

    if existing_feedback:
        flash('You have already submitted feedback for this interview.', 'info')
        return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        # Get all ratings
        technical_rating = int(request.form.get('technical_rating'))
        communication_rating = int(request.form.get('communication_rating'))
        problem_solving_rating = int(request.form.get('problem_solving_rating'))
        cultural_fit_rating = int(request.form.get('cultural_fit_rating'))
        team_collaboration_rating = int(request.form.get('team_collaboration_rating'))

        # Calculate overall rating
        overall_rating = (technical_rating + communication_rating + problem_solving_rating +
                          cultural_fit_rating + team_collaboration_rating) / 5

        recommendation = request.form.get('recommendation')
        strengths = request.form.get('strengths')
        areas_of_concern = request.form.get('areas_of_concern')
        comments = request.form.get('comments')

        feedback = InterviewFeedback(
            interview_id=interview_id,
            ip_user_id=current_user.id,
            technical_rating=technical_rating,
            communication_rating=communication_rating,
            problem_solving_rating=problem_solving_rating,
            cultural_fit_rating=cultural_fit_rating,
            team_collaboration_rating=team_collaboration_rating,
            overall_rating=overall_rating,
            recommendation=recommendation,
            strengths=strengths,
            areas_of_concern=areas_of_concern,
            comments=comments,
            rating=int(overall_rating)
        )
        db.session.add(feedback)

        # Get all panel members
        position = candidate.position
        panel_members = InterviewPanel.query.filter_by(position_id=position.id).all()
        panel_member_ids = [p.ip_user_id for p in panel_members]

        # Get all feedback submissions
        all_feedbacks = InterviewFeedback.query.filter_by(interview_id=interview_id).all()
        feedback_submitters = [f.ip_user_id for f in all_feedbacks] + [current_user.id]

        # ===== KEY FIX: Check if first 2 panel members (non-VH) have submitted =====
        # Get vertical head ID
        vertical_head_id = position.vertical.vertical_head_id if position.vertical else None

        # Separate VH from regular panel members
        regular_panel_ids = [pid for pid in panel_member_ids if pid != vertical_head_id]

        # Check if the first 2 regular panel members have submitted
        regular_feedback_count = len(
            [f for f in feedback_submitters if f in regular_panel_ids and f != vertical_head_id])

        if regular_feedback_count == 2 and len(regular_panel_ids) == 2:
            # First 2 panel members have submitted - time to notify about VH interview
            all_feedbacks_including_new = all_feedbacks + [feedback]
            avg_overall = sum(f.overall_rating for f in all_feedbacks_including_new) / len(all_feedbacks_including_new)

            strong_recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'strongly_recommend')
            recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'recommend')
            do_not_recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'do_not_recommend')

            # If candidate passed first 2 interviews, mark for VH interview
            if avg_overall >= 3.5 and (strong_recommends + recommends) > do_not_recommends:
                candidate.status = 'awaiting_vh_interview'
                flash(
                    f'First 2 panel interviews complete! {candidate.name} PASSED (Avg Score: {avg_overall:.1f}/5). Ready for Vertical Head interview.',
                    'success')
            else:
                candidate.status = 'interview_rejected'
                interview.status = 'completed'
                flash(f'All feedback received. {candidate.name} did not pass (Avg Score: {avg_overall:.1f}/5)', 'info')

        # Check if ALL panel members including VH have submitted
        elif set(panel_member_ids).issubset(set(feedback_submitters)):
            interview.status = 'completed'

            # Calculate final decision
            all_feedbacks_including_new = all_feedbacks + [feedback]
            avg_overall = sum(f.overall_rating for f in all_feedbacks_including_new) / len(all_feedbacks_including_new)

            strong_recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'strongly_recommend')
            recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'recommend')
            do_not_recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'do_not_recommend')

            if avg_overall >= 3.5 and (strong_recommends + recommends) > do_not_recommends:
                candidate.status = 'interview_passed'
                flash(f'All feedback received (including VH). {candidate.name} PASSED (Avg Score: {avg_overall:.1f}/5)',
                      'success')
            else:
                candidate.status = 'interview_rejected'
                flash(f'All feedback received. {candidate.name} did not pass (Avg Score: {avg_overall:.1f}/5)', 'info')
        else:
            flash('Your feedback has been submitted. Waiting for other panel members.', 'success')

        db.session.commit()
        log_action(f'Feedback submitted for interview {interview_id} by {current_user.username}.',
                   entity_type='Interview', entity_id=interview_id)

        return redirect(url_for('main.dashboard'))

    return render_template('feedback_form.html', interview=interview, candidate=candidate)


@main.route('/candidates/<int:cand_id>/notes', methods=['POST'])
@login_required
@role_required('Recruiter', 'Hiring_Manager')
def add_note(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    note_text = request.form.get('note_text')
    if not note_text:
        flash('Note cannot be empty.', 'warning')
    else:
        note = CandidateNote(
            candidate_id=cand_id,
            author_id=current_user.id,
            note=note_text
        )
        db.session.add(note)
        db.session.commit()
        flash('Note added successfully.', 'success')
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- File Downloads & Miscellaneous ---

@main.route('/uploads/<path:filename>')
@login_required
def download_file(filename):
    """Serve uploaded files"""
    try:
        upload_folder = current_app.config['UPLOAD_FOLDER']
        return send_from_directory(upload_folder, filename, as_attachment=True)
    except Exception as e:
        flash(f'Error downloading file: {str(e)}', 'danger')
        return redirect(request.referrer or url_for('main.dashboard'))


@main.route('/silver_medalists')
@login_required
@role_required('Hiring_Manager', 'Recruiter')
def silver_medalists():
    candidates = Candidate.query.filter_by(is_silver=True).all()
    return render_template('silver_medalists.html', candidates=candidates)


# --- Reporting (ADDED) ---

@main.route('/reporting')
@login_required
@role_required('Admin','CEO')
def reporting():
    """Reporting dashboard for SA"""
    # Position stats
    positions_by_status = db.session.query(
        Position.status,
        db.func.count(Position.id)
    ).group_by(Position.status).all()
    
    # Candidate stats
    candidates_by_status = db.session.query(
        Candidate.status,
        db.func.count(Candidate.id)
    ).group_by(Candidate.status).all()
    
    # Aggregate metrics
    open_positions = Position.query.filter(Position.status.in_(['approved', 'open'])).count()
    total_candidates = Candidate.query.count()
    candidates_in_interview = Candidate.query.filter_by(status='interview').count()
    # Salary proposals pending CEO approval
    from .models import SalaryProposal
    pending_salaries = SalaryProposal.query.filter_by(status='pending').count()

    avg_similarity = db.session.query(db.func.avg(Candidate.similarity_score)).scalar() or 0
    
    return render_template('reporting.html',
                          positions_by_status=positions_by_status,
                          candidates_by_status=candidates_by_status,
                          open_positions=open_positions,
                          total_candidates=total_candidates,
                          candidates_in_interview=candidates_in_interview,
                          pending_salaries=pending_salaries,
                          avg_similarity=round(avg_similarity, 2))


# --- Audit Logs (ADDED) ---

@main.route('/audit_logs')
@login_required
@role_required('Admin')
def audit_logs():
    """View audit logs"""
    from .models import AuditLog
    page = request.args.get('page', 1, type=int)
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=50)
    return render_template('admin/audit_log.html', logs=logs)


# --- Export Routes ---

@main.route('/export/positions')
@login_required
@role_required('Admin', 'Hiring_Manager')
def export_positions():
    """Export positions to CSV"""
    import csv
    from io import StringIO
    from flask import Response
    
    # Get positions based on role
    if current_user.role.name == 'Hiring_Manager':
        positions = Position.query.filter_by(hm_id=current_user.id).all()
    else:
        positions = Position.query.all()
    
    # Create CSV
    si = StringIO()
    writer = csv.writer(si)
    
    # Write header
    writer.writerow([
        'ID', 'Title', 'Project', 'Openings', 'Status', 
        'Hiring Manager', 'Total Candidates', 'Created Date'
    ])
    
    # Write data
    for pos in positions:
        writer.writerow([
            pos.id,
            pos.position_title.title if pos.position_title else '',
            pos.project_name,
            pos.openings,
            pos.status,
            pos.hiring_manager.username if pos.hiring_manager else '',
            pos.candidates.count(),
            pos.created_at.strftime('%Y-%m-%d')
        ])
    
    # Create response
    output = si.getvalue()
    si.close()
    
    from datetime import datetime
    filename = f'positions_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    return Response(
        output,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename={filename}'}
    )


# --- Schedule Interviews Overview ---

@main.route('/schedule-interviews')
@login_required
@role_required('Hiring_Manager', 'Recruiter')
def schedule_interviews():
    """View all candidates ready for interview"""
    if current_user.role.name == 'Hiring_Manager':
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        candidates = Candidate.query.filter(
            Candidate.position_id.in_(position_ids),
            Candidate.status == 'test_passed'
        ).all()
    else:
        candidates = Candidate.query.filter_by(status='test_passed').all()
    
    return render_template('schedule_interviews.html', candidates=candidates)


# --- Onboarding Overview ---

@main.route('/onboarding-overview')
@login_required
@role_required('Hiring_Manager', 'Recruiter', 'Admin')
def onboarding_overview():
    """View all candidates in onboarding"""
    from .models import OnboardingTask
    
    # Get candidates with joining dates
    if current_user.role.name == 'Hiring_Manager':
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        candidates = Candidate.query.filter(
            Candidate.position_id.in_(position_ids),
            Candidate.joining_date.isnot(None)
        ).all()
    else:
        candidates = Candidate.query.filter(
            Candidate.joining_date.isnot(None)
        ).all()
    
    # Get task counts for each candidate
    candidate_tasks = []
    for cand in candidates:
        tasks = OnboardingTask.query.filter_by(candidate_id=cand.id).all()
        completed = len([t for t in tasks if t.status == 'completed'])
        total = len(tasks)
        
        candidate_tasks.append({
            'candidate': cand,
            'total_tasks': total,
            'completed_tasks': completed,
            'completion_percentage': round((completed / total * 100) if total > 0 else 0, 1)
        })
    
    return render_template('onboarding_overview.html', candidate_tasks=candidate_tasks)

@main.route('/export/candidates')
@login_required
@role_required('Admin', 'Recruiter', 'Hiring_Manager')
def export_candidates():
    """Export candidates to CSV"""
    import csv
    from io import StringIO
    from flask import Response
    
    # Get candidates based on role
    if current_user.role.name == 'Hiring_Manager':
        # HM can see candidates from their positions
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        candidates = Candidate.query.filter(Candidate.position_id.in_(position_ids)).all()
    else:
        candidates = Candidate.query.all()
    
    # Create CSV
    si = StringIO()
    writer = csv.writer(si)
    
    # Write header
    writer.writerow([
        'ID', 'Name', 'Email', 'Phone', 'Location', 'Experience (Years)',
        'Key Skills', 'Education', 'Position', 'Similarity Score (%)',
        'Status', 'Test Score', 'Created Date'
    ])
    
    # Write data
    for cand in candidates:
        writer.writerow([
            cand.id,
            cand.name,
            cand.email,
            cand.phone,
            cand.location,
            cand.experience,
            cand.key_skills,
            cand.education,
            cand.position.position_title.title if cand.position and cand.position.position_title else '',
            round(cand.similarity_score, 2) if cand.similarity_score else 0,
            cand.status,
            cand.test_score if cand.test_score else '',
            cand.created_at.strftime('%Y-%m-%d')
        ])
    
    # Create response
    output = si.getvalue()
    si.close()
    
    from datetime import datetime
    filename = f'candidates_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    return Response(
        output,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename={filename}'}
    )


@main.route('/candidates/<int:cand_id>/view-feedback')
@login_required
@role_required('Hiring_Manager', 'Recruiter', 'Vertical_Head', 'CEO')
def view_candidate_feedback(cand_id):
    """View all interview feedback for a candidate"""
    candidate = Candidate.query.get_or_404(cand_id)

    # Check access permissions
    if current_user.role.name == 'HM':
        if candidate.position.hm_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('main.dashboard'))
    elif current_user.role.name == 'Vertical Head':
        if candidate.position.vertical_id != current_user.vertical_id:
            flash('Access denied', 'danger')
            return redirect(url_for('vertical_head.dashboard'))

    # Get all interviews and feedback
    interviews = Interview.query.filter_by(candidate_id=cand_id).all()

    # Collect all feedback with interviewer details
    all_feedback = []
    for interview in interviews:
        feedbacks = InterviewFeedback.query.filter_by(interview_id=interview.id).all()
        for feedback in feedbacks:
            all_feedback.append({
                'interview': interview,
                'feedback': feedback,
                'interviewer': feedback.interviewer
            })

    # Calculate aggregate statistics
    if all_feedback:
        avg_technical = sum(f['feedback'].technical_rating for f in all_feedback) / len(all_feedback)
        avg_communication = sum(f['feedback'].communication_rating for f in all_feedback) / len(all_feedback)
        avg_problem_solving = sum(f['feedback'].problem_solving_rating for f in all_feedback) / len(all_feedback)
        avg_cultural_fit = sum(f['feedback'].cultural_fit_rating for f in all_feedback) / len(all_feedback)
        avg_team_collaboration = sum(f['feedback'].team_collaboration_rating for f in all_feedback) / len(all_feedback)
        avg_overall = sum(f['feedback'].overall_rating for f in all_feedback) / len(all_feedback)

        # Count recommendations
        recommendations = {
            'strongly_recommend': sum(1 for f in all_feedback if f['feedback'].recommendation == 'strongly_recommend'),
            'recommend': sum(1 for f in all_feedback if f['feedback'].recommendation == 'recommend'),
            'neutral': sum(1 for f in all_feedback if f['feedback'].recommendation == 'neutral'),
            'do_not_recommend': sum(1 for f in all_feedback if f['feedback'].recommendation == 'do_not_recommend')
        }
    else:
        avg_technical = avg_communication = avg_problem_solving = avg_cultural_fit = avg_team_collaboration = avg_overall = 0
        recommendations = {'strongly_recommend': 0, 'recommend': 0, 'neutral': 0, 'do_not_recommend': 0}

    return render_template('view_feedback.html',
                           candidate=candidate,
                           all_feedback=all_feedback,
                           avg_technical=round(avg_technical, 2),
                           avg_communication=round(avg_communication, 2),
                           avg_problem_solving=round(avg_problem_solving, 2),
                           avg_cultural_fit=round(avg_cultural_fit, 2),
                           avg_team_collaboration=round(avg_team_collaboration, 2),
                           avg_overall=round(avg_overall, 2),
                           recommendations=recommendations)


# Add this route to main_routes.py

@main.route('/interviewer-performance')
@login_required
@role_required('Recruiter', 'Admin', 'CEO')
def interviewer_performance():
    """View interviewer performance metrics"""
    from .models import InterviewerRole

    # Get all IP users
    ip_role = Role.query.filter_by(name='IP').first()
    interviewers = User.query.filter_by(role_id=ip_role.id, is_active=True).all() if ip_role else []

    interviewer_stats = {}

    for interviewer in interviewers:
        # Get assigned roles
        role_mappings = InterviewerRole.query.filter_by(user_id=interviewer.id).all()
        assigned_roles = ', '.join([rm.role_name for rm in role_mappings]) if role_mappings else 'Not mapped'

        # Current open interviews (scheduled, no feedback yet)
        current_open = db.session.query(Interview).join(Candidate).join(
            InterviewPanel, InterviewPanel.position_id == Candidate.position_id
        ).filter(
            InterviewPanel.ip_user_id == interviewer.id,
            Interview.status == 'scheduled',
            ~Interview.id.in_(
                db.session.query(InterviewFeedback.interview_id).filter_by(ip_user_id=interviewer.id)
            )
        ).count()

        # Pending feedback count
        pending = current_open

        # Total assigned interviews (all time)
        assigned = db.session.query(Interview).join(Candidate).join(
            InterviewPanel, InterviewPanel.position_id == Candidate.position_id
        ).filter(
            InterviewPanel.ip_user_id == interviewer.id
        ).count()

        # Completed interviews (with feedback)
        completed = InterviewFeedback.query.filter_by(ip_user_id=interviewer.id).count()

        # Average rating given by this interviewer
        avg_rating_query = db.session.query(
            func.avg(InterviewFeedback.overall_rating)
        ).filter_by(ip_user_id=interviewer.id).scalar()

        avg_rating = round(avg_rating_query, 1) if avg_rating_query else 0

        # Selection rate (recommended / total feedbacks)
        if completed > 0:
            recommended = InterviewFeedback.query.filter_by(
                ip_user_id=interviewer.id
            ).filter(
                InterviewFeedback.recommendation.in_(['strongly_recommend', 'recommend'])
            ).count()
            selection_rate = round((recommended / completed) * 100, 1)
        else:
            selection_rate = 0

        # Feedback submission rate
        if assigned > 0:
            feedback_rate = round((completed / assigned) * 100, 1)
        else:
            feedback_rate = 0

        interviewer_stats[interviewer.id] = {
            'assigned_roles': assigned_roles,
            'assigned': assigned,
            'pending': pending,
            'completed': completed,
            'current_open': current_open,
            'avg_rating': avg_rating,
            'selection_rate': selection_rate,
            'feedback_rate': feedback_rate
        }

    return render_template('recruiter/interviewer_performance.html',
                           interviewers=interviewers,
                           interviewer_stats=interviewer_stats)


@main.route('/candidates/<int:cand_id>/detail')
@login_required
@role_required('Recruiter', 'Hiring_Manager', 'Vertical_Head', 'CEO', 'Admin', 'IP')
def candidate_detail(cand_id):
    """Comprehensive candidate profile view"""
    candidate = Candidate.query.get_or_404(cand_id)

    # Security check based on role
    if current_user.role.name == 'Hiring_Manager':
        if candidate.position.hm_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('main.dashboard'))
    elif current_user.role.name == 'Vertical_Head':
        if candidate.position.vertical_id != current_user.vertical_id:
            flash('Access denied', 'danger')
            return redirect(url_for('vertical_head.dashboard'))
    elif current_user.role.name == 'IP':
        # Check if IP is on the interview panel for this position
        panel_member = InterviewPanel.query.filter_by(
            position_id=candidate.position_id,
            ip_user_id=current_user.id
        ).first()
        if not panel_member:
            flash('Access denied', 'danger')
            return redirect(url_for('main.dashboard'))

    # Get all related data
    interviews = Interview.query.filter_by(candidate_id=cand_id).all()

    # Get all feedbacks
    feedbacks = []
    for interview in interviews:
        feedbacks.extend(InterviewFeedback.query.filter_by(interview_id=interview.id).all())

    # Sort feedbacks by date
    feedbacks.sort(key=lambda x: x.created_at if x.created_at else datetime.min, reverse=True)

    # Get salary proposals
    proposals = SalaryProposal.query.filter_by(
        candidate_id=cand_id
    ).order_by(SalaryProposal.version.desc()).all()

    # Get background checks
    bgv_checks = BackgroundCheck.query.filter_by(candidate_id=cand_id).all()

    # Get reference checks
    references = ReferenceCheck.query.filter_by(candidate_id=cand_id).all()

    # Get notes
    notes = CandidateNote.query.filter_by(
        candidate_id=cand_id
    ).order_by(CandidateNote.created_at.desc()).all()

    return render_template('candidate_detail.html',
                           candidate=candidate,
                           interviews=interviews,
                           feedbacks=feedbacks,
                           proposals=proposals,
                           bgv_checks=bgv_checks,
                           references=references,
                           notes=notes)


@main.route('/candidates/<int:cand_id>/schedule_vh_interview', methods=['POST'])
@login_required
@role_required('Recruiter')
def schedule_vh_interview(cand_id):
    """Schedule interview with Vertical Head"""
    candidate = Candidate.query.get_or_404(cand_id)
    schedule_date_str = request.form.get('date')

    from datetime import datetime
    try:
        schedule_date = datetime.strptime(schedule_date_str, '%Y-%m-%d').date()
    except ValueError:
        flash('Invalid date format', 'danger')
        return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))

    # Create interview for VH
    interview = Interview(
        candidate_id=cand_id,
        schedule_date=schedule_date,
        schedule_time=request.form.get('time', '10:00 AM'),
        interview_mode='Video',
        status='scheduled'
    )
    candidate.status = 'vh_interview_scheduled'
    db.session.add(interview)
    db.session.commit()

    flash(f'Vertical Head interview scheduled for {candidate.name} on {schedule_date.strftime("%d %b %Y")}', 'success')
    log_action(f'VH interview scheduled for candidate "{candidate.name}".',
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# Add this route to main_routes.py for IP users

@main.route('/my-performance')
@login_required
@role_required('IP')
def my_performance():
    """Interviewer's personal performance dashboard"""

    # Get all interviews assigned to this interviewer
    assigned_interviews = db.session.query(Interview).join(Candidate).join(
        InterviewPanel, InterviewPanel.position_id == Candidate.position_id
    ).filter(
        InterviewPanel.ip_user_id == current_user.id
    ).all()

    # Pending interviews (scheduled, no feedback yet)
    pending_interviews = db.session.query(Interview).join(Candidate).join(
        InterviewPanel, InterviewPanel.position_id == Candidate.position_id
    ).filter(
        InterviewPanel.ip_user_id == current_user.id,
        Interview.status == 'scheduled',
        ~Interview.id.in_(
            db.session.query(InterviewFeedback.interview_id).filter_by(ip_user_id=current_user.id)
        )
    ).all()

    # Completed interviews with feedback
    completed_feedbacks = InterviewFeedback.query.filter_by(
        ip_user_id=current_user.id
    ).order_by(InterviewFeedback.created_at.desc()).all()

    # Calculate statistics
    total_assigned = len(assigned_interviews)
    total_completed = len(completed_feedbacks)
    total_pending = len(pending_interviews)

    # Average rating given
    if completed_feedbacks:
        avg_rating = sum(f.overall_rating for f in completed_feedbacks) / len(completed_feedbacks)
    else:
        avg_rating = 0

    # Recommendation breakdown
    strong_recommends = sum(1 for f in completed_feedbacks if f.recommendation == 'strongly_recommend')
    recommends = sum(1 for f in completed_feedbacks if f.recommendation == 'recommend')
    neutrals = sum(1 for f in completed_feedbacks if f.recommendation == 'neutral')
    do_not_recommends = sum(1 for f in completed_feedbacks if f.recommendation == 'do_not_recommend')

    # Get detailed feedback with candidate info
    detailed_feedbacks = []
    for feedback in completed_feedbacks[:20]:  # Last 20 feedbacks
        interview = Interview.query.get(feedback.interview_id)
        if interview:
            candidate = Candidate.query.get(interview.candidate_id)
            position = candidate.position if candidate else None
            detailed_feedbacks.append({
                'feedback': feedback,
                'interview': interview,
                'candidate': candidate,
                'position': position
            })

    # Get pending interview details
    pending_details = []
    for interview in pending_interviews:
        candidate = Candidate.query.get(interview.candidate_id)
        position = candidate.position if candidate else None
        pending_details.append({
            'interview': interview,
            'candidate': candidate,
            'position': position
        })

    return render_template(
        'ip_performance.html',
        total_assigned=total_assigned,
        total_completed=total_completed,
        total_pending=total_pending,
        avg_rating=avg_rating,
        strong_recommends=strong_recommends,
        recommends=recommends,
        neutrals=neutrals,
        do_not_recommends=do_not_recommends,
        detailed_feedbacks=detailed_feedbacks,
        pending_details=pending_details
    )