# recruitflow/cv_parser.py (FIXED)
import docx
import pdfplumber
import re
import spacy
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

nlp = spacy.load("en_core_web_sm")

def extract_text_from_docx(file_path):
    """Extract text from DOCX file with error handling"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    try:
        doc = docx.Document(file_path)
        return " ".join([para.text for para in doc.paragraphs])
    except Exception as e:
        raise Exception(f"Error reading DOCX file: {str(e)}")

def extract_text_from_pdf(file_path):
    """Extract text from PDF file with error handling"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    try:
        text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        return text
    except Exception as e:
        raise Exception(f"Error reading PDF file: {str(e)}")


def extract_fields(text):
    """Extract candidate information from CV text with intelligent skill extraction"""
    doc = nlp(text)
    fields = {
        'name': '',
        'location': '',
        'phone': '',
        'email': '',
        'linkedin': '',
        'experience': 0.0,
        'key_skills': '',
        'education': '',
        'employment_history': ''
    }

    # Simple regex for common fields
    email_regex = re.compile(r'[\w\.-]+@[\w\.-]+')
    phone_regex = re.compile(r'(\+?\d{1,3}[-.\s]?)?(\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}')
    linkedin_regex = re.compile(r'(linkedin\.com/in/[\w\-]+)')
    experience_regex = re.compile(r'(\d+)\s*(years?|yrs?)(\s*of\s*experience)?', re.I)

    fields['email'] = email_regex.search(text).group() if email_regex.search(text) else ''
    fields['phone'] = phone_regex.search(text).group() if phone_regex.search(text) else ''
    fields['linkedin'] = linkedin_regex.search(text).group() if linkedin_regex.search(text) else ''
    match = experience_regex.search(text)
    if match:
        fields['experience'] = float(match.group(1))

    # Use spaCy for NER
    persons_found = []
    for ent in doc.ents:
        if ent.label_ == 'PERSON':
            persons_found.append(ent.text)
        elif ent.label_ == 'GPE':
            fields['location'] += ent.text + ', '
        elif ent.label_ == 'ORG':
            fields['employment_history'] += ent.text + ', '

    # Take first person name found (usually candidate name)
    if persons_found:
        fields['name'] = persons_found[0]

    # ENHANCED: Intelligent skill extraction
    fields['key_skills'] = extract_top_skills(text)

    # Clean up
    fields['location'] = fields['location'].strip(', ') or 'Not specified'
    fields['employment_history'] = fields['employment_history'].strip(', ') or 'Not specified'
    fields['education'] = 'Not specified'  # Placeholder - enhance as needed

    return fields


def extract_top_skills(text):
    """
    Intelligently extract top 5-10 skills from CV text
    Uses comprehensive skill database with scoring
    """
    text_lower = text.lower()

    # Comprehensive skill database with categories
    skill_database = {
        # Programming Languages
        'python': 5, 'java': 5, 'javascript': 5, 'typescript': 4, 'c++': 4, 'c#': 4,
        'go': 4, 'golang': 4, 'rust': 4, 'kotlin': 4, 'swift': 4, 'ruby': 4, 'php': 4,
        'scala': 4, 'r': 3, 'matlab': 3, 'perl': 3,

        # Web Technologies
        'react': 5, 'angular': 5, 'vue': 4, 'vue.js': 4, 'node.js': 5, 'nodejs': 5,
        'express': 4, 'django': 5, 'flask': 4, 'spring boot': 5, 'spring': 4,
        'asp.net': 4, '.net': 4, 'html': 3, 'css': 3, 'sass': 3, 'less': 3,
        'bootstrap': 3, 'tailwind': 3, 'next.js': 4, 'nuxt': 4, 'gatsby': 3,

        # Databases
        'sql': 4, 'mysql': 4, 'postgresql': 5, 'mongodb': 5, 'redis': 4,
        'oracle': 4, 'sql server': 4, 'cassandra': 4, 'dynamodb': 4, 'elasticsearch': 4,
        'neo4j': 3, 'couchdb': 3, 'firebase': 3,

        # Cloud & DevOps
        'aws': 5, 'azure': 5, 'gcp': 5, 'google cloud': 5, 'docker': 5, 'kubernetes': 5,
        'jenkins': 4, 'ci/cd': 4, 'terraform': 5, 'ansible': 4, 'chef': 3, 'puppet': 3,
        'cloudformation': 4, 'helm': 3, 'vagrant': 3, 'grafana': 4, 'prometheus': 4,

        # Data Science & ML
        'machine learning': 5, 'deep learning': 5, 'tensorflow': 5, 'pytorch': 5,
        'scikit-learn': 4, 'pandas': 5, 'numpy': 4, 'keras': 4, 'nlp': 5,
        'computer vision': 5, 'data analysis': 4, 'data science': 5, 'statistics': 4,
        'tableau': 4, 'power bi': 4, 'powerbi': 4, 'looker': 3, 'qlikview': 3,

        # Mobile
        'android': 4, 'ios': 4, 'react native': 5, 'flutter': 5, 'xamarin': 3,
        'ionic': 3, 'cordova': 3,

        # Methodologies
        'agile': 4, 'scrum': 4, 'kanban': 3, 'devops': 5, 'microservices': 5,
        'rest api': 4, 'restful': 4, 'graphql': 4, 'soap': 3, 'grpc': 3,
        'tdd': 3, 'bdd': 3, 'ci/cd': 4,

        # Version Control & Tools
        'git': 4, 'github': 3, 'gitlab': 3, 'bitbucket': 3, 'jira': 3, 'confluence': 3,
        'postman': 3, 'swagger': 3,

        # Security
        'security': 3, 'oauth': 4, 'jwt': 4, 'ssl': 3, 'encryption': 3, 'penetration testing': 4,

        # Others
        'linux': 4, 'unix': 3, 'bash': 3, 'shell scripting': 3, 'apache': 3,
        'nginx': 4, 'tomcat': 3, 'websocket': 3, 'rabbitmq': 4, 'kafka': 5,
        'spark': 4, 'hadoop': 4, 'etl': 4, 'data warehousing': 4, 'bi': 3
    }

    # Find all skills mentioned in text
    found_skills = {}
    for skill, weight in skill_database.items():
        # Use word boundaries for exact matching
        pattern = r'\b' + re.escape(skill) + r'\b'
        if re.search(pattern, text_lower):
            # Count occurrences for importance
            occurrences = len(re.findall(pattern, text_lower))
            found_skills[skill] = weight * occurrences

    # Sort by score and get top 5-10
    sorted_skills = sorted(found_skills.items(), key=lambda x: x[1], reverse=True)

    # Get top skills (between 5 and 10)
    top_count = min(10, max(5, len(sorted_skills)))
    top_skills = [skill for skill, score in sorted_skills[:top_count]]

    if not top_skills:
        return 'Skills not detected'

    # Format nicely with proper capitalization
    formatted_skills = []
    for skill in top_skills:
        # Capitalize properly
        if skill in ['aws', 'gcp', 'ios', 'api', 'sql', 'nlp', 'tdd', 'bdd', 'jwt', 'ssl', 'etl', 'bi']:
            formatted_skills.append(skill.upper())
        elif '.' in skill:
            formatted_skills.append(skill)
        else:
            formatted_skills.append(skill.title())

    return ', '.join(formatted_skills)

def calculate_similarity(jd_text, cv_text):
    """
    Enhanced similarity calculation with multi-faceted matching
    Returns: similarity score (0-100)
    """
    try:
        if not jd_text or not cv_text or len(jd_text) < 50 or len(cv_text) < 50:
            return 50.0

        # 1. TF-IDF Cosine Similarity (40% weight)
        vectorizer = TfidfVectorizer(
            max_features=500,
            stop_words='english',
            ngram_range=(1, 2),  # Include bigrams
            min_df=1
        )
        try:
            vectors = vectorizer.fit_transform([jd_text, cv_text])
            tfidf_similarity = cosine_similarity(vectors[0:1], vectors[1:2])[0][0]
        except:
            tfidf_similarity = 0.5

        # 2. Skill-based matching (30% weight)
        skill_database = {
            # Programming Languages
            'python': 5, 'java': 5, 'javascript': 5, 'typescript': 4, 'c++': 4, 'c#': 4,
            'ruby': 3, 'php': 3, 'swift': 4, 'kotlin': 4, 'scala': 3, 'go': 4, 'rust': 4,

            # Web Technologies
            'react': 5, 'angular': 4, 'vue': 4, 'node.js': 5, 'express': 4, 'django': 4,
            'flask': 3, 'spring': 4, 'asp.net': 3, 'html': 2, 'css': 2, 'bootstrap': 2,

            # Databases
            'sql': 4, 'mysql': 4, 'postgresql': 4, 'mongodb': 4, 'oracle': 4, 'redis': 4,
            'elasticsearch': 4, 'cassandra': 3, 'dynamodb': 3,

            # Cloud & DevOps
            'openshift': 5, 'redhat': 5, 'kafka': 5, 'docker': 5, 'kubernetes': 5, 'jenkins': 4,
            'terraform': 4, 'ansible': 3, 'ci/cd': 4, 'devops': 4,

            # Data Science & ML
            'machine learning': 5, 'deep learning': 5, 'tensorflow': 5, 'pytorch': 5,
            'scikit-learn': 4, 'pandas': 4, 'numpy': 4, 'data science': 4, 'nlp': 5,

            # Other
            'agile': 3, 'scrum': 3, 'git': 4, 'rest api': 4, 'microservices': 4,
            'security': 4, 'testing': 3, 'leadership': 3, 'project management': 4
        }

        jd_lower = jd_text.lower()
        cv_lower = cv_text.lower()

        jd_skills = set()
        cv_skills = set()

        for skill, weight in skill_database.items():
            if skill in jd_lower:
                jd_skills.add((skill, weight))
            if skill in cv_lower:
                cv_skills.add((skill, weight))

        if jd_skills:
            # Calculate skill match score
            matched_skills = set([s[0] for s in jd_skills]) & set([s[0] for s in cv_skills])
            required_skills = set([s[0] for s in jd_skills])
            skill_match = len(matched_skills) / len(required_skills) if required_skills else 0
        else:
            skill_match = 0.5  # No skills identified in JD

        # 3. Experience level matching (15% weight)
        # Extract years from JD
        jd_years_pattern = r'(\d+)\s*(?:\+)?\s*years?'
        jd_years_matches = re.findall(jd_years_pattern, jd_lower)

        cv_years_pattern = r'(\d+)\s*(?:\+)?\s*years?.*?experience'
        cv_years_matches = re.findall(cv_years_pattern, cv_lower)

        experience_match = 0.7  # Default neutral score
        if jd_years_matches and cv_years_matches:
            try:
                jd_exp = int(jd_years_matches[0])
                cv_exp = int(cv_years_matches[0])
                # Perfect match if within 20% range
                if abs(cv_exp - jd_exp) / max(jd_exp, 1) <= 0.2:
                    experience_match = 1.0
                elif abs(cv_exp - jd_exp) <= 2:
                    experience_match = 0.8
                else:
                    experience_match = 0.6
            except:
                pass

        # 4. Education matching (15% weight)
        education_keywords = ['bachelor', 'master', 'phd', 'mba', 'degree', 'btech', 'mtech',
                             'engineering', 'computer science', 'information technology']

        jd_edu = sum(1 for kw in education_keywords if kw in jd_lower)
        cv_edu = sum(1 for kw in education_keywords if kw in cv_lower)

        if jd_edu > 0:
            education_match = min(cv_edu / jd_edu, 1.0)
        else:
            education_match = 0.7  # Neutral if no education mentioned in JD

        # Calculate weighted final score
        final_score = (
            tfidf_similarity * 0.40 +
            skill_match * 0.30 +
            experience_match * 0.15 +
            education_match * 0.15
        ) * 100

        # Apply penalties for edge cases
        # Penalty if CV is too short (less than 200 words)
        cv_word_count = len(cv_text.split())
        if cv_word_count < 1000:
            final_score *= 0.8

        # Bonus for comprehensive CVs (more than 800 words)
        if cv_word_count > 2000:
            final_score = min(final_score * 1.05, 100)

        return round(final_score, 2)

    except Exception as e:
        print(f"Error in improved similarity calculation: {e}")
        return 50.0  # Return default on error

def parse_cv(cv_path, jd_text):
    """Parse CV and calculate match with JD"""
    # Validate CV file exists
    if not os.path.exists(cv_path):
        raise FileNotFoundError(f"CV file not found: {cv_path}")
    
    # Extract text based on file type
    if cv_path.lower().endswith('.docx'):
        cv_text = extract_text_from_docx(cv_path)
    elif cv_path.lower().endswith('.pdf'):
        cv_text = extract_text_from_pdf(cv_path)
    else:
        raise ValueError(f"Unsupported file type. Please upload .docx or .pdf files only.")
    
    if not cv_text or len(cv_text.strip()) < 50:
        raise ValueError("CV appears to be empty or too short. Please upload a valid CV.")
    
    # Extract candidate information
    fields = extract_fields(cv_text)
    
    # Calculate similarity with JD
    if jd_text and len(jd_text.strip()) > 50:
        similarity = calculate_similarity(jd_text, cv_text)
    else:
        print("Warning: JD text is empty or too short, using default similarity")
        similarity = 50.0
    
    fields['similarity_score'] = similarity
    
    # Ensure name is not empty
    if not fields['name']:
        fields['name'] = 'Name not detected'
    
    return fields