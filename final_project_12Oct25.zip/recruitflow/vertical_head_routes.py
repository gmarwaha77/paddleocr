# recruitflow/vertical_head_routes.py
"""
Routes for Vertical Head role
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from sqlalchemy import func

from .models import db, Position, Candidate, Vertical, PositionTitle, SalaryProposal, Interview, InterviewFeedback, \
    InterviewPanel
from .utils.helpers import role_required, log_action

vh_bp = Blueprint('vertical_head', __name__, url_prefix='/vertical-head')


@vh_bp.route('/dashboard')
@login_required
@role_required('Vertical_Head')
def dashboard():
    """Vertical Head dashboard with their vertical's pipeline"""

    # Get vertical head's vertical
    vertical = Vertical.query.get(current_user.vertical_id)

    if not vertical:
        flash('No vertical assigned', 'warning')
        return redirect(url_for('main.dashboard'))

    # Get positions in this vertical
    positions = Position.query.filter_by(vertical_id=vertical.id).all()

    # Positions pending approval
    pending_positions = Position.query.filter_by(
        vertical_id=vertical.id,
        status='pending_approval'
    ).all()

    # Active positions
    active_positions = Position.query.filter_by(
        vertical_id=vertical.id,
        status='approved'
    ).count()

    # Total candidates in pipeline
    position_ids = [p.id for p in positions]
    total_candidates = Candidate.query.filter(
        Candidate.position_id.in_(position_ids)
    ).count()

    # Candidates in interview stage
    in_interview = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status == 'interview'
    ).count()

    # Recent hires (last 30 days)
    recent_hires = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status == 'hired',
        Candidate.joining_date >= datetime.now().date() - timedelta(days=30)
    ).count()

    return render_template(
        'vertical_head/dashboard.html',
        vertical=vertical,
        pending_positions=pending_positions,
        active_positions=active_positions,
        total_candidates=total_candidates,
        in_interview=in_interview,
        recent_hires=recent_hires
    )


@vh_bp.route('/positions')
@login_required
@role_required('Vertical_Head')
def positions():
    """View all positions in vertical"""
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id
    ).order_by(Position.created_at.desc()).all()

    return render_template('vertical_head/positions.html', positions=positions)


@vh_bp.route('/pipeline')
@login_required
@role_required('Vertical_Head')
def pipeline():
    """Recruitment pipeline for vertical"""
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id,
        status='approved'
    ).all()

    position_ids = [p.id for p in positions]

    # Candidates by status
    pipeline_data = db.session.query(
        Candidate.status,
        func.count(Candidate.id)
    ).filter(
        Candidate.position_id.in_(position_ids)
    ).group_by(Candidate.status).all()

    return render_template(
        'vertical_head/pipeline.html',
        positions=positions,
        pipeline_data=pipeline_data
    )


@vh_bp.route('/salary-proposals')
@login_required
@role_required('Vertical_Head')
def salary_proposals():
    """View salary proposals for vertical (read-only)"""

    # Get all positions in vertical
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id
    ).all()

    position_ids = [p.id for p in positions]

    # Get candidates from these positions
    candidate_ids = [c.id for c in Candidate.query.filter(
        Candidate.position_id.in_(position_ids)
    ).all()]

    # Get salary proposals
    proposals = SalaryProposal.query.filter(
        SalaryProposal.candidate_id.in_(candidate_ids)
    ).order_by(SalaryProposal.created_at.desc()).all()

    return render_template(
        'vertical_head/salary_proposals.html',
        proposals=proposals
    )


@vh_bp.route('/interview/<int:interview_id>/feedback')
@login_required
@role_required('Vertical_Head')
def view_interview_feedback(interview_id):
    """Vertical Head view of interview feedback."""
    interview = Interview.query.get_or_404(interview_id)
    candidate = interview.candidate

    # Security check: Ensure the position is within the VH's vertical
    if candidate.position.vertical_id != current_user.vertical_id:
        flash("You do not have permission to view this feedback.", "danger")
        return redirect(url_for('vertical_head.dashboard'))

    # Get feedback from previous rounds for this candidate
    previous_feedback = db.session.query(InterviewFeedback).join(Interview).filter(
        Interview.candidate_id == candidate.id,
        Interview.id != interview_id
    ).all()

    return render_template('vertical_head/view_feedback.html',
                           interview=interview,
                           candidate=candidate,
                           previous_feedback=previous_feedback)


# Add these routes to vertical_head_routes.py

@vh_bp.route('/all-feedbacks')
@login_required
@role_required('Vertical_Head')
def all_feedbacks():
    """View all interview feedbacks for vertical's positions"""

    # Get all positions in vertical
    positions = Position.query.filter_by(
        vertical_id=current_user.vertical_id
    ).all()

    position_ids = [p.id for p in positions]

    # Get all candidates from these positions
    candidates = Candidate.query.filter(
        Candidate.position_id.in_(position_ids)
    ).all()

    candidate_ids = [c.id for c in candidates]

    # Get all interviews for these candidates
    interviews = Interview.query.filter(
        Interview.candidate_id.in_(candidate_ids)
    ).all()

    interview_ids = [i.id for i in interviews]

    # Get all feedbacks
    feedbacks = InterviewFeedback.query.filter(
        InterviewFeedback.interview_id.in_(interview_ids)
    ).order_by(InterviewFeedback.created_at.desc()).all()

    return render_template('vertical_head/all_feedbacks.html',
                           feedbacks=feedbacks)


@vh_bp.route('/candidate/<int:candidate_id>/all-feedback')
@login_required
@role_required('Vertical_Head')
def candidate_all_feedback(candidate_id):
    """View all feedback for a specific candidate"""
    candidate = Candidate.query.get_or_404(candidate_id)

    # Security check
    if candidate.position.vertical_id != current_user.vertical_id:
        flash('Access denied', 'danger')
        return redirect(url_for('vertical_head.dashboard'))

    # Get all interviews and feedbacks
    interviews = Interview.query.filter_by(candidate_id=candidate_id).all()

    all_feedbacks = []
    for interview in interviews:
        feedbacks = InterviewFeedback.query.filter_by(interview_id=interview.id).all()
        for feedback in feedbacks:
            all_feedbacks.append({
                'feedback': feedback,
                'interview': interview
            })

    return render_template('vertical_head/candidate_feedback.html',
                           candidate=candidate,
                           all_feedbacks=all_feedbacks)


# Add this route for interview scorecard submission by Vertical Head

@vh_bp.route('/interview/<int:interview_id>/scorecard', methods=['GET', 'POST'])
@login_required
@role_required('Vertical_Head')
def interview_scorecard(interview_id):
    """Vertical Head interview scorecard submission"""
    interview = Interview.query.get_or_404(interview_id)
    candidate = interview.candidate

    # Security check
    if candidate.position.vertical_id != current_user.vertical_id:
        flash('Access denied', 'danger')
        return redirect(url_for('vertical_head.dashboard'))

    # Check if already submitted
    existing_feedback = InterviewFeedback.query.filter_by(
        interview_id=interview_id,
        ip_user_id=current_user.id
    ).first()

    if existing_feedback:
        flash('You have already submitted feedback for this interview', 'info')
        return redirect(url_for('vertical_head.dashboard'))

    if request.method == 'POST':
        # Get all ratings
        technical_rating = int(request.form.get('technical_rating'))
        communication_rating = int(request.form.get('communication_rating'))
        problem_solving_rating = int(request.form.get('problem_solving_rating'))
        cultural_fit_rating = int(request.form.get('cultural_fit_rating'))
        team_collaboration_rating = int(request.form.get('team_collaboration_rating'))

        # Calculate overall rating
        overall_rating = (technical_rating + communication_rating + problem_solving_rating +
                          cultural_fit_rating + team_collaboration_rating) / 5

        recommendation = request.form.get('recommendation')
        strengths = request.form.get('strengths')
        areas_of_concern = request.form.get('areas_of_concern')
        comments = request.form.get('comments')

        feedback = InterviewFeedback(
            interview_id=interview_id,
            ip_user_id=current_user.id,
            technical_rating=technical_rating,
            communication_rating=communication_rating,
            problem_solving_rating=problem_solving_rating,
            cultural_fit_rating=cultural_fit_rating,
            team_collaboration_rating=team_collaboration_rating,
            overall_rating=overall_rating,
            recommendation=recommendation,
            strengths=strengths,
            areas_of_concern=areas_of_concern,
            comments=comments,
            rating=int(overall_rating)
        )
        db.session.add(feedback)

        # Check if all panel members have submitted
        position = candidate.position
        panel_members = InterviewPanel.query.filter_by(position_id=position.id).all()
        panel_member_ids = [p.ip_user_id for p in panel_members]

        all_feedbacks = InterviewFeedback.query.filter_by(interview_id=interview_id).all()
        feedback_submitters = [f.ip_user_id for f in all_feedbacks] + [current_user.id]

        if set(panel_member_ids).issubset(set(feedback_submitters)):
            interview.status = 'completed'

            # Calculate decision
            all_feedbacks_including_new = all_feedbacks + [feedback]
            avg_overall = sum(f.overall_rating for f in all_feedbacks_including_new) / len(all_feedbacks_including_new)

            strong_recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'strongly_recommend')
            recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'recommend')
            do_not_recommends = sum(1 for f in all_feedbacks_including_new if f.recommendation == 'do_not_recommend')

            if avg_overall >= 3.5 and (strong_recommends + recommends) > do_not_recommends:
                candidate.status = 'interview_passed'
                flash(f'All feedback received. {candidate.name} PASSED (Avg Score: {avg_overall:.1f}/5)', 'success')
            else:
                candidate.status = 'interview_rejected'
                flash(f'All feedback received. {candidate.name} did not pass (Avg Score: {avg_overall:.1f}/5)', 'info')
        else:
            flash('Your feedback has been submitted. Waiting for other panel members.', 'success')

        db.session.commit()
        log_action(f'Vertical Head feedback submitted for interview {interview_id}.',
                   entity_type='Interview', entity_id=interview_id)

        return redirect(url_for('vertical_head.dashboard'))

    # GET - show previous feedbacks
    previous_feedbacks = InterviewFeedback.query.filter_by(interview_id=interview_id).all()

    return render_template('vertical_head/interview_scorecard.html',
                           interview=interview,
                           candidate=candidate,
                           previous_feedbacks=previous_feedbacks)


# Add this route to vertical_head_routes.py

@vh_bp.route('/my-interviews')
@login_required
@role_required('Vertical_Head')
def my_interviews():
    """View interviews assigned to vertical head"""

    # Get vertical head's vertical
    vertical = Vertical.query.get(current_user.vertical_id)

    if not vertical:
        flash('No vertical assigned', 'warning')
        return redirect(url_for('main.dashboard'))

    # Get all positions in this vertical
    positions = Position.query.filter_by(vertical_id=vertical.id).all()
    position_ids = [p.id for p in positions]

    # Get candidates awaiting VH interview or scheduled for VH interview
    candidates_awaiting = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status.in_(['awaiting_vh_interview', 'vh_interview_scheduled'])
    ).all()

    # Get interviews where VH needs to provide feedback
    # Find interviews for these candidates where VH hasn't submitted feedback yet
    pending_interviews = []
    for candidate in candidates_awaiting:
        interviews = Interview.query.filter_by(
            candidate_id=candidate.id,
            status='scheduled'
        ).all()

        for interview in interviews:
            # Check if VH has already submitted feedback
            existing_feedback = InterviewFeedback.query.filter_by(
                interview_id=interview.id,
                ip_user_id=current_user.id
            ).first()

            if not existing_feedback:
                pending_interviews.append({
                    'interview': interview,
                    'candidate': candidate,
                    'position': candidate.position
                })

    # Get completed interviews (where VH has provided feedback)
    completed_interviews = []
    completed_candidates = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status.in_(['interview_passed', 'interview_rejected', 'hired'])
    ).all()

    for candidate in completed_candidates:
        feedbacks = db.session.query(InterviewFeedback).join(Interview).filter(
            Interview.candidate_id == candidate.id,
            InterviewFeedback.ip_user_id == current_user.id
        ).all()

        if feedbacks:
            completed_interviews.append({
                'candidate': candidate,
                'feedbacks': feedbacks,
                'position': candidate.position
            })

    return render_template(
        'vertical_head/my_interviews.html',
        pending_interviews=pending_interviews,
        completed_interviews=completed_interviews,
        vertical=vertical
    )