# recruitflow/utils/file_manager.py
"""
Organized file upload management
"""

import os
from datetime import datetime
from werkzeug.utils import secure_filename
from flask import current_app


class FileManager:
    """Manage file uploads with organized folder structure"""
    
    @staticmethod
    def get_upload_path(file_type, position_id=None, candidate_id=None):
        """
        Get organized upload path
        
        Args:
            file_type: Type of file ('jd', 'cv', 'offer_letter', 'document')
            position_id: Position ID (optional)
            candidate_id: Candidate ID (optional)
            
        Returns:
            str: Full path for file storage
        """
        base_path = current_app.config.get('UPLOAD_FOLDER', 'recruitflow/static/uploads')
        
        # Create organized structure
        year = datetime.now().year
        month = datetime.now().strftime('%m')
        
        if file_type == 'jd' and position_id:
            folder = os.path.join(base_path, 'job_descriptions', str(year), f'position_{position_id}')
        elif file_type == 'cv' and position_id and candidate_id:
            folder = os.path.join(base_path, 'cvs', str(year), f'position_{position_id}', f'candidate_{candidate_id}')
        elif file_type == 'offer_letter' and candidate_id:
            folder = os.path.join(base_path, 'offer_letters', str(year), month, f'candidate_{candidate_id}')
        elif file_type == 'document':
            folder = os.path.join(base_path, 'documents', str(year), month)
        else:
            folder = os.path.join(base_path, 'misc', str(year), month)
        
        # Create folder if doesn't exist
        os.makedirs(folder, exist_ok=True)
        
        return folder
    
    @staticmethod
    def save_file(file, file_type, position_id=None, candidate_id=None):
        """
        Save file with organized structure
        
        Args:
            file: File object from request.files
            file_type: Type of file
            position_id: Position ID (optional)
            candidate_id: Candidate ID (optional)
            
        Returns:
            str: Relative path to saved file
        """
        if not file or file.filename == '':
            return None
        
        # Secure filename
        original_filename = secure_filename(file.filename)
        name, ext = os.path.splitext(original_filename)
        
        # Add timestamp to prevent conflicts
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{name}_{timestamp}{ext}"
        
        # Get organized folder
        folder = FileManager.get_upload_path(file_type, position_id, candidate_id)
        
        # Full path
        filepath = os.path.join(folder, filename)
        
        # Save file
        file.save(filepath)
        
        # Return relative path from uploads folder
        base_path = current_app.config.get('UPLOAD_FOLDER', 'recruitflow/static/uploads')
        relative_path = os.path.relpath(filepath, base_path)
        
        return relative_path
    
    @staticmethod
    def get_file_url(relative_path):
        """
        Get URL for accessing file
        
        Args:
            relative_path: Relative path from uploads folder
            
        Returns:
            str: URL path
        """
        return f"/uploads/{relative_path.replace(os.sep, '/')}"