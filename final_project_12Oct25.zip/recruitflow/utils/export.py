# recruitflow_project/utils/export.py
"""
Data export utilities
"""
import csv
import io
from datetime import datetime
from flask import make_response

def export_candidates_csv(candidates):
    """
    Export candidates to CSV
    
    Args:
        candidates: List of Candidate objects
    
    Returns:
        Flask response with CSV file
    """
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow([
        'ID', 'Name', 'Email', 'Phone', 'Location',
        'Experience (Years)', 'Key Skills', 'Education',
        'Similarity Score (%)', 'Status', 'Test Score',
        'Created At'
    ])
    
    # Write data
    for candidate in candidates:
        writer.writerow([
            candidate.id,
            candidate.name,
            candidate.email,
            candidate.phone,
            candidate.location,
            candidate.experience,
            candidate.key_skills,
            candidate.education,
            round(candidate.similarity_score, 2) if candidate.similarity_score else 0,
            candidate.status,
            candidate.test_score if candidate.test_score else '',
            candidate.created_at.strftime('%Y-%m-%d %H:%M:%S')
        ])
    
    # Create response
    output.seek(0)
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = f'attachment; filename=candidates_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    return response

def export_positions_csv(positions):
    """
    Export positions to CSV
    
    Args:
        positions: List of Position objects
    
    Returns:
        Flask response with CSV file
    """
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow([
        'ID', 'Title', 'Project Name', 'Openings',
        'Status', 'Hiring Manager', 'Senior Approver',
        'Total Candidates', 'Created At'
    ])
    
    # Write data
    for position in positions:
        writer.writerow([
            position.id,
            position.position_title.title if position.position_title else '',
            position.project_name,
            position.openings,
            position.status,
            position.hiring_manager.username if position.hiring_manager else '',
            position.senior_approver.username if position.senior_approver else '',
            len(position.candidates),
            position.created_at.strftime('%Y-%m-%d %H:%M:%S')
        ])
    
    # Create response
    output.seek(0)
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = f'attachment; filename=positions_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    return response


# recruitflow_project/utils/helpers.py
"""
Helper functions
"""
from functools import wraps
from flask import flash, redirect, url_for
from flask_login import current_user

def role_required(*roles):
    """
    Decorator to require specific roles
    
    Usage:
        @role_required('Hiring_Manager', 'Admin')
        def my_view():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('main.login'))
            
            if current_user.role.name not in roles:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('main.dashboard'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_candidate_stats(position_id=None):
    """
    Get candidate statistics
    
    Args:
        position_id: Optional position ID to filter by
    
    Returns:
        Dictionary with statistics
    """
    from recruitflow.models import Candidate, db
    
    query = db.session.query(
        Candidate.status,
        db.func.count(Candidate.id).label('count')
    )
    
    if position_id:
        query = query.filter_by(position_id=position_id)
    
    results = query.group_by(Candidate.status).all()
    
    stats = {
        'total': sum(r.count for r in results),
        'by_status': {r.status: r.count for r in results}
    }
    
    return stats

def get_position_stats():
    """Get position statistics"""
    from recruitflow.models import Position, db
    
    results = db.session.query(
        Position.status,
        db.func.count(Position.id).label('count')
    ).group_by(Position.status).all()
    
    stats = {
        'total': sum(r.count for r in results),
        'by_status': {r.status: r.count for r in results}
    }
    
    return stats

def calculate_time_to_hire(candidate):
    """
    Calculate time-to-hire for a candidate
    
    Args:
        candidate: Candidate object
    
    Returns:
        Days from application to hire, or None if not hired
    """
    if candidate.status not in ['hired', 'offer']:
        return None
    
    from datetime import datetime
    
    # Find the most recent interview
    if candidate.interviews:
        latest_interview = max(candidate.interviews, key=lambda i: i.schedule_date)
        days = (latest_interview.schedule_date - candidate.created_at.date()).days
        return days
    
    return None

def format_experience(years):
    """Format experience years"""
    if not years:
        return 'Not specified'
    
    if years < 1:
        return f'{int(years * 12)} months'
    elif years == 1:
        return '1 year'
    else:
        return f'{int(years)} years'

def get_similarity_label(score):
    """Get label for similarity score"""
    if score >= 80:
        return 'Excellent Match'
    elif score >= 70:
        return 'Great Match'
    elif score >= 60:
        return 'Good Match'
    elif score >= 50:
        return 'Fair Match'
    else:
        return 'Poor Match'

def get_similarity_color(score):
    """Get color class for similarity score"""
    if score >= 70:
        return 'success'
    elif score >= 50:
        return 'warning'
    else:
        return 'danger'