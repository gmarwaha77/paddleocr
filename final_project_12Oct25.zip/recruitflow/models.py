# recruitflow_project/models.py (COMPLETE & CORRECTED)
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()


# --- User and Role Management ---

class Role(db.Model):
    __tablename__ = 'role'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    users = db.relationship('User', backref='role', lazy='dynamic')


class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), nullable=False)
    full_name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True, index=True)
    vertical_id = db.Column(db.Integer, db.ForeignKey('vertical.id'))
    reporting_manager_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # For HM reporting to Vertical Head

    # Add relationship
    user_vertical = db.relationship('Vertical', foreign_keys=[vertical_id], backref='vertical_members')
    manager = db.relationship('User', remote_side=[id], backref='team_members')

    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class InterviewerRole(db.Model):
    __tablename__ = 'interviewer_role'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    role_name = db.Column(db.String(100), nullable=False)

    user = db.relationship('User', backref='interview_roles')

# --- Core Recruitment Models ---

class PositionTitle(db.Model):
    __tablename__ = 'position_title'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False, unique=True)
    positions = db.relationship('Position', backref='position_title', lazy=True)

class Vertical(db.Model):
    """Organization verticals/departments"""
    __tablename__ = 'vertical'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    vertical_head_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    vertical_head = db.relationship('User', foreign_keys=[vertical_head_id], backref='managed_vertical')
    positions = db.relationship('Position', backref='vertical', lazy='dynamic')

class Position(db.Model):
    __tablename__ = 'position'
    id = db.Column(db.Integer, primary_key=True)
    title_id = db.Column(db.Integer, db.ForeignKey('position_title.id'))
    project_name = db.Column(db.String(100))
    openings = db.Column(db.Integer, default=1)
    jd_file_path = db.Column(db.String(255))
    status = db.Column(db.String(50), default='draft', index=True)
    hm_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    vertical_id = db.Column(db.Integer, db.ForeignKey('vertical.id'))
    jd_clarity_score = db.Column(db.Float)  # JD quality score
    jd_clarity_feedback = db.Column(db.Text)  # AI feedback on JD
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    hiring_manager = db.relationship('User', foreign_keys=[hm_id], backref='hm_positions')
    candidates = db.relationship('Candidate', backref='position', lazy='dynamic', cascade="all, delete-orphan")
    panels = db.relationship('InterviewPanel', backref='position', lazy=True, cascade="all, delete-orphan")
    position_type = db.Column(db.String(20), default='full_time')  # 'full_time' or 'contract'
    contract_duration_months = db.Column(db.Integer)  # Only for contract positions
    contract_start_date = db.Column(db.Date)
    contract_end_date = db.Column(db.Date)
    ceo_interview = db.relationship('CEOInterview', backref='position', uselist=False, cascade="all, delete-orphan")



class Candidate(db.Model):
    __tablename__ = 'candidate'
    id = db.Column(db.Integer, primary_key=True)
    position_id = db.Column(db.Integer, db.ForeignKey('position.id'), nullable=False)
    cv_file_path = db.Column(db.String(255))
    name = db.Column(db.String(100))
    location = db.Column(db.String(100))
    phone = db.Column(db.String(50))
    email = db.Column(db.String(100))
    linkedin = db.Column(db.String(255))
    experience = db.Column(db.Float)
    key_skills = db.Column(db.Text)
    education = db.Column(db.Text)
    employment_history = db.Column(db.Text)
    similarity_score = db.Column(db.Float)
    status = db.Column(db.String(50), default='applied', index=True)
    test_score = db.Column(db.Float)
    is_silver = db.Column(db.Boolean, default=False)

    # Enhanced fields
    current_ctc = db.Column(db.Float)
    expected_ctc = db.Column(db.Float)
    previous_ctc = db.Column(db.Float)  # For tracking actual current CTC when proposing
    notice_period_days = db.Column(db.Integer)
    joining_date = db.Column(db.Date)
    source = db.Column(db.String(50))
    referred_by = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    interviews = db.relationship('Interview', backref='candidate', lazy='dynamic', cascade="all, delete-orphan")
    notes = db.relationship('CandidateNote', backref='candidate', lazy='dynamic', cascade="all, delete-orphan")
    salary_proposals = db.relationship('SalaryProposal', backref='candidate', lazy='dynamic',
                                       cascade="all, delete-orphan")
    offer_letters = db.relationship('OfferLetter', backref='candidate', lazy='dynamic', cascade="all, delete-orphan")
    background_checks = db.relationship('BackgroundCheck', backref='candidate', lazy='dynamic',
                                        cascade="all, delete-orphan")
    onboarding_tasks = db.relationship('OnboardingTask', backref='candidate', lazy='dynamic',
                                       cascade="all, delete-orphan")
    communications = db.relationship('CandidateCommunication', backref='candidate', lazy='dynamic',
                                     cascade="all, delete-orphan")
    reference_checks = db.relationship('ReferenceCheck', backref='candidate', lazy='dynamic',
                                       cascade="all, delete-orphan")


class InternalApplication(db.Model):
    """Applications from existing employees for internal positions"""
    __tablename__ = 'internal_application'
    id = db.Column(db.Integer, primary_key=True)
    position_id = db.Column(db.Integer, db.ForeignKey('position.id'), nullable=False)
    employee_id = db.Column(db.String(50), nullable=False)
    employee_name = db.Column(db.String(100), nullable=False)
    employee_email = db.Column(db.String(100), nullable=False)
    current_department = db.Column(db.String(100))
    current_designation = db.Column(db.String(100))
    years_in_company = db.Column(db.Float)
    
    # Application details
    why_suitable = db.Column(db.Text, nullable=False)
    additional_info = db.Column(db.Text)
    
    # Status tracking
    status = db.Column(db.String(50), default='submitted', index=True)
    # Possible values: submitted, under_review, shortlisted, interview, selected, rejected
    
    applied_date = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    review_comments = db.Column(db.Text)
    
    position = db.relationship('Position', backref='internal_applications')
    reviewer = db.relationship('User', backref='internal_applications_reviewed')

class InterviewPanel(db.Model):
    __tablename__ = 'interview_panel'
    id = db.Column(db.Integer, primary_key=True)
    position_id = db.Column(db.Integer, db.ForeignKey('position.id'))
    ip_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    panel_member = db.relationship('User', backref='panel_positions')


# --- MISSING MODELS - NOW ADDED ---
class Interview(db.Model):
    __tablename__ = 'interview'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    schedule_date = db.Column(db.Date)
    schedule_time = db.Column(db.String(20))
    interview_mode = db.Column(db.String(20))
    meeting_link = db.Column(db.String(255))
    status = db.Column(db.String(50), default='scheduled')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    feedbacks = db.relationship('InterviewFeedback', backref='interview', lazy='dynamic', cascade="all, delete-orphan")


# In models.py, replace the InterviewFeedback class with this enhanced version:

class InterviewFeedback(db.Model):
    __tablename__ = 'interview_feedback'
    id = db.Column(db.Integer, primary_key=True)
    interview_id = db.Column(db.Integer, db.ForeignKey('interview.id'), nullable=False)
    ip_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    # Detailed Ratings (1-5 scale)
    technical_rating = db.Column(db.Integer)  # Technical skills
    communication_rating = db.Column(db.Integer)  # Communication skills
    problem_solving_rating = db.Column(db.Integer)  # Problem solving
    cultural_fit_rating = db.Column(db.Integer)  # Cultural fit
    team_collaboration_rating = db.Column(db.Integer)  # Team work

    # Overall rating (calculated average)
    overall_rating = db.Column(db.Float)

    # Recommendation
    recommendation = db.Column(db.String(50))  # 'strongly_recommend', 'recommend', 'neutral', 'do_not_recommend'

    # Detailed Comments
    strengths = db.Column(db.Text)
    areas_of_concern = db.Column(db.Text)
    comments = db.Column(db.Text)  # Overall comments

    # Legacy field for backward compatibility
    rating = db.Column(db.Integer)  # Keep for old data

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    interviewer = db.relationship('User', backref='interview_feedbacks')


class CandidateNote(db.Model):
    __tablename__ = 'candidate_note'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    note = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship('User', backref='candidate_notes')


# --- Salary, Offer, and Onboarding Models ---

class SalaryProposal(db.Model):
    __tablename__ = 'salary_proposal'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)

    # Proposer info
    proposed_by = db.Column(db.Integer, db.ForeignKey('user.id'))

    # Total CTC
    annual_ctc = db.Column(db.Float, nullable=False)

    # CTC Breakup
    basic_salary = db.Column(db.Float)
    hra = db.Column(db.Float)
    special_allowance = db.Column(db.Float)
    performance_bonus = db.Column(db.Float)

    # Employer Contributions
    pf_employer = db.Column(db.Float)
    gratuity = db.Column(db.Float)

    # Deductions
    pf_employee = db.Column(db.Float)
    professional_tax = db.Column(db.Float)

    # Additional Benefits
    medical_insurance = db.Column(db.Float)
    other_benefits = db.Column(db.Text)

    # In-hand salary
    monthly_gross = db.Column(db.Float)
    monthly_net = db.Column(db.Float)

    # Approval workflow
    status = db.Column(db.String(50), default='pending', index=True)
    approved_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    approval_date = db.Column(db.DateTime)
    approval_comments = db.Column(db.Text)

    # Candidate response
    candidate_response = db.Column(db.String(50))
    candidate_feedback = db.Column(db.Text)
    counter_amount = db.Column(db.Float)

    version = db.Column(db.Integer, default=1)
    is_final = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime)

    # Relationships
    proposer = db.relationship('User', foreign_keys=[proposed_by], backref='salary_proposals_created')
    approver = db.relationship('User', foreign_keys=[approved_by], backref='salary_proposals_approved')


class OfferLetter(db.Model):
    __tablename__ = 'offer_letter'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    salary_proposal_id = db.Column(db.Integer, db.ForeignKey('salary_proposal.id'))

    offer_letter_path = db.Column(db.String(255))
    generated_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    generated_date = db.Column(db.DateTime, default=datetime.utcnow)

    # Offer details
    designation = db.Column(db.String(100))
    department = db.Column(db.String(100))
    location = db.Column(db.String(100))
    joining_date = db.Column(db.Date)

    # Status tracking
    sent_date = db.Column(db.DateTime)
    accepted_date = db.Column(db.DateTime)
    declined_date = db.Column(db.DateTime)
    status = db.Column(db.String(50), default='draft')

    generator = db.relationship('User', backref='offer_letters_generated')


class BackgroundCheck(db.Model):
    __tablename__ = 'background_check'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)

    check_type = db.Column(db.String(50))
    status = db.Column(db.String(50), default='pending')

    vendor_name = db.Column(db.String(100))
    initiated_date = db.Column(db.Date)
    completed_date = db.Column(db.Date)

    findings = db.Column(db.Text)
    documents = db.Column(db.Text)

    verified_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    verifier = db.relationship('User', backref='background_checks_verified')


class OnboardingTask(db.Model):
    __tablename__ = 'onboarding_task'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)

    task_name = db.Column(db.String(200))
    task_category = db.Column(db.String(50))
    description = db.Column(db.Text)

    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id'))
    due_date = db.Column(db.Date)

    status = db.Column(db.String(50), default='pending')
    completed_date = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assignee = db.relationship('User', backref='onboarding_tasks_assigned')


class CandidateCommunication(db.Model):
    __tablename__ = 'candidate_communication'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)

    communication_type = db.Column(db.String(50))
    subject = db.Column(db.String(200))
    message = db.Column(db.Text)

    communicated_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    communication_date = db.Column(db.DateTime, default=datetime.utcnow)

    response_received = db.Column(db.Boolean, default=False)
    response_text = db.Column(db.Text)
    response_date = db.Column(db.DateTime)

    communicator = db.relationship('User', backref='communications')


class ReferenceCheck(db.Model):
    __tablename__ = 'reference_check'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)  # FIXED: was user.id

    reference_name = db.Column(db.String(100))
    reference_designation = db.Column(db.String(100))
    reference_company = db.Column(db.String(100))
    reference_phone = db.Column(db.String(50))
    reference_email = db.Column(db.String(100))

    relationship = db.Column(db.String(50))

    contacted_date = db.Column(db.Date)
    contacted_by = db.Column(db.Integer, db.ForeignKey('user.id'))

    overall_rating = db.Column(db.Integer)
    would_rehire = db.Column(db.Boolean)
    feedback = db.Column(db.Text)
    status = db.Column(db.String(50), default='pending')

    contactor = db.relationship('User', backref='reference_checks_conducted')


class TalentPool(db.Model):
    __tablename__ = 'talent_pool'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)

    pool_category = db.Column(db.String(50))
    skills_tags = db.Column(db.Text)
    experience_level = db.Column(db.String(50))

    added_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    added_date = db.Column(db.DateTime, default=datetime.utcnow)

    last_contacted = db.Column(db.DateTime)
    availability = db.Column(db.String(50))
    notes = db.Column(db.Text)

    adder = db.relationship('User', backref='talent_pool_entries')
    candidate = db.relationship('Candidate', backref='talent_pool_entry')


class AuditLog(db.Model):
    __tablename__ = 'audit_log'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action = db.Column(db.Text, nullable=False)
    entity_type = db.Column(db.String(50))  # ADDED MISSING FIELD
    entity_id = db.Column(db.Integer)  # ADDED MISSING FIELD
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship('User', backref='audit_logs')


class ContractPerformanceReview(db.Model):
    """Monthly performance reviews for contract employees"""
    __tablename__ = 'contract_performance_review'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    
    # Review period
    review_month = db.Column(db.Integer, nullable=False)  # 1-12
    review_year = db.Column(db.Integer, nullable=False)
    
    # Ratings (1-5 scale)
    technical_rating = db.Column(db.Integer, nullable=False)
    functional_rating = db.Column(db.Integer, nullable=False)
    overall_rating = db.Column(db.Float)
    
    # Comments
    strengths = db.Column(db.Text)
    areas_for_improvement = db.Column(db.Text)
    textual_comments = db.Column(db.Text, nullable=False)
    
    # Reviewer info
    reviewed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    review_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Contract continuation
    recommend_continuation = db.Column(db.Boolean)
    
    candidate = db.relationship('Candidate', backref='performance_reviews')
    reviewer = db.relationship('User', backref='contract_reviews_given')
    
    __table_args__ = (
        db.UniqueConstraint('candidate_id', 'review_month', 'review_year', 
                          name='unique_monthly_review'),
    )

class PipelineMetrics(db.Model):
    """Track time spent at each recruitment stage"""
    __tablename__ = 'pipeline_metrics'
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    
    stage = db.Column(db.String(50), nullable=False)
    # Stages: position_created, position_approved, cv_uploaded, hm_review, 
    # test_allocated, interview_scheduled, offer_made, hired
    
    entered_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    exited_at = db.Column(db.DateTime)
    duration_hours = db.Column(db.Float)
    
    candidate = db.relationship('Candidate', backref='pipeline_stages')


class SalaryHistory(db.Model):
    """Track all approved salaries for analytics"""
    __tablename__ = 'salary_history'
    id = db.Column(db.Integer, primary_key=True)
    position_title_id = db.Column(db.Integer, db.ForeignKey('position_title.id'), nullable=False)
    vertical_id = db.Column(db.Integer, db.ForeignKey('vertical.id'))
    annual_ctc = db.Column(db.Float, nullable=False)
    experience_years = db.Column(db.Float)
    approved_date = db.Column(db.DateTime, default=datetime.utcnow)
    approved_by = db.Column(db.Integer, db.ForeignKey('user.id'))

    position_title = db.relationship('PositionTitle', backref='salary_history')
    vertical_ref = db.relationship('Vertical', backref='salary_history')
    approver = db.relationship('User', backref='salaries_approved_history')


class CEOInterview(db.Model):
    __tablename__ = 'ceo_interview'
    id = db.Column(db.Integer, primary_key=True)
    position_id = db.Column(db.Integer, db.ForeignKey('position.id'), nullable=False)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    schedule_date = db.Column(db.Date)
    schedule_time = db.Column(db.String(20))
    status = db.Column(db.String(50), default='scheduled')
    feedback = db.Column(db.Text)

    candidate = db.relationship('Candidate', backref='ceo_interview')