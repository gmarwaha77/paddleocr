# recruitflow/contract_routes.py
"""
Routes for contract employee performance management
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime, date
from calendar import month_name

from .models import db, Candidate, ContractPerformanceReview, Position
from .utils.helpers import role_required, log_action

contract_bp = Blueprint('contract', __name__, url_prefix='/contract')


@contract_bp.route('/my-team')
@login_required
@role_required('Hiring_Manager')
def my_contract_team():
    """View contract employees under hiring manager"""
    # Get all contract positions for this HM
    positions = Position.query.filter_by(
        hm_id=current_user.id,
        position_type='contract'
    ).all()
    
    # Get all hired contract candidates from these positions
    position_ids = [p.id for p in positions]
    contract_employees = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status.in_(['hired', 'offer_accepted']),
        Candidate.joining_date.isnot(None)
    ).order_by(Candidate.joining_date.desc()).all()
    
    # Get latest review for each employee
    employee_data = []
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    for emp in contract_employees:
        latest_review = ContractPerformanceReview.query.filter_by(
            candidate_id=emp.id
        ).order_by(
            ContractPerformanceReview.review_year.desc(),
            ContractPerformanceReview.review_month.desc()
        ).first()
        
        # Check if review for current month exists
        current_review = ContractPerformanceReview.query.filter_by(
            candidate_id=emp.id,
            review_month=current_month,
            review_year=current_year
        ).first()
        
        # Calculate months since joining
        if emp.joining_date:
            months_working = (
                (current_year - emp.joining_date.year) * 12 +
                (current_month - emp.joining_date.month)
            )
        else:
            months_working = 0
        
        employee_data.append({
            'candidate': emp,
            'latest_review': latest_review,
            'current_review_done': current_review is not None,
            'months_working': months_working,
            'total_reviews': emp.performance_reviews.count()
        })
    
    return render_template(
        'contract/my_team.html',
        employee_data=employee_data,
        current_month=month_name[current_month],
        current_year=current_year
    )


@contract_bp.route('/add-review/<int:candidate_id>', methods=['GET', 'POST'])
@login_required
@role_required('Hiring_Manager')
def add_monthly_review(candidate_id):
    """Add monthly performance review for contract employee"""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    # Verify this is HM's employee
    if candidate.position.hm_id != current_user.id:
        flash('You can only review your own team members', 'danger')
        return redirect(url_for('contract.my_contract_team'))
    
    # Verify it's a contract position
    if candidate.position.position_type != 'contract':
        flash('Performance reviews are only for contract employees', 'warning')
        return redirect(url_for('contract.my_contract_team'))
    
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    # Check if review already exists for this month
    existing_review = ContractPerformanceReview.query.filter_by(
        candidate_id=candidate_id,
        review_month=current_month,
        review_year=current_year
    ).first()
    
    if existing_review:
        flash('Review for this month already exists', 'info')
        return redirect(url_for('contract.view_reviews', candidate_id=candidate_id))
    
    if request.method == 'POST':
        technical_rating = int(request.form.get('technical_rating'))
        functional_rating = int(request.form.get('functional_rating'))
        strengths = request.form.get('strengths', '').strip()
        improvements = request.form.get('improvements', '').strip()
        textual_comments = request.form.get('textual_comments', '').strip()
        recommend = request.form.get('recommend_continuation') == 'yes'
        
        if not textual_comments or len(textual_comments) < 20:
            flash('Please provide detailed comments (minimum 20 characters)', 'warning')
            return redirect(request.url)
        
        # Calculate overall rating
        overall = (technical_rating + functional_rating) / 2
        
        review = ContractPerformanceReview(
            candidate_id=candidate_id,
            review_month=current_month,
            review_year=current_year,
            technical_rating=technical_rating,
            functional_rating=functional_rating,
            overall_rating=overall,
            strengths=strengths,
            areas_for_improvement=improvements,
            textual_comments=textual_comments,
            recommend_continuation=recommend,
            reviewed_by=current_user.id
        )
        
        db.session.add(review)
        db.session.commit()
        
        log_action(
            f'Monthly review added for contract employee {candidate.name}',
            entity_type='ContractPerformanceReview',
            entity_id=review.id
        )
        
        flash('Performance review submitted successfully!', 'success')
        return redirect(url_for('contract.my_contract_team'))
    
    # Get previous reviews for reference
    previous_reviews = ContractPerformanceReview.query.filter_by(
        candidate_id=candidate_id
    ).order_by(
        ContractPerformanceReview.review_year.desc(),
        ContractPerformanceReview.review_month.desc()
    ).limit(3).all()
    
    return render_template(
        'contract/add_review.html',
        candidate=candidate,
        current_month=month_name[current_month],
        current_year=current_year,
        previous_reviews=previous_reviews
    )


@contract_bp.route('/reviews/<int:candidate_id>')
@login_required
@role_required('Hiring_Manager', 'CEO')
def view_reviews(candidate_id):
    """View all performance reviews for a contract employee"""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    # Verify access
    if current_user.role.name == 'Hiring_Manager':
        if candidate.position.hm_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('contract.my_contract_team'))
    
    reviews = ContractPerformanceReview.query.filter_by(
        candidate_id=candidate_id
    ).order_by(
        ContractPerformanceReview.review_year.desc(),
        ContractPerformanceReview.review_month.desc()
    ).all()
    
    # Calculate statistics
    if reviews:
        avg_technical = sum(r.technical_rating for r in reviews) / len(reviews)
        avg_functional = sum(r.functional_rating for r in reviews) / len(reviews)
        avg_overall = sum(r.overall_rating for r in reviews) / len(reviews)
    else:
        avg_technical = avg_functional = avg_overall = 0
    
    return render_template(
        'contract/view_reviews.html',
        candidate=candidate,
        reviews=reviews,
        avg_technical=round(avg_technical, 2),
        avg_functional=round(avg_functional, 2),
        avg_overall=round(avg_overall, 2)
    )


@contract_bp.route('/pending-reviews')
@login_required
@role_required('Hiring_Manager')
def pending_reviews():
    """List of contract employees needing reviews this month"""
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    # Get HM's contract positions
    positions = Position.query.filter_by(
        hm_id=current_user.id,
        position_type='contract'
    ).all()
    
    position_ids = [p.id for p in positions]
    
    # Get hired contract employees
    contract_employees = Candidate.query.filter(
        Candidate.position_id.in_(position_ids),
        Candidate.status == 'hired',
        Candidate.joining_date.isnot(None)
    ).all()
    
    # Filter those without current month review
    pending = []
    for emp in contract_employees:
        review_exists = ContractPerformanceReview.query.filter_by(
            candidate_id=emp.id,
            review_month=current_month,
            review_year=current_year
        ).first()
        
        if not review_exists:
            # Check if they've been working for at least a month
            months_working = (
                (current_year - emp.joining_date.year) * 12 +
                (current_month - emp.joining_date.month)
            )
            if months_working >= 1:
                pending.append(emp)
    
    return render_template(
        'contract/pending_reviews.html',
        pending_employees=pending,
        current_month=month_name[current_month]
    )