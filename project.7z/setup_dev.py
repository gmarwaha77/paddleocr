# setup_dev.py - Place in recruitflow_project/ (NOT inside recruitflow_project/)
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app, db
from recruitflow.models import Role, User, PositionTitle
from werkzeug.security import generate_password_hash

# Default admin credentials
DEFAULT_ADMIN_USERNAME = 'admin'
DEFAULT_ADMIN_PASSWORD = 'Admin@123'


def setup_database():
    """Initialize the database, create roles, and the first admin user."""
    with app.app_context():
        # Check if database exists
        db_file = app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
        if os.path.exists(db_file):
            print(f"⚠️  Database file '{db_file}' already exists.")
            recreate = input("Do you want to delete it and start fresh? (y/n): ").lower()
            if recreate == 'y':
                os.remove(db_file)
                print("✅ Existing database deleted.")
            else:
                print("❌ Setup cancelled. Using existing database.")
                return

        print("\n📦 Creating all database tables...")
        db.create_all()
        print("✅ Tables created successfully.\n")

        # Create roles
        print("👥 Creating user roles...")
        roles = ['SA', 'HM', 'Recruiter', 'IP']
        for role_name in roles:
            if not Role.query.filter_by(name=role_name).first():
                role = Role(name=role_name)
                db.session.add(role)
        db.session.commit()
        print("✅ Roles created: SA, HM, Recruiter, IP\n")

        # Create sample position titles
        print("📋 Creating sample position titles...")
        titles = ['Software Engineer', 'Data Analyst', 'Project Manager', 'UI/UX Designer']
        for title in titles:
            if not PositionTitle.query.filter_by(title=title).first():
                pos_title = PositionTitle(title=title)
                db.session.add(pos_title)
        db.session.commit()
        print("✅ Position titles created\n")

        # Create admin user
        print(f"🔐 Creating default admin user '{DEFAULT_ADMIN_USERNAME}'...")
        if not User.query.filter_by(username=DEFAULT_ADMIN_USERNAME).first():
            sa_role = Role.query.filter_by(name='SA').first()
            if sa_role:
                admin_user = User(
                    username=DEFAULT_ADMIN_USERNAME,
                    password_hash=generate_password_hash(DEFAULT_ADMIN_PASSWORD),
                    role_id=sa_role.id,
                    full_name='System Administrator',
                    email='admin@recruitflow_project.local',
                    is_active=True
                )
                db.session.add(admin_user)
                db.session.commit()

                print("\n" + "=" * 60)
                print("✅ SETUP COMPLETE!")
                print("=" * 60)
                print(f"🔑 Admin Credentials:")
                print(f"   Username: {DEFAULT_ADMIN_USERNAME}")
                print(f"   Password: {DEFAULT_ADMIN_PASSWORD}")
                print("=" * 60)
                print("\n📝 Next Steps:")
                print("   1. Run: python run.py")
                print("   2. Open: http://localhost:5000")
                print("   3. Login with admin credentials")
                print("=" * 60 + "\n")
            else:
                print("❌ Error: 'SA' role not found. Could not create admin user.")
        else:
            print(f"ℹ️  Admin user '{DEFAULT_ADMIN_USERNAME}' already exists.\n")


if __name__ == '__main__':
    setup_database()