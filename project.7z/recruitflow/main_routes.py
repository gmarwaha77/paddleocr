# recruitflow/main_routes.py (COMPLETE & FIXED)
import os
from flask import (Blueprint, render_template, request, redirect, url_for,
                   flash, current_app, send_from_directory, abort)
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from .models import (db, User, Role, Position, PositionTitle, Candidate,
                     InterviewPanel, Interview, InterviewFeedback, CandidateNote)
from .cv_parser import parse_cv, extract_text_from_docx
from .utils.helpers import role_required, log_action

main = Blueprint('main', __name__)


# --- Authentication Routes ---

@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            if user.is_active:
                login_user(user, remember=True)
                log_action(f'User {user.username} logged in successfully.')
                return redirect(url_for('main.dashboard'))
            else:
                flash('Your account is inactive. Please contact the administrator.', 'warning')
        else:
            flash('Invalid username or password. Please try again.', 'danger')
    return render_template('login.html')


@main.route('/logout')
@login_required
def logout():
    log_action(f'User {current_user.username} logged out.')
    logout_user()
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('main.login'))


# --- Dashboard Route ---

@main.route('/')
@login_required
def dashboard():
    role_name = current_user.role.name
    if role_name == 'HM':
        positions = Position.query.filter_by(hm_id=current_user.id).all()
        return render_template('hm_dashboard.html', positions=positions)
    elif role_name == 'Recruiter':
        positions = Position.query.filter(Position.status.in_(['approved', 'open'])).all()
        return render_template('recruiter_dashboard.html', positions=positions)
    elif role_name == 'IP':
        panel_positions = [p.position_id for p in InterviewPanel.query.filter_by(ip_user_id=current_user.id).all()]
        candidates = Candidate.query.join(Interview).filter(
            Candidate.position_id.in_(panel_positions),
            Interview.status == 'scheduled'
        ).all()
        return render_template('ip_dashboard.html', candidates=candidates)
    elif role_name == 'SA':
        positions = Position.query.filter_by(status='pending_approval').all()
        return render_template('sa_dashboard.html', positions=positions)
    else:
        return "Dashboard not configured for this role."


# --- Position Management (HM & SA) ---

@main.route('/positions/create', methods=['GET', 'POST'])
@login_required
@role_required('HM')
def create_position():
    if request.method == 'POST':
        title_id = request.form.get('title_id')
        project_name = request.form.get('project_name')
        openings = request.form.get('openings')
        jd_file = request.files.get('jd_file')

        if not all([title_id, project_name, openings, jd_file]):
            flash('All fields are required.', 'danger')
            return redirect(request.url)

        filename = secure_filename(jd_file.filename)
        jd_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        jd_file.save(jd_path)

        position = Position(
            title_id=title_id,
            project_name=project_name,
            openings=int(openings),
            jd_file_path=jd_path,
            hm_id=current_user.id,
            status='draft'
        )
        db.session.add(position)
        db.session.commit()

        # Add interview panel
        for i in range(3):
            ip_username = request.form.get(f'ip_{i}')
            ip_user = User.query.filter_by(username=ip_username,
                                           role_id=Role.query.filter_by(name='IP').first().id).first()
            if ip_user:
                panel = InterviewPanel(position_id=position.id, ip_user_id=ip_user.id)
                db.session.add(panel)

        db.session.commit()
        log_action(f'Position "{position.position_title.title}" created in draft state.', 
                   entity_type='Position', entity_id=position.id)
        flash('Position created as a draft. You can submit it for approval from your dashboard.', 'success')
        return redirect(url_for('main.dashboard'))

    titles = PositionTitle.query.all()
    return render_template('create_position.html', titles=titles)


@main.route('/positions/<int:pos_id>/submit', methods=['POST'])
@login_required
@role_required('HM')
def submit_for_approval(pos_id):
    position = Position.query.get_or_404(pos_id)
    if position.hm_id != current_user.id:
        abort(403)
    position.status = 'pending_approval'
    db.session.commit()
    log_action(f'Position "{position.position_title.title}" submitted for approval.', 
               entity_type='Position', entity_id=pos_id)
    flash('Position submitted for approval.', 'success')
    return redirect(url_for('main.dashboard'))


@main.route('/positions/<int:pos_id>/approve', methods=['POST'])
@login_required
@role_required('SA')
def approve_position(pos_id):
    position = Position.query.get_or_404(pos_id)
    action = request.form.get('action')
    if action == 'approve':
        position.status = 'approved'
        flash('Position has been approved and is now active.', 'success')
        log_action(f'Position "{position.position_title.title}" approved.', 
                   entity_type='Position', entity_id=pos_id)
    elif action == 'reject':
        position.status = 'rejected'
        flash('Position has been rejected.', 'warning')
        log_action(f'Position "{position.position_title.title}" rejected.', 
                   entity_type='Position', entity_id=pos_id)
    db.session.commit()
    return redirect(url_for('main.dashboard'))


# --- Candidate Management (Recruiter & HM) ---

@main.route('/positions/<int:pos_id>/candidates')
@login_required
def candidate_list(pos_id):
    position = Position.query.get_or_404(pos_id)
    candidates = position.candidates.order_by(Candidate.created_at.desc()).all()
    return render_template('candidate_list.html', position=position, candidates=candidates)


@main.route('/positions/<int:pos_id>/upload_cv', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter')
def upload_cv(pos_id):
    position = Position.query.get_or_404(pos_id)
    if request.method == 'POST':
        cv_file = request.files.get('cv_file')
        if not cv_file or cv_file.filename == '':
            flash('No file selected.', 'danger')
            return redirect(request.url)

        # Validate file extension
        if not cv_file.filename.lower().endswith(('.docx', '.pdf')):
            flash('Invalid file type. Please upload .docx or .pdf files only.', 'danger')
            return redirect(request.url)

        filename = secure_filename(cv_file.filename)
        cv_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        cv_file.save(cv_path)

        try:
            # Check if JD file exists
            if not position.jd_file_path or not os.path.exists(position.jd_file_path):
                flash(f'Warning: Job Description file not found. CV will be processed without similarity matching.', 'warning')
                jd_text = ""
            else:
                jd_text = extract_text_from_docx(position.jd_file_path)
            
            # Parse CV
            cv_data = parse_cv(cv_path, jd_text)

            # Create candidate record
            candidate = Candidate(
                position_id=pos_id,
                cv_file_path=cv_path,
                **cv_data
            )
            db.session.add(candidate)
            db.session.commit()
            
            log_action(
                f'New CV for candidate "{candidate.name}" uploaded to position "{position.position_title.title}".',
                entity_type='Candidate', entity_id=candidate.id)
            
            flash(
                f'CV processed successfully! Candidate {cv_data["name"]} added with a match score of {cv_data["similarity_score"]:.2f}%.',
                'success')
                
        except FileNotFoundError as e:
            db.session.rollback()
            # Clean up uploaded CV if processing failed
            if os.path.exists(cv_path):
                os.remove(cv_path)
            flash(f'File not found: {str(e)}', 'danger')
            return redirect(request.url)
            
        except ValueError as e:
            db.session.rollback()
            # Clean up uploaded CV if processing failed
            if os.path.exists(cv_path):
                os.remove(cv_path)
            flash(f'Validation error: {str(e)}', 'danger')
            return redirect(request.url)
            
        except Exception as e:
            db.session.rollback()
            # Clean up uploaded CV if processing failed
            if os.path.exists(cv_path):
                os.remove(cv_path)
            flash(f'An error occurred while parsing the CV: {str(e)}', 'danger')
            return redirect(request.url)

        return redirect(url_for('main.candidate_list', pos_id=pos_id))

    return render_template('upload_cv.html', position=position)


@main.route('/candidates/<int:cand_id>/review', methods=['POST'])
@login_required
@role_required('HM')
def hm_review(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    action = request.form.get('action')
    if action == 'accept':
        candidate.status = 'under_hm_review'
        flash('Candidate accepted for the next round.', 'success')
    else:
        candidate.status = 'rejected_by_hm'
        flash('Candidate has been rejected.', 'info')
    db.session.commit()
    log_action(f'HM reviewed candidate "{candidate.name}" with action: {action}.', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- Test Allocation & Updates (MISSING ROUTES - NOW ADDED) ---

@main.route('/candidates/<int:cand_id>/allocate_test', methods=['POST'])
@login_required
@role_required('Recruiter')
def allocate_test(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    candidate.status = 'test_allocated'
    db.session.commit()
    
    flash(f'Test allocated to {candidate.name}. Update status after completion.', 'success')
    log_action(f'Test allocated to candidate "{candidate.name}".', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


@main.route('/candidates/<int:cand_id>/update_test', methods=['POST'])
@login_required
@role_required('Recruiter')
def update_test(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    status = request.form.get('status')
    score = request.form.get('score')
    
    if status == 'passed':
        candidate.status = 'test_passed'
        if score:
            candidate.test_score = float(score)
        flash(f'{candidate.name} passed the test! Ready for interview.', 'success')
    elif status == 'failed':
        candidate.status = 'test_failed'
        if score:
            candidate.test_score = float(score)
        flash(f'{candidate.name} did not pass the test.', 'info')
    
    db.session.commit()
    log_action(f'Test status updated for candidate "{candidate.name}": {status}.', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- Interview & Feedback ---

@main.route('/candidates/<int:cand_id>/schedule_interview', methods=['POST'])
@login_required
@role_required('Recruiter')
def schedule_interview(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    schedule_date = request.form.get('date')

    interview = Interview(candidate_id=cand_id, schedule_date=schedule_date)
    candidate.status = 'interview'
    db.session.add(interview)
    db.session.commit()

    flash(f'Interview scheduled for {candidate.name} on {schedule_date}.', 'success')
    log_action(f'Interview scheduled for candidate "{candidate.name}".', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


@main.route('/interviews/<int:interview_id>/feedback', methods=['GET', 'POST'])
@login_required
@role_required('IP')
def provide_feedback(interview_id):
    interview = Interview.query.get_or_404(interview_id)
    if request.method == 'POST':
        rating = request.form.get('rating')
        comments = request.form.get('comments')

        feedback = InterviewFeedback(
            interview_id=interview_id,
            ip_user_id=current_user.id,
            rating=int(rating),
            comments=comments
        )
        db.session.add(feedback)
        interview.status = 'completed'
        db.session.commit()

        flash('Feedback submitted successfully.', 'success')
        log_action(f'Feedback submitted for interview {interview_id}.', 
                   entity_type='Interview', entity_id=interview_id)
        return redirect(url_for('main.dashboard'))

    return render_template('feedback_form.html', interview=interview)


@main.route('/candidates/<int:cand_id>/notes', methods=['POST'])
@login_required
@role_required('Recruiter', 'HM')
def add_note(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    note_text = request.form.get('note_text')
    if not note_text:
        flash('Note cannot be empty.', 'warning')
    else:
        note = CandidateNote(
            candidate_id=cand_id,
            author_id=current_user.id,
            note=note_text
        )
        db.session.add(note)
        db.session.commit()
        flash('Note added successfully.', 'success')
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- File Downloads & Miscellaneous ---

@main.route('/uploads/<filename>')
@login_required
def download_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)


@main.route('/silver_medalists')
@login_required
@role_required('HM', 'Recruiter')
def silver_medalists():
    candidates = Candidate.query.filter_by(is_silver=True).all()
    return render_template('silver_medalists.html', candidates=candidates)


# --- Reporting (ADDED) ---

@main.route('/reporting')
@login_required
@role_required('SA')
def reporting():
    """Reporting dashboard for SA"""
    # Position stats
    positions_by_status = db.session.query(
        Position.status,
        db.func.count(Position.id)
    ).group_by(Position.status).all()
    
    # Candidate stats
    candidates_by_status = db.session.query(
        Candidate.status,
        db.func.count(Candidate.id)
    ).group_by(Candidate.status).all()
    
    # Aggregate metrics
    open_positions = Position.query.filter(Position.status.in_(['approved', 'open'])).count()
    total_candidates = Candidate.query.count()
    candidates_in_interview = Candidate.query.filter_by(status='interview').count()
    
    avg_similarity = db.session.query(db.func.avg(Candidate.similarity_score)).scalar() or 0
    
    return render_template('reporting.html',
                          positions_by_status=positions_by_status,
                          candidates_by_status=candidates_by_status,
                          open_positions=open_positions,
                          total_candidates=total_candidates,
                          candidates_in_interview=candidates_in_interview,
                          avg_similarity=round(avg_similarity, 2))


# --- Audit Logs (ADDED) ---

@main.route('/audit_logs')
@login_required
@role_required('SA')
def audit_logs():
    """View audit logs"""
    from .models import AuditLog
    page = request.args.get('page', 1, type=int)
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=50)
    return render_template('admin/audit_log.html', logs=logs)