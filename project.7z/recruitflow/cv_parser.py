# recruitflow/cv_parser.py (FIXED)
import docx
import pdfplumber
import re
import spacy
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

nlp = spacy.load("en_core_web_sm")

def extract_text_from_docx(file_path):
    """Extract text from DOCX file with error handling"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    try:
        doc = docx.Document(file_path)
        return " ".join([para.text for para in doc.paragraphs])
    except Exception as e:
        raise Exception(f"Error reading DOCX file: {str(e)}")

def extract_text_from_pdf(file_path):
    """Extract text from PDF file with error handling"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    try:
        text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        return text
    except Exception as e:
        raise Exception(f"Error reading PDF file: {str(e)}")

def extract_fields(text):
    """Extract candidate information from CV text"""
    doc = nlp(text)
    fields = {
        'name': '',
        'location': '',
        'phone': '',
        'email': '',
        'linkedin': '',
        'experience': 0.0,
        'key_skills': '',
        'education': '',
        'employment_history': ''
    }

    # Simple regex for common fields
    email_regex = re.compile(r'[\w\.-]+@[\w\.-]+')
    phone_regex = re.compile(r'(\+?\d{1,3}[-.\s]?)?(\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}')
    linkedin_regex = re.compile(r'(linkedin\.com/in/[\w\-]+)')
    experience_regex = re.compile(r'(\d+)\s*(years?|yrs?)(\s*of\s*experience)?', re.I)

    fields['email'] = email_regex.search(text).group() if email_regex.search(text) else ''
    fields['phone'] = phone_regex.search(text).group() if phone_regex.search(text) else ''
    fields['linkedin'] = linkedin_regex.search(text).group() if linkedin_regex.search(text) else ''
    match = experience_regex.search(text)
    if match:
        fields['experience'] = float(match.group(1))

    # Use spaCy for NER
    persons_found = []
    for ent in doc.ents:
        if ent.label_ == 'PERSON':
            persons_found.append(ent.text)
        elif ent.label_ == 'GPE':
            fields['location'] += ent.text + ', '
        elif ent.label_ == 'ORG':
            fields['employment_history'] += ent.text + ', '

    # Take first person name found (usually candidate name)
    if persons_found:
        fields['name'] = persons_found[0]
    
    # Extract skills (simple keyword matching - can be enhanced)
    skill_keywords = ['python', 'java', 'javascript', 'react', 'angular', 'node', 'sql', 
                     'mongodb', 'aws', 'azure', 'docker', 'kubernetes', 'flask', 'django',
                     'html', 'css', 'git', 'agile', 'scrum', 'api', 'rest', 'microservices']
    
    text_lower = text.lower()
    found_skills = [skill for skill in skill_keywords if skill in text_lower]
    fields['key_skills'] = ', '.join(found_skills) if found_skills else 'Not detected'
    
    # Clean up
    fields['location'] = fields['location'].strip(', ') or 'Not specified'
    fields['employment_history'] = fields['employment_history'].strip(', ') or 'Not specified'
    fields['education'] = 'Not specified'  # Placeholder - enhance as needed
    
    return fields

def calculate_similarity(jd_text, cv_text):
    """Calculate similarity between JD and CV"""
    try:
        vectorizer = TfidfVectorizer()
        vectors = vectorizer.fit_transform([jd_text, cv_text])
        similarity = cosine_similarity(vectors[0:1], vectors[1:2])[0][0] * 100
        return round(similarity, 2)
    except Exception as e:
        print(f"Warning: Could not calculate similarity: {e}")
        return 50.0  # Return default similarity on error

def parse_cv(cv_path, jd_text):
    """Parse CV and calculate match with JD"""
    # Validate CV file exists
    if not os.path.exists(cv_path):
        raise FileNotFoundError(f"CV file not found: {cv_path}")
    
    # Extract text based on file type
    if cv_path.lower().endswith('.docx'):
        cv_text = extract_text_from_docx(cv_path)
    elif cv_path.lower().endswith('.pdf'):
        cv_text = extract_text_from_pdf(cv_path)
    else:
        raise ValueError(f"Unsupported file type. Please upload .docx or .pdf files only.")
    
    if not cv_text or len(cv_text.strip()) < 50:
        raise ValueError("CV appears to be empty or too short. Please upload a valid CV.")
    
    # Extract candidate information
    fields = extract_fields(cv_text)
    
    # Calculate similarity with JD
    if jd_text and len(jd_text.strip()) > 50:
        similarity = calculate_similarity(jd_text, cv_text)
    else:
        print("Warning: JD text is empty or too short, using default similarity")
        similarity = 50.0
    
    fields['similarity_score'] = similarity
    
    # Ensure name is not empty
    if not fields['name']:
        fields['name'] = 'Name not detected'
    
    return fields