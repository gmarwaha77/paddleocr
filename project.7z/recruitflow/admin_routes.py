# recruitflow_project/admin_routes.py (NEW)
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from .models import db, User, Role, AuditLog
from recruitflow.utils import role_required, log_action
from werkzeug.security import generate_password_hash

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# --- User Management ---

@admin_bp.route('/users')
@login_required
@role_required('SA')
def user_list():
    """Display a list of all users."""
    users = User.query.order_by(User.username).all()
    return render_template('admin/user_list.html', users=users)

@admin_bp.route('/users/new', methods=['GET', 'POST'])
@login_required
@role_required('SA')
def create_user():
    """Create a new user."""
    if request.method == 'POST':
        username = request.form.get('username')
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        role_id = request.form.get('role_id')
        is_active = 'is_active' in request.form

        # Validation
        if User.query.filter_by(username=username).first():
            flash(f'Username "{username}" already exists.', 'danger')
            return redirect(request.url)
        if User.query.filter_by(email=email).first():
            flash(f'Email "{email}" is already in use.', 'danger')
            return redirect(request.url)

        new_user = User(
            username=username,
            full_name=full_name,
            email=email,
            role_id=int(role_id),
            is_active=is_active
        )
        new_user.set_password(password)

        db.session.add(new_user)
        db.session.commit()

        log_action(f'New user "{username}" created.', entity_type='User', entity_id=new_user.id)
        flash(f'User "{username}" has been created successfully.', 'success')
        return redirect(url_for('admin.user_list'))

    roles = Role.query.all()
    return render_template('admin/user_form.html', roles=roles, form_title='Create New User', user=None)


@admin_bp.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
@role_required('SA')
def edit_user(user_id):
    """Edit an existing user's details."""
    user = User.query.get_or_404(user_id)
    if request.method == 'POST':
        # Get data from form
        user.full_name = request.form.get('full_name')
        user.email = request.form.get('email')
        user.role_id = int(request.form.get('role_id'))
        user.is_active = 'is_active' in request.form
        password = request.form.get('password')

        # Check for email uniqueness if changed
        if User.query.filter(User.email == user.email, User.id != user_id).first():
            flash(f'Email "{user.email}" is already in use by another user.', 'danger')
            return redirect(request.url)

        if password:
            user.set_password(password)
            flash('User password has been updated.', 'info')

        db.session.commit()
        log_action(f'User "{user.username}" (ID: {user_id}) updated.', entity_type='User', entity_id=user_id)
        flash(f'User "{user.username}" has been updated successfully.', 'success')
        return redirect(url_for('admin.user_list'))

    roles = Role.query.all()
    return render_template('admin/user_form.html', roles=roles, user=user, form_title=f'Edit User: {user.username}')

# --- Audit Log Viewer ---

@admin_bp.route('/audit-log')
@login_required
@role_required('SA')
def audit_log():
    """Display the audit log."""
    page = request.args.get('page', 1, type=int)
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=20)
    return render_template('admin/audit_log.html', logs=logs)
