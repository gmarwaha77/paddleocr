# recruitflow_project/utils/salary_calculator.py
"""
Indian CTC Salary Calculator Utilities
Handles Indian salary structure with all statutory components
"""


class IndianSalaryCalculator:
    """
    Calculate Indian CTC breakup based on standard formulas

    Standard CTC Structure:
    - Basic: 40-50% of CTC
    - HRA: 40-50% of Basic
    - Special Allowance: Balancing component
    - PF: 12% of Basic (capped at ₹1,800/month)
    - Gratuity: ~4.81% of Basic
    - Professional Tax: ₹2,400/year (varies by state)
    """

    # Constants
    PF_RATE = 0.12
    PF_MAX_MONTHLY = 1800
    GRATUITY_RATE = 0.0481
    PROFESSIONAL_TAX_ANNUAL = 2400

    def __init__(self, annual_ctc):
        """
        Initialize calculator with annual CTC

        Args:
            annual_ctc (float): Annual CTC in rupees
        """
        self.annual_ctc = float(annual_ctc)
        self.breakup = {}

    def calculate_standard_breakup(self, basic_percentage=0.40):
        """
        Calculate standard CTC breakup

        Args:
            basic_percentage (float): Percentage of CTC as basic (default 40%)

        Returns:
            dict: Complete salary breakup
        """
        # Basic salary
        basic = self.annual_ctc * basic_percentage

        # HRA (50% of basic)
        hra = basic * 0.50

        # Performance bonus (10% of CTC)
        bonus = self.annual_ctc * 0.10

        # Calculate employer contributions
        pf_employer = min(basic * self.PF_RATE, self.PF_MAX_MONTHLY * 12)
        gratuity = basic * self.GRATUITY_RATE

        # Special allowance is balancing figure
        fixed_components = basic + hra + bonus + pf_employer + gratuity
        special_allowance = self.annual_ctc - fixed_components

        # Employee deductions
        pf_employee = pf_employer  # Same as employer contribution
        professional_tax = self.PROFESSIONAL_TAX_ANNUAL

        # Monthly calculations
        monthly_gross = (basic + hra + special_allowance) / 12
        monthly_deductions = (pf_employee + professional_tax) / 12
        monthly_net = monthly_gross - monthly_deductions

        self.breakup = {
            'annual_ctc': self.annual_ctc,
            'basic_salary': round(basic, 2),
            'hra': round(hra, 2),
            'special_allowance': round(special_allowance, 2),
            'performance_bonus': round(bonus, 2),
            'pf_employer': round(pf_employer, 2),
            'gratuity': round(gratuity, 2),
            'pf_employee': round(pf_employee, 2),
            'professional_tax': professional_tax,
            'monthly_gross': round(monthly_gross, 2),
            'monthly_net': round(monthly_net, 2),
            'annual_gross': round(monthly_gross * 12, 2),
            'annual_net': round(monthly_net * 12, 2)
        }

        return self.breakup

    def calculate_with_components(self, **components):
        """
        Calculate CTC with specific component values

        Args:
            **components: Component values (basic_salary, hra, etc.)

        Returns:
            dict: Complete salary breakup
        """
        basic = components.get('basic_salary', self.annual_ctc * 0.40)
        hra = components.get('hra', basic * 0.50)
        special = components.get('special_allowance', self.annual_ctc * 0.20)
        bonus = components.get('performance_bonus', self.annual_ctc * 0.10)

        pf_employer = min(basic * self.PF_RATE, self.PF_MAX_MONTHLY * 12)
        gratuity = basic * self.GRATUITY_RATE

        pf_employee = pf_employer
        pt = self.PROFESSIONAL_TAX_ANNUAL

        monthly_gross = (basic + hra + special) / 12
        monthly_deductions = (pf_employee + pt) / 12
        monthly_net = monthly_gross - monthly_deductions

        self.breakup = {
            'annual_ctc': self.annual_ctc,
            'basic_salary': round(basic, 2),
            'hra': round(hra, 2),
            'special_allowance': round(special, 2),
            'performance_bonus': round(bonus, 2),
            'pf_employer': round(pf_employer, 2),
            'gratuity': round(gratuity, 2),
            'pf_employee': round(pf_employee, 2),
            'professional_tax': pt,
            'monthly_gross': round(monthly_gross, 2),
            'monthly_net': round(monthly_net, 2)
        }

        return self.breakup

    def get_take_home(self):
        """Get monthly take-home salary"""
        if not self.breakup:
            self.calculate_standard_breakup()
        return self.breakup['monthly_net']

    def get_annual_take_home(self):
        """Get annual take-home salary"""
        return self.get_take_home() * 12

    def compare_offers(self, other_ctc):
        """
        Compare two CTC offers

        Args:
            other_ctc (float): Other CTC amount to compare

        Returns:
            dict: Comparison details
        """
        calc1 = IndianSalaryCalculator(self.annual_ctc)
        calc1.calculate_standard_breakup()

        calc2 = IndianSalaryCalculator(other_ctc)
        calc2.calculate_standard_breakup()

        return {
            'ctc_difference': other_ctc - self.annual_ctc,
            'monthly_net_difference': calc2.get_take_home() - calc1.get_take_home(),
            'annual_net_difference': calc2.get_annual_take_home() - calc1.get_annual_take_home(),
            'percentage_increase': ((other_ctc - self.annual_ctc) / self.annual_ctc) * 100
        }

    def calculate_hike(self, current_ctc, hike_percentage):
        """
        Calculate new CTC after hike

        Args:
            current_ctc (float): Current CTC
            hike_percentage (float): Hike percentage

        Returns:
            float: New CTC after hike
        """
        return current_ctc * (1 + hike_percentage / 100)

    @staticmethod
    def format_currency(amount):
        """Format amount in Indian currency format"""
        amount = float(amount)

        if amount >= 10000000:  # 1 Crore
            return f"₹{amount / 10000000:.2f} Cr"
        elif amount >= 100000:  # 1 Lakh
            return f"₹{amount / 100000:.2f} L"
        else:
            return f"₹{amount:,.0f}"


# Helper functions for templates
def format_ctc(amount):
    """Jinja2 filter for formatting CTC"""
    return IndianSalaryCalculator.format_currency(amount)


def calculate_hike_percentage(current_ctc, new_ctc):
    """Calculate hike percentage"""
    if current_ctc == 0:
        return 0
    return ((new_ctc - current_ctc) / current_ctc) * 100


# Example usage and tests
if __name__ == '__main__':
    # Example 1: Standard calculation
    calc = IndianSalaryCalculator(1200000)  # 12 LPA
    breakup = calc.calculate_standard_breakup()

    print("CTC Breakup for ₹12,00,000:")
    print(f"Basic: ₹{breakup['basic_salary']:,.0f}")
    print(f"HRA: ₹{breakup['hra']:,.0f}")
    print(f"Special Allowance: ₹{breakup['special_allowance']:,.0f}")
    print(f"Performance Bonus: ₹{breakup['performance_bonus']:,.0f}")
    print(f"Monthly In-hand: ₹{breakup['monthly_net']:,.0f}")
    print(f"Annual In-hand: ₹{breakup['annual_net']:,.0f}")

    # Example 2: Compare offers
    comparison = calc.compare_offers(1500000)  # 15 LPA
    print(f"\nComparing ₹12L vs ₹15L:")
    print(f"CTC Increase: {IndianSalaryCalculator.format_currency(comparison['ctc_difference'])}")
    print(f"Monthly Net Increase: {IndianSalaryCalculator.format_currency(comparison['monthly_net_difference'])}")
    print(f"Percentage Increase: {comparison['percentage_increase']:.1f}%")

    # Example 3: Calculate hike
    new_ctc = calc.calculate_hike(1200000, 15)  # 15% hike
    print(f"\n15% hike on ₹12L: {IndianSalaryCalculator.format_currency(new_ctc)}")