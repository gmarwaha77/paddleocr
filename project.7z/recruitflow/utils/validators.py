# recruitflow_project/utils/validators.py
"""
Validation utilities
"""
import re
from werkzeug.utils import secure_filename

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """Validate phone number format"""
    # Remove common separators
    cleaned = re.sub(r'[-.()\s]', '', phone)
    # Check if it's a valid number (10-15 digits)
    return len(cleaned) >= 10 and len(cleaned) <= 15 and cleaned.isdigit()

def validate_linkedin(url):
    """Validate LinkedIn URL"""
    pattern = r'(https?://)?(www\.)?linkedin\.com/in/[\w-]+'
    return re.match(pattern, url) is not None

def allowed_file(filename, allowed_extensions):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions

def sanitize_filename(filename):
    """Sanitize and secure filename"""
    # Remove path components
    filename = secure_filename(filename)
    
    # Add timestamp to prevent conflicts
    from datetime import datetime
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name, ext = filename.rsplit('.', 1)
    
    return f"{name}_{timestamp}.{ext}"