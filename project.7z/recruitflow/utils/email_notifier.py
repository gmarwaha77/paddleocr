# recruitflow_project/utils/email_notifier.py
"""
Email notification module
NOTE: Only works when network allows external connections
For offline environments, this will be disabled
"""
import os
from flask import current_app
from flask_mail import Mail, Message

mail = Mail()

def init_mail(app):
    """Initialize email configuration"""
    app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.internal.company.com')
    app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
    app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
    app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME')
    app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD')
    app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', 'recruitflow_project@company.com')
    mail.init_app(app)

def send_email(to, subject, template, **kwargs):
    """
    Send email notification
    
    Args:
        to: Recipient email address(es)
        subject: Email subject
        template: Email body template
        **kwargs: Template variables
    """
    try:
        msg = Message(
            subject=f'[RecruitFlow] {subject}',
            recipients=[to] if isinstance(to, str) else to,
            body=template.format(**kwargs)
        )
        mail.send(msg)
        return True
    except Exception as e:
        current_app.logger.error(f'Failed to send email: {str(e)}')
        return False

def notify_position_submitted(position, approver_email):
    """Notify SA when position is submitted"""
    template = """
    Hello,
    
    A new position has been submitted for your approval:
    
    Position: {title}
    Project: {project}
    Openings: {openings}
    Submitted by: {hm_name}
    
    Please log in to RecruitFlow to review and approve.
    
    Best regards,
    RecruitFlow System
    """
    
    return send_email(
        approver_email,
        'New Position Awaiting Approval',
        template,
        title=position.position_title.title,
        project=position.project_name,
        openings=position.openings,
        hm_name=position.hiring_manager.username
    )

def notify_position_approved(position, hm_email):
    """Notify HM when position is approved"""
    template = """
    Hello,
    
    Your position requisition has been approved:
    
    Position: {title}
    Project: {project}
    
    The position is now active and recruiters can start uploading CVs.
    
    Best regards,
    RecruitFlow System
    """
    
    return send_email(
        hm_email,
        'Position Approved',
        template,
        title=position.position_title.title,
        project=position.project_name
    )

def notify_interview_scheduled(candidate, interview, panel_emails):
    """Notify interview panel members"""
    template = """
    Hello,
    
    You have been assigned to interview a candidate:
    
    Candidate: {name}
    Position: {position}
    Date: {date}
    
    Please log in to RecruitFlow to view candidate details.
    
    Best regards,
    RecruitFlow System
    """
    
    return send_email(
        panel_emails,
        'Interview Scheduled',
        template,
        name=candidate.name,
        position=candidate.position.position_title.title,
        date=interview.schedule_date
    )