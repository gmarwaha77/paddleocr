# recruitflow_project/utils/search.py
"""
Advanced search utilities
"""
from sqlalchemy import or_, and_

def build_candidate_search_query(base_query, filters):
    """
    Build advanced search query for candidates
    
    Args:
        base_query: Base SQLAlchemy query
        filters: Dictionary of filter criteria
    
    Returns:
        Modified query
    """
    from recruitflow.models import Candidate
    
    # Text search (name, skills)
    if filters.get('search'):
        search_term = f"%{filters['search']}%"
        base_query = base_query.filter(
            or_(
                Candidate.name.ilike(search_term),
                Candidate.key_skills.ilike(search_term),
                Candidate.email.ilike(search_term)
            )
        )
    
    # Experience range
    if filters.get('min_experience'):
        base_query = base_query.filter(
            Candidate.experience >= filters['min_experience']
        )
    
    if filters.get('max_experience'):
        base_query = base_query.filter(
            Candidate.experience <= filters['max_experience']
        )
    
    # Similarity score range
    if filters.get('min_similarity'):
        base_query = base_query.filter(
            Candidate.similarity_score >= filters['min_similarity']
        )
    
    # Status filter
    if filters.get('status'):
        base_query = base_query.filter_by(status=filters['status'])
    
    # Location filter
    if filters.get('location'):
        base_query = base_query.filter(
            Candidate.location.ilike(f"%{filters['location']}%")
        )
    
    # Silver medalist filter
    if filters.get('silver_only'):
        base_query = base_query.filter_by(is_silver=True)
    
    return base_query

def get_matching_candidates(jd_text, threshold=60, position_id=None):
    """
    Find candidates matching JD based on similarity threshold
    
    Args:
        jd_text: Job description text
        threshold: Minimum similarity score (0-100)
        position_id: Optional position ID to filter
    
    Returns:
        List of matching candidates
    """
    from recruitflow.models import Candidate
    from recruitflow.cv_parser import calculate_similarity
    
    query = Candidate.query
    
    if position_id:
        query = query.filter_by(position_id=position_id)
    
    candidates = query.filter(
        Candidate.similarity_score >= threshold
    ).order_by(Candidate.similarity_score.desc()).all()
    
    return candidates