# recruitflow_project/config.py (UPDATED)
import os
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()
basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    """Base configuration class."""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'a-very-hard-to-guess-secret-key'
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or os.path.join(basedir, 'static', 'uploads')
    ALLOWED_EXTENSIONS = {'docx', 'pdf'}
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class DevelopmentConfig(Config):
    """Development configuration."""
    # Use SQLite for simple, local development without a separate DB server
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'recruitflow_dev.db')
    DEBUG = True

class ProductionConfig(Config):
    """Production configuration."""
    # Use PostgreSQL for production (as originally intended)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'postgresql://user:password@localhost/recruitflow_project'
    DEBUG = False

def get_config():
    """Returns the appropriate config class based on the ENVIRONMENT variable."""
    env = os.environ.get('ENVIRONMENT', 'development').lower()
    if env == 'production':
        print("--- Running in PRODUCTION mode ---")
        return ProductionConfig
    print("--- Running in DEVELOPMENT mode ---")
    return DevelopmentConfig
