-- recruitflow_project/schema_enhanced.sql
-- Complete database schema with salary management and additional features

-- Base tables
CREATE TABLE role (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE "user" (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    full_name VARCHAR(100),
    role_id INTEGER REFERENCES role(id) NOT NULL
);

CREATE TABLE position_title (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL
);

CREATE TABLE position (
    id SERIAL PRIMARY KEY,
    title_id INTEGER REFERENCES position_title(id),
    project_name VARCHAR(100),
    openings INTEGER,
    jd_file_path VARCHAR(255),
    status VARCHAR(50) DEFAULT 'draft',
    hm_id INTEGER REFERENCES "user"(id),
    sa_id INTEGER REFERENCES "user"(id),
    min_ctc FLOAT,
    max_ctc FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE interview_panel (
    id SERIAL PRIMARY KEY,
    position_id INTEGER REFERENCES position(id),
    ip_user_id INTEGER REFERENCES "user"(id)
);

CREATE TABLE candidate (
    id SERIAL PRIMARY KEY,
    position_id INTEGER REFERENCES position(id),
    cv_file_path VARCHAR(255),
    name VARCHAR(100),
    location VARCHAR(100),
    phone VARCHAR(50),
    email VARCHAR(100),
    linkedin VARCHAR(255),
    experience FLOAT,
    key_skills TEXT,
    education TEXT,
    employment_history TEXT,
    similarity_score FLOAT,
    status VARCHAR(50) DEFAULT 'applied',
    test_score FLOAT,
    is_silver BOOLEAN DEFAULT FALSE,

    -- Enhanced fields
    current_ctc FLOAT,
    expected_ctc FLOAT,
    notice_period_days INTEGER,
    joining_date DATE,
    source VARCHAR(50),
    referred_by VARCHAR(100),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE interview (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),
    schedule_date DATE,
    schedule_time VARCHAR(20),
    interview_mode VARCHAR(20),
    meeting_link VARCHAR(255),
    status VARCHAR(50)
);

CREATE TABLE interview_feedback (
    id SERIAL PRIMARY KEY,
    interview_id INTEGER REFERENCES interview(id),
    ip_user_id INTEGER REFERENCES "user"(id),
    rating INTEGER,
    comments TEXT,

    -- Enhanced feedback
    technical_rating INTEGER,
    communication_rating INTEGER,
    cultural_fit_rating INTEGER,
    recommendation VARCHAR(20),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============= SALARY MANAGEMENT TABLES =============

CREATE TABLE salary_proposal (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),
    proposed_by INTEGER REFERENCES "user"(id),

    -- Total CTC
    annual_ctc FLOAT NOT NULL,

    -- CTC Breakup (Indian Structure)
    basic_salary FLOAT,
    hra FLOAT,
    special_allowance FLOAT,
    performance_bonus FLOAT,

    -- Employer Contributions
    pf_employer FLOAT,
    gratuity FLOAT,

    -- Deductions
    pf_employee FLOAT,
    professional_tax FLOAT,

    -- Additional Benefits
    medical_insurance FLOAT,
    other_benefits TEXT,

    -- In-hand salary
    monthly_gross FLOAT,
    monthly_net FLOAT,

    -- Approval workflow
    status VARCHAR(50) DEFAULT 'pending',
    approved_by INTEGER REFERENCES "user"(id),
    approval_date TIMESTAMP,
    approval_comments TEXT,

    -- Candidate response (via recruiter)
    candidate_response VARCHAR(50),
    candidate_feedback TEXT,
    counter_amount FLOAT,

    version INTEGER DEFAULT 1,
    is_final BOOLEAN DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE offer_letter (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),
    salary_proposal_id INTEGER REFERENCES salary_proposal(id),

    offer_letter_path VARCHAR(255),
    generated_by INTEGER REFERENCES "user"(id),
    generated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    -- Offer details
    designation VARCHAR(100),
    department VARCHAR(100),
    location VARCHAR(100),
    joining_date DATE,

    -- Status tracking
    sent_date TIMESTAMP,
    accepted_date TIMESTAMP,
    declined_date TIMESTAMP,
    status VARCHAR(50) DEFAULT 'draft'
);

-- ============= BACKGROUND VERIFICATION =============

CREATE TABLE background_check (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),

    check_type VARCHAR(50),
    status VARCHAR(50) DEFAULT 'pending',

    vendor_name VARCHAR(100),
    initiated_date DATE,
    completed_date DATE,

    findings TEXT,
    documents TEXT,

    verified_by INTEGER REFERENCES "user"(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============= ONBOARDING =============

CREATE TABLE onboarding_task (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),

    task_name VARCHAR(200),
    task_category VARCHAR(50),
    description TEXT,

    assigned_to INTEGER REFERENCES "user"(id),
    due_date DATE,

    status VARCHAR(50) DEFAULT 'pending',
    completed_date TIMESTAMP,

    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============= COMMUNICATION TRACKING =============

CREATE TABLE candidate_communication (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),

    communication_type VARCHAR(50),
    subject VARCHAR(200),
    message TEXT,

    communicated_by INTEGER REFERENCES "user"(id),
    communication_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    response_received BOOLEAN DEFAULT FALSE,
    response_text TEXT,
    response_date TIMESTAMP
);

-- ============= REFERENCE CHECKS =============

CREATE TABLE reference_check (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),

    reference_name VARCHAR(100),
    reference_designation VARCHAR(100),
    reference_company VARCHAR(100),
    reference_phone VARCHAR(50),
    reference_email VARCHAR(100),

    relationship VARCHAR(50),

    contacted_date DATE,
    contacted_by INTEGER REFERENCES "user"(id),

    overall_rating INTEGER,
    would_rehire BOOLEAN,
    feedback TEXT,

    status VARCHAR(50) DEFAULT 'pending'
);

-- ============= TALENT POOL =============

CREATE TABLE talent_pool (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidate(id),

    pool_category VARCHAR(50),
    skills_tags TEXT,
    experience_level VARCHAR(50),

    added_by INTEGER REFERENCES "user"(id),
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    last_contacted TIMESTAMP,
    availability VARCHAR(50),

    notes TEXT
);

-- ============= AUDIT LOG =============

CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES "user"(id),
    action TEXT,
    entity_type VARCHAR(50),
    entity_id INTEGER,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============= INDEXES FOR PERFORMANCE =============

CREATE INDEX idx_candidate_position ON candidate(position_id);
CREATE INDEX idx_candidate_status ON candidate(status);
CREATE INDEX idx_candidate_similarity ON candidate(similarity_score DESC);
CREATE INDEX idx_candidate_joining_date ON candidate(joining_date);

CREATE INDEX idx_salary_proposal_candidate ON salary_proposal(candidate_id);
CREATE INDEX idx_salary_proposal_status ON salary_proposal(status);
CREATE INDEX idx_salary_proposal_version ON salary_proposal(candidate_id, version DESC);

CREATE INDEX idx_background_check_candidate ON background_check(candidate_id);
CREATE INDEX idx_onboarding_task_candidate ON onboarding_task(candidate_id);
CREATE INDEX idx_communication_candidate ON candidate_communication(candidate_id);
CREATE INDEX idx_reference_check_candidate ON reference_check(candidate_id);
CREATE INDEX idx_talent_pool_candidate ON talent_pool(candidate_id);

CREATE INDEX idx_audit_log_user ON audit_log(user_id);
CREATE INDEX idx_audit_log_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_log_timestamp ON audit_log(timestamp DESC);

-- ============= VIEWS FOR REPORTING =============

-- Active candidates with salary proposals
CREATE VIEW v_candidates_with_salary AS
SELECT
    c.id,
    c.name,
    c.email,
    c.status,
    c.joining_date,
    p.title_id,
    pt.title as position_title,
    sp.annual_ctc,
    sp.monthly_net,
    sp.status as salary_status,
    sp.version as salary_version
FROM candidate c
JOIN position p ON c.position_id = p.id
JOIN position_title pt ON p.title_id = pt.id
LEFT JOIN salary_proposal sp ON c.id = sp.candidate_id AND sp.is_final = TRUE;

-- Onboarding progress
CREATE VIEW v_onboarding_progress AS
SELECT
    c.id as candidate_id,
    c.name,
    c.joining_date,
    COUNT(ot.id) as total_tasks,
    SUM(CASE WHEN ot.status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
    ROUND(100.0 * SUM(CASE WHEN ot.status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(ot.id), 0), 2) as completion_percentage
FROM candidate c
LEFT JOIN onboarding_task ot ON c.id = ot.candidate_id
WHERE c.joining_date IS NOT NULL
GROUP BY c.id, c.name, c.joining_date;

-- Pending approvals summary
CREATE VIEW v_pending_salary_approvals AS
SELECT
    sp.id,
    c.name as candidate_name,
    pt.title as position_title,
    sp.annual_ctc,
    sp.monthly_net,
    sp.version,
    u.username as proposed_by,
    sp.created_at
FROM salary_proposal sp
JOIN candidate c ON sp.candidate_id = c.id
JOIN position p ON c.position_id = p.id
JOIN position_title pt ON p.title_id = pt.id
JOIN "user" u ON sp.proposed_by = u.id
WHERE sp.status = 'pending'
ORDER BY sp.created_at DESC;

-- Recruitment funnel metrics
CREATE VIEW v_recruitment_funnel AS
SELECT
    p.id as position_id,
    pt.title as position_title,
    p.project_name,
    COUNT(DISTINCT c.id) as total_candidates,
    SUM(CASE WHEN c.status = 'applied' THEN 1 ELSE 0 END) as applied,
    SUM(CASE WHEN c.status = 'under_hm_review' THEN 1 ELSE 0 END) as under_review,
    SUM(CASE WHEN c.status LIKE 'test%' THEN 1 ELSE 0 END) as testing,
    SUM(CASE WHEN c.status = 'interview' THEN 1 ELSE 0 END) as interview,
    SUM(CASE WHEN c.status = 'offer_accepted' THEN 1 ELSE 0 END) as offer_accepted,
    SUM(CASE WHEN c.status = 'hired' THEN 1 ELSE 0 END) as hired,
    SUM(CASE WHEN c.status = 'rejected' THEN 1 ELSE 0 END) as rejected
FROM position p
JOIN position_title pt ON p.title_id = pt.id
LEFT JOIN candidate c ON p.id = c.position_id
GROUP BY p.id, pt.title, p.project_name;