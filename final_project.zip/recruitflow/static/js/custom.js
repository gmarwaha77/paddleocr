// Table Sorting
document.addEventListener('DOMContentLoaded', function() {
    const tables = document.querySelectorAll('.table-sortable');
    // Auto-hide flash messages
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            new bootstrap.Alert(alert).close();
        }, 5000);
    });

    // Password visibility toggle for login page
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const passwordField = document.getElementById('password');
            const eyeIcon = document.getElementById('eyeIcon');
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            eyeIcon.classList.toggle('bi-eye');
            eyeIcon.classList.toggle('bi-eye-slash');
        });
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    tables.forEach(table => {
        const headers = table.querySelectorAll('thead th');
        
        headers.forEach((header, index) => {
            header.addEventListener('click', () => {
                sortTable(table, index);
            });
        });
    });
});

function sortTable(table, column) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const header = table.querySelectorAll('thead th')[column];
    
    // Determine sort direction
    const isAsc = header.classList.contains('asc');
    
    // Remove all sort classes
    table.querySelectorAll('thead th').forEach(th => {
        th.classList.remove('asc', 'desc');
    });
    
    // Add appropriate class
    header.classList.add(isAsc ? 'desc' : 'asc');
    
    // Sort rows
    rows.sort((a, b) => {
        const aValue = a.cells[column].textContent.trim();
        const bValue = b.cells[column].textContent.trim();
        
        // Try to parse as number
        const aNum = parseFloat(aValue);
        const bNum = parseFloat(bValue);
        
        if (!isNaN(aNum) && !isNaN(bNum)) {
            return isAsc ? bNum - aNum : aNum - bNum;
        }
        
        // String comparison
        return isAsc 
            ? bValue.localeCompare(aValue)
            : aValue.localeCompare(bValue);
    });
    
    // Reorder table
    rows.forEach(row => tbody.appendChild(row));
}

// Color code similarity scores
function colorCodeSimilarityScores() {
    document.querySelectorAll('.similarity-score').forEach(el => {
        const score = parseFloat(el.textContent);
        el.classList.remove('similarity-high', 'similarity-medium', 'similarity-low');
        
        if (score >= 70) {
            el.classList.add('similarity-high');
        } else if (score >= 40) {
            el.classList.add('similarity-medium');
        } else {
            el.classList.add('similarity-low');
        }
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', colorCodeSimilarityScores);

// Filter functionality
function filterCandidates() {
    const searchInput = document.getElementById('searchInput');
    const minExp = document.getElementById('minExperience');
    const minSim = document.getElementById('minSimilarity');
    const statusFilter = document.getElementById('statusFilter');
    
    if (!searchInput) return;
    
    const searchTerm = searchInput.value.toLowerCase();
    const minExpValue = minExp ? parseFloat(minExp.value) || 0 : 0;
    const minSimValue = minSim ? parseFloat(minSim.value) || 0 : 0;
    const statusValue = statusFilter ? statusFilter.value : '';
    
    const rows = document.querySelectorAll('.candidate-row');
    
    rows.forEach(row => {
        const name = row.querySelector('.candidate-name')?.textContent.toLowerCase() || '';
        const skills = row.querySelector('.candidate-skills')?.textContent.toLowerCase() || '';
        const exp = parseFloat(row.querySelector('.candidate-exp')?.textContent) || 0;
        const sim = parseFloat(row.querySelector('.similarity-score')?.textContent) || 0;
        const status = row.querySelector('.candidate-status')?.textContent.trim() || '';
        
        const matchesSearch = name.includes(searchTerm) || skills.includes(searchTerm);
        const matchesExp = exp >= minExpValue;
        const matchesSim = sim >= minSimValue;
        const matchesStatus = !statusValue || status === statusValue;
        
        if (matchesSearch && matchesExp && matchesSim && matchesStatus) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Confirmation dialogs
function confirmAction(message) {
    return confirm(message || 'Are you sure you want to perform this action?');
}

// Form validation
function validatePositionForm(form) {
    const openings = form.querySelector('[name="openings"]');
    if (openings && parseInt(openings.value) < 1) {
        alert('Number of openings must be at least 1');
        return false;
    }
    
    const jdFile = form.querySelector('[name="jd_file"]');
    if (jdFile && jdFile.files.length > 0) {
        const fileName = jdFile.files[0].name;
        if (!fileName.endsWith('.docx')) {
            alert('Job Description must be a .docx file');
            return false;
        }
    }
    
    return true;
}

// Auto-hide flash messages
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });
});