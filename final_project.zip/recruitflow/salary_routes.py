# recruitflow_project/salary_routes.py - NEW MODULE FOR SALARY MANAGEMENT

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from datetime import datetime, date
from recruitflow.models import (db, Candidate, SalaryProposal, OfferLetter, BackgroundCheck,
                                OnboardingTask, CandidateCommunication, ReferenceCheck, TalentPool)
from recruitflow.utils import role_required

salary_bp = Blueprint('salary', __name__, url_prefix='/salary')


# ============= SALARY PROPOSAL MANAGEMENT =============

@salary_bp.route('/propose/<int:candidate_id>', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter')
def propose_salary(candidate_id):
    """Recruiter creates salary proposal"""
    candidate = Candidate.query.get_or_404(candidate_id)

    if request.method == 'POST':
        try:
            # Get CTC amount
            annual_ctc = float(request.form['annual_ctc'])

            # Calculate Indian CTC breakup (standard formula)
            basic_salary = annual_ctc * 0.40  # 40% of CTC
            hra = basic_salary * 0.50  # 50% of basic
            special_allowance = annual_ctc * 0.20  # 20% of CTC
            performance_bonus = annual_ctc * 0.10  # 10% of CTC (variable)

            # Employer contributions
            pf_employer = min(basic_salary * 0.12, 1800 * 12)  # 12% or max 1800/month
            gratuity = (basic_salary / 26) * 15 / 12  # Gratuity calculation

            # Employee deductions
            pf_employee = pf_employer  # Same as employer contribution
            professional_tax = 2400  # Annual PT (varies by state)

            # Medical insurance
            medical_insurance = float(request.form.get('medical_insurance', 0))

            # Calculate monthly amounts
            monthly_gross = (basic_salary + hra + special_allowance) / 12
            monthly_deductions = (pf_employee + professional_tax) / 12
            monthly_net = monthly_gross - monthly_deductions

            # Check version number
            existing_proposals = SalaryProposal.query.filter_by(
                candidate_id=candidate_id
            ).count()
            version = existing_proposals + 1

            # Create proposal
            proposal = SalaryProposal(
                candidate_id=candidate_id,
                proposed_by=current_user.id,
                annual_ctc=annual_ctc,
                basic_salary=basic_salary,
                hra=hra,
                special_allowance=special_allowance,
                performance_bonus=performance_bonus,
                pf_employer=pf_employer,
                gratuity=gratuity,
                pf_employee=pf_employee,
                professional_tax=professional_tax,
                medical_insurance=medical_insurance,
                monthly_gross=monthly_gross,
                monthly_net=monthly_net,
                other_benefits=request.form.get('other_benefits', ''),
                version=version,
                status='pending'
            )

            db.session.add(proposal)
            db.session.commit()

            flash(f'Salary proposal of ₹{annual_ctc:,.0f} submitted for approval', 'success')
            return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))

        except Exception as e:
            db.session.rollback()
            flash(f'Error creating salary proposal: {str(e)}', 'danger')

    # Get candidate's expected CTC for reference
    latest_proposal = SalaryProposal.query.filter_by(
        candidate_id=candidate_id
    ).order_by(SalaryProposal.version.desc()).first()

    return render_template('salary/propose_salary.html',
                           candidate=candidate,
                           latest_proposal=latest_proposal)


@salary_bp.route('/view/<int:candidate_id>')
@login_required
def view_salary_proposals(candidate_id):
    """View all salary proposals for a candidate (Recruiter & SA only)"""
    if current_user.role.name not in ['Recruiter', 'SA']:
        flash('Access denied', 'danger')
        return redirect(url_for('main.dashboard'))

    candidate = Candidate.query.get_or_404(candidate_id)
    proposals = SalaryProposal.query.filter_by(
        candidate_id=candidate_id
    ).order_by(SalaryProposal.version.desc()).all()

    return render_template('salary/view_proposals.html',
                           candidate=candidate,
                           proposals=proposals)


@salary_bp.route('/approve/<int:proposal_id>', methods=['POST'])
@login_required
@role_required('SA')
def approve_salary(proposal_id):
    """Senior Approver approves/rejects salary proposal"""
    proposal = SalaryProposal.query.get_or_404(proposal_id)

    action = request.form['action']
    comments = request.form.get('comments', '')

    if action == 'approve':
        proposal.status = 'approved'
        proposal.approved_by = current_user.id
        proposal.approval_date = datetime.now()
        proposal.approval_comments = comments

        flash(f'Salary proposal of ₹{proposal.annual_ctc:,.0f} approved', 'success')

    elif action == 'reject':
        proposal.status = 'rejected'
        proposal.approved_by = current_user.id
        proposal.approval_date = datetime.now()
        proposal.approval_comments = comments

        flash('Salary proposal rejected', 'info')

    db.session.commit()
    return redirect(url_for('salary.pending_approvals'))


@salary_bp.route('/pending-approvals')
@login_required
@role_required('SA')
def pending_approvals():
    """View all pending salary approvals"""
    pending = SalaryProposal.query.filter_by(
        status='pending'
    ).order_by(SalaryProposal.created_at.desc()).all()

    return render_template('salary/pending_approvals.html', proposals=pending)


@salary_bp.route('/candidate-response/<int:proposal_id>', methods=['POST'])
@login_required
@role_required('Recruiter')
def candidate_response(proposal_id):
    """Recruiter updates candidate's response to salary offer"""
    proposal = SalaryProposal.query.get_or_404(proposal_id)

    if proposal.status != 'approved':
        flash('Can only respond to approved proposals', 'warning')
        return redirect(url_for('main.candidate_list',
                                pos_id=proposal.candidate.position_id))

    response = request.form['response']  # accepted, rejected, counter
    feedback = request.form.get('feedback', '')

    proposal.candidate_response = response
    proposal.candidate_feedback = feedback

    if response == 'accepted':
        proposal.status = 'accepted'
        proposal.is_final = True
        proposal.candidate.status = 'offer_accepted'

        flash('Candidate accepted the offer! Set joining date.', 'success')

    elif response == 'rejected':
        proposal.status = 'rejected_by_candidate'
        proposal.candidate.status = 'offer_declined'

        flash('Candidate declined the offer', 'info')

    elif response == 'counter':
        counter_amount = float(request.form.get('counter_amount', 0))
        proposal.counter_amount = counter_amount
        proposal.status = 'countered'

        flash(f'Candidate countered with ₹{counter_amount:,.0f}. Create new proposal.', 'warning')

    db.session.commit()
    return redirect(url_for('salary.view_salary_proposals',
                            candidate_id=proposal.candidate_id))


@salary_bp.route('/set-joining-date/<int:candidate_id>', methods=['POST'])
@login_required
@role_required('Recruiter')
def set_joining_date(candidate_id):
    """Set joining date after offer acceptance"""
    candidate = Candidate.query.get_or_404(candidate_id)

    # Verify offer is accepted
    accepted_proposal = SalaryProposal.query.filter_by(
        candidate_id=candidate_id,
        status='accepted'
    ).first()

    if not accepted_proposal:
        flash('No accepted offer found for this candidate', 'danger')
        return redirect(url_for('main.candidate_list',
                                pos_id=candidate.position_id))

    joining_date_str = request.form['joining_date']
    joining_date = datetime.strptime(joining_date_str, '%Y-%m-%d').date()

    candidate.joining_date = joining_date
    candidate.status = 'hired'

    # Update position openings
    candidate.position.openings -= 1

    db.session.commit()

    flash(f'Joining date set: {joining_date.strftime("%d %B %Y")}. Candidate marked as hired!', 'success')
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# ============= OFFER LETTER MANAGEMENT =============

@salary_bp.route('/generate-offer/<int:candidate_id>', methods=['POST'])
@login_required
@role_required('Recruiter', 'SA')
def generate_offer_letter(candidate_id):
    """Generate offer letter after salary acceptance"""
    candidate = Candidate.query.get_or_404(candidate_id)

    # Get accepted salary proposal
    proposal = SalaryProposal.query.filter_by(
        candidate_id=candidate_id,
        status='accepted'
    ).first()

    if not proposal:
        flash('No accepted salary proposal found', 'danger')
        return redirect(url_for('main.candidate_list',
                                pos_id=candidate.position_id))

    # Create offer letter record
    offer = OfferLetter(
        candidate_id=candidate_id,
        salary_proposal_id=proposal.id,
        generated_by=current_user.id,
        designation=candidate.position.position_title.title,
        department=request.form.get('department', ''),
        location=request.form.get('location', ''),
        joining_date=datetime.strptime(request.form['joining_date'], '%Y-%m-%d').date(),
        status='draft'
    )

    db.session.add(offer)
    db.session.commit()

    # In production, integrate with document generation library
    # For now, just create a record

    flash('Offer letter generated successfully', 'success')
    return redirect(url_for('salary.view_salary_proposals', candidate_id=candidate_id))


# ============= BACKGROUND VERIFICATION =============

@salary_bp.route('/background-check/<int:candidate_id>', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter', 'SA')
def background_check(candidate_id):
    """Manage background verification"""
    candidate = Candidate.query.get_or_404(candidate_id)

    if request.method == 'POST':
        check = BackgroundCheck(
            candidate_id=candidate_id,
            check_type=request.form['check_type'],
            vendor_name=request.form.get('vendor_name', ''),
            initiated_date=datetime.strptime(request.form['initiated_date'], '%Y-%m-%d').date(),
            status='in_progress',
            verified_by=current_user.id
        )

        db.session.add(check)
        db.session.commit()

        flash('Background check initiated', 'success')
        return redirect(url_for('salary.background_check', candidate_id=candidate_id))

    checks = BackgroundCheck.query.filter_by(candidate_id=candidate_id).all()
    return render_template('salary/background_check.html',
                           candidate=candidate,
                           checks=checks)


@salary_bp.route('/update-bgv/<int:check_id>', methods=['POST'])
@login_required
@role_required('Recruiter', 'SA')
def update_background_check(check_id):
    """Update background check status"""
    check = BackgroundCheck.query.get_or_404(check_id)

    check.status = request.form['status']
    check.findings = request.form.get('findings', '')

    if check.status in ['clear', 'issue', 'failed']:
        check.completed_date = date.today()

    db.session.commit()

    flash('Background check updated', 'success')
    return redirect(url_for('salary.background_check',
                            candidate_id=check.candidate_id))


# ============= ONBOARDING TASKS =============

@salary_bp.route('/onboarding/<int:candidate_id>', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter', 'SA')
def onboarding_tasks(candidate_id):
    """Manage pre-joining onboarding tasks"""
    candidate = Candidate.query.get_or_404(candidate_id)

    if request.method == 'POST':
        task = OnboardingTask(
            candidate_id=candidate_id,
            task_name=request.form['task_name'],
            task_category=request.form['task_category'],
            description=request.form.get('description', ''),
            assigned_to=current_user.id,
            due_date=datetime.strptime(request.form['due_date'], '%Y-%m-%d').date(),
            status='pending'
        )

        db.session.add(task)
        db.session.commit()

        flash('Onboarding task created', 'success')
        return redirect(url_for('salary.onboarding_tasks', candidate_id=candidate_id))

    tasks = OnboardingTask.query.filter_by(candidate_id=candidate_id).all()
    return render_template('salary/onboarding_tasks.html',
                           candidate=candidate,
                           tasks=tasks)


@salary_bp.route('/complete-task/<int:task_id>', methods=['POST'])
@login_required
def complete_onboarding_task(task_id):
    """Mark onboarding task as complete"""
    task = OnboardingTask.query.get_or_404(task_id)

    task.status = 'completed'
    task.completed_date = datetime.now()
    task.notes = request.form.get('notes', '')

    db.session.commit()

    flash('Task marked as complete', 'success')
    return redirect(url_for('salary.onboarding_tasks',
                            candidate_id=task.candidate_id))


# ============= COMMUNICATION TRACKING =============

@salary_bp.route('/communication/<int:candidate_id>', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter')
def track_communication(candidate_id):
    """Track communications with candidate"""
    candidate = Candidate.query.get_or_404(candidate_id)

    if request.method == 'POST':
        comm = CandidateCommunication(
            candidate_id=candidate_id,
            communication_type=request.form['communication_type'],
            subject=request.form['subject'],
            message=request.form['message'],
            communicated_by=current_user.id
        )

        db.session.add(comm)
        db.session.commit()

        flash('Communication logged', 'success')
        return redirect(url_for('salary.track_communication', candidate_id=candidate_id))

    communications = CandidateCommunication.query.filter_by(
        candidate_id=candidate_id
    ).order_by(CandidateCommunication.communication_date.desc()).all()

    return render_template('salary/communication_log.html',
                           candidate=candidate,
                           communications=communications)


# ============= REFERENCE CHECKS =============

@salary_bp.route('/reference-check/<int:candidate_id>', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter', 'HM')
def reference_check(candidate_id):
    """Manage reference checks"""
    candidate = Candidate.query.get_or_404(candidate_id)

    if request.method == 'POST':
        ref = ReferenceCheck(
            candidate_id=candidate_id,
            reference_name=request.form['reference_name'],
            reference_designation=request.form['reference_designation'],
            reference_company=request.form['reference_company'],
            reference_phone=request.form['reference_phone'],
            reference_email=request.form.get('reference_email', ''),
            relationship=request.form['relationship'],
            contacted_by=current_user.id,
            status='pending'
        )

        db.session.add(ref)
        db.session.commit()

        flash('Reference added', 'success')
        return redirect(url_for('salary.reference_check', candidate_id=candidate_id))

    references = ReferenceCheck.query.filter_by(candidate_id=candidate_id).all()
    return render_template('salary/reference_check.html',
                           candidate=candidate,
                           references=references)


@salary_bp.route('/update-reference/<int:ref_id>', methods=['POST'])
@login_required
@role_required('Recruiter', 'HM')
def update_reference(ref_id):
    """Update reference check feedback"""
    ref = ReferenceCheck.query.get_or_404(ref_id)

    ref.contacted_date = date.today()
    ref.overall_rating = int(request.form.get('overall_rating', 0))
    ref.would_rehire = request.form.get('would_rehire') == 'yes'
    ref.feedback = request.form.get('feedback', '')
    ref.status = 'completed'

    db.session.commit()

    flash('Reference feedback updated', 'success')
    return redirect(url_for('salary.reference_check',
                            candidate_id=ref.candidate_id))


# ============= TALENT POOL =============

@salary_bp.route('/talent-pool/add/<int:candidate_id>', methods=['POST'])
@login_required
@role_required('Recruiter', 'HM')
def add_to_talent_pool(candidate_id):
    """Add candidate to talent pool"""
    candidate = Candidate.query.get_or_404(candidate_id)

    # Check if already in pool
    existing = TalentPool.query.filter_by(candidate_id=candidate_id).first()
    if existing:
        flash('Candidate already in talent pool', 'info')
        return redirect(request.referrer or url_for('main.dashboard'))

    pool = TalentPool(
        candidate_id=candidate_id,
        pool_category=request.form.get('pool_category', 'Future Opportunity'),
        skills_tags=request.form.get('skills_tags', ''),
        experience_level=request.form.get('experience_level', ''),
        added_by=current_user.id,
        availability=request.form.get('availability', ''),
        notes=request.form.get('notes', '')
    )

    db.session.add(pool)
    db.session.commit()

    flash('Candidate added to talent pool', 'success')
    return redirect(request.referrer or url_for('main.dashboard'))


@salary_bp.route('/talent-pool')
@login_required
@role_required('Recruiter', 'HM', 'SA')
def view_talent_pool():
    """View all talent pool candidates"""
    pools = TalentPool.query.order_by(TalentPool.added_date.desc()).all()
    return render_template('salary/talent_pool.html', pools=pools)