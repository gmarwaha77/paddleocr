# recruitflow_project/app.py (FIXED)
from flask import Flask, redirect, url_for
from flask_login import LoginManager, current_user
from flask_migrate import Migrate
from .config import get_config
from .models import db, User
import os
from datetime import datetime, date, timedelta


def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    config = get_config()
    app.config.from_object(config)

    # Create upload folder if it doesn't exist
    upload_folder = app.config.get('UPLOAD_FOLDER')
    if upload_folder and not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
        print(f"✅ Created upload folder: {upload_folder}")

    db.init_app(app)
    Migrate(app, db)

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'main.login'
    login_manager.login_message_category = 'info'

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    @login_manager.unauthorized_handler
    def unauthorized():
        # Redirect anonymous users to the login page
        return redirect(url_for('main.login'))

    # Register blueprints
    from .main_routes import main as main_bp
    app.register_blueprint(main_bp)

    from .salary_routes import salary_bp
    app.register_blueprint(salary_bp)

    from .admin_routes import admin_bp
    app.register_blueprint(admin_bp)
    
    from .internal_routes import internal_bp
    app.register_blueprint(internal_bp)
    
    from .contract_routes import contract_bp
    app.register_blueprint(contract_bp)

    from .ceo_routes import ceo_bp
    app.register_blueprint(ceo_bp)



    # Jinja2 context processors - FIXED with proper datetime imports
    @app.context_processor
    def inject_utilities():
        """Make utilities available in all templates"""
        return dict(
            datetime=datetime,
            date=date,
            timedelta=timedelta
        )

    # Custom Jinja2 filters
    @app.template_filter('format_ctc')
    def format_ctc_filter(amount):
        """Format CTC in lakhs/crores"""
        if not amount:
            return '₹0'
        amount = float(amount)
        if amount >= 10000000:
            return f"₹{amount / 10000000:.2f} Cr"
        elif amount >= 100000:
            return f"₹{amount / 100000:.2f} L"
        else:
            return f"₹{amount:,.0f}"

    return app


app = create_app()

if __name__ == '__main__':
    app.run(debug=True)