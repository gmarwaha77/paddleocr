# recruitflow/utils/ad_auth.py
"""
Windows Active Directory Authentication Module
Requires python-ldap3 package: pip install ldap3
"""

import os
from ldap3 import Server, Connection, ALL, NTLM
from ldap3.core.exceptions import LDAPException


class ADAuthenticator:
    """Handle Windows Active Directory authentication"""
    
    def __init__(self):
        self.ad_server = os.environ.get('AD_SERVER', 'ldap://your-domain-controller.com')
        self.ad_domain = os.environ.get('AD_DOMAIN', 'YOURDOMAIN')
        self.ad_search_base = os.environ.get('AD_SEARCH_BASE', 'DC=yourdomain,DC=com')
        self.enabled = os.environ.get('AD_AUTH_ENABLED', 'false').lower() == 'true'
    
    def authenticate(self, username, password):
        """
        Authenticate user against Active Directory
        
        Args:
            username: Windows username (without domain)
            password: User password
            
        Returns:
            dict: User info if successful, None if failed
                {
                    'username': 'jdoe',
                    'full_name': 'John Doe',
                    'email': 'jdoe@company.com',
                    'employee_id': 'EMP001',
                    'department': 'Engineering',
                    'designation': 'Senior Developer'
                }
        """
        if not self.enabled:
            return None
        
        try:
            # Create server object
            server = Server(self.ad_server, get_info=ALL)
            
            # Format username for AD
            user_dn = f'{self.ad_domain}\\{username}'
            
            # Attempt connection
            conn = Connection(
                server,
                user=user_dn,
                password=password,
                authentication=NTLM,
                auto_bind=True
            )
            
            if not conn.bind():
                return None
            
            # Search for user details
            search_filter = f'(sAMAccountName={username})'
            conn.search(
                self.ad_search_base,
                search_filter,
                attributes=[
                    'sAMAccountName',
                    'displayName',
                    'mail',
                    'employeeID',
                    'department',
                    'title'
                ]
            )
            
            if len(conn.entries) > 0:
                entry = conn.entries[0]
                user_info = {
                    'username': str(entry.sAMAccountName),
                    'full_name': str(entry.displayName) if hasattr(entry, 'displayName') else username,
                    'email': str(entry.mail) if hasattr(entry, 'mail') else f'{username}@company.com',
                    'employee_id': str(entry.employeeID) if hasattr(entry, 'employeeID') else None,
                    'department': str(entry.department) if hasattr(entry, 'department') else None,
                    'designation': str(entry.title) if hasattr(entry, 'title') else None
                }
                
                conn.unbind()
                return user_info
            
            conn.unbind()
            return None
            
        except LDAPException as e:
            print(f"AD Authentication Error: {e}")
            return None
        except Exception as e:
            print(f"Unexpected error during AD authentication: {e}")
            return None
    
    def get_user_info(self, username):
        """
        Get user info from AD without authentication (requires service account)
        
        Args:
            username: Windows username
            
        Returns:
            dict: User info or None
        """
        # This would require a service account configured in environment
        # For simplicity, returning None - implement if needed
        return None


# Singleton instance
ad_authenticator = ADAuthenticator()