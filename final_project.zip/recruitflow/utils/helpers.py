# recruitflow_project/utils/helpers.py (COMPLETE & FIXED)
"""
Helper functions and decorators
"""
from functools import wraps
from flask import flash, redirect, url_for
from flask_login import current_user
from recruitflow.models import db, AuditLog, Candidate, Position


def role_required(*roles):
    """
    Decorator to require specific roles for accessing a view.

    Usage:
        @role_required('HM', 'SA')
        def my_view():
            ...
    """

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('main.login'))

            if current_user.role.name not in roles:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('main.dashboard'))

            return f(*args, **kwargs)

        return decorated_function

    return decorator


def log_action(action, entity_type=None, entity_id=None):
    """
    Logs an action to the AuditLog.

    Args:
        action (str): Description of the action performed.
        entity_type (str, optional): The type of entity affected (e.g., 'User', 'Position').
        entity_id (int, optional): The ID of the affected entity.
    """
    try:
        log_entry = AuditLog(
            user_id=current_user.id if current_user.is_authenticated else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        # Avoid crashing the app if logging fails
        print(f"⚠️  Error logging action: {e}")
        db.session.rollback()


def get_candidate_stats(position_id=None):
    """
    Get candidate statistics

    Args:
        position_id: Optional position ID to filter by

    Returns:
        Dictionary with statistics
    """
    query = db.session.query(
        Candidate.status,
        db.func.count(Candidate.id).label('count')
    )

    if position_id:
        query = query.filter_by(position_id=position_id)

    results = query.group_by(Candidate.status).all()

    stats = {
        'total': sum(r.count for r in results),
        'by_status': {r.status: r.count for r in results}
    }

    return stats


def get_position_stats():
    """Get position statistics"""
    results = db.session.query(
        Position.status,
        db.func.count(Position.id).label('count')
    ).group_by(Position.status).all()

    stats = {
        'total': sum(r.count for r in results),
        'by_status': {r.status: r.count for r in results}
    }

    return stats


def calculate_time_to_hire(candidate):
    """
    Calculate time-to-hire for a candidate

    Args:
        candidate: Candidate object

    Returns:
        Days from application to hire, or None if not hired
    """
    if candidate.status not in ['hired', 'offer']:
        return None

    # Find the most recent interview
    if candidate.interviews and candidate.interviews.count() > 0:
        latest_interview = max(candidate.interviews.all(), key=lambda i: i.schedule_date)
        days = (latest_interview.schedule_date - candidate.created_at.date()).days
        return days

    return None


def format_experience(years):
    """Format experience years"""
    if not years:
        return 'Not specified'

    if years < 1:
        return f'{int(years * 12)} months'
    elif years == 1:
        return '1 year'
    else:
        return f'{int(years)} years'


def get_similarity_label(score):
    """Get label for similarity score"""
    if score >= 80:
        return 'Excellent Match'
    elif score >= 70:
        return 'Great Match'
    elif score >= 60:
        return 'Good Match'
    elif score >= 50:
        return 'Fair Match'
    else:
        return 'Poor Match'


def get_similarity_color(score):
    """Get color class for similarity score"""
    if score >= 70:
        return 'success'
    elif score >= 50:
        return 'warning'
    else:
        return 'danger'


def format_currency(amount):
    """Format amount in Indian currency"""
    if not amount:
        return '₹0'

    amount = float(amount)
    if amount >= 10000000:  # 1 Crore
        return f"₹{amount / 10000000:.2f} Cr"
    elif amount >= 100000:  # 1 Lakh
        return f"₹{amount / 100000:.2f} L"
    else:
        return f"₹{amount:,.0f}"


def get_months_between_dates(start_date, end_date=None):
    """
    Calculate months between two dates
    
    Args:
        start_date: Starting date
        end_date: Ending date (defaults to today)
    
    Returns:
        int: Number of months
    """
    from datetime import datetime
    
    if end_date is None:
        end_date = datetime.now().date()
    
    if isinstance(start_date, datetime):
        start_date = start_date.date()
    if isinstance(end_date, datetime):
        end_date = end_date.date()
    
    months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
    return months


def is_review_pending(candidate_id, month=None, year=None):
    """
    Check if monthly review is pending for a contract employee
    
    Args:
        candidate_id: Candidate ID
        month: Month to check (defaults to current month)
        year: Year to check (defaults to current year)
    
    Returns:
        bool: True if review is pending
    """
    from datetime import datetime
    from recruitflow.models import ContractPerformanceReview, Candidate
    
    if month is None:
        month = datetime.now().month
    if year is None:
        year = datetime.now().year
    
    candidate = Candidate.query.get(candidate_id)
    if not candidate or not candidate.joining_date:
        return False
    
    # Check if they've been working for at least a month
    months_working = get_months_between_dates(candidate.joining_date)
    if months_working < 1:
        return False
    
    # Check if review exists
    review = ContractPerformanceReview.query.filter_by(
        candidate_id=candidate_id,
        review_month=month,
        review_year=year
    ).first()
    
    return review is None