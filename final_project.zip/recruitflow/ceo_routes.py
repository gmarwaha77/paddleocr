# recruitflow/ceo_routes.py
"""
CEO Dashboard with pipeline analytics
"""

from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from sqlalchemy import func, case

from .models import (db, Position, Candidate, PositionTitle, Interview,
                     SalaryProposal, PipelineMetrics)
from .utils.helpers import role_required

ceo_bp = Blueprint('ceo', __name__, url_prefix='/ceo')


@ceo_bp.route('/dashboard')
@login_required
@role_required('SA')  # CEO would be SA role
def dashboard():
    """Main CEO dashboard with pipeline visualizations"""
    # Get all position titles for filtering
    titles = PositionTitle.query.all()
    
    # Get date range for filtering
    date_from = request.args.get('date_from', 
                                 (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d'))
    date_to = request.args.get('date_to', datetime.now().strftime('%Y-%m-%d'))
    position_title_id = request.args.get('position_title', '')
    
    return render_template(
        'ceo/dashboard.html',
        titles=titles,
        date_from=date_from,
        date_to=date_to,
        position_title_id=position_title_id
    )


@ceo_bp.route('/api/pipeline-data')
@login_required
@role_required('SA')
def pipeline_data():
    """API endpoint for pipeline chart data"""
    position_title_id = request.args.get('position_title', type=int)
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    
    # Build query
    query = Candidate.query.join(Position)
    
    if position_title_id:
        query = query.filter(Position.title_id == position_title_id)
    
    if date_from:
        query = query.filter(Candidate.created_at >= datetime.strptime(date_from, '%Y-%m-%d'))
    
    if date_to:
        query = query.filter(Candidate.created_at <= datetime.strptime(date_to, '%Y-%m-%d'))
    
    # Count by status
    status_counts = query.with_entities(
        Candidate.status,
        func.count(Candidate.id).label('count')
    ).group_by(Candidate.status).all()
    
    # Prepare data for funnel chart
    stages = {
        'applied': 0,
        'under_hm_review': 0,
        'test_allocated': 0,
        'test_passed': 0,
        'interview': 0,
        'offer_accepted': 0,
        'hired': 0
    }
    
    for status, count in status_counts:
        if status in stages:
            stages[status] = count
    
    # Create funnel data
    funnel_data = {
        'labels': [
            'Applied',
            'HM Review',
            'Test Passed',
            'Interview',
            'Offer',
            'Hired'
        ],
        'values': [
            stages['applied'] + stages['under_hm_review'],
            stages['under_hm_review'],
            stages['test_passed'],
            stages['interview'],
            stages['offer_accepted'],
            stages['hired']
        ]
    }
    
    return jsonify(funnel_data)


@ceo_bp.route('/api/time-metrics')
@login_required
@role_required('SA')
def time_metrics():
    """API endpoint for average time at each stage"""
    position_title_id = request.args.get('position_title', type=int)
    
    # Query for calculating average times
    # This is a complex query - simplified version here
    
    # Get all candidates with joining date (completed pipeline)
    query = Candidate.query.filter(Candidate.joining_date.isnot(None))
    
    if position_title_id:
        query = query.join(Position).filter(Position.title_id == position_title_id)
    
    candidates = query.all()
    
    if not candidates:
        return jsonify({
            'labels': [],
            'values': []
        })
    
    # Calculate average times (simplified - in production, use PipelineMetrics table)
    # For now, calculating based on created_at to joining_date
    
    total_days = 0
    count = 0
    
    for candidate in candidates:
        if candidate.joining_date and candidate.created_at:
            days = (candidate.joining_date - candidate.created_at.date()).days
            if days > 0:  # Sanity check
                total_days += days
                count += 1
    
    avg_days = total_days / count if count > 0 else 0
    
    # Estimate breakdown (in production, track each stage separately)
    stages_data = {
        'labels': [
            'Position Approval',
            'CV Screening',
            'HM Review',
            'Testing',
            'Interview',
            'Offer & BGV',
            'Onboarding'
        ],
        'values': [
            round(avg_days * 0.10, 1),  # 10% for approval
            round(avg_days * 0.15, 1),  # 15% for CV screening
            round(avg_days * 0.15, 1),  # 15% for HM review
            round(avg_days * 0.15, 1),  # 15% for testing
            round(avg_days * 0.20, 1),  # 20% for interviews
            round(avg_days * 0.15, 1),  # 15% for offer/BGV
            round(avg_days * 0.10, 1)   # 10% for onboarding
        ]
    }
    
    return jsonify(stages_data)


@ceo_bp.route('/api/conversion-rates')
@login_required
@role_required('SA')
def conversion_rates():
    """API endpoint for conversion rates between stages"""
    position_title_id = request.args.get('position_title', type=int)
    
    query = Candidate.query
    
    if position_title_id:
        query = query.join(Position).filter(Position.title_id == position_title_id)
    
    total_applied = query.count()
    
    if total_applied == 0:
        return jsonify({
            'labels': [],
            'values': []
        })
    
    hm_review = query.filter(
        Candidate.status.in_(['under_hm_review', 'test_passed', 'interview', 
                             'offer_accepted', 'hired'])
    ).count()
    
    test_passed = query.filter(
        Candidate.status.in_(['test_passed', 'interview', 'offer_accepted', 'hired'])
    ).count()
    
    interviewed = query.filter(
        Candidate.status.in_(['interview', 'offer_accepted', 'hired'])
    ).count()
    
    offered = query.filter(
        Candidate.status.in_(['offer_accepted', 'hired'])
    ).count()
    
    hired = query.filter_by(status='hired').count()
    
    conversion_data = {
        'labels': [
            'Applied → HM Review',
            'HM Review → Test Passed',
            'Test → Interview',
            'Interview → Offer',
            'Offer → Hired'
        ],
        'values': [
            round((hm_review / total_applied * 100), 1) if total_applied > 0 else 0,
            round((test_passed / hm_review * 100), 1) if hm_review > 0 else 0,
            round((interviewed / test_passed * 100), 1) if test_passed > 0 else 0,
            round((offered / interviewed * 100), 1) if interviewed > 0 else 0,
            round((hired / offered * 100), 1) if offered > 0 else 0
        ]
    }
    
    return jsonify(conversion_data)


@ceo_bp.route('/api/position-stats')
@login_required
@role_required('SA')
def position_stats():
    """API endpoint for position-wise statistics"""
    # Get all positions with candidate counts
    positions = db.session.query(
        Position.id,
        PositionTitle.title,
        Position.openings,
        Position.status,
        func.count(Candidate.id).label('total_candidates'),
        func.sum(case((Candidate.status == 'hired', 1), else_=0)).label('hired_count')
    ).join(PositionTitle).outerjoin(Candidate).group_by(
        Position.id, PositionTitle.title, Position.openings, Position.status
    ).all()
    
    position_data = {
        'labels': [],
        'openings': [],
        'candidates': [],
        'hired': [],
        'fill_rate': []
    }
    
    for pos in positions:
        position_data['labels'].append(pos.title)
        position_data['openings'].append(pos.openings)
        position_data['candidates'].append(pos.total_candidates or 0)
        position_data['hired'].append(pos.hired_count or 0)
        fill_rate = ((pos.hired_count or 0) / pos.openings * 100) if pos.openings > 0 else 0
        position_data['fill_rate'].append(round(fill_rate, 1))
    
    return jsonify(position_data)