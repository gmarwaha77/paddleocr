# recruitflow/main_routes.py (COMPLETE & FIXED)
import os
from flask import (Blueprint, render_template, request, redirect, url_for,
                   flash, current_app, send_from_directory, abort)
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash  # ADD THIS
from datetime import datetime, date  # ADD datetime here too
from .models import (db, User, Role, Position, PositionTitle, Candidate,
                     InterviewPanel, Interview, InterviewFeedback, CandidateNote)
from .cv_parser import parse_cv, extract_text_from_docx
from .utils.helpers import role_required, log_action
from .utils.ad_auth import ad_authenticator


main = Blueprint('main', __name__)


# --- Authentication Routes ---

@main.route('/login', methods=['GET', 'POST'])
@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        use_ad = request.form.get('use_ad') == 'on'  # Checkbox for AD login
        
        user = None
        
        # Try AD authentication first if enabled
        if use_ad and ad_authenticator.enabled:
            ad_user_info = ad_authenticator.authenticate(username, password)
            
            if ad_user_info:
                # Check if user exists in our system
                user = User.query.filter_by(username=ad_user_info['username']).first()
                
                if not user:
                    # Create new user from AD info
                    # Internal employees get a special "Employee" role
                    employee_role = Role.query.filter_by(name='Employee').first()
                    if not employee_role:
                        employee_role = Role(name='Employee')
                        db.session.add(employee_role)
                        db.session.commit()
                    
                    user = User(
                        username=ad_user_info['username'],
                        password_hash=generate_password_hash(os.urandom(24).hex()),  # Random password
                        full_name=ad_user_info['full_name'],
                        email=ad_user_info['email'],
                        role_id=employee_role.id,
                        is_active=True
                    )
                    # Store employee_id as custom attribute if needed
                    db.session.add(user)
                    db.session.commit()
                    
                    log_action(f'New AD user auto-created: {user.username}')
                
                # Log them in
                login_user(user, remember=True)
                log_action(f'User {user.username} logged in via AD')
                
                # Redirect employees to internal positions
                if user.role.name == 'Employee':
                    return redirect(url_for('internal.open_positions'))
                else:
                    return redirect(url_for('main.dashboard'))
        
        # Fall back to regular authentication
        if not user:
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                if user.is_active:
                    login_user(user, remember=True)
                    log_action(f'User {user.username} logged in successfully.')
                    return redirect(url_for('main.dashboard'))
                else:
                    flash('Your account is inactive. Please contact the administrator.', 'warning')
            else:
                flash('Invalid username or password. Please try again.', 'danger')
    
    # Check if AD is enabled
    ad_enabled = ad_authenticator.enabled
    
    return render_template('login.html', ad_enabled=ad_enabled)


@main.route('/logout')
@login_required
def logout():
    log_action(f'User {current_user.username} logged out.')
    logout_user()
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('main.login'))


# --- Dashboard Route ---

# --- Dashboard Route ---

@main.route('/')
@login_required
def dashboard():
    from datetime import datetime
    role_name = current_user.role.name
    
    if role_name == 'HM':
        positions = Position.query.filter_by(hm_id=current_user.id).all()
        
        # Check for contract employees needing reviews
        contract_positions = Position.query.filter_by(
            hm_id=current_user.id,
            position_type='contract'
        ).all()
        
        contract_position_ids = [p.id for p in contract_positions]
        contract_employees = Candidate.query.filter(
            Candidate.position_id.in_(contract_position_ids),
            Candidate.status == 'hired'
        ).count()
        
        # Check pending reviews
        from .models import ContractPerformanceReview
        current_month = datetime.now().month
        current_year = datetime.now().year
        
        pending_review_count = 0
        for pos_id in contract_position_ids:
            hired = Candidate.query.filter_by(
                position_id=pos_id,
                status='hired'
            ).all()
            
            for cand in hired:
                if cand.joining_date:
                    months_working = (
                        (current_year - cand.joining_date.year) * 12 +
                        (current_month - cand.joining_date.month)
                    )
                    
                    if months_working >= 1:
                        review_exists = ContractPerformanceReview.query.filter_by(
                            candidate_id=cand.id,
                            review_month=current_month,
                            review_year=current_year
                        ).first()
                        
                        if not review_exists:
                            pending_review_count += 1
        
        return render_template('hm_dashboard.html', 
                             positions=positions,
                             contract_employees=contract_employees,
                             pending_review_count=pending_review_count)
    
    elif role_name == 'Recruiter':
        positions = Position.query.filter(Position.status.in_(['approved', 'open'])).all()
        return render_template('recruiter_dashboard.html', positions=positions)
    
    elif role_name == 'IP':
        panel_positions = [p.position_id for p in InterviewPanel.query.filter_by(ip_user_id=current_user.id).all()]
        candidates = Candidate.query.join(Interview).filter(
            Candidate.position_id.in_(panel_positions),
            Interview.status == 'scheduled'
        ).all()
        return render_template('ip_dashboard.html', candidates=candidates)
    
    elif role_name == 'SA':
        positions = Position.query.filter_by(status='pending_approval').all()
        return render_template('sa_dashboard.html', positions=positions)
    
    elif role_name == 'Employee':
        # Redirect employees to internal positions page
        return redirect(url_for('internal.open_positions'))
    
    else:
        flash('Dashboard not configured for this role.', 'warning')
        return redirect(url_for('main.logout'))


# --- Position Management (HM & SA) ---

# UPDATE the create_position route to include position_type:
@main.route('/positions/create', methods=['GET', 'POST'])
@login_required
@role_required('HM')
def create_position():
    if request.method == 'POST':
        title_id = request.form.get('title_id')
        project_name = request.form.get('project_name')
        openings = request.form.get('openings')
        position_type = request.form.get('position_type', 'full_time')  # NEW
        contract_duration = request.form.get('contract_duration') if position_type == 'contract' else None  # NEW
        jd_file = request.files.get('jd_file')

        if not all([title_id, project_name, openings, jd_file]):
            flash('All fields are required.', 'danger')
            return redirect(request.url)

        # Use new FileManager for organized storage
        from .utils.file_manager import FileManager
        
        # Create position first to get ID
        position = Position(
            title_id=title_id,
            project_name=project_name,
            openings=int(openings),
            hm_id=current_user.id,
            status='draft',
            position_type=position_type,  # NEW
            contract_duration_months=int(contract_duration) if contract_duration else None  # NEW
        )
        db.session.add(position)
        db.session.flush()  # Get position.id without committing
        
        # Save JD file with organized structure
        jd_path = FileManager.save_file(jd_file, 'jd', position_id=position.id)
        if jd_path:
            position.jd_file_path = jd_path
        
        # Add interview panel
        for i in range(3):
            ip_username = request.form.get(f'ip_{i}')
            if ip_username:
                ip_user = User.query.filter_by(
                    username=ip_username,
                    role_id=Role.query.filter_by(name='IP').first().id
                ).first()
                if ip_user:
                    panel = InterviewPanel(position_id=position.id, ip_user_id=ip_user.id)
                    db.session.add(panel)

        db.session.commit()
        
        log_action(f'Position "{position.position_title.title}" created as {position_type}.', 
                   entity_type='Position', entity_id=position.id)
        
        flash('Position created as a draft. You can submit it for approval from your dashboard.', 'success')
        return redirect(url_for('main.dashboard'))

    titles = PositionTitle.query.all()
    return render_template('create_position.html', titles=titles)


@main.route('/positions/<int:pos_id>/submit', methods=['POST'])
@login_required
@role_required('HM')
def submit_for_approval(pos_id):
    position = Position.query.get_or_404(pos_id)
    if position.hm_id != current_user.id:
        abort(403)
    position.status = 'pending_approval'
    db.session.commit()
    log_action(f'Position "{position.position_title.title}" submitted for approval.', 
               entity_type='Position', entity_id=pos_id)
    flash('Position submitted for approval.', 'success')
    return redirect(url_for('main.dashboard'))


@main.route('/positions/<int:pos_id>/approve', methods=['POST'])
@login_required
@role_required('SA')
def approve_position(pos_id):
    position = Position.query.get_or_404(pos_id)
    action = request.form.get('action')
    if action == 'approve':
        position.status = 'approved'
        flash('Position has been approved and is now active.', 'success')
        log_action(f'Position "{position.position_title.title}" approved.', 
                   entity_type='Position', entity_id=pos_id)
    elif action == 'reject':
        position.status = 'rejected'
        flash('Position has been rejected.', 'warning')
        log_action(f'Position "{position.position_title.title}" rejected.', 
                   entity_type='Position', entity_id=pos_id)
    db.session.commit()
    return redirect(url_for('main.dashboard'))


# --- Candidate Management (Recruiter & HM) ---

@main.route('/positions/<int:pos_id>/candidates')
@login_required
def candidate_list(pos_id):
    position = Position.query.get_or_404(pos_id)
    candidates = position.candidates.order_by(Candidate.created_at.desc()).all()
    return render_template('candidate_list.html', position=position, candidates=candidates)


# UPDATE upload_cv route to use organized file storage:
@main.route('/positions/<int:pos_id>/upload_cv', methods=['GET', 'POST'])
@login_required
@role_required('Recruiter')
def upload_cv(pos_id):
    position = Position.query.get_or_404(pos_id)
    if request.method == 'POST':
        cv_file = request.files.get('cv_file')
        if not cv_file or cv_file.filename == '':
            flash('No file selected.', 'danger')
            return redirect(request.url)

        # Validate file extension
        if not cv_file.filename.lower().endswith(('.docx', '.pdf')):
            flash('Invalid file type. Please upload .docx or .pdf files only.', 'danger')
            return redirect(request.url)

        try:
            # Create candidate first to get ID
            candidate = Candidate(
                position_id=pos_id,
                status='applied'
            )
            db.session.add(candidate)
            db.session.flush()  # Get candidate.id
            
            # Use FileManager for organized storage
            from .utils.file_manager import FileManager
            cv_path = FileManager.save_file(cv_file, 'cv', position_id=pos_id, candidate_id=candidate.id)
            
            if not cv_path:
                raise ValueError("Failed to save CV file")
            
            # Get full path for parsing
            base_path = current_app.config.get('UPLOAD_FOLDER', 'recruitflow/static/uploads')
            full_cv_path = os.path.join(base_path, cv_path)
            
            # Check if JD file exists
            if not position.jd_file_path:
                jd_text = ""
                flash('Warning: Job Description file not found. CV will be processed without similarity matching.', 'warning')
            else:
                jd_full_path = os.path.join(base_path, position.jd_file_path)
                if os.path.exists(jd_full_path):
                    jd_text = extract_text_from_docx(jd_full_path)
                else:
                    jd_text = ""
                    flash('Warning: Job Description file not found.', 'warning')
            
            # Parse CV
            cv_data = parse_cv(full_cv_path, jd_text)

            # Update candidate with parsed data
            candidate.cv_file_path = cv_path
            candidate.name = cv_data.get('name', 'Name not detected')
            candidate.location = cv_data.get('location')
            candidate.phone = cv_data.get('phone')
            candidate.email = cv_data.get('email')
            candidate.linkedin = cv_data.get('linkedin')
            candidate.experience = cv_data.get('experience')
            candidate.key_skills = cv_data.get('key_skills')
            candidate.education = cv_data.get('education')
            candidate.employment_history = cv_data.get('employment_history')
            candidate.similarity_score = cv_data.get('similarity_score')
            
            # Create pipeline metrics entry
            from .models import PipelineMetrics
            metric = PipelineMetrics(
                candidate_id=candidate.id,
                stage='cv_uploaded',
                entered_at=datetime.utcnow()
            )
            db.session.add(metric)
            
            db.session.commit()
            
            log_action(
                f'CV uploaded for candidate "{candidate.name}" to position "{position.position_title.title}".',
                entity_type='Candidate', entity_id=candidate.id)
            
            flash(
                f'CV processed successfully! Candidate {cv_data["name"]} added with match score of {cv_data["similarity_score"]:.2f}%.',
                'success')
                
        except FileNotFoundError as e:
            db.session.rollback()
            flash(f'File error: {str(e)}', 'danger')
            return redirect(request.url)
            
        except ValueError as e:
            db.session.rollback()
            flash(f'Validation error: {str(e)}', 'danger')
            return redirect(request.url)
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error processing CV: {str(e)}', 'danger')
            return redirect(request.url)

        return redirect(url_for('main.candidate_list', pos_id=pos_id))

    return render_template('upload_cv.html', position=position)


@main.route('/candidates/<int:cand_id>/review', methods=['POST'])
@login_required
@role_required('HM')
def hm_review(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    action = request.form.get('action')
    if action == 'accept':
        candidate.status = 'under_hm_review'
        flash('Candidate accepted for the next round.', 'success')
    else:
        candidate.status = 'rejected_by_hm'
        flash('Candidate has been rejected.', 'info')
    db.session.commit()
    log_action(f'HM reviewed candidate "{candidate.name}" with action: {action}.', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- Test Allocation & Updates (MISSING ROUTES - NOW ADDED) ---

@main.route('/candidates/<int:cand_id>/allocate_test', methods=['POST'])
@login_required
@role_required('Recruiter')
def allocate_test(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    candidate.status = 'test_allocated'
    db.session.commit()
    
    flash(f'Test allocated to {candidate.name}. Update status after completion.', 'success')
    log_action(f'Test allocated to candidate "{candidate.name}".', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


@main.route('/candidates/<int:cand_id>/update_test', methods=['POST'])
@login_required
@role_required('Recruiter')
def update_test(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    status = request.form.get('status')
    score = request.form.get('score')
    
    if status == 'passed':
        candidate.status = 'test_passed'
        if score:
            candidate.test_score = float(score)
        flash(f'{candidate.name} passed the test! Ready for interview.', 'success')
    elif status == 'failed':
        candidate.status = 'test_failed'
        if score:
            candidate.test_score = float(score)
        flash(f'{candidate.name} did not pass the test.', 'info')
    
    db.session.commit()
    log_action(f'Test status updated for candidate "{candidate.name}": {status}.', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- Interview & Feedback ---

@main.route('/candidates/<int:cand_id>/schedule_interview', methods=['POST'])
@login_required
@role_required('Recruiter')
def schedule_interview(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    schedule_date_str = request.form.get('date')
    
    # Convert string to date object
    from datetime import datetime
    try:
        schedule_date = datetime.strptime(schedule_date_str, '%Y-%m-%d').date()
    except ValueError:
        flash('Invalid date format', 'danger')
        return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))

    interview = Interview(
        candidate_id=cand_id, 
        schedule_date=schedule_date,
        schedule_time=request.form.get('time', '10:00 AM'),
        interview_mode='Video',
        status='scheduled'
    )
    candidate.status = 'interview'
    db.session.add(interview)
    db.session.commit()
    
    flash(f'Interview scheduled for {candidate.name} on {schedule_date.strftime("%d %b %Y")}', 'success')
    log_action(f'Interview scheduled for candidate "{candidate.name}".', 
               entity_type='Candidate', entity_id=cand_id)
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


@main.route('/interviews/<int:interview_id>/feedback', methods=['GET', 'POST'])
@login_required
@role_required('IP')
def provide_feedback(interview_id):
    interview = Interview.query.get_or_404(interview_id)
    if request.method == 'POST':
        rating = request.form.get('rating')
        comments = request.form.get('comments')

        feedback = InterviewFeedback(
            interview_id=interview_id,
            ip_user_id=current_user.id,
            rating=int(rating),
            comments=comments
        )
        db.session.add(feedback)
        interview.status = 'completed'
        db.session.commit()

        flash('Feedback submitted successfully.', 'success')
        log_action(f'Feedback submitted for interview {interview_id}.', 
                   entity_type='Interview', entity_id=interview_id)
        return redirect(url_for('main.dashboard'))

    return render_template('feedback_form.html', interview=interview)


@main.route('/candidates/<int:cand_id>/notes', methods=['POST'])
@login_required
@role_required('Recruiter', 'HM')
def add_note(cand_id):
    candidate = Candidate.query.get_or_404(cand_id)
    note_text = request.form.get('note_text')
    if not note_text:
        flash('Note cannot be empty.', 'warning')
    else:
        note = CandidateNote(
            candidate_id=cand_id,
            author_id=current_user.id,
            note=note_text
        )
        db.session.add(note)
        db.session.commit()
        flash('Note added successfully.', 'success')
    return redirect(url_for('main.candidate_list', pos_id=candidate.position_id))


# --- File Downloads & Miscellaneous ---

@main.route('/uploads/<filename>')
@login_required
def download_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)


@main.route('/silver_medalists')
@login_required
@role_required('HM', 'Recruiter')
def silver_medalists():
    candidates = Candidate.query.filter_by(is_silver=True).all()
    return render_template('silver_medalists.html', candidates=candidates)


# --- Reporting (ADDED) ---

@main.route('/reporting')
@login_required
@role_required('SA')
def reporting():
    """Reporting dashboard for SA"""
    # Position stats
    positions_by_status = db.session.query(
        Position.status,
        db.func.count(Position.id)
    ).group_by(Position.status).all()
    
    # Candidate stats
    candidates_by_status = db.session.query(
        Candidate.status,
        db.func.count(Candidate.id)
    ).group_by(Candidate.status).all()
    
    # Aggregate metrics
    open_positions = Position.query.filter(Position.status.in_(['approved', 'open'])).count()
    total_candidates = Candidate.query.count()
    candidates_in_interview = Candidate.query.filter_by(status='interview').count()
    
    avg_similarity = db.session.query(db.func.avg(Candidate.similarity_score)).scalar() or 0
    
    return render_template('reporting.html',
                          positions_by_status=positions_by_status,
                          candidates_by_status=candidates_by_status,
                          open_positions=open_positions,
                          total_candidates=total_candidates,
                          candidates_in_interview=candidates_in_interview,
                          avg_similarity=round(avg_similarity, 2))


# --- Audit Logs (ADDED) ---

@main.route('/audit_logs')
@login_required
@role_required('SA')
def audit_logs():
    """View audit logs"""
    from .models import AuditLog
    page = request.args.get('page', 1, type=int)
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=50)
    return render_template('admin/audit_log.html', logs=logs)


# --- Export Routes ---

@main.route('/export/positions')
@login_required
@role_required('SA', 'HM')
def export_positions():
    """Export positions to CSV"""
    import csv
    from io import StringIO
    from flask import Response
    
    # Get positions based on role
    if current_user.role.name == 'HM':
        positions = Position.query.filter_by(hm_id=current_user.id).all()
    else:
        positions = Position.query.all()
    
    # Create CSV
    si = StringIO()
    writer = csv.writer(si)
    
    # Write header
    writer.writerow([
        'ID', 'Title', 'Project', 'Openings', 'Status', 
        'Hiring Manager', 'Total Candidates', 'Created Date'
    ])
    
    # Write data
    for pos in positions:
        writer.writerow([
            pos.id,
            pos.position_title.title if pos.position_title else '',
            pos.project_name,
            pos.openings,
            pos.status,
            pos.hiring_manager.username if pos.hiring_manager else '',
            pos.candidates.count(),
            pos.created_at.strftime('%Y-%m-%d')
        ])
    
    # Create response
    output = si.getvalue()
    si.close()
    
    from datetime import datetime
    filename = f'positions_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    return Response(
        output,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename={filename}'}
    )


# --- Schedule Interviews Overview ---

@main.route('/schedule-interviews')
@login_required
@role_required('HM', 'Recruiter')
def schedule_interviews():
    """View all candidates ready for interview"""
    if current_user.role.name == 'HM':
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        candidates = Candidate.query.filter(
            Candidate.position_id.in_(position_ids),
            Candidate.status == 'test_passed'
        ).all()
    else:
        candidates = Candidate.query.filter_by(status='test_passed').all()
    
    return render_template('schedule_interviews.html', candidates=candidates)


# --- Onboarding Overview ---

@main.route('/onboarding-overview')
@login_required
@role_required('HM', 'Recruiter', 'SA')
def onboarding_overview():
    """View all candidates in onboarding"""
    from .models import OnboardingTask
    
    # Get candidates with joining dates
    if current_user.role.name == 'HM':
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        candidates = Candidate.query.filter(
            Candidate.position_id.in_(position_ids),
            Candidate.joining_date.isnot(None)
        ).all()
    else:
        candidates = Candidate.query.filter(
            Candidate.joining_date.isnot(None)
        ).all()
    
    # Get task counts for each candidate
    candidate_tasks = []
    for cand in candidates:
        tasks = OnboardingTask.query.filter_by(candidate_id=cand.id).all()
        completed = len([t for t in tasks if t.status == 'completed'])
        total = len(tasks)
        
        candidate_tasks.append({
            'candidate': cand,
            'total_tasks': total,
            'completed_tasks': completed,
            'completion_percentage': round((completed / total * 100) if total > 0 else 0, 1)
        })
    
    return render_template('onboarding_overview.html', candidate_tasks=candidate_tasks)

@main.route('/export/candidates')
@login_required
@role_required('SA', 'Recruiter', 'HM')
def export_candidates():
    """Export candidates to CSV"""
    import csv
    from io import StringIO
    from flask import Response
    
    # Get candidates based on role
    if current_user.role.name == 'HM':
        # HM can see candidates from their positions
        position_ids = [p.id for p in Position.query.filter_by(hm_id=current_user.id).all()]
        candidates = Candidate.query.filter(Candidate.position_id.in_(position_ids)).all()
    else:
        candidates = Candidate.query.all()
    
    # Create CSV
    si = StringIO()
    writer = csv.writer(si)
    
    # Write header
    writer.writerow([
        'ID', 'Name', 'Email', 'Phone', 'Location', 'Experience (Years)',
        'Key Skills', 'Education', 'Position', 'Similarity Score (%)',
        'Status', 'Test Score', 'Created Date'
    ])
    
    # Write data
    for cand in candidates:
        writer.writerow([
            cand.id,
            cand.name,
            cand.email,
            cand.phone,
            cand.location,
            cand.experience,
            cand.key_skills,
            cand.education,
            cand.position.position_title.title if cand.position and cand.position.position_title else '',
            round(cand.similarity_score, 2) if cand.similarity_score else 0,
            cand.status,
            cand.test_score if cand.test_score else '',
            cand.created_at.strftime('%Y-%m-%d')
        ])
    
    # Create response
    output = si.getvalue()
    si.close()
    
    from datetime import datetime
    filename = f'candidates_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    return Response(
        output,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename={filename}'}
    )