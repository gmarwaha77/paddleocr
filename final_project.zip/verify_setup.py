#!/usr/bin/env python
"""
verify_setup.py - Verify RecruitFlow Installation
Run this from project root: python verify_setup.py
"""
import os
import sys

def print_header(text):
    print("\n" + "="*60)
    print(f"  {text}")
    print("="*60)

def check_mark(condition):
    return "✅" if condition else "❌"

def verify_setup():
    print_header("🔍 RecruitFlow Setup Verification")
    
    issues = []
    warnings = []
    
    # 1. Check Python version
    print("\n📍 Checking Python version...")
    py_version = sys.version_info
    if py_version >= (3, 8):
        print(f"  {check_mark(True)} Python {py_version.major}.{py_version.minor}.{py_version.micro}")
    else:
        print(f"  {check_mark(False)} Python {py_version.major}.{py_version.minor}.{py_version.micro}")
        issues.append("Python 3.8+ required")
    
    # 2. Check project structure
    print("\n📍 Checking project structure...")
    required_files = [
        'recruitflow/__init__.py',
        'recruitflow/app.py',
        'recruitflow/models.py',
        'recruitflow/config.py',
        'recruitflow/main_routes.py',
        'recruitflow/salary_routes.py',
        'recruitflow/admin_routes.py',
        'recruitflow/cv_parser.py',
        'recruitflow/utils/__init__.py',
        'recruitflow/utils/helpers.py',
        'recruitflow/templates/base.html',
        'recruitflow/templates/login.html',
        'recruitflow/static/css/custom.css',
        'recruitflow/static/js/custom.js',
        'setup_dev.py',
        'run.py'
    ]
    
    for file_path in required_files:
        exists = os.path.exists(file_path)
        print(f"  {check_mark(exists)} {file_path}")
        if not exists:
            issues.append(f"Missing file: {file_path}")
    
    # 3. Check required directories
    print("\n📍 Checking directories...")
    required_dirs = [
        'recruitflow/static/uploads',
        'recruitflow/templates/admin',
        'recruitflow/templates/salary'
    ]
    
    for dir_path in required_dirs:
        exists = os.path.exists(dir_path)
        print(f"  {check_mark(exists)} {dir_path}")
        if not exists:
            warnings.append(f"Missing directory: {dir_path} (will be created)")
            try:
                os.makedirs(dir_path, exist_ok=True)
                print(f"     → Created: {dir_path}")
            except Exception as e:
                issues.append(f"Could not create {dir_path}: {e}")
    
    # 4. Check installed packages
    print("\n📍 Checking installed packages...")
    required_packages = [
        'flask',
        'flask_login',
        'flask_sqlalchemy',
        'flask_migrate',
        'werkzeug',
        'docx',
        'pdfplumber',
        'sklearn',
        'spacy'
    ]
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"  {check_mark(True)} {package}")
        except ImportError:
            print(f"  {check_mark(False)} {package}")
            issues.append(f"Missing package: {package}")
    
    # 5. Check spacy model
    print("\n📍 Checking spacy language model...")
    try:
        import spacy
        nlp = spacy.load("en_core_web_sm")
        print(f"  {check_mark(True)} en_core_web_sm")
    except:
        print(f"  {check_mark(False)} en_core_web_sm")
        issues.append("Spacy model not installed. Run: python -m spacy download en_core_web_sm")
    
    # 6. Check .env file
    print("\n📍 Checking configuration...")
    if os.path.exists('.env'):
        print(f"  {check_mark(True)} .env file exists")
    else:
        print(f"  {check_mark(False)} .env file missing")
        warnings.append("No .env file - using defaults")
    
    # 7. Check database
    print("\n📍 Checking database...")
    db_path = 'recruitflow/recruitflow_dev.db'
    if os.path.exists(db_path):
        print(f"  {check_mark(True)} Database initialized: {db_path}")
    else:
        print(f"  {check_mark(False)} Database not initialized")
        warnings.append("Run: python setup_dev.py to create database")
    
    # 8. Try importing recruitflow
    print("\n📍 Testing imports...")
    try:
        sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
        from recruitflow import app
        print(f"  {check_mark(True)} recruitflow.app imports successfully")
    except Exception as e:
        print(f"  {check_mark(False)} recruitflow.app import failed")
        issues.append(f"Import error: {e}")
    
    # Summary
    print_header("📊 Verification Summary")
    
    if not issues and not warnings:
        print("\n🎉 Perfect! Everything is set up correctly!")
        print("\n📝 Next steps:")
        print("   1. python setup_dev.py  (if database not initialized)")
        print("   2. python run.py")
        print("   3. Open http://localhost:5000")
        print("   4. Login: admin / Admin@123")
    else:
        if issues:
            print(f"\n❌ Found {len(issues)} critical issue(s):")
            for i, issue in enumerate(issues, 1):
                print(f"   {i}. {issue}")
        
        if warnings:
            print(f"\n⚠️  Found {len(warnings)} warning(s):")
            for i, warning in enumerate(warnings, 1):
                print(f"   {i}. {warning}")
        
        print("\n📝 Recommended actions:")
        if any('Missing package' in i for i in issues):
            print("   → pip install -r requirements.txt")
        if any('spacy model' in i for i in issues):
            print("   → python -m spacy download en_core_web_sm")
        if any('Missing file' in i for i in issues):
            print("   → Check project structure against SETUP_GUIDE.md")
        if any('database' in w.lower() for w in warnings):
            print("   → python setup_dev.py")
    
    print("\n" + "="*60 + "\n")

if __name__ == '__main__':
    verify_setup()