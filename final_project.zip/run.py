#!/usr/bin/env python
"""
run.py - RecruitFlow Application Launcher
Place this file in: recruitflow_project/ (project root)
Run with: python run.py
"""
import os
import sys

# Add project root to Python path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from recruitflow.app import app

if __name__ == '__main__':
    # Create uploads folder if it doesn't exist
    upload_folder = app.config.get('UPLOAD_FOLDER')
    if upload_folder and not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
        print(f"✅ Created upload folder: {upload_folder}")
    
    print("\n" + "="*60)
    print("🚀 Starting RecruitFlow Application...")
    print("="*60)
    print(f"Environment: {os.environ.get('ENVIRONMENT', 'development')}")
    print(f"Debug Mode: {app.config.get('DEBUG', False)}")
    print(f"Database: {app.config.get('SQLALCHEMY_DATABASE_URI', 'Not configured')}")
    print("="*60)
    print("\n📝 Default Login Credentials:")
    print("   Username: admin")
    print("   Password: Admin@123")
    print("\n🌐 Access the application at:")
    print("   http://localhost:5000")
    print("   http://127.0.0.1:5000")
    print("\n⚠️  Press CTRL+C to stop the server")
    print("="*60 + "\n")
    
    # Run the Flask application
    app.run(
        debug=True,           # Enable debug mode for development
        host='0.0.0.0',       # Accept connections from any IP
        port=5000,            # Port 5000
        use_reloader=True,    # Auto-reload on code changes
        threaded=True         # Handle multiple requests
    )