import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { delay } from 'rxjs/operators';

export interface Case {
  id: string;
  departmentName: string;
  vendorName: string;
  categoryName: string;
  dateCreated: Date;
  budget: number;
  status: string;
  department: string;
  section: string;
  category: string;
  mediaMix: string;
  caseType: string;
  campaignName: string;
  fundType: string;
  totalBudget: string;
  freeText: string;
  mediaDetails: MediaDetail[];
}

export interface MediaDetail {
  type: string;
  amount: number;
}

export interface CaseFormData {
  department: string;
  section: string;
  category: string;
  caseType: string;
  mediaMix: string[];
  campaignName: string;
  vendorName: string;
  fundType: string;
  totalBudget: number;
  freeText: string;
}

@Injectable({
  providedIn: 'root'
})
export class CaseService {
  private casesSubject = new BehaviorSubject<Case[]>([]);
  public cases$ = this.casesSubject.asObservable();

  private mockCases: Case[] = [
    {
      id: 'RBI-00001',
      departmentName: 'Department of Communication (DOC)',
      vendorName: 'R K Swami',
      categoryName: 'Advertisement',
      dateCreated: new Date('2024-11-28'),
      budget: 12.6,
      status: 'Pending Review',
      department: 'Department of Communication (DOC)',
      section: 'Section Name',
      category: 'Advertisement',
      mediaMix: 'Television, Radio, Google',
      caseType: 'Public Awareness Campaigns (PAC)',
      campaignName: 'Fraud Impersonation',
      fundType: 'DEA fund',
      totalBudget: '12,60,000.00',
      freeText: 'Lorem ipsum dolor sit amet consectetur. Tempor diam consequat eget phasellus gravida. Maecenas diam mi nisl felis arcu. Nullam sit nec tempus amet sed vitae tellus. Nisl phasellus nec viverra mi.',
      mediaDetails: [
        { type: 'Television', amount: 5.20 },
        { type: 'OOH', amount: 3.24 },
        { type: 'Google', amount: 4.16 }
      ]
    },
    {
      id: 'RBI-00002',
      departmentName: 'Department of Communication (DOC)',
      vendorName: 'R K Swami',
      categoryName: 'Advertisement',
      dateCreated: new Date('2024-11-28'),
      budget: 12.6,
      status: 'Draft',
      department: 'Department of Communication (DOC)',
      section: 'Section Name',
      category: 'Advertisement',
      mediaMix: 'Television, Radio',
      caseType: 'Public Awareness Campaigns (PAC)',
      campaignName: 'Digital Banking Awareness',
      fundType: 'DEA fund',
      totalBudget: '8,50,000.00',
      freeText: 'Campaign focused on promoting digital banking services and security awareness among rural populations.',
      mediaDetails: [
        { type: 'Television', amount: 5.20 },
        { type: 'Radio', amount: 2.50 }
      ]
    },
    {
      id: 'RBI-00003',
      departmentName: 'Department of Communication (DOC)',
      vendorName: 'R K Swami',
      categoryName: 'Advertisement',
      dateCreated: new Date('2024-11-28'),
      budget: 12.6,
      status: 'Rejected by checker',
      department: 'Department of Communication (DOC)',
      section: 'Section Name',
      category: 'Advertisement',
      mediaMix: 'Google, Print',
      caseType: 'Public Awareness Campaigns (PAC)',
      campaignName: 'Financial Literacy',
      fundType: 'DEA fund',
      totalBudget: '6,00,000.00',
      freeText: 'Educational campaign to improve financial literacy and awareness about banking services.',
      mediaDetails: [
        { type: 'Google', amount: 4.16 },
        { type: 'Print', amount: 1.80 }
      ]
    },
    {
      id: 'RBI-00004',
      departmentName: 'Department of Communication (DOC)',
      vendorName: 'R K Swami',
      categoryName: 'Advertisement',
      dateCreated: new Date('2024-11-28'),
      budget: 12.6,
      status: 'Awaiting Estimation',
      department: 'Department of Communication (DOC)',
      section: 'Section Name',
      category: 'Advertisement',
      mediaMix: 'Television, OOH',
      caseType: 'Public Awareness Campaigns (PAC)',
      campaignName: 'Cyber Security Awareness',
      fundType: 'DEA fund',
      totalBudget: '9,75,000.00',
      freeText: 'Campaign to educate public about cyber security threats and safe banking practices.',
      mediaDetails: [
        { type: 'Television', amount: 5.20 },
        { type: 'OOH', amount: 3.24 }
      ]
    }
  ];

  constructor() {
    this.casesSubject.next(this.mockCases);
  }

  // Get all cases
  getCases(): Observable<Case[]> {
    return of(this.mockCases).pipe(delay(500)); // Simulate API delay
  }

  // Get case by ID
  getCaseById(id: string): Observable<Case | undefined> {
    const case_ = this.mockCases.find(c => c.id === id);
    return of(case_).pipe(delay(300));
  }

  // Create new case
  createCase(caseData: CaseFormData): Observable<Case> {
    const newCase: Case = {
      id: this.generateCaseId(),
      departmentName: this.getDepartmentDisplayName(caseData.department),
      vendorName: this.getVendorDisplayName(caseData.vendorName),
      categoryName: this.getCategoryDisplayName(caseData.category),
      dateCreated: new Date(),
      budget: caseData.totalBudget / 100000, // Convert to crores
      status: 'Draft',
      department: this.getDepartmentDisplayName(caseData.department),
      section: this.getSectionDisplayName(caseData.section),
      category: this.getCategoryDisplayName(caseData.category),
      mediaMix: caseData.mediaMix.join(', '),
      caseType: this.getCaseTypeDisplayName(caseData.caseType),
      campaignName: caseData.campaignName,
      fundType: this.getFundTypeDisplayName(caseData.fundType),
      totalBudget: caseData.totalBudget.toLocaleString('en-IN'),
      freeText: caseData.freeText,
      mediaDetails: this.generateMediaDetails(caseData.mediaMix)
    };

    this.mockCases.push(newCase);
    this.casesSubject.next(this.mockCases);
    
    return of(newCase).pipe(delay(800));
  }

  // Update case
  updateCase(id: string, caseData: Partial<Case>): Observable<Case | null> {
    const index = this.mockCases.findIndex(c => c.id === id);
    if (index !== -1) {
      this.mockCases[index] = { ...this.mockCases[index], ...caseData };
      this.casesSubject.next(this.mockCases);
      return of(this.mockCases[index]).pipe(delay(500));
    }
    return of(null);
  }

  // Update case status
  updateCaseStatus(id: string, status: string): Observable<Case | null> {
    return this.updateCase(id, { status });
  }

  // Delete case
  deleteCase(id: string): Observable<boolean> {
    const index = this.mockCases.findIndex(c => c.id === id);
    if (index !== -1) {
      this.mockCases.splice(index, 1);
      this.casesSubject.next(this.mockCases);
      return of(true).pipe(delay(300));
    }
    return of(false);
  }

  // Helper methods for display names
  private getDepartmentDisplayName(value: string): string {
    const departments: { [key: string]: string } = {
      'doc': 'Department of Communication (DOC)',
      'dbo': 'Department of Banking Operations',
      'dor': 'Department of Regulation'
    };
    return departments[value] || value;
  }

  private getSectionDisplayName(value: string): string {
    const sections: { [key: string]: string } = {
      'section1': 'Section Name',
      'media_relations': 'Media Relations',
      'public_affairs': 'Public Affairs'
    };
    return sections[value] || value;
  }

  private getCategoryDisplayName(value: string): string {
    const categories: { [key: string]: string } = {
      'advertisement': 'Advertisement',
      'public_notice': 'Public Notice',
      'awareness_campaign': 'Awareness Campaign'
    };
    return categories[value] || value;
  }

  private getCaseTypeDisplayName(value: string): string {
    const caseTypes: { [key: string]: string } = {
      'pac': 'Public Awareness Campaigns (PAC)',
      'media_outreach': 'Media Outreach',
      'digital_campaign': 'Digital Campaign'
    };
    return caseTypes[value] || value;
  }

  private getVendorDisplayName(value: string): string {
    const vendors: { [key: string]: string } = {
      'agency1': 'Media Agency Name 1',
      'rk_swami': 'R K Swami',
      'creative_solutions': 'Creative Solutions Ltd'
    };
    return vendors[value] || value;
  }

  private getFundTypeDisplayName(value: string): string {
    const fundTypes: { [key: string]: string } = {
      'dea_fund': 'DEA fund',
      'marketing_fund': 'Marketing Fund',
      'special_fund': 'Special Fund'
    };
    return fundTypes[value] || value;
  }

  private generateMediaDetails(mediaMix: string[]): MediaDetail[] {
    const mediaAmounts: { [key: string]: number } = {
      'Television': 5.20,
      'OOH': 3.24,
      'Google': 4.16,
      'Radio': 2.50,
      'Print': 1.80
    };

    return mediaMix.map(media => ({
      type: media,
      amount: mediaAmounts[media] || 0
    }));
  }

  private generateCaseId(): string {
    const count = this.mockCases.length + 1;
    return `RBI-${count.toString().padStart(5, '0')}`;
  }
}
