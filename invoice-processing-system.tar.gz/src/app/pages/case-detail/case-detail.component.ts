import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location, CommonModule } from '@angular/common';
import { Tabs, TabPanels, TabPanel } from 'primeng/tabs';
import { CaseService, Case, MediaDetail } from '../../services/case.service';

@Component({
  selector: 'app-case-detail',
  imports: [
    CommonModule,
    Tabs,
    TabPanels,
    TabPanel
  ],
  templateUrl: './case-detail.component.html',
  styleUrl: './case-detail.component.scss'
})
export class CaseDetailComponent implements OnInit {
  caseData: Case | null = null;
  loading = true;
  showApprovalActions = true;
  showSuccessMessage = false;
  successMessage = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private caseService: CaseService
  ) {}

  ngOnInit() {
    // Get case ID from route params
    const caseId = this.route.snapshot.paramMap.get('id');
    if (caseId) {
      this.loadCaseData(caseId);
    }
  }

  loadCaseData(caseId: string) {
    this.loading = true;
    this.caseService.getCaseById(caseId).subscribe({
      next: (caseData) => {
        if (caseData) {
          this.caseData = caseData;
          this.showApprovalActions = caseData.status === 'Pending Review';
        } else {
          // Case not found, redirect to dashboard
          this.router.navigate(['/dashboard']);
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading case:', error);
        this.loading = false;
        this.router.navigate(['/dashboard']);
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'Pending Review':
        return 'status-pending';
      case 'Draft':
        return 'status-draft';
      case 'Rejected by checker':
        return 'status-rejected';
      case 'Awaiting Estimation':
      case 'Awaiting estimations':
        return 'status-awaiting';
      case 'Approved':
        return 'status-approved';
      default:
        return 'status-default';
    }
  }

  getStatusIcon(status: string): string {
    switch (status) {
      case 'Pending Review':
        return 'pi pi-clock';
      case 'Draft':
        return 'pi pi-file-edit';
      case 'Rejected by checker':
        return 'pi pi-times-circle';
      case 'Awaiting Estimation':
      case 'Awaiting estimations':
        return 'pi pi-hourglass';
      case 'Approved':
        return 'pi pi-check-circle';
      default:
        return 'pi pi-info-circle';
    }
  }

  getMediaIcon(media: string): string {
    switch (media) {
      case 'Television':
        return 'pi pi-video';
      case 'OOH':
        return 'pi pi-map-marker';
      case 'Google':
        return 'pi pi-google';
      case 'Radio':
        return 'pi pi-volume-up';
      case 'Print':
        return 'pi pi-file';
      default:
        return 'pi pi-circle';
    }
  }

  goBack() {
    this.location.back();
  }

  editCase() {
    if (this.caseData) {
      this.router.navigate(['/cases/edit', this.caseData.id]);
    }
  }

  deleteCase() {
    if (this.caseData) {
      console.log('Delete case:', this.caseData.id);
    }
  }

  rejectCase() {
    if (this.caseData) {
      this.caseService.updateCaseStatus(this.caseData.id, 'Rejected by checker').subscribe({
        next: (updatedCase) => {
          if (updatedCase) {
            this.caseData = updatedCase;
            this.showApprovalActions = false;
            this.showSuccessMessage = true;
            this.successMessage = 'Case has been rejected.';
            this.hideSuccessMessageAfterDelay();
          }
        },
        error: (error) => {
          console.error('Error rejecting case:', error);
        }
      });
    }
  }

  sendBackCase() {
    if (this.caseData) {
      this.caseService.updateCaseStatus(this.caseData.id, 'Draft').subscribe({
        next: (updatedCase) => {
          if (updatedCase) {
            this.caseData = updatedCase;
            this.showApprovalActions = false;
            this.showSuccessMessage = true;
            this.successMessage = 'Case has been sent back for revision.';
            this.hideSuccessMessageAfterDelay();
          }
        },
        error: (error) => {
          console.error('Error sending back case:', error);
        }
      });
    }
  }

  approveCase() {
    if (this.caseData) {
      this.caseService.updateCaseStatus(this.caseData.id, 'Awaiting estimations').subscribe({
        next: (updatedCase) => {
          if (updatedCase) {
            this.caseData = updatedCase;
            this.showApprovalActions = false;
            this.showSuccessMessage = true;
            this.successMessage = 'Case Approved. Case has been successfully approved and sent to media agency.';
            this.hideSuccessMessageAfterDelay();
          }
        },
        error: (error) => {
          console.error('Error approving case:', error);
        }
      });
    }
  }

  closeSuccessMessage() {
    this.showSuccessMessage = false;
  }

  private hideSuccessMessageAfterDelay() {
    setTimeout(() => {
      this.showSuccessMessage = false;
    }, 5000);
  }
}
