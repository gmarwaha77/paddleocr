import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Location, CommonModule } from '@angular/common';
import { Select } from 'primeng/select';
import { MultiSelect } from 'primeng/multiselect';
import { InputText } from 'primeng/inputtext';
import { Textarea } from 'primeng/textarea';
import { InputNumber } from 'primeng/inputnumber';
import { Tabs, TabPanels, TabPanel } from 'primeng/tabs';
import { Dialog } from 'primeng/dialog';

interface DropdownOption {
  name: string;
  value: string;
}

@Component({
  selector: 'app-case-create',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    Select,
    MultiSelect,
    InputText,
    Textarea,
    InputNumber,
    Tabs,
    TabPanels,
    TabPanel,
    Dialog
  ],
  templateUrl: './case-create.component.html',
  styleUrl: './case-create.component.scss'
})
export class CaseCreateComponent implements OnInit {
  caseForm!: FormGroup;
  showConfirmDialog = false;
  selectedMediaMix: string[] = [];

  departments: DropdownOption[] = [
    { name: 'Department of Communication (DOC)', value: 'doc' },
    { name: 'Department of Banking Operations', value: 'dbo' },
    { name: 'Department of Regulation', value: 'dor' }
  ];

  sections: DropdownOption[] = [
    { name: 'Section Name', value: 'section1' },
    { name: 'Media Relations', value: 'media_relations' },
    { name: 'Public Affairs', value: 'public_affairs' }
  ];

  categories: DropdownOption[] = [
    { name: 'Advertisement', value: 'advertisement' },
    { name: 'Public Notice', value: 'public_notice' },
    { name: 'Awareness Campaign', value: 'awareness_campaign' }
  ];

  caseTypes: DropdownOption[] = [
    { name: 'Public Awareness Campaigns (PAC)', value: 'pac' },
    { name: 'Media Outreach', value: 'media_outreach' },
    { name: 'Digital Campaign', value: 'digital_campaign' }
  ];

  mediaMixOptions: DropdownOption[] = [
    { name: 'Television', value: 'Television' },
    { name: 'OOH', value: 'OOH' },
    { name: 'Google', value: 'Google' },
    { name: 'Radio', value: 'Radio' },
    { name: 'Print', value: 'Print' }
  ];

  vendors: DropdownOption[] = [
    { name: 'Media Agency Name 1', value: 'agency1' },
    { name: 'R K Swami', value: 'rk_swami' },
    { name: 'Creative Solutions Ltd', value: 'creative_solutions' }
  ];

  fundTypes: DropdownOption[] = [
    { name: 'DEA fund', value: 'dea_fund' },
    { name: 'Marketing Fund', value: 'marketing_fund' },
    { name: 'Special Fund', value: 'special_fund' }
  ];

  mediaAmounts: { [key: string]: number } = {
    'Television': 5.20,
    'OOH': 3.24,
    'Google': 4.16,
    'Radio': 2.50,
    'Print': 1.80
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private location: Location
  ) {}

  ngOnInit() {
    this.initializeForm();
  }

  initializeForm() {
    this.caseForm = this.fb.group({
      department: ['', Validators.required],
      section: ['', Validators.required],
      category: ['', Validators.required],
      caseType: ['', Validators.required],
      mediaMix: [[], Validators.required],
      campaignName: ['', Validators.required],
      vendorName: ['', Validators.required],
      fundType: ['', Validators.required],
      totalBudget: [null, [Validators.required, Validators.min(0)]],
      freeText: ['']
    });
  }

  onMediaMixChange(event: any) {
    this.selectedMediaMix = event.value || [];
  }

  getMediaIcon(media: string): string {
    switch (media) {
      case 'Television':
        return 'pi pi-video';
      case 'OOH':
        return 'pi pi-map-marker';
      case 'Google':
        return 'pi pi-google';
      case 'Radio':
        return 'pi pi-volume-up';
      case 'Print':
        return 'pi pi-file';
      default:
        return 'pi pi-circle';
    }
  }

  getMediaAmount(media: string): number {
    return this.mediaAmounts[media] || 0;
  }

  goBack() {
    this.location.back();
  }

  saveAsDraft() {
    if (this.caseForm.valid) {
      // Save as draft logic
      console.log('Saving as draft:', this.caseForm.value);
      this.router.navigate(['/dashboard']);
    } else {
      this.markFormGroupTouched();
    }
  }

  submitCase() {
    if (this.caseForm.valid) {
      this.showConfirmDialog = true;
    } else {
      this.markFormGroupTouched();
    }
  }

  confirmSubmit() {
    this.showConfirmDialog = false;
    // Submit case logic
    console.log('Submitting case:', this.caseForm.value);
    this.router.navigate(['/dashboard']);
  }

  private markFormGroupTouched() {
    Object.keys(this.caseForm.controls).forEach(key => {
      const control = this.caseForm.get(key);
      control?.markAsTouched();
    });
  }
}
