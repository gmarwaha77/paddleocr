import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Table, TableModule } from 'primeng/table';
import { Tag, TagModule } from 'primeng/tag';
import { Button, ButtonModule } from 'primeng/button';
import { CaseService, Case, MediaDetail } from '../../services/case.service';
import { RippleModule } from 'primeng/ripple';

@Component({
  selector: 'app-case-list',
  imports: [CommonModule, TableModule, ButtonModule, TagModule, RippleModule],
  templateUrl: './case-list.component.html',
  styleUrl: './case-list.component.scss'
})
export class CaseListComponent implements OnInit {
  cases: Case[] = [];
  expandedRows: any = {};
  showSuccessMessage = false;
  successMessage = '';
  loading = true;

  constructor(
    private router: Router,
    private caseService: CaseService
  ) {}

  ngOnInit() {
    this.loadCases();
    // Subscribe to case updates
    this.caseService.cases$.subscribe(cases => {
      this.cases = cases;
    });
  }

  loadCases() {
    this.loading = true;
    this.caseService.getCases().subscribe({
      next: (cases) => {
        this.cases = cases;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading cases:', error);
        this.loading = false;
      }
    });
  }

  getStatusSeverity(status: string): string {
    switch (status) {
      case 'Pending Review':
        return 'info';
      case 'Draft':
        return 'secondary';
      case 'Rejected by checker':
        return 'danger';
      case 'Awaiting Estimation':
        return 'warning';
      case 'Approved':
        return 'success';
      default:
        return 'secondary';
    }
  }

  getStatusIcon(status: string): string {
    switch (status) {
      case 'Pending Review':
        return 'pi pi-clock';
      case 'Draft':
        return 'pi pi-file-edit';
      case 'Rejected by checker':
        return 'pi pi-times-circle';
      case 'Awaiting Estimation':
        return 'pi pi-hourglass';
      case 'Approved':
        return 'pi pi-check-circle';
      default:
        return 'pi pi-info-circle';
    }
  }

  viewCase(caseId: string) {
    this.router.navigate(['/cases', caseId]);
  }

  showSuccess(message: string) {
    this.successMessage = message;
    this.showSuccessMessage = true;
    setTimeout(() => {
      this.showSuccessMessage = false;
    }, 5000);
  }

  closeSuccessMessage() {
    this.showSuccessMessage = false;
  }

  viewCaseDetail(caseId: string) {
    this.router.navigate(['/cases', caseId]);
  }

  formatSerialNumber(num: number): string {
    return String(num).padStart(2, '0');
  }
}