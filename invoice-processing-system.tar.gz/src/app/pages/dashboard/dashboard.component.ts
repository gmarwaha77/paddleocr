import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CaseListComponent } from '../case-list/case-list.component';
import { CaseService, Case } from '../../services/case.service';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, CaseListComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent implements OnInit {
  cases: Case[] = [];
  loading = true;

  constructor(
    private router: Router,
    private caseService: CaseService
  ) {}

  ngOnInit() {
    this.loadCases();
  }

  loadCases() {
    this.loading = true;
    this.caseService.getCases().subscribe({
      next: (cases) => {
        this.cases = cases;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading cases:', error);
        this.loading = false;
      }
    });
  }

  createCase() {
    this.router.navigate(['/cases/create']);
  }

  get hasCases(): boolean {
    return this.cases.length > 0;
  }
}
